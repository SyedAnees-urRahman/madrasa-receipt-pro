import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../core/theme/app_colors.dart';
import '../features/auth/login_screen.dart';
import '../features/auth/splash_screen.dart';
import '../features/audit/audit_screen.dart';
import '../features/backup/backup_screen.dart';
import '../features/books/books_screen.dart';
import '../features/dashboard/dashboard_screen.dart';
import '../features/donors/donor_list_screen.dart';
import '../features/expenses/expense_form_screen.dart';
import '../features/expenses/expense_list_screen.dart';
import '../features/funds/fund_list_screen.dart';
import '../features/reconciliation/reconciliation_screen.dart';
import '../features/receipts/receipt_detail_screen.dart';
import '../features/receipts/receipt_register_screen.dart';
import '../features/receipts/receipt_wizard_screen.dart';
import '../features/receipts/verification_queue_screen.dart';
import '../features/reports/reports_screen.dart';
import '../features/settings/institution_profile_screen.dart';
import '../features/settings/settings_screen.dart';
import '../features/setup/setup_wizard_screen.dart';
import '../features/staff/staff_screen.dart';
import '../features/sync_center/sync_center_screen.dart';

/// Bottom navigation: Home | Receipts | (New Receipt) | Reports | Settings.
/// The central action is prominent, as required.
class ScaffoldWithNavBar extends StatelessWidget {
  const ScaffoldWithNavBar({super.key, required this.navigationShell});
  final StatefulNavigationShell navigationShell;

  void _goBranch(int index) {
    navigationShell.goBranch(
      index,
      initialLocation: index == navigationShell.currentIndex,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: navigationShell,
      bottomNavigationBar: BottomAppBar(
        shape: const CircularNotchedRectangle(),
        notchMargin: 8,
        color: Colors.white,
        elevation: 8,
        child: SizedBox(
          height: 64,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _NavItem(
                icon: Icons.home_outlined,
                activeIcon: Icons.home,
                label: 'ہوم',
                selected: navigationShell.currentIndex == 0,
                onTap: () => _goBranch(0),
              ),
              _NavItem(
                icon: Icons.receipt_long_outlined,
                activeIcon: Icons.receipt_long,
                label: 'رسیدیں',
                selected: navigationShell.currentIndex == 1,
                onTap: () => _goBranch(1),
              ),
              const SizedBox(width: 64), // notch space
              _NavItem(
                icon: Icons.bar_chart_outlined,
                activeIcon: Icons.bar_chart,
                label: 'رپورٹس',
                selected: navigationShell.currentIndex == 3,
                onTap: () => _goBranch(3),
              ),
              _NavItem(
                icon: Icons.settings_outlined,
                activeIcon: Icons.settings,
                label: 'ترتیبات',
                selected: navigationShell.currentIndex == 4,
                onTap: () => _goBranch(4),
              ),
            ],
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: Builder(builder: (context) {
        final bg = Theme.of(context).scaffoldBackgroundColor;
        final isClay = bg.value == const Color(0xFF7FB3DE).value;
        final isNeu = bg.value == const Color(0xFFE4EAF2).value;
        final fabColor = isClay
            ? const Color(0xFF5B7FE8)
            : isNeu
                ? const Color(0xFF3B82F6)
                : AppColors.emerald700;
        return Semantics(
          button: true,
          label: 'نئی رسید',
          child: FloatingActionButton(
            backgroundColor: fabColor,
            foregroundColor: Colors.white,
            shape: const CircleBorder(
              side: BorderSide(color: AppColors.gold500, width: 2),
            ),
            onPressed: () => _goBranch(2),
            child: const Icon(Icons.add, size: 28),
          ),
        );
      }),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.icon,
    required this.activeIcon,
    required this.label,
    required this.selected,
    required this.onTap,
  });
  final IconData icon;
  final IconData activeIcon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = selected ? AppColors.emerald700 : AppColors.ink500;
    return Semantics(
      button: true,
      selected: selected,
      label: label,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(selected ? activeIcon : icon, color: color, size: 26),
              Text(label,
                  style: TextStyle(
                      color: color,
                      fontSize: 11,
                      fontWeight:
                          selected ? FontWeight.w700 : FontWeight.normal)),
            ],
          ),
        ),
      ),
    );
  }
}

final appRouter = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(path: '/', builder: (_, __) => const SplashScreen()),
    GoRoute(path: '/setup', builder: (_, __) => const SetupWizardScreen()),
    GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),
    StatefulShellRoute.indexedStack(
      builder: (_, __, navigationShell) =>
          ScaffoldWithNavBar(navigationShell: navigationShell),
      branches: [
        StatefulShellBranch(routes: [
          GoRoute(path: '/home', builder: (_, __) => const DashboardScreen()),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(
              path: '/receipts',
              builder: (_, __) => const ReceiptRegisterScreen(),
              routes: [
                GoRoute(
                  path: ':id',
                  builder: (_, state) => ReceiptDetailScreen(
                      receiptId: state.pathParameters['id']!),
                ),
              ]),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(
              path: '/receipt/new',
              builder: (_, __) => const ReceiptWizardScreen()),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(path: '/reports', builder: (_, __) => const ReportsScreen()),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(
              path: '/settings', builder: (_, __) => const SettingsScreen()),
        ]),
      ],
    ),
    // Menu destinations (outside the bottom bar).
    GoRoute(path: '/verify', builder: (_, __) => const VerificationQueueScreen()),
    GoRoute(path: '/donors', builder: (_, __) => const DonorListScreen()),
    GoRoute(path: '/funds', builder: (_, __) => const FundListScreen()),
    GoRoute(path: '/expenses', builder: (_, __) => const ExpenseListScreen()),
    GoRoute(
        path: '/expenses/new',
        builder: (_, __) => const ExpenseFormScreen()),
    GoRoute(path: '/books', builder: (_, __) => const BooksScreen()),
    GoRoute(
        path: '/reconciliation',
        builder: (_, __) => const ReconciliationScreen()),
    GoRoute(path: '/audit', builder: (_, __) => const AuditScreen()),
    GoRoute(path: '/sync', builder: (_, __) => const SyncCenterScreen()),
    GoRoute(path: '/staff', builder: (_, __) => const StaffScreen()),
    GoRoute(path: '/backup', builder: (_, __) => const BackupScreen()),
    GoRoute(
        path: '/institution',
        builder: (_, __) => const InstitutionProfileScreen()),
  ],
);
