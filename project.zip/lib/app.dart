import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'app_providers.dart';
import 'core/theme/app_themes.dart';
import 'navigation.dart';

/// Root widget. Urdu is the default locale → the whole app is RTL-first.
class MadrasaApp extends ConsumerWidget {
  const MadrasaApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final locale = ref.watch(localeProvider);
    final themeMode = ref.watch(themeModeProvider);
    return MaterialApp.router(
      title: 'Madrasa Receipt Pro',
      debugShowCheckedModeBanner: false,
      theme: themeMode == MrpThemeMode.neumorphic
          ? NeumorphicTheme.theme
          : ClayTheme.theme,
      locale: locale,
      supportedLocales: const [Locale('ur'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      // Generated l10n (flutter gen-l10n) is wired here once the SDK
      // finishes installing; until then the delegates above cover
      // Material strings and all app copy resolves via AppStrings.
      routerConfig: appRouter,
      builder: (context, child) {
        // Respect the OS text-scale setting but keep it sane for
        // dense financial tables.
        final mq = MediaQuery.of(context);
        return MediaQuery(
          data: mq.copyWith(
            textScaler: TextScaler.linear(
              mq.textScaler.scale(1.0).clamp(0.85, 1.3),
            ),
          ),
          child: child ?? const SizedBox.shrink(),
        );
      },
    );
  }
}
