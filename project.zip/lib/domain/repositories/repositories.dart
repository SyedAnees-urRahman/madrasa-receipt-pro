import '../entities/entities.dart';
import '../entities/enums.dart';
import '../../core/error/failures.dart';

/// Repository contracts. Implementations live in data/.
/// Every write is scoped to an institution; demo data (isDemo) is
/// filtered by the same institution scope — never mixed.
abstract class InstitutionRepository {
  Future<Result<Institution?>> getCurrent();
  Future<Result<Institution>> save(Institution institution);
  Future<Result<void>> completeSetup(SetupDraft draft);
  Future<Result<List<Institution>>> listWorkspaces();
  Future<Result<void>> switchWorkspace(String institutionId);
}

class SetupDraft {
  SetupDraft({
    required this.nameUr,
    required this.nameEn,
    this.logoPath,
    this.address,
    this.phone,
    this.email,
    this.registrationNo,
    this.ntn,
    this.fyStartMonth = 7,
    this.fyStartDay = 1,
    this.receiptPrefix = 'MD',
    this.numberingFormat = '{prefix}-{yyyy}-{seq:06d}',
    this.receiptLanguage = 'bilingual',
    this.printFormat = 'a4',
    this.acceptedMethods = const [PaymentMethod.cash, PaymentMethod.bankTransfer],
    this.signatories = const [],
    this.dualApprovalThresholdPaisa = 100000 * 100,
    this.autoSync = true,
    this.funds = const [],
    this.purposes = const [],
    this.accounts = const [],
    this.seedDemo = false,
    this.adminName = 'ایڈمن',
    this.adminPin = '1234',
  });
  final String nameUr;
  final String nameEn;
  final String? logoPath;
  final String? address;
  final String? phone;
  final String? email;
  final String? registrationNo;
  final String? ntn;
  final int fyStartMonth;
  final int fyStartDay;
  final String receiptPrefix;
  final String numberingFormat;
  final String receiptLanguage;
  final String printFormat;
  final List<PaymentMethod> acceptedMethods;
  final List<SignatoryDraft> signatories;
  final int dualApprovalThresholdPaisa;
  final bool autoSync;
  final List<FundDraft> funds;
  final List<PurposeDraft> purposes;
  final List<AccountDraft> accounts;
  final bool seedDemo;
  final String adminName;
  final String adminPin;
}

class SignatoryDraft {
  const SignatoryDraft({required this.name, required this.title});
  final String name;
  final String title;
}

class FundDraft {
  const FundDraft({
    required this.code,
    required this.nameUr,
    required this.nameEn,
    required this.category,
    this.isRestricted = false,
  });
  final String code;
  final String nameUr;
  final String nameEn;
  final FundCategory category;
  final bool isRestricted;
}

class PurposeDraft {
  const PurposeDraft({required this.nameUr, required this.nameEn});
  final String nameUr;
  final String nameEn;
}

class AccountDraft {
  const AccountDraft({
    required this.type,
    required this.title,
    this.bankName,
    this.openingBalancePaisa = 0,
  });
  final AccountType type;
  final String title;
  final String? bankName;
  final int openingBalancePaisa;
}

abstract class DonorRepository {
  Future<Result<List<Donor>>> search(String query, {int limit = 20});
  Future<Result<Donor>> create(Donor donor);
  Future<Result<Donor?>> getById(String id);
  Future<Result<List<Donor>>> recent({int limit = 20});
}

abstract class FundRepository {
  Future<Result<List<FundType>>> funds({bool activeOnly = true});
  Future<Result<List<Purpose>>> purposes({bool activeOnly = true});
  Future<Result<FundType>> createFund(FundType fund);
  Future<Result<void>> updateFund(FundType fund, {required String reason});
  Future<Result<FundBalance>> balance(String fundId, {DateTime? asOf});
  Future<Result<List<FundBalance>>> allBalances({DateTime? asOf});
}

class FundBalance {
  const FundBalance({
    required this.fund,
    required this.openingPaisa,
    required this.confirmedReceiptsPaisa,
    required this.approvedAdjustmentsPaisa,
    required this.authorizedExpensesPaisa,
    required this.pendingPaisa,
  });
  final FundType fund;
  final int openingPaisa;
  final int confirmedReceiptsPaisa;
  final int approvedAdjustmentsPaisa;
  final int authorizedExpensesPaisa;
  final int pendingPaisa;

  int get closingPaisa =>
      openingPaisa + confirmedReceiptsPaisa + approvedAdjustmentsPaisa - authorizedExpensesPaisa;
}

abstract class AccountRepository {
  Future<Result<List<BankAccount>>> accounts({bool activeOnly = true});
  Future<Result<BankAccount>> create(BankAccount account);
  Future<Result<int>> bookBalance(String accountId, {DateTime? asOf});
}

abstract class ReceiptRepository {
  Future<Result<Receipt>> createDraft(ReceiptDraft draft);
  Future<Result<Receipt>> submitForVerification(String receiptId);
  Future<Result<Receipt>> verifyPayment({
    required String receiptId,
    required String verifierId,
    required String evidenceSummary,
    String? note,
  });
  Future<Result<Receipt>> issueOfficial(String receiptId);
  Future<Result<Receipt>> voidReceipt({
    required String receiptId,
    required String actorId,
    required String reason,
  });
  Future<Result<Receipt>> reverseReceipt({
    required String receiptId,
    required String actorId,
    required String reason,
  });
  Future<Result<Receipt?>> getById(String id);
  Future<Result<Receipt?>> getByOfficialNumber(String number);
  Future<Result<List<Receipt>>> register({
    DateTime? from,
    DateTime? to,
    ReceiptStatus? status,
    String? donorQuery,
    int limit = 100,
    int offset = 0,
  });
  Future<Result<List<Receipt>>> pendingVerification();
  Future<Result<List<Receipt>>> findPossibleDuplicates(ReceiptDraft draft);
  Future<Result<List<PaymentVerification>>> verificationHistory(String receiptId);
}

class ReceiptDraft {
  ReceiptDraft({
    required this.txType,
    this.donorId,
    required this.donorName,
    this.donorPhone,
    this.donorEmail,
    this.donorAddress,
    required this.isAnonymous,
    required this.totalPaisa,
    required this.allocations,
    required this.receiptDate,
    required this.paymentMethod,
    this.bankAccountId,
    this.referenceNo,
    this.evidencePath,
    this.staffNotes,
    this.donorNote,
  });
  final TxType txType;
  final String? donorId;
  final String donorName;
  final String? donorPhone;
  final String? donorEmail;
  final String? donorAddress;
  final bool isAnonymous;
  final int totalPaisa;
  final List<AllocationDraft> allocations;
  final DateTime receiptDate;
  final PaymentMethod paymentMethod;
  final String? bankAccountId;
  final String? referenceNo;
  final String? evidencePath;
  final String? staffNotes;
  final String? donorNote;
}

class AllocationDraft {
  const AllocationDraft({
    required this.fundTypeId,
    this.purposeId,
    required this.amountPaisa,
  });
  final String fundTypeId;
  final String? purposeId;
  final int amountPaisa;
}

abstract class ExpenseRepository {
  Future<Result<ExpenseVoucher>> create(ExpenseDraft draft);
  Future<Result<ExpenseVoucher>> approve({
    required String voucherId,
    required String approverId,
    String? note,
  });
  Future<Result<ExpenseVoucher>> reject({
    required String voucherId,
    required String approverId,
    required String reason,
  });
  Future<Result<ExpenseVoucher>> markPaid({
    required String voucherId,
    required String actorId,
  });
  Future<Result<List<ExpenseVoucher>>> register({
    DateTime? from,
    DateTime? to,
    ExpenseStatus? status,
    int limit = 100,
    int offset = 0,
  });
  Future<Result<ExpenseVoucher?>> getById(String id);
}

class ExpenseDraft {
  const ExpenseDraft({
    required this.voucherDate,
    required this.payee,
    required this.description,
    required this.totalPaisa,
    required this.allocations,
    required this.paymentMethod,
    this.bankAccountId,
    this.attachmentPath,
  });
  final DateTime voucherDate;
  final String payee;
  final String description;
  final int totalPaisa;
  final List<AllocationDraft> allocations;
  final PaymentMethod paymentMethod;
  final String? bankAccountId;
  final String? attachmentPath;
}

abstract class AuditRepository {
  Future<Result<void>> log(AuditDraft draft);
  Future<Result<List<AuditEvent>>> query({
    String? entityType,
    String? entityId,
    DateTime? from,
    DateTime? to,
    int limit = 200,
  });
  Future<Result<bool>> verifyChain();
}

class AuditDraft {
  const AuditDraft({
    required this.entityType,
    required this.entityId,
    required this.action,
    required this.actorId,
    this.reason,
    this.beforeJson,
    this.afterJson,
  });
  final String entityType;
  final String entityId;
  final String action;
  final String actorId;
  final String? reason;
  final String? beforeJson;
  final String? afterJson;
}

abstract class AuthRepository {
  Future<Result<UserProfile>> signIn(String email, String password);
  Future<Result<void>> signOut();
  Future<Result<UserProfile?>> currentSession();
  Future<Result<bool>> biometricAvailable();
  Future<Result<bool>> authenticateBiometric();
  Future<Result<void>> revokeSession();
}

abstract class ReportRepository {
  Future<Result<LedgerReport>> daily(DateTime day);
  Future<Result<LedgerReport>> period(DateTime from, DateTime to);
  Future<Result<List<DonorHistoryRow>>> donorHistory(String donorId);
  Future<Result<List<FundFlowRow>>> fundFlows(DateTime from, DateTime to);
  Future<Result<List<MethodSummaryRow>>> paymentMethodSummary(DateTime from, DateTime to);
  Future<Result<List<PurposeFlowRow>>> purposeFlows(DateTime from, DateTime to);
  Future<Result<CashBook>> cashBook(DateTime from, DateTime to, String accountId);
  Future<Result<List<Receipt>>> canceledRegister(DateTime from, DateTime to);
}

class LedgerReport {
  const LedgerReport({
    required this.confirmedTotalPaisa,
    required this.pendingTotalPaisa,
    required this.byMethod,
    required this.byFund,
    required this.receipts,
  });
  final int confirmedTotalPaisa;
  final int pendingTotalPaisa;
  final Map<PaymentMethod, int> byMethod;
  final Map<String, int> byFund;
  final List<Receipt> receipts;
}

class DonorHistoryRow {
  const DonorHistoryRow({required this.receipt, required this.fundNames});
  final Receipt receipt;
  final List<String> fundNames;
}

class FundFlowRow {
  const FundFlowRow({
    required this.fund,
    required this.receiptsPaisa,
    required this.expensesPaisa,
  });
  final FundType fund;
  final int receiptsPaisa;
  final int expensesPaisa;
}

class MethodSummaryRow {
  const MethodSummaryRow({required this.method, required this.totalPaisa, required this.count});
  final PaymentMethod method;
  final int totalPaisa;
  final int count;
}

class PurposeFlowRow {
  const PurposeFlowRow({required this.purpose, required this.totalPaisa});
  final Purpose purpose;
  final int totalPaisa;
}

class CashBook {
  const CashBook({
    required this.openingPaisa,
    required this.lines,
    required this.closingPaisa,
  });
  final int openingPaisa;
  final List<CashBookLine> lines;
  final int closingPaisa;
}

class CashBookLine {
  const CashBookLine({
    required this.date,
    required this.label,
    required this.reference,
    required this.inPaisa,
    required this.outPaisa,
  });
  final DateTime date;
  final String label;
  final String reference;
  final int inPaisa;
  final int outPaisa;
}
