import '../entities/enums.dart';

/// Role-based permission matrix. The UI consults this for visibility;
/// the repository layer AND the server (RLS) enforce it for real.
/// Hiding a button is not authorization.
abstract final class Permissions {
  static const _matrix = <UserRole, Set<String>>{
    UserRole.admin: {
      'settings.write', 'users.manage', 'receipt.create', 'receipt.verify',
      'receipt.void', 'receipt.view', 'expense.create', 'expense.approve',
      'expense.pay', 'funds.manage', 'accounts.manage', 'reports.view',
      'audit.view', 'backup.run', 'reconcile.run', 'sync.resolve',
    },
    UserRole.accountant: {
      'receipt.create', 'receipt.verify', 'receipt.view', 'receipt.void',
      'expense.create', 'expense.approve', 'expense.pay', 'reports.view',
      'audit.view', 'reconcile.run', 'backup.run', 'sync.resolve',
    },
    UserRole.receiptOperator: {
      'receipt.create', 'receipt.view', 'expense.create',
    },
    UserRole.paymentVerifier: {
      'receipt.verify', 'receipt.view', 'reports.view',
    },
    UserRole.auditor: {
      'receipt.view', 'reports.view', 'audit.view',
    },
  };

  static bool can(UserRole role, String permission) =>
      _matrix[role]?.contains(permission) ?? false;

  /// Separation of duties: verifier/approver must differ from creator.
  static bool isSelfApproval(String actorId, String? creatorId) =>
      creatorId != null && actorId == creatorId;

  /// Ordinary operators can never delete confirmed receipts, renumber,
  /// or erase audit history — enforced in repositories + RLS.
  static bool get auditIsAppendOnly => true;
}
