/// Domain enums shared across layers. Persisted as TEXT in SQLite/Postgres.
enum UserRole { admin, accountant, receiptOperator, paymentVerifier, auditor }

enum ReceiptStatus { draft, pendingVerification, confirmed, voided, reversed }

enum TxType {
  cash, // نقد وصول — cash actually received
  bankTransfer, // بینک ٹرانسفر
  cheque, // چیک — only confirmed after clearance verified
  wallet, // موبائل والٹ
  pendingBankWallet, // منتظر بینک/والٹ ادائیگی
  pledge, // وعدہ — NEVER a confirmed receipt
}

enum PaymentMethod { cash, bankTransfer, cheque, wallet }

enum AccountType { cash, bank, wallet }

enum FundCategory {
  zakat,
  sadaqahNafilah,
  sadaqahWajibah,
  lillah,
  restricted,
  studentMeals,
  booksEducation,
  scholarships,
  accommodation,
  construction,
  utilities,
  other,
}

enum ExpenseStatus { draft, pendingApproval, approved, paid, rejected }

enum ApprovalDecision { approved, rejected }

enum SyncStatus { pending, inFlight, failed, done }

enum OutboxOperation { insert, update, delete }

/// Money rule: all amounts are integer paisa. This file documents the
/// invariant; enforcement lives in Money + DB CHECK constraints.
abstract final class DomainRules {
  /// A pledge is never a confirmed receipt.
  static bool pledgeCanConfirm(TxType t) => t != TxType.pledge;

  /// Only cash confirmed by an authorized receiver, or a verified
  /// bank/wallet/cheque transaction, may become confirmed.
  static bool mayConfirm(TxType t, {required bool paymentVerified}) {
    if (t == TxType.pledge || t == TxType.pendingBankWallet) return false;
    return paymentVerified;
  }

  /// Confirmed financial records are immutable except through
  /// linked adjustment / reversal / replacement entries.
  static bool isFinanciallyLocked(ReceiptStatus s) =>
      s == ReceiptStatus.confirmed || s == ReceiptStatus.reversed;

  /// Pending donations are never part of confirmed collection totals.
  static bool countsAsCollection(ReceiptStatus s) => s == ReceiptStatus.confirmed;
}
