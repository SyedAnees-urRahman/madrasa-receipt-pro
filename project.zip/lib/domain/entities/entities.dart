import 'package:meta/meta.dart';
import 'enums.dart';

/// Immutable domain entities. IDs are UUID v4 strings, stable across
/// offline creation and server sync (idempotency anchors).
@immutable
class Institution {
  const Institution({
    required this.id,
    required this.nameUr,
    required this.nameEn,
    this.logoPath,
    this.address,
    this.phone,
    this.email,
    this.registrationNo,
    this.ntn,
    required this.fyStartMonth,
    required this.fyStartDay,
    required this.receiptPrefix,
    required this.numberingFormat,
    required this.receiptLanguage,
    required this.printFormat,
    required this.acceptedMethods,
    required this.dualApprovalThresholdPaisa,
    required this.autoSync,
    required this.isDemo,
    this.signatoriesJson,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String nameUr;
  final String nameEn;
  final String? logoPath;
  final String? address;
  final String? phone;
  final String? email;
  final String? registrationNo;
  final String? ntn;
  final int fyStartMonth;
  final int fyStartDay;
  final String receiptPrefix; // e.g. "MD"
  final String numberingFormat; // e.g. "{prefix}-{yyyy}-{seq:06d}"
  final String receiptLanguage; // ur | en | bilingual
  final String printFormat; // a4 | thermal80
  final List<PaymentMethod> acceptedMethods;
  final int dualApprovalThresholdPaisa;
  final bool autoSync;
  final bool isDemo;
  final String? signatoriesJson;
  final DateTime createdAt;
  final DateTime updatedAt;
}

@immutable
class UserProfile {
  const UserProfile({
    required this.id,
    required this.institutionId,
    required this.displayName,
    required this.email,
    required this.role,
    required this.isActive,
    required this.createdAt,
  });
  final String id; // == Supabase auth user id
  final String institutionId;
  final String displayName;
  final String email;
  final UserRole role;
  final bool isActive;
  final DateTime createdAt;
}

@immutable
class Donor {
  const Donor({
    required this.id,
    required this.institutionId,
    required this.name,
    this.phone,
    this.email,
    this.address,
    this.notes,
    required this.createdBy,
    required this.createdAt,
    required this.updatedAt,
  });
  final String id;
  final String institutionId;
  final String name;
  final String? phone;
  final String? email;
  final String? address;
  final String? notes;
  final String createdBy;
  final DateTime createdAt;
  final DateTime updatedAt;
}

@immutable
class FundType {
  const FundType({
    required this.id,
    required this.institutionId,
    required this.code,
    required this.nameUr,
    required this.nameEn,
    required this.category,
    required this.isRestricted,
    required this.isActive,
    required this.openingBalancePaisa,
    required this.sortOrder,
  });
  final String id;
  final String institutionId;
  final String code;
  final String nameUr;
  final String nameEn;
  final FundCategory category;
  final bool isRestricted;
  final bool isActive;
  final int openingBalancePaisa;
  final int sortOrder;
}

@immutable
class Purpose {
  const Purpose({
    required this.id,
    required this.institutionId,
    required this.nameUr,
    required this.nameEn,
    this.description,
    required this.isActive,
  });
  final String id;
  final String institutionId;
  final String nameUr;
  final String nameEn;
  final String? description;
  final bool isActive;
}

@immutable
class BankAccount {
  const BankAccount({
    required this.id,
    required this.institutionId,
    required this.type,
    required this.title,
    this.bankName,
    this.accountNoMasked,
    required this.openingBalancePaisa,
    required this.isActive,
  });
  final String id;
  final String institutionId;
  final AccountType type;
  final String title;
  final String? bankName;
  final String? accountNoMasked; // never store full numbers on device
  final int openingBalancePaisa;
  final bool isActive;
}

/// The receipt aggregate root. [officialNumber] is assigned ONLY by the
/// trusted server; offline it stays null and the receipt is provisional.
@immutable
class Receipt {
  const Receipt({
    required this.id,
    required this.institutionId,
    this.officialNumber,
    this.localProvisionalLabel,
    required this.status,
    required this.txType,
    this.donorId,
    required this.donorNameSnapshot,
    required this.isAnonymous,
    required this.totalPaisa,
    required this.receiptDate,
    required this.paymentMethod,
    this.bankAccountId,
    this.referenceNo,
    this.evidencePath,
    this.staffNotes,
    this.donorNote,
    this.createdBy,
    this.verifiedBy,
    this.verifiedAt,
    this.voidReason,
    this.replacedById,
    this.reversesId,
    required this.idempotencyKey,
    required this.serverAck,
    required this.allocations,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String institutionId;
  final String? officialNumber;
  final String? localProvisionalLabel;
  final ReceiptStatus status;
  final TxType txType;
  final String? donorId;
  final String donorNameSnapshot;
  final bool isAnonymous;
  final int totalPaisa;
  final DateTime receiptDate;
  final PaymentMethod paymentMethod;
  final String? bankAccountId;
  final String? referenceNo;
  final String? evidencePath;
  final String? staffNotes; // NEVER on the donor-facing PDF
  final String? donorNote;
  final String? createdBy;
  final String? verifiedBy;
  final DateTime? verifiedAt;
  final String? voidReason;
  final String? replacedById;
  final String? reversesId;
  final String idempotencyKey;
  final bool serverAck;
  final List<ReceiptAllocation> allocations;
  final DateTime createdAt;
  final DateTime updatedAt;

  int get allocatedTotal =>
      allocations.fold(0, (sum, a) => sum + a.amountPaisa);

  bool get allocationBalanced => allocatedTotal == totalPaisa;

  /// Provisional until the server issues an official number.
  bool get isProvisional => officialNumber == null;

  Receipt copyWith({
    ReceiptStatus? status,
    String? officialNumber,
    String? verifiedBy,
    DateTime? verifiedAt,
    String? voidReason,
    String? replacedById,
    bool? serverAck,
    DateTime? updatedAt,
  }) {
    return Receipt(
      id: id,
      institutionId: institutionId,
      officialNumber: officialNumber ?? this.officialNumber,
      localProvisionalLabel: localProvisionalLabel,
      status: status ?? this.status,
      txType: txType,
      donorId: donorId,
      donorNameSnapshot: donorNameSnapshot,
      isAnonymous: isAnonymous,
      totalPaisa: totalPaisa,
      receiptDate: receiptDate,
      paymentMethod: paymentMethod,
      bankAccountId: bankAccountId,
      referenceNo: referenceNo,
      evidencePath: evidencePath,
      staffNotes: staffNotes,
      donorNote: donorNote,
      createdBy: createdBy,
      verifiedBy: verifiedBy ?? this.verifiedBy,
      verifiedAt: verifiedAt ?? this.verifiedAt,
      voidReason: voidReason ?? this.voidReason,
      replacedById: replacedById ?? this.replacedById,
      reversesId: reversesId,
      idempotencyKey: idempotencyKey,
      serverAck: serverAck ?? this.serverAck,
      allocations: allocations,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

@immutable
class ReceiptAllocation {
  const ReceiptAllocation({
    required this.id,
    required this.receiptId,
    required this.fundTypeId,
    this.purposeId,
    required this.amountPaisa,
  });
  final String id;
  final String receiptId;
  final String fundTypeId;
  final String? purposeId;
  final int amountPaisa;
}

@immutable
class PaymentVerification {
  const PaymentVerification({
    required this.id,
    required this.receiptId,
    required this.verifiedBy,
    required this.verifiedAt,
    required this.evidenceSummary,
    this.note,
  });
  final String id;
  final String receiptId;
  final String verifiedBy;
  final DateTime verifiedAt;
  final String evidenceSummary;
  final String? note;
}

@immutable
class ExpenseVoucher {
  const ExpenseVoucher({
    required this.id,
    required this.institutionId,
    required this.voucherNumber,
    required this.voucherDate,
    required this.payee,
    required this.description,
    required this.totalPaisa,
    required this.paymentMethod,
    this.bankAccountId,
    this.attachmentPath,
    required this.status,
    this.createdBy,
    this.approvedBy,
    this.approvedAt,
    this.rejectionReason,
    required this.idempotencyKey,
    required this.allocations,
    required this.createdAt,
    required this.updatedAt,
  });
  final String id;
  final String institutionId;
  final String voucherNumber;
  final DateTime voucherDate;
  final String payee;
  final String description;
  final int totalPaisa;
  final PaymentMethod paymentMethod;
  final String? bankAccountId;
  final String? attachmentPath;
  final ExpenseStatus status;
  final String? createdBy;
  final String? approvedBy;
  final DateTime? approvedAt;
  final String? rejectionReason;
  final String idempotencyKey;
  final List<ExpenseAllocation> allocations;
  final DateTime createdAt;
  final DateTime updatedAt;
}

@immutable
class ExpenseAllocation {
  const ExpenseAllocation({
    required this.id,
    required this.voucherId,
    required this.fundTypeId,
    this.purposeId,
    required this.amountPaisa,
  });
  final String id;
  final String voucherId;
  final String fundTypeId;
  final String? purposeId;
  final int amountPaisa;
}

@immutable
class AuditEvent {
  const AuditEvent({
    required this.id,
    required this.institutionId,
    required this.sequence,
    required this.entityType,
    required this.entityId,
    required this.action,
    required this.actorId,
    required this.occurredAt,
    this.reason,
    this.beforeJson,
    this.afterJson,
    required this.prevHash,
    required this.hash,
  });
  final String id;
  final String institutionId;
  final int sequence;
  final String entityType;
  final String entityId;
  final String action;
  final String actorId;
  final DateTime occurredAt;
  final String? reason;
  final String? beforeJson;
  final String? afterJson;
  final String prevHash;
  final String hash;
}

@immutable
class SyncConflict {
  const SyncConflict({
    required this.id,
    required this.entityType,
    required this.entityId,
    required this.localJson,
    required this.remoteJson,
    required this.detectedAt,
    required this.status,
    this.resolvedBy,
    this.resolvedAt,
    this.resolutionNote,
  });
  final String id;
  final String entityType;
  final String entityId;
  final String localJson;
  final String remoteJson;
  final DateTime detectedAt;
  final String status; // open | resolved_keep_local | resolved_keep_remote | resolved_merged
  final String? resolvedBy;
  final DateTime? resolvedAt;
  final String? resolutionNote;
}
