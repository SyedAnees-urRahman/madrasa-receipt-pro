import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_en.dart';
import 'app_localizations_ur.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'arb/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
      : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations)!;
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('ur'),
    Locale('en')
  ];

  /// No description provided for @allocationAdd.
  ///
  /// In en, this message translates to:
  /// **'Add allocation'**
  String get allocationAdd;

  /// No description provided for @allocationFund.
  ///
  /// In en, this message translates to:
  /// **'Fund'**
  String get allocationFund;

  /// No description provided for @allocationPurpose.
  ///
  /// In en, this message translates to:
  /// **'Purpose'**
  String get allocationPurpose;

  /// No description provided for @allocationTotalMismatch.
  ///
  /// In en, this message translates to:
  /// **'Allocation total must exactly equal the receipt total.'**
  String get allocationTotalMismatch;

  /// No description provided for @amountInWordsEn.
  ///
  /// In en, this message translates to:
  /// **'Amount in words (English)'**
  String get amountInWordsEn;

  /// No description provided for @amountInWordsUr.
  ///
  /// In en, this message translates to:
  /// **'Amount in words (Urdu)'**
  String get amountInWordsUr;

  /// No description provided for @amountPkr.
  ///
  /// In en, this message translates to:
  /// **'Amount (PKR)'**
  String get amountPkr;

  /// No description provided for @appName.
  ///
  /// In en, this message translates to:
  /// **'Madrasa Receipt Pro'**
  String get appName;

  /// No description provided for @auditAction.
  ///
  /// In en, this message translates to:
  /// **'Action'**
  String get auditAction;

  /// No description provided for @auditActor.
  ///
  /// In en, this message translates to:
  /// **'Actor'**
  String get auditActor;

  /// No description provided for @auditReason.
  ///
  /// In en, this message translates to:
  /// **'Reason'**
  String get auditReason;

  /// No description provided for @auditTime.
  ///
  /// In en, this message translates to:
  /// **'Time'**
  String get auditTime;

  /// No description provided for @backupLast.
  ///
  /// In en, this message translates to:
  /// **'Last backup'**
  String get backupLast;

  /// No description provided for @backupNow.
  ///
  /// In en, this message translates to:
  /// **'Back up now'**
  String get backupNow;

  /// No description provided for @backupRestore.
  ///
  /// In en, this message translates to:
  /// **'Restore'**
  String get backupRestore;

  /// No description provided for @commonAddress.
  ///
  /// In en, this message translates to:
  /// **'Address'**
  String get commonAddress;

  /// No description provided for @commonAmount.
  ///
  /// In en, this message translates to:
  /// **'Amount'**
  String get commonAmount;

  /// No description provided for @commonBack.
  ///
  /// In en, this message translates to:
  /// **'Back'**
  String get commonBack;

  /// No description provided for @commonCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get commonCancel;

  /// No description provided for @commonClose.
  ///
  /// In en, this message translates to:
  /// **'Close'**
  String get commonClose;

  /// No description provided for @commonConfirm.
  ///
  /// In en, this message translates to:
  /// **'Confirm'**
  String get commonConfirm;

  /// No description provided for @commonDate.
  ///
  /// In en, this message translates to:
  /// **'Date'**
  String get commonDate;

  /// No description provided for @commonDelete.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get commonDelete;

  /// No description provided for @commonDone.
  ///
  /// In en, this message translates to:
  /// **'Done'**
  String get commonDone;

  /// No description provided for @commonEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit'**
  String get commonEdit;

  /// No description provided for @commonEmail.
  ///
  /// In en, this message translates to:
  /// **'Email'**
  String get commonEmail;

  /// No description provided for @commonError.
  ///
  /// In en, this message translates to:
  /// **'Something went wrong'**
  String get commonError;

  /// No description provided for @commonExport.
  ///
  /// In en, this message translates to:
  /// **'Export'**
  String get commonExport;

  /// No description provided for @commonFilter.
  ///
  /// In en, this message translates to:
  /// **'Filter'**
  String get commonFilter;

  /// No description provided for @commonLoading.
  ///
  /// In en, this message translates to:
  /// **'Loading…'**
  String get commonLoading;

  /// No description provided for @commonName.
  ///
  /// In en, this message translates to:
  /// **'Name'**
  String get commonName;

  /// No description provided for @commonNext.
  ///
  /// In en, this message translates to:
  /// **'Next'**
  String get commonNext;

  /// No description provided for @commonNo.
  ///
  /// In en, this message translates to:
  /// **'No'**
  String get commonNo;

  /// No description provided for @commonNoData.
  ///
  /// In en, this message translates to:
  /// **'No records found'**
  String get commonNoData;

  /// No description provided for @commonNotes.
  ///
  /// In en, this message translates to:
  /// **'Notes'**
  String get commonNotes;

  /// No description provided for @commonOptional.
  ///
  /// In en, this message translates to:
  /// **'Optional'**
  String get commonOptional;

  /// No description provided for @commonPhone.
  ///
  /// In en, this message translates to:
  /// **'Phone'**
  String get commonPhone;

  /// No description provided for @commonPreview.
  ///
  /// In en, this message translates to:
  /// **'Preview'**
  String get commonPreview;

  /// No description provided for @commonPrint.
  ///
  /// In en, this message translates to:
  /// **'Print'**
  String get commonPrint;

  /// No description provided for @commonRequired.
  ///
  /// In en, this message translates to:
  /// **'Required'**
  String get commonRequired;

  /// No description provided for @commonRetry.
  ///
  /// In en, this message translates to:
  /// **'Retry'**
  String get commonRetry;

  /// No description provided for @commonSave.
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get commonSave;

  /// No description provided for @commonSearch.
  ///
  /// In en, this message translates to:
  /// **'Search'**
  String get commonSearch;

  /// No description provided for @commonShare.
  ///
  /// In en, this message translates to:
  /// **'Share'**
  String get commonShare;

  /// No description provided for @commonStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get commonStatus;

  /// No description provided for @commonThisMonth.
  ///
  /// In en, this message translates to:
  /// **'This month'**
  String get commonThisMonth;

  /// No description provided for @commonToday.
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get commonToday;

  /// No description provided for @commonTotal.
  ///
  /// In en, this message translates to:
  /// **'Total'**
  String get commonTotal;

  /// No description provided for @commonYes.
  ///
  /// In en, this message translates to:
  /// **'Yes'**
  String get commonYes;

  /// No description provided for @currencyPkr.
  ///
  /// In en, this message translates to:
  /// **'PKR'**
  String get currencyPkr;

  /// No description provided for @dashFailedSync.
  ///
  /// In en, this message translates to:
  /// **'Failed syncs needing attention'**
  String get dashFailedSync;

  /// No description provided for @dashFundBalances.
  ///
  /// In en, this message translates to:
  /// **'Fund balances'**
  String get dashFundBalances;

  /// No description provided for @dashLastSync.
  ///
  /// In en, this message translates to:
  /// **'Last successful sync'**
  String get dashLastSync;

  /// No description provided for @dashMonthConfirmed.
  ///
  /// In en, this message translates to:
  /// **'This month\'s confirmed collections'**
  String get dashMonthConfirmed;

  /// No description provided for @dashNeverSynced.
  ///
  /// In en, this message translates to:
  /// **'Never synced'**
  String get dashNeverSynced;

  /// No description provided for @dashOfflinePending.
  ///
  /// In en, this message translates to:
  /// **'Offline records awaiting sync'**
  String get dashOfflinePending;

  /// No description provided for @dashPendingVerification.
  ///
  /// In en, this message translates to:
  /// **'Pending verifications'**
  String get dashPendingVerification;

  /// No description provided for @dashRecentAudit.
  ///
  /// In en, this message translates to:
  /// **'Recent audit events'**
  String get dashRecentAudit;

  /// No description provided for @dashRecentExpenses.
  ///
  /// In en, this message translates to:
  /// **'Recent expense vouchers'**
  String get dashRecentExpenses;

  /// No description provided for @dashRecentReceipts.
  ///
  /// In en, this message translates to:
  /// **'Recent receipts'**
  String get dashRecentReceipts;

  /// No description provided for @dashStaleWarning.
  ///
  /// In en, this message translates to:
  /// **'Figures may be stale — last synced {time}.'**
  String dashStaleWarning(Object time);

  /// No description provided for @dashTodayConfirmed.
  ///
  /// In en, this message translates to:
  /// **'Today\'s confirmed collections'**
  String get dashTodayConfirmed;

  /// No description provided for @demoBadge.
  ///
  /// In en, this message translates to:
  /// **'DEMO'**
  String get demoBadge;

  /// No description provided for @demoBanner.
  ///
  /// In en, this message translates to:
  /// **'DEMO workspace — sample data only. Not real financial records.'**
  String get demoBanner;

  /// No description provided for @demoWorkspace.
  ///
  /// In en, this message translates to:
  /// **'Demo workspace'**
  String get demoWorkspace;

  /// No description provided for @donorAnonymous.
  ///
  /// In en, this message translates to:
  /// **'Anonymous donation'**
  String get donorAnonymous;

  /// No description provided for @donorName.
  ///
  /// In en, this message translates to:
  /// **'Donor name'**
  String get donorName;

  /// No description provided for @donorNew.
  ///
  /// In en, this message translates to:
  /// **'New donor'**
  String get donorNew;

  /// No description provided for @donorNote.
  ///
  /// In en, this message translates to:
  /// **'Note for donor (appears on receipt)'**
  String get donorNote;

  /// No description provided for @donorSearchHint.
  ///
  /// In en, this message translates to:
  /// **'Search donors by name or phone'**
  String get donorSearchHint;

  /// No description provided for @errorInvalidAmount.
  ///
  /// In en, this message translates to:
  /// **'Enter a valid amount greater than zero.'**
  String get errorInvalidAmount;

  /// No description provided for @errorNetwork.
  ///
  /// In en, this message translates to:
  /// **'No internet connection. Your work is saved locally and will sync later.'**
  String get errorNetwork;

  /// No description provided for @errorPermission.
  ///
  /// In en, this message translates to:
  /// **'You do not have permission for this action.'**
  String get errorPermission;

  /// No description provided for @errorRequired.
  ///
  /// In en, this message translates to:
  /// **'This field is required.'**
  String get errorRequired;

  /// No description provided for @errorSelfApproval.
  ///
  /// In en, this message translates to:
  /// **'Self-approval is not allowed. Another authorized person must approve.'**
  String get errorSelfApproval;

  /// No description provided for @expenseApprove.
  ///
  /// In en, this message translates to:
  /// **'Approve'**
  String get expenseApprove;

  /// No description provided for @expenseDescription.
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get expenseDescription;

  /// No description provided for @expenseMarkPaid.
  ///
  /// In en, this message translates to:
  /// **'Mark as paid'**
  String get expenseMarkPaid;

  /// No description provided for @expenseNew.
  ///
  /// In en, this message translates to:
  /// **'New expense voucher'**
  String get expenseNew;

  /// No description provided for @expenseOverBudget.
  ///
  /// In en, this message translates to:
  /// **'This exceeds the available fund balance.'**
  String get expenseOverBudget;

  /// No description provided for @expensePayee.
  ///
  /// In en, this message translates to:
  /// **'Payee / vendor'**
  String get expensePayee;

  /// No description provided for @expenseReject.
  ///
  /// In en, this message translates to:
  /// **'Reject'**
  String get expenseReject;

  /// No description provided for @expenseStatus.
  ///
  /// In en, this message translates to:
  /// **'Voucher status'**
  String get expenseStatus;

  /// No description provided for @expenseVoucherNo.
  ///
  /// In en, this message translates to:
  /// **'Voucher no.'**
  String get expenseVoucherNo;

  /// No description provided for @exportCsv.
  ///
  /// In en, this message translates to:
  /// **'Export CSV'**
  String get exportCsv;

  /// No description provided for @exportPdf.
  ///
  /// In en, this message translates to:
  /// **'Export PDF'**
  String get exportPdf;

  /// No description provided for @exportXlsx.
  ///
  /// In en, this message translates to:
  /// **'Export Excel'**
  String get exportXlsx;

  /// No description provided for @issueOfficial.
  ///
  /// In en, this message translates to:
  /// **'Issue official receipt'**
  String get issueOfficial;

  /// No description provided for @issueProvisional.
  ///
  /// In en, this message translates to:
  /// **'Save as provisional'**
  String get issueProvisional;

  /// No description provided for @issueSave.
  ///
  /// In en, this message translates to:
  /// **'Save receipt'**
  String get issueSave;

  /// No description provided for @loginBiometric.
  ///
  /// In en, this message translates to:
  /// **'Use biometrics'**
  String get loginBiometric;

  /// No description provided for @loginButton.
  ///
  /// In en, this message translates to:
  /// **'Sign in'**
  String get loginButton;

  /// No description provided for @loginEmail.
  ///
  /// In en, this message translates to:
  /// **'Email'**
  String get loginEmail;

  /// No description provided for @loginFailed.
  ///
  /// In en, this message translates to:
  /// **'Sign in failed. Check your email and password.'**
  String get loginFailed;

  /// No description provided for @loginPassword.
  ///
  /// In en, this message translates to:
  /// **'Password'**
  String get loginPassword;

  /// No description provided for @loginSessionExpired.
  ///
  /// In en, this message translates to:
  /// **'Your session has expired. Please sign in again.'**
  String get loginSessionExpired;

  /// No description provided for @loginTitle.
  ///
  /// In en, this message translates to:
  /// **'Sign in'**
  String get loginTitle;

  /// No description provided for @logoutConfirm.
  ///
  /// In en, this message translates to:
  /// **'Sign out of this device?'**
  String get logoutConfirm;

  /// No description provided for @menuAudit.
  ///
  /// In en, this message translates to:
  /// **'Audit History'**
  String get menuAudit;

  /// No description provided for @menuBackup.
  ///
  /// In en, this message translates to:
  /// **'Backup & Restore'**
  String get menuBackup;

  /// No description provided for @menuBooks.
  ///
  /// In en, this message translates to:
  /// **'Cash & Bank Books'**
  String get menuBooks;

  /// No description provided for @menuDonors.
  ///
  /// In en, this message translates to:
  /// **'Donors'**
  String get menuDonors;

  /// No description provided for @menuExpenses.
  ///
  /// In en, this message translates to:
  /// **'Expenses'**
  String get menuExpenses;

  /// No description provided for @menuFunds.
  ///
  /// In en, this message translates to:
  /// **'Funds'**
  String get menuFunds;

  /// No description provided for @menuReconciliation.
  ///
  /// In en, this message translates to:
  /// **'Bank Reconciliation'**
  String get menuReconciliation;

  /// No description provided for @menuStaff.
  ///
  /// In en, this message translates to:
  /// **'Staff & Permissions'**
  String get menuStaff;

  /// No description provided for @menuVerification.
  ///
  /// In en, this message translates to:
  /// **'Payment Verification'**
  String get menuVerification;

  /// No description provided for @navHome.
  ///
  /// In en, this message translates to:
  /// **'Home'**
  String get navHome;

  /// No description provided for @navNewReceipt.
  ///
  /// In en, this message translates to:
  /// **'New Receipt'**
  String get navNewReceipt;

  /// No description provided for @navReceipts.
  ///
  /// In en, this message translates to:
  /// **'Receipts'**
  String get navReceipts;

  /// No description provided for @navReports.
  ///
  /// In en, this message translates to:
  /// **'Reports'**
  String get navReports;

  /// No description provided for @navSettings.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get navSettings;

  /// No description provided for @payDate.
  ///
  /// In en, this message translates to:
  /// **'Transaction date'**
  String get payDate;

  /// No description provided for @payEvidence.
  ///
  /// In en, this message translates to:
  /// **'Supporting evidence (private)'**
  String get payEvidence;

  /// No description provided for @payMethod.
  ///
  /// In en, this message translates to:
  /// **'Payment method'**
  String get payMethod;

  /// No description provided for @payReceivingAccount.
  ///
  /// In en, this message translates to:
  /// **'Receiving account'**
  String get payReceivingAccount;

  /// No description provided for @payReference.
  ///
  /// In en, this message translates to:
  /// **'Transaction / cheque reference'**
  String get payReference;

  /// No description provided for @pdfDuplicateLabel.
  ///
  /// In en, this message translates to:
  /// **'DUPLICATE COPY'**
  String get pdfDuplicateLabel;

  /// No description provided for @pdfProvisionalLabel.
  ///
  /// In en, this message translates to:
  /// **'PROVISIONAL — NOT AN OFFICIAL RECEIPT'**
  String get pdfProvisionalLabel;

  /// No description provided for @pdfThankYou.
  ///
  /// In en, this message translates to:
  /// **'May Allah accept your donation and reward you abundantly.'**
  String get pdfThankYou;

  /// No description provided for @receiptHistory.
  ///
  /// In en, this message translates to:
  /// **'History'**
  String get receiptHistory;

  /// No description provided for @receiptIssueDate.
  ///
  /// In en, this message translates to:
  /// **'Issue date'**
  String get receiptIssueDate;

  /// No description provided for @receiptNumber.
  ///
  /// In en, this message translates to:
  /// **'Receipt no.'**
  String get receiptNumber;

  /// No description provided for @receiptReverse.
  ///
  /// In en, this message translates to:
  /// **'Reverse receipt'**
  String get receiptReverse;

  /// No description provided for @receiptVoid.
  ///
  /// In en, this message translates to:
  /// **'Void receipt'**
  String get receiptVoid;

  /// No description provided for @receiptVoidReason.
  ///
  /// In en, this message translates to:
  /// **'Reason (required)'**
  String get receiptVoidReason;

  /// No description provided for @reportAnnualRegister.
  ///
  /// In en, this message translates to:
  /// **'Annual receipt register'**
  String get reportAnnualRegister;

  /// No description provided for @reportAuditLog.
  ///
  /// In en, this message translates to:
  /// **'Audit event log'**
  String get reportAuditLog;

  /// No description provided for @reportBalances.
  ///
  /// In en, this message translates to:
  /// **'Opening & closing balances'**
  String get reportBalances;

  /// No description provided for @reportBankbook.
  ///
  /// In en, this message translates to:
  /// **'Bankbook'**
  String get reportBankbook;

  /// No description provided for @reportCanceled.
  ///
  /// In en, this message translates to:
  /// **'Canceled / reversed receipts'**
  String get reportCanceled;

  /// No description provided for @reportCashbook.
  ///
  /// In en, this message translates to:
  /// **'Cashbook'**
  String get reportCashbook;

  /// No description provided for @reportDaily.
  ///
  /// In en, this message translates to:
  /// **'Daily collection report'**
  String get reportDaily;

  /// No description provided for @reportDonorHistory.
  ///
  /// In en, this message translates to:
  /// **'Donor-wise history'**
  String get reportDonorHistory;

  /// No description provided for @reportExpenseRegister.
  ///
  /// In en, this message translates to:
  /// **'Expense voucher register'**
  String get reportExpenseRegister;

  /// No description provided for @reportFundIncomeExpense.
  ///
  /// In en, this message translates to:
  /// **'Fund-wise income & expenditure'**
  String get reportFundIncomeExpense;

  /// No description provided for @reportFundReceipts.
  ///
  /// In en, this message translates to:
  /// **'Fund-wise receipts'**
  String get reportFundReceipts;

  /// No description provided for @reportMonthlyRegister.
  ///
  /// In en, this message translates to:
  /// **'Monthly receipt register'**
  String get reportMonthlyRegister;

  /// No description provided for @reportPaymentMethod.
  ///
  /// In en, this message translates to:
  /// **'Payment-method summary'**
  String get reportPaymentMethod;

  /// No description provided for @reportPendingVerification.
  ///
  /// In en, this message translates to:
  /// **'Pending verification report'**
  String get reportPendingVerification;

  /// No description provided for @reportPurposeCollections.
  ///
  /// In en, this message translates to:
  /// **'Purpose-wise collections'**
  String get reportPurposeCollections;

  /// No description provided for @reportReconciliation.
  ///
  /// In en, this message translates to:
  /// **'Bank reconciliation'**
  String get reportReconciliation;

  /// No description provided for @reportSyncConflicts.
  ///
  /// In en, this message translates to:
  /// **'Sync & conflict report'**
  String get reportSyncConflicts;

  /// No description provided for @reviewWarnings.
  ///
  /// In en, this message translates to:
  /// **'Warnings'**
  String get reviewWarnings;

  /// No description provided for @roleAccountant.
  ///
  /// In en, this message translates to:
  /// **'Accountant'**
  String get roleAccountant;

  /// No description provided for @roleAdmin.
  ///
  /// In en, this message translates to:
  /// **'Administrator'**
  String get roleAdmin;

  /// No description provided for @roleAuditor.
  ///
  /// In en, this message translates to:
  /// **'Auditor'**
  String get roleAuditor;

  /// No description provided for @roleOperator.
  ///
  /// In en, this message translates to:
  /// **'Receipt Operator'**
  String get roleOperator;

  /// No description provided for @roleVerifier.
  ///
  /// In en, this message translates to:
  /// **'Payment Verifier'**
  String get roleVerifier;

  /// No description provided for @settingsAccessibility.
  ///
  /// In en, this message translates to:
  /// **'Accessibility'**
  String get settingsAccessibility;

  /// No description provided for @settingsAppearance.
  ///
  /// In en, this message translates to:
  /// **'Appearance'**
  String get settingsAppearance;

  /// No description provided for @settingsInstitution.
  ///
  /// In en, this message translates to:
  /// **'Institution profile'**
  String get settingsInstitution;

  /// No description provided for @settingsLanguage.
  ///
  /// In en, this message translates to:
  /// **'Language'**
  String get settingsLanguage;

  /// No description provided for @setupAddAccount.
  ///
  /// In en, this message translates to:
  /// **'Add account'**
  String get setupAddAccount;

  /// No description provided for @setupAddFund.
  ///
  /// In en, this message translates to:
  /// **'Add fund'**
  String get setupAddFund;

  /// No description provided for @setupAddPurpose.
  ///
  /// In en, this message translates to:
  /// **'Add purpose'**
  String get setupAddPurpose;

  /// No description provided for @setupAddSignatory.
  ///
  /// In en, this message translates to:
  /// **'Add signatory'**
  String get setupAddSignatory;

  /// No description provided for @setupAddress.
  ///
  /// In en, this message translates to:
  /// **'Address & contact'**
  String get setupAddress;

  /// No description provided for @setupApprovalThreshold.
  ///
  /// In en, this message translates to:
  /// **'Two-person approval above (PKR)'**
  String get setupApprovalThreshold;

  /// No description provided for @setupAutoSync.
  ///
  /// In en, this message translates to:
  /// **'Sync automatically when online'**
  String get setupAutoSync;

  /// No description provided for @setupBackup.
  ///
  /// In en, this message translates to:
  /// **'Backup & sync'**
  String get setupBackup;

  /// No description provided for @setupBankAccounts.
  ///
  /// In en, this message translates to:
  /// **'Institution bank accounts'**
  String get setupBankAccounts;

  /// No description provided for @setupDemoNote.
  ///
  /// In en, this message translates to:
  /// **'Sample data lives only in the DEMO workspace and is never mixed with real records.'**
  String get setupDemoNote;

  /// No description provided for @setupFinancialYear.
  ///
  /// In en, this message translates to:
  /// **'Financial year'**
  String get setupFinancialYear;

  /// No description provided for @setupFinish.
  ///
  /// In en, this message translates to:
  /// **'Finish setup'**
  String get setupFinish;

  /// No description provided for @setupFundCategories.
  ///
  /// In en, this message translates to:
  /// **'Fund categories'**
  String get setupFundCategories;

  /// No description provided for @setupFunds.
  ///
  /// In en, this message translates to:
  /// **'Funds & purposes'**
  String get setupFunds;

  /// No description provided for @setupFyEnd.
  ///
  /// In en, this message translates to:
  /// **'Year ends'**
  String get setupFyEnd;

  /// No description provided for @setupFyStart.
  ///
  /// In en, this message translates to:
  /// **'Year starts'**
  String get setupFyStart;

  /// No description provided for @setupInstitution.
  ///
  /// In en, this message translates to:
  /// **'Institution'**
  String get setupInstitution;

  /// No description provided for @setupLogo.
  ///
  /// In en, this message translates to:
  /// **'Institution logo'**
  String get setupLogo;

  /// No description provided for @setupNameEn.
  ///
  /// In en, this message translates to:
  /// **'Institution name (English)'**
  String get setupNameEn;

  /// No description provided for @setupNameUr.
  ///
  /// In en, this message translates to:
  /// **'Institution name (Urdu)'**
  String get setupNameUr;

  /// No description provided for @setupNtn.
  ///
  /// In en, this message translates to:
  /// **'NTN (if applicable)'**
  String get setupNtn;

  /// No description provided for @setupNumbering.
  ///
  /// In en, this message translates to:
  /// **'Receipt numbering'**
  String get setupNumbering;

  /// No description provided for @setupNumberingFormat.
  ///
  /// In en, this message translates to:
  /// **'Numbering format'**
  String get setupNumberingFormat;

  /// No description provided for @setupPaymentMethods.
  ///
  /// In en, this message translates to:
  /// **'Accepted payment methods'**
  String get setupPaymentMethods;

  /// No description provided for @setupPayments.
  ///
  /// In en, this message translates to:
  /// **'Payments'**
  String get setupPayments;

  /// No description provided for @setupPickLogo.
  ///
  /// In en, this message translates to:
  /// **'Choose logo'**
  String get setupPickLogo;

  /// No description provided for @setupPrefix.
  ///
  /// In en, this message translates to:
  /// **'Receipt prefix'**
  String get setupPrefix;

  /// No description provided for @setupPrintFormat.
  ///
  /// In en, this message translates to:
  /// **'Default print format'**
  String get setupPrintFormat;

  /// No description provided for @setupPurposes.
  ///
  /// In en, this message translates to:
  /// **'Expenditure purposes'**
  String get setupPurposes;

  /// No description provided for @setupReceiptLanguage.
  ///
  /// In en, this message translates to:
  /// **'Receipt language'**
  String get setupReceiptLanguage;

  /// No description provided for @setupRegNo.
  ///
  /// In en, this message translates to:
  /// **'Registration number'**
  String get setupRegNo;

  /// No description provided for @setupRegistration.
  ///
  /// In en, this message translates to:
  /// **'Registration'**
  String get setupRegistration;

  /// No description provided for @setupRoles.
  ///
  /// In en, this message translates to:
  /// **'Roles & approvals'**
  String get setupRoles;

  /// No description provided for @setupSignatories.
  ///
  /// In en, this message translates to:
  /// **'Authorized signatories'**
  String get setupSignatories;

  /// No description provided for @setupSignatoryName.
  ///
  /// In en, this message translates to:
  /// **'Signatory name'**
  String get setupSignatoryName;

  /// No description provided for @setupSignatoryTitle.
  ///
  /// In en, this message translates to:
  /// **'Title'**
  String get setupSignatoryTitle;

  /// No description provided for @setupWelcome.
  ///
  /// In en, this message translates to:
  /// **'Welcome'**
  String get setupWelcome;

  /// No description provided for @setupWelcomeBody.
  ///
  /// In en, this message translates to:
  /// **'Let\'s set up your madrasa in a few steps. You can change everything later from Settings.'**
  String get setupWelcomeBody;

  /// No description provided for @staffNotes.
  ///
  /// In en, this message translates to:
  /// **'Staff notes (not shown to donor)'**
  String get staffNotes;

  /// No description provided for @statusConfirmed.
  ///
  /// In en, this message translates to:
  /// **'Confirmed'**
  String get statusConfirmed;

  /// No description provided for @statusDraft.
  ///
  /// In en, this message translates to:
  /// **'Draft'**
  String get statusDraft;

  /// No description provided for @statusPendingVerification.
  ///
  /// In en, this message translates to:
  /// **'Pending verification'**
  String get statusPendingVerification;

  /// No description provided for @statusPledge.
  ///
  /// In en, this message translates to:
  /// **'Pledge'**
  String get statusPledge;

  /// No description provided for @statusReversed.
  ///
  /// In en, this message translates to:
  /// **'Reversed'**
  String get statusReversed;

  /// No description provided for @statusVoided.
  ///
  /// In en, this message translates to:
  /// **'Voided'**
  String get statusVoided;

  /// No description provided for @syncConflicts.
  ///
  /// In en, this message translates to:
  /// **'Conflicts'**
  String get syncConflicts;

  /// No description provided for @syncFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed'**
  String get syncFailed;

  /// No description provided for @syncNow.
  ///
  /// In en, this message translates to:
  /// **'Sync now'**
  String get syncNow;

  /// No description provided for @syncPending.
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get syncPending;

  /// No description provided for @syncResolve.
  ///
  /// In en, this message translates to:
  /// **'Send to review'**
  String get syncResolve;

  /// No description provided for @syncTitle.
  ///
  /// In en, this message translates to:
  /// **'Sync Center'**
  String get syncTitle;

  /// No description provided for @tagline.
  ///
  /// In en, this message translates to:
  /// **'Trusted donation management'**
  String get tagline;

  /// No description provided for @txBankTransfer.
  ///
  /// In en, this message translates to:
  /// **'Bank transfer'**
  String get txBankTransfer;

  /// No description provided for @txCash.
  ///
  /// In en, this message translates to:
  /// **'Cash received'**
  String get txCash;

  /// No description provided for @txCheque.
  ///
  /// In en, this message translates to:
  /// **'Cheque (cleared)'**
  String get txCheque;

  /// No description provided for @txPending.
  ///
  /// In en, this message translates to:
  /// **'Pending bank/wallet payment'**
  String get txPending;

  /// No description provided for @txPledge.
  ///
  /// In en, this message translates to:
  /// **'Pledge / promised donation'**
  String get txPledge;

  /// No description provided for @txWallet.
  ///
  /// In en, this message translates to:
  /// **'Mobile wallet'**
  String get txWallet;

  /// No description provided for @verifyConfirm.
  ///
  /// In en, this message translates to:
  /// **'Confirm receipt of payment'**
  String get verifyConfirm;

  /// No description provided for @verifyEvidenceHint.
  ///
  /// In en, this message translates to:
  /// **'Verified against bank record / cash in hand'**
  String get verifyEvidenceHint;

  /// No description provided for @verifyTitle.
  ///
  /// In en, this message translates to:
  /// **'Verify payment'**
  String get verifyTitle;

  /// No description provided for @warnAllocation.
  ///
  /// In en, this message translates to:
  /// **'Fund allocation is incomplete or invalid.'**
  String get warnAllocation;

  /// No description provided for @warnDuplicate.
  ///
  /// In en, this message translates to:
  /// **'A similar receipt exists — possible duplicate.'**
  String get warnDuplicate;

  /// No description provided for @warnUnverified.
  ///
  /// In en, this message translates to:
  /// **'Payment is not yet verified. Only a provisional acknowledgment will be issued.'**
  String get warnUnverified;

  /// No description provided for @wizardStage1.
  ///
  /// In en, this message translates to:
  /// **'Transaction type'**
  String get wizardStage1;

  /// No description provided for @wizardStage2.
  ///
  /// In en, this message translates to:
  /// **'Donor'**
  String get wizardStage2;

  /// No description provided for @wizardStage3.
  ///
  /// In en, this message translates to:
  /// **'Amount & allocation'**
  String get wizardStage3;

  /// No description provided for @wizardStage4.
  ///
  /// In en, this message translates to:
  /// **'Payment details'**
  String get wizardStage4;

  /// No description provided for @wizardStage5.
  ///
  /// In en, this message translates to:
  /// **'Review'**
  String get wizardStage5;

  /// No description provided for @wizardStage6.
  ///
  /// In en, this message translates to:
  /// **'Issue receipt'**
  String get wizardStage6;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) =>
      <String>['en', 'ur'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'en':
      return AppLocalizationsEn();
    case 'ur':
      return AppLocalizationsUr();
  }

  throw FlutterError(
      'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
      'an issue with the localizations generation tool. Please file an issue '
      'on GitHub with a reproducible sample app and the gen-l10n configuration '
      'that was used.');
}
