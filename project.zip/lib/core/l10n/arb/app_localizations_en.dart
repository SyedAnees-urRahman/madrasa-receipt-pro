// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get allocationAdd => 'Add allocation';

  @override
  String get allocationFund => 'Fund';

  @override
  String get allocationPurpose => 'Purpose';

  @override
  String get allocationTotalMismatch =>
      'Allocation total must exactly equal the receipt total.';

  @override
  String get amountInWordsEn => 'Amount in words (English)';

  @override
  String get amountInWordsUr => 'Amount in words (Urdu)';

  @override
  String get amountPkr => 'Amount (PKR)';

  @override
  String get appName => 'Madrasa Receipt Pro';

  @override
  String get auditAction => 'Action';

  @override
  String get auditActor => 'Actor';

  @override
  String get auditReason => 'Reason';

  @override
  String get auditTime => 'Time';

  @override
  String get backupLast => 'Last backup';

  @override
  String get backupNow => 'Back up now';

  @override
  String get backupRestore => 'Restore';

  @override
  String get commonAddress => 'Address';

  @override
  String get commonAmount => 'Amount';

  @override
  String get commonBack => 'Back';

  @override
  String get commonCancel => 'Cancel';

  @override
  String get commonClose => 'Close';

  @override
  String get commonConfirm => 'Confirm';

  @override
  String get commonDate => 'Date';

  @override
  String get commonDelete => 'Delete';

  @override
  String get commonDone => 'Done';

  @override
  String get commonEdit => 'Edit';

  @override
  String get commonEmail => 'Email';

  @override
  String get commonError => 'Something went wrong';

  @override
  String get commonExport => 'Export';

  @override
  String get commonFilter => 'Filter';

  @override
  String get commonLoading => 'Loading…';

  @override
  String get commonName => 'Name';

  @override
  String get commonNext => 'Next';

  @override
  String get commonNo => 'No';

  @override
  String get commonNoData => 'No records found';

  @override
  String get commonNotes => 'Notes';

  @override
  String get commonOptional => 'Optional';

  @override
  String get commonPhone => 'Phone';

  @override
  String get commonPreview => 'Preview';

  @override
  String get commonPrint => 'Print';

  @override
  String get commonRequired => 'Required';

  @override
  String get commonRetry => 'Retry';

  @override
  String get commonSave => 'Save';

  @override
  String get commonSearch => 'Search';

  @override
  String get commonShare => 'Share';

  @override
  String get commonStatus => 'Status';

  @override
  String get commonThisMonth => 'This month';

  @override
  String get commonToday => 'Today';

  @override
  String get commonTotal => 'Total';

  @override
  String get commonYes => 'Yes';

  @override
  String get currencyPkr => 'PKR';

  @override
  String get dashFailedSync => 'Failed syncs needing attention';

  @override
  String get dashFundBalances => 'Fund balances';

  @override
  String get dashLastSync => 'Last successful sync';

  @override
  String get dashMonthConfirmed => 'This month\'s confirmed collections';

  @override
  String get dashNeverSynced => 'Never synced';

  @override
  String get dashOfflinePending => 'Offline records awaiting sync';

  @override
  String get dashPendingVerification => 'Pending verifications';

  @override
  String get dashRecentAudit => 'Recent audit events';

  @override
  String get dashRecentExpenses => 'Recent expense vouchers';

  @override
  String get dashRecentReceipts => 'Recent receipts';

  @override
  String dashStaleWarning(Object time) {
    return 'Figures may be stale — last synced $time.';
  }

  @override
  String get dashTodayConfirmed => 'Today\'s confirmed collections';

  @override
  String get demoBadge => 'DEMO';

  @override
  String get demoBanner =>
      'DEMO workspace — sample data only. Not real financial records.';

  @override
  String get demoWorkspace => 'Demo workspace';

  @override
  String get donorAnonymous => 'Anonymous donation';

  @override
  String get donorName => 'Donor name';

  @override
  String get donorNew => 'New donor';

  @override
  String get donorNote => 'Note for donor (appears on receipt)';

  @override
  String get donorSearchHint => 'Search donors by name or phone';

  @override
  String get errorInvalidAmount => 'Enter a valid amount greater than zero.';

  @override
  String get errorNetwork =>
      'No internet connection. Your work is saved locally and will sync later.';

  @override
  String get errorPermission => 'You do not have permission for this action.';

  @override
  String get errorRequired => 'This field is required.';

  @override
  String get errorSelfApproval =>
      'Self-approval is not allowed. Another authorized person must approve.';

  @override
  String get expenseApprove => 'Approve';

  @override
  String get expenseDescription => 'Description';

  @override
  String get expenseMarkPaid => 'Mark as paid';

  @override
  String get expenseNew => 'New expense voucher';

  @override
  String get expenseOverBudget => 'This exceeds the available fund balance.';

  @override
  String get expensePayee => 'Payee / vendor';

  @override
  String get expenseReject => 'Reject';

  @override
  String get expenseStatus => 'Voucher status';

  @override
  String get expenseVoucherNo => 'Voucher no.';

  @override
  String get exportCsv => 'Export CSV';

  @override
  String get exportPdf => 'Export PDF';

  @override
  String get exportXlsx => 'Export Excel';

  @override
  String get issueOfficial => 'Issue official receipt';

  @override
  String get issueProvisional => 'Save as provisional';

  @override
  String get issueSave => 'Save receipt';

  @override
  String get loginBiometric => 'Use biometrics';

  @override
  String get loginButton => 'Sign in';

  @override
  String get loginEmail => 'Email';

  @override
  String get loginFailed => 'Sign in failed. Check your email and password.';

  @override
  String get loginPassword => 'Password';

  @override
  String get loginSessionExpired =>
      'Your session has expired. Please sign in again.';

  @override
  String get loginTitle => 'Sign in';

  @override
  String get logoutConfirm => 'Sign out of this device?';

  @override
  String get menuAudit => 'Audit History';

  @override
  String get menuBackup => 'Backup & Restore';

  @override
  String get menuBooks => 'Cash & Bank Books';

  @override
  String get menuDonors => 'Donors';

  @override
  String get menuExpenses => 'Expenses';

  @override
  String get menuFunds => 'Funds';

  @override
  String get menuReconciliation => 'Bank Reconciliation';

  @override
  String get menuStaff => 'Staff & Permissions';

  @override
  String get menuVerification => 'Payment Verification';

  @override
  String get navHome => 'Home';

  @override
  String get navNewReceipt => 'New Receipt';

  @override
  String get navReceipts => 'Receipts';

  @override
  String get navReports => 'Reports';

  @override
  String get navSettings => 'Settings';

  @override
  String get payDate => 'Transaction date';

  @override
  String get payEvidence => 'Supporting evidence (private)';

  @override
  String get payMethod => 'Payment method';

  @override
  String get payReceivingAccount => 'Receiving account';

  @override
  String get payReference => 'Transaction / cheque reference';

  @override
  String get pdfDuplicateLabel => 'DUPLICATE COPY';

  @override
  String get pdfProvisionalLabel => 'PROVISIONAL — NOT AN OFFICIAL RECEIPT';

  @override
  String get pdfThankYou =>
      'May Allah accept your donation and reward you abundantly.';

  @override
  String get receiptHistory => 'History';

  @override
  String get receiptIssueDate => 'Issue date';

  @override
  String get receiptNumber => 'Receipt no.';

  @override
  String get receiptReverse => 'Reverse receipt';

  @override
  String get receiptVoid => 'Void receipt';

  @override
  String get receiptVoidReason => 'Reason (required)';

  @override
  String get reportAnnualRegister => 'Annual receipt register';

  @override
  String get reportAuditLog => 'Audit event log';

  @override
  String get reportBalances => 'Opening & closing balances';

  @override
  String get reportBankbook => 'Bankbook';

  @override
  String get reportCanceled => 'Canceled / reversed receipts';

  @override
  String get reportCashbook => 'Cashbook';

  @override
  String get reportDaily => 'Daily collection report';

  @override
  String get reportDonorHistory => 'Donor-wise history';

  @override
  String get reportExpenseRegister => 'Expense voucher register';

  @override
  String get reportFundIncomeExpense => 'Fund-wise income & expenditure';

  @override
  String get reportFundReceipts => 'Fund-wise receipts';

  @override
  String get reportMonthlyRegister => 'Monthly receipt register';

  @override
  String get reportPaymentMethod => 'Payment-method summary';

  @override
  String get reportPendingVerification => 'Pending verification report';

  @override
  String get reportPurposeCollections => 'Purpose-wise collections';

  @override
  String get reportReconciliation => 'Bank reconciliation';

  @override
  String get reportSyncConflicts => 'Sync & conflict report';

  @override
  String get reviewWarnings => 'Warnings';

  @override
  String get roleAccountant => 'Accountant';

  @override
  String get roleAdmin => 'Administrator';

  @override
  String get roleAuditor => 'Auditor';

  @override
  String get roleOperator => 'Receipt Operator';

  @override
  String get roleVerifier => 'Payment Verifier';

  @override
  String get settingsAccessibility => 'Accessibility';

  @override
  String get settingsAppearance => 'Appearance';

  @override
  String get settingsInstitution => 'Institution profile';

  @override
  String get settingsLanguage => 'Language';

  @override
  String get setupAddAccount => 'Add account';

  @override
  String get setupAddFund => 'Add fund';

  @override
  String get setupAddPurpose => 'Add purpose';

  @override
  String get setupAddSignatory => 'Add signatory';

  @override
  String get setupAddress => 'Address & contact';

  @override
  String get setupApprovalThreshold => 'Two-person approval above (PKR)';

  @override
  String get setupAutoSync => 'Sync automatically when online';

  @override
  String get setupBackup => 'Backup & sync';

  @override
  String get setupBankAccounts => 'Institution bank accounts';

  @override
  String get setupDemoNote =>
      'Sample data lives only in the DEMO workspace and is never mixed with real records.';

  @override
  String get setupFinancialYear => 'Financial year';

  @override
  String get setupFinish => 'Finish setup';

  @override
  String get setupFundCategories => 'Fund categories';

  @override
  String get setupFunds => 'Funds & purposes';

  @override
  String get setupFyEnd => 'Year ends';

  @override
  String get setupFyStart => 'Year starts';

  @override
  String get setupInstitution => 'Institution';

  @override
  String get setupLogo => 'Institution logo';

  @override
  String get setupNameEn => 'Institution name (English)';

  @override
  String get setupNameUr => 'Institution name (Urdu)';

  @override
  String get setupNtn => 'NTN (if applicable)';

  @override
  String get setupNumbering => 'Receipt numbering';

  @override
  String get setupNumberingFormat => 'Numbering format';

  @override
  String get setupPaymentMethods => 'Accepted payment methods';

  @override
  String get setupPayments => 'Payments';

  @override
  String get setupPickLogo => 'Choose logo';

  @override
  String get setupPrefix => 'Receipt prefix';

  @override
  String get setupPrintFormat => 'Default print format';

  @override
  String get setupPurposes => 'Expenditure purposes';

  @override
  String get setupReceiptLanguage => 'Receipt language';

  @override
  String get setupRegNo => 'Registration number';

  @override
  String get setupRegistration => 'Registration';

  @override
  String get setupRoles => 'Roles & approvals';

  @override
  String get setupSignatories => 'Authorized signatories';

  @override
  String get setupSignatoryName => 'Signatory name';

  @override
  String get setupSignatoryTitle => 'Title';

  @override
  String get setupWelcome => 'Welcome';

  @override
  String get setupWelcomeBody =>
      'Let\'s set up your madrasa in a few steps. You can change everything later from Settings.';

  @override
  String get staffNotes => 'Staff notes (not shown to donor)';

  @override
  String get statusConfirmed => 'Confirmed';

  @override
  String get statusDraft => 'Draft';

  @override
  String get statusPendingVerification => 'Pending verification';

  @override
  String get statusPledge => 'Pledge';

  @override
  String get statusReversed => 'Reversed';

  @override
  String get statusVoided => 'Voided';

  @override
  String get syncConflicts => 'Conflicts';

  @override
  String get syncFailed => 'Failed';

  @override
  String get syncNow => 'Sync now';

  @override
  String get syncPending => 'Pending';

  @override
  String get syncResolve => 'Send to review';

  @override
  String get syncTitle => 'Sync Center';

  @override
  String get tagline => 'Trusted donation management';

  @override
  String get txBankTransfer => 'Bank transfer';

  @override
  String get txCash => 'Cash received';

  @override
  String get txCheque => 'Cheque (cleared)';

  @override
  String get txPending => 'Pending bank/wallet payment';

  @override
  String get txPledge => 'Pledge / promised donation';

  @override
  String get txWallet => 'Mobile wallet';

  @override
  String get verifyConfirm => 'Confirm receipt of payment';

  @override
  String get verifyEvidenceHint =>
      'Verified against bank record / cash in hand';

  @override
  String get verifyTitle => 'Verify payment';

  @override
  String get warnAllocation => 'Fund allocation is incomplete or invalid.';

  @override
  String get warnDuplicate => 'A similar receipt exists — possible duplicate.';

  @override
  String get warnUnverified =>
      'Payment is not yet verified. Only a provisional acknowledgment will be issued.';

  @override
  String get wizardStage1 => 'Transaction type';

  @override
  String get wizardStage2 => 'Donor';

  @override
  String get wizardStage3 => 'Amount & allocation';

  @override
  String get wizardStage4 => 'Payment details';

  @override
  String get wizardStage5 => 'Review';

  @override
  String get wizardStage6 => 'Issue receipt';
}
