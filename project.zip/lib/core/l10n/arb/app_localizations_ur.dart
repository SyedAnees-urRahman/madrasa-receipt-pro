// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Urdu (`ur`).
class AppLocalizationsUr extends AppLocalizations {
  AppLocalizationsUr([String locale = 'ur']) : super(locale);

  @override
  String get allocationAdd => 'تقسیم شامل کریں';

  @override
  String get allocationFund => 'فنڈ';

  @override
  String get allocationPurpose => 'مصرف';

  @override
  String get allocationTotalMismatch =>
      'تقسیم کا مجموعہ رسید کی رقم کے بالکل برابر ہونا چاہیے۔';

  @override
  String get amountInWordsEn => 'رقم لفظوں میں (انگریزی)';

  @override
  String get amountInWordsUr => 'رقم لفظوں میں (اردو)';

  @override
  String get amountPkr => 'رقم (روپے)';

  @override
  String get appName => 'مدرسہ رسید پرو';

  @override
  String get auditAction => 'عمل';

  @override
  String get auditActor => 'عمل کرنے والا';

  @override
  String get auditReason => 'وجہ';

  @override
  String get auditTime => 'وقت';

  @override
  String get backupLast => 'آخری بیک اپ';

  @override
  String get backupNow => 'ابھی بیک اپ لیں';

  @override
  String get backupRestore => 'بحال کریں';

  @override
  String get commonAddress => 'پتہ';

  @override
  String get commonAmount => 'رقم';

  @override
  String get commonBack => 'پیچھے';

  @override
  String get commonCancel => 'منسوخ';

  @override
  String get commonClose => 'بند کریں';

  @override
  String get commonConfirm => 'تصدیق کریں';

  @override
  String get commonDate => 'تاریخ';

  @override
  String get commonDelete => 'حذف کریں';

  @override
  String get commonDone => 'مکمل';

  @override
  String get commonEdit => 'ترمیم';

  @override
  String get commonEmail => 'ای میل';

  @override
  String get commonError => 'کچھ غلط ہو گیا';

  @override
  String get commonExport => 'برآمد کریں';

  @override
  String get commonFilter => 'فلٹر';

  @override
  String get commonLoading => 'لوڈ ہو رہا ہے…';

  @override
  String get commonName => 'نام';

  @override
  String get commonNext => 'آگے';

  @override
  String get commonNo => 'نہیں';

  @override
  String get commonNoData => 'کوئی ریکارڈ نہیں ملا';

  @override
  String get commonNotes => 'نوٹس';

  @override
  String get commonOptional => 'اختیاری';

  @override
  String get commonPhone => 'فون';

  @override
  String get commonPreview => 'پیش نظارہ';

  @override
  String get commonPrint => 'پرنٹ';

  @override
  String get commonRequired => 'لازمی';

  @override
  String get commonRetry => 'دوبارہ کوشش';

  @override
  String get commonSave => 'محفوظ کریں';

  @override
  String get commonSearch => 'تلاش';

  @override
  String get commonShare => 'شیئر';

  @override
  String get commonStatus => 'حیثیت';

  @override
  String get commonThisMonth => 'اس ماہ';

  @override
  String get commonToday => 'آج';

  @override
  String get commonTotal => 'کل';

  @override
  String get commonYes => 'جی ہاں';

  @override
  String get currencyPkr => 'روپے';

  @override
  String get dashFailedSync => 'توجہ طلب ناکام مطابقت پذیری';

  @override
  String get dashFundBalances => 'فنڈ بیلنس';

  @override
  String get dashLastSync => 'آخری کامیاب مطابقت';

  @override
  String get dashMonthConfirmed => 'اس ماہ کی مصدقہ وصولیاں';

  @override
  String get dashNeverSynced => 'کبھی مطابقت نہیں ہوئی';

  @override
  String get dashOfflinePending => 'آف لائن ریکارڈ — مطابقت باقی';

  @override
  String get dashPendingVerification => 'تصدیق کے منتظر';

  @override
  String get dashRecentAudit => 'حالیہ آڈٹ واقعات';

  @override
  String get dashRecentExpenses => 'حالیہ اخراجات';

  @override
  String get dashRecentReceipts => 'حالیہ رسیدیں';

  @override
  String dashStaleWarning(Object time) {
    return 'اعداد پرانے ہو سکتے ہیں — آخری مطابقت: $time۔';
  }

  @override
  String get dashTodayConfirmed => 'آج کی مصدقہ وصولیاں';

  @override
  String get demoBadge => 'ڈیمو';

  @override
  String get demoBanner =>
      'ڈیمو ورک اسپیس — صرف نمونہ ڈیٹا۔ یہ حقیقی مالی ریکارڈ نہیں۔';

  @override
  String get demoWorkspace => 'ڈیمو ورک اسپیس';

  @override
  String get donorAnonymous => 'گمنام عطیہ';

  @override
  String get donorName => 'عطیہ دہندہ کا نام';

  @override
  String get donorNew => 'نیا عطیہ دہندہ';

  @override
  String get donorNote => 'عطیہ دہندہ کے لیے نوٹ (رسید پر ظاہر ہوگا)';

  @override
  String get donorSearchHint => 'نام یا فون سے عطیہ دہندہ تلاش کریں';

  @override
  String get errorInvalidAmount => 'درست رقم درج کریں جو صفر سے زیادہ ہو۔';

  @override
  String get errorNetwork =>
      'انٹرنیٹ نہیں ہے۔ آپ کا کام مقامی طور پر محفوظ ہے، بعد میں مطابقت ہو جائے گی۔';

  @override
  String get errorPermission => 'آپ کو اس عمل کی اجازت نہیں۔';

  @override
  String get errorRequired => 'یہ خانہ لازمی ہے۔';

  @override
  String get errorSelfApproval =>
      'اپنی منظوری جائز نہیں۔ کسی دوسرے مجاز شخص سے منظور کروائیں۔';

  @override
  String get expenseApprove => 'منظور کریں';

  @override
  String get expenseDescription => 'تفصیل';

  @override
  String get expenseMarkPaid => 'ادا شدہ قرار دیں';

  @override
  String get expenseNew => 'نیا اخراجات واؤچر';

  @override
  String get expenseOverBudget => 'یہ فنڈ کے دستیاب بیلنس سے زیادہ ہے۔';

  @override
  String get expensePayee => 'وصول کنندہ / دکاندار';

  @override
  String get expenseReject => 'مسترد کریں';

  @override
  String get expenseStatus => 'واؤچر کی حیثیت';

  @override
  String get expenseVoucherNo => 'واؤچر نمبر';

  @override
  String get exportCsv => 'CSV برآمد کریں';

  @override
  String get exportPdf => 'PDF برآمد کریں';

  @override
  String get exportXlsx => 'ایکسل برآمد کریں';

  @override
  String get issueOfficial => 'سرکاری رسید جاری کریں';

  @override
  String get issueProvisional => 'عارضی طور پر محفوظ کریں';

  @override
  String get issueSave => 'رسید محفوظ کریں';

  @override
  String get loginBiometric => 'بائیومیٹرک استعمال کریں';

  @override
  String get loginButton => 'لاگ اِن';

  @override
  String get loginEmail => 'ای میل';

  @override
  String get loginFailed => 'لاگ اِن ناکام۔ ای میل اور پاس ورڈ چیک کریں۔';

  @override
  String get loginPassword => 'پاس ورڈ';

  @override
  String get loginSessionExpired =>
      'آپ کا سیشن ختم ہو گیا۔ دوبارہ لاگ اِن کریں۔';

  @override
  String get loginTitle => 'لاگ اِن';

  @override
  String get logoutConfirm => 'اس ڈیوائس سے لاگ آؤٹ کریں؟';

  @override
  String get menuAudit => 'آڈٹ تاریخ';

  @override
  String get menuBackup => 'بیک اپ و بحالی';

  @override
  String get menuBooks => 'کیش و بینک کتب';

  @override
  String get menuDonors => 'عطیہ دہندگان';

  @override
  String get menuExpenses => 'اخراجات';

  @override
  String get menuFunds => 'فنڈز';

  @override
  String get menuReconciliation => 'بینک مفاہمت';

  @override
  String get menuStaff => 'عملہ و اجازتیں';

  @override
  String get menuVerification => 'ادائیگی کی تصدیق';

  @override
  String get navHome => 'ہوم';

  @override
  String get navNewReceipt => 'نئی رسید';

  @override
  String get navReceipts => 'رسیدیں';

  @override
  String get navReports => 'رپورٹس';

  @override
  String get navSettings => 'ترتیبات';

  @override
  String get payDate => 'لین دین کی تاریخ';

  @override
  String get payEvidence => 'ثبوت (نجی)';

  @override
  String get payMethod => 'ادائیگی کا طریقہ';

  @override
  String get payReceivingAccount => 'وصول کنندہ اکاؤنٹ';

  @override
  String get payReference => 'لین دین / چیک حوالہ';

  @override
  String get pdfDuplicateLabel => 'نقل — ڈپلیکیٹ کاپی';

  @override
  String get pdfProvisionalLabel => 'عارضی — یہ سرکاری رسید نہیں';

  @override
  String get pdfThankYou =>
      'اللہ تعالیٰ آپ کا عطیہ قبول فرمائے اور اجر عظیم عطا فرمائے۔';

  @override
  String get receiptHistory => 'تاریخچہ';

  @override
  String get receiptIssueDate => 'اجراء کی تاریخ';

  @override
  String get receiptNumber => 'رسید نمبر';

  @override
  String get receiptReverse => 'رسید واپس لیں';

  @override
  String get receiptVoid => 'رسید منسوخ کریں';

  @override
  String get receiptVoidReason => 'وجہ (لازمی)';

  @override
  String get reportAnnualRegister => 'سالانہ رسید رجسٹر';

  @override
  String get reportAuditLog => 'آڈٹ واقعات لاگ';

  @override
  String get reportBalances => 'ابتدائی و اختتامی بیلنس';

  @override
  String get reportBankbook => 'بینک بک';

  @override
  String get reportCanceled => 'منسوخ / واپس شدہ رسیدیں';

  @override
  String get reportCashbook => 'کیش بک';

  @override
  String get reportDaily => 'روزانہ وصولی رپورٹ';

  @override
  String get reportDonorHistory => 'عطیہ دہندہ وار تاریخ';

  @override
  String get reportExpenseRegister => 'اخراجات واؤچر رجسٹر';

  @override
  String get reportFundIncomeExpense => 'فنڈ وار آمدن و اخراجات';

  @override
  String get reportFundReceipts => 'فنڈ وار رسیدیں';

  @override
  String get reportMonthlyRegister => 'ماہانہ رسید رجسٹر';

  @override
  String get reportPaymentMethod => 'طریقۂ ادائیگی خلاصہ';

  @override
  String get reportPendingVerification => 'تصدیق کے منتظر رپورٹ';

  @override
  String get reportPurposeCollections => 'مصرف وار وصولیاں';

  @override
  String get reportReconciliation => 'بینک مفاہمت';

  @override
  String get reportSyncConflicts => 'مطابقت و تنازعات رپورٹ';

  @override
  String get reviewWarnings => 'تنبیہات';

  @override
  String get roleAccountant => 'محاسب';

  @override
  String get roleAdmin => 'منتظم';

  @override
  String get roleAuditor => 'آڈیٹر';

  @override
  String get roleOperator => 'رسید آپریٹر';

  @override
  String get roleVerifier => 'ادائیگی تصدیق کنندہ';

  @override
  String get settingsAccessibility => 'رسائی';

  @override
  String get settingsAppearance => 'ظاہری شکل';

  @override
  String get settingsInstitution => 'ادارے کی پروفائل';

  @override
  String get settingsLanguage => 'زبان';

  @override
  String get setupAddAccount => 'اکاؤنٹ شامل کریں';

  @override
  String get setupAddFund => 'فنڈ شامل کریں';

  @override
  String get setupAddPurpose => 'مصرف شامل کریں';

  @override
  String get setupAddSignatory => 'دستخط کنندہ شامل کریں';

  @override
  String get setupAddress => 'پتہ و رابطہ';

  @override
  String get setupApprovalThreshold =>
      'دو افراد کی منظوری اس رقم سے زائد (روپے)';

  @override
  String get setupAutoSync => 'آن لائن ہوتے ہی خودکار مطابقت';

  @override
  String get setupBackup => 'بیک اپ و مطابقت';

  @override
  String get setupBankAccounts => 'ادارے کے بینک اکاؤنٹس';

  @override
  String get setupDemoNote =>
      'نمونہ ڈیٹا صرف ڈیمو ورک اسپیس میں رہتا ہے، حقیقی ریکارڈ سے کبھی نہیں ملتا۔';

  @override
  String get setupFinancialYear => 'مالی سال';

  @override
  String get setupFinish => 'سیٹ اپ مکمل کریں';

  @override
  String get setupFundCategories => 'فنڈ کی اقسام';

  @override
  String get setupFunds => 'فنڈز و مصارف';

  @override
  String get setupFyEnd => 'سال کا اختتام';

  @override
  String get setupFyStart => 'سال کا آغاز';

  @override
  String get setupInstitution => 'ادارہ';

  @override
  String get setupLogo => 'ادارے کا لوگو';

  @override
  String get setupNameEn => 'ادارے کا نام (انگریزی)';

  @override
  String get setupNameUr => 'ادارے کا نام (اردو)';

  @override
  String get setupNtn => 'NTN (اگر ہو)';

  @override
  String get setupNumbering => 'رسید نمبرنگ';

  @override
  String get setupNumberingFormat => 'نمبرنگ فارمیٹ';

  @override
  String get setupPaymentMethods => 'قبول شدہ ادائیگی کے طریقے';

  @override
  String get setupPayments => 'ادائیگیاں';

  @override
  String get setupPickLogo => 'لوگو منتخب کریں';

  @override
  String get setupPrefix => 'رسید کا سابقہ';

  @override
  String get setupPrintFormat => 'طے شدہ پرنٹ فارمیٹ';

  @override
  String get setupPurposes => 'اخراجات کے مصارف';

  @override
  String get setupReceiptLanguage => 'رسید کی زبان';

  @override
  String get setupRegNo => 'رجسٹریشن نمبر';

  @override
  String get setupRegistration => 'رجسٹریشن';

  @override
  String get setupRoles => 'کردار و منظوری';

  @override
  String get setupSignatories => 'مجاز دستخط کنندگان';

  @override
  String get setupSignatoryName => 'دستخط کنندہ کا نام';

  @override
  String get setupSignatoryTitle => 'عہدہ';

  @override
  String get setupWelcome => 'خوش آمدید';

  @override
  String get setupWelcomeBody =>
      'چند مراحل میں اپنا مدرسہ ترتیب دیں۔ بعد میں ترتیبات سے سب کچھ بدلا جا سکتا ہے۔';

  @override
  String get staffNotes => 'عملے کے نوٹس (عطیہ دہندہ کو نظر نہیں آئیں گے)';

  @override
  String get statusConfirmed => 'مصدقہ';

  @override
  String get statusDraft => 'مسودہ';

  @override
  String get statusPendingVerification => 'تصدیق منتظر';

  @override
  String get statusPledge => 'وعدہ';

  @override
  String get statusReversed => 'واپس شدہ';

  @override
  String get statusVoided => 'منسوخ';

  @override
  String get syncConflicts => 'تنازعات';

  @override
  String get syncFailed => 'ناکام';

  @override
  String get syncNow => 'ابھی مطابقت کریں';

  @override
  String get syncPending => 'منتظر';

  @override
  String get syncResolve => 'جائزے کے لیے بھیجیں';

  @override
  String get syncTitle => 'مطابقت مرکز';

  @override
  String get tagline => 'قابلِ اعتماد عطیات کا انتظام';

  @override
  String get txBankTransfer => 'بینک ٹرانسفر';

  @override
  String get txCash => 'نقد وصول';

  @override
  String get txCheque => 'چیک (کلیئر شدہ)';

  @override
  String get txPending => 'منتظر بینک/والٹ ادائیگی';

  @override
  String get txPledge => 'وعدہ / متوقع عطیہ';

  @override
  String get txWallet => 'موبائل والٹ';

  @override
  String get verifyConfirm => 'ادائیگی کی وصولی کی تصدیق کریں';

  @override
  String get verifyEvidenceHint => 'بینک ریکارڈ / نقد وصولی سے تصدیق شدہ';

  @override
  String get verifyTitle => 'ادائیگی کی تصدیق';

  @override
  String get warnAllocation => 'فنڈ کی تقسیم نامکمل یا غلط ہے۔';

  @override
  String get warnDuplicate => 'اسی جیسی رسید موجود ہے — ممکنہ نقل۔';

  @override
  String get warnUnverified =>
      'ادائیگی کی ابھی تصدیق نہیں ہوئی۔ صرف عارضی رسید جاری ہوگی۔';

  @override
  String get wizardStage1 => 'لین دین کی قسم';

  @override
  String get wizardStage2 => 'عطیہ دہندہ';

  @override
  String get wizardStage3 => 'رقم و تقسیم';

  @override
  String get wizardStage4 => 'ادائیگی کی تفصیل';

  @override
  String get wizardStage5 => 'جائزہ';

  @override
  String get wizardStage6 => 'رسید جاری کریں';
}
