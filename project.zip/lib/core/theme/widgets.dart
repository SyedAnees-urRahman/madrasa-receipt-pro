import 'package:flutter/material.dart';
import 'app_colors.dart';
import 'app_typography.dart';

/// Reusable design-system widgets. All touch targets are >= 48dp,
/// every interactive element carries a semantic label.
class AppMotion {
  /// 180–260ms transitions; honors the OS reduced-motion setting.
  static Duration of(BuildContext context, [int ms = 220]) =>
      MediaQuery.disableAnimationsOf(context) ? Duration.zero : Duration(milliseconds: ms.clamp(180, 260));
}

class MrpPrimaryButton extends StatelessWidget {
  const MrpPrimaryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.loading = false,
    this.semanticLabel,
  });
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool loading;
  final String? semanticLabel;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: semanticLabel ?? label,
      child: FilledButton.icon(
        onPressed: loading ? null : onPressed,
        style: FilledButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, fontFamily: AppTypography.urduFont),
        ),
        icon: loading
            ? const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
              )
            : (icon != null ? Icon(icon, size: 20) : const SizedBox.shrink()),
        label: Text(label),
      ),
    );
  }
}

class MrpSecondaryButton extends StatelessWidget {
  const MrpSecondaryButton({super.key, required this.label, required this.onPressed, this.icon});
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        textStyle: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600, fontFamily: AppTypography.urduFont),
      ),
      icon: icon != null ? Icon(icon, size: 20) : const SizedBox.shrink(),
      label: Text(label),
    );
  }
}

class MrpTextField extends StatelessWidget {
  const MrpTextField({
    super.key,
    this.controller,
    this.label,
    this.hint,
    this.keyboardType,
    this.validator,
    this.onChanged,
    this.maxLines = 1,
    this.obscureText = false,
    this.prefixIcon,
    this.textDirection,
    this.semanticLabel,
    this.enabled = true,
  });
  final TextEditingController? controller;
  final String? label;
  final String? hint;
  final TextInputType? keyboardType;
  final String? Function(String?)? validator;
  final ValueChanged<String>? onChanged;
  final int maxLines;
  final bool obscureText;
  final IconData? prefixIcon;
  final TextDirection? textDirection;
  final String? semanticLabel;
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      textField: true,
      label: semanticLabel ?? label,
      child: TextFormField(
        controller: controller,
        enabled: enabled,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          prefixIcon: prefixIcon != null ? Icon(prefixIcon) : null,
        ),
        keyboardType: keyboardType,
        validator: validator,
        onChanged: onChanged,
        maxLines: maxLines,
        obscureText: obscureText,
        textDirection: textDirection,
      ),
    );
  }
}

class MrpCard extends StatelessWidget {
  const MrpCard({super.key, required this.child, this.onTap, this.padding});
  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry? padding;
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final bg = theme.scaffoldBackgroundColor;
    // Detect active decorative theme by its signature background color.
    final isClay = bg.value == const Color(0xFF7FB3DE).value;
    final isNeu = bg.value == const Color(0xFFE4EAF2).value;

    List<BoxShadow> shadows;
    double radius;
    if (isClay) {
      // Puffy clay 3D — like soft modeling clay, inflated
      radius = 22;
      shadows = [
        BoxShadow(
          color: const Color(0xFF4A7AB5).withOpacity(0.30),
          blurRadius: 18,
          offset: const Offset(0, 8),
          spreadRadius: 0,
        ),
        const BoxShadow(
          color: Colors.white,
          blurRadius: 10,
          offset: Offset(0, -3),
          spreadRadius: 0,
        ),
      ];
    } else if (isNeu) {
      // Neumorphic dual shadow
      radius = 20;
      shadows = [
        BoxShadow(
          color: const Color(0xFFB8C2D0).withOpacity(0.6),
          blurRadius: 16,
          offset: const Offset(6, 6),
        ),
        const BoxShadow(
          color: Colors.white,
          blurRadius: 16,
          offset: Offset(-6, -6),
        ),
      ];
    } else {
      // FinTech: clean white card, 20px radius, soft diffused shadow
      radius = 20;
      shadows = [
        BoxShadow(
          color: const Color(0xFF0F172A).withOpacity(0.06),
          blurRadius: 20,
          offset: const Offset(0, 6),
          spreadRadius: 0,
        ),
        BoxShadow(
          color: const Color(0xFF0F172A).withOpacity(0.04),
          blurRadius: 6,
          offset: const Offset(0, 2),
          spreadRadius: 0,
        ),
      ];
    }

    final card = Container(
      decoration: BoxDecoration(
        color: isClay || !isNeu ? Colors.white : theme.cardColor,
        borderRadius: BorderRadius.circular(radius),
        boxShadow: shadows,
        border: isClay || isNeu
            ? null
            : Border.all(color: const Color(0xFFE2E8F0), width: 1),
      ),
      child: Padding(
        padding: padding ?? const EdgeInsets.all(16),
        child: child,
      ),
    );
    if (onTap == null) return card;
    return InkWell(
      borderRadius: BorderRadius.circular(radius),
      onTap: onTap,
      child: card,
    );
  }
}

class MrpSectionHeader extends StatelessWidget {
  const MrpSectionHeader({super.key, required this.title, this.action});
  final String title;
  final Widget? action;
  @override
  Widget build(BuildContext context) {
    final isUrdu = Localizations.localeOf(context).languageCode == 'ur';
    return Padding(
      padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.lg, AppSpacing.lg, AppSpacing.sm),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: isUrdu ? AppTypography.titleUr.copyWith(fontSize: 18) : AppTypography.titleEn.copyWith(fontSize: 17),
            ),
          ),
          if (action != null) action!,
        ],
      ),
    );
  }
}

enum MrpStatusKind { success, warning, danger, info, neutral }

class MrpStatusBadge extends StatelessWidget {
  const MrpStatusBadge({super.key, required this.label, required this.kind});
  final String label;
  final MrpStatusKind kind;
  @override
  Widget build(BuildContext context) {
    final (bg, fg) = switch (kind) {
      MrpStatusKind.success => (AppColors.successBg, AppColors.success),
      MrpStatusKind.warning => (AppColors.warningBg, AppColors.warning),
      MrpStatusKind.danger => (AppColors.dangerBg, AppColors.danger),
      MrpStatusKind.info => (AppColors.infoBg, AppColors.info),
      MrpStatusKind.neutral => (AppColors.ivoryDeep, AppColors.ink500),
    };
    return Semantics(
      label: label,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: AppSpacing.xs),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(AppSpacing.radiusSm)),
        child: Text(label, style: TextStyle(color: fg, fontSize: 12, fontWeight: FontWeight.w600)),
      ),
    );
  }
}

class MrpKpiCard extends StatelessWidget {
  const MrpKpiCard({
    super.key,
    required this.title,
    required this.value,
    required this.icon,
    this.onTap,
    this.accent = AppColors.emerald700,
  });
  final String title;
  final String value;
  final IconData icon;
  final VoidCallback? onTap;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    final isUrdu = Localizations.localeOf(context).languageCode == 'ur';
    return MrpCard(
      onTap: onTap,
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: accent.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
            ),
            child: Icon(icon, color: accent, size: 26),
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(value, style: AppTypography.amountLarge.copyWith(fontSize: 20)),
                const SizedBox(height: 2),
                Text(
                  title,
                  style: isUrdu
                      ? AppTypography.captionUr
                      : AppTypography.captionEn,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Animated card entry (fades/slides in once). Disabled under reduced motion.
class MrpAnimatedEntry extends StatefulWidget {
  const MrpAnimatedEntry({super.key, required this.child, this.delayMs = 0});
  final Widget child;
  final int delayMs;
  @override
  State<MrpAnimatedEntry> createState() => _MrpAnimatedEntryState();
}

class _MrpAnimatedEntryState extends State<MrpAnimatedEntry> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late final Animation<double> _opacity;
  late final Animation<Offset> _offset;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 240));
    _opacity = CurvedAnimation(parent: _c, curve: Curves.easeOut);
    _offset = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeOut));
    if (widget.delayMs > 0) {
      Future.delayed(Duration(milliseconds: widget.delayMs), () {
        if (mounted) _c.forward();
      });
    } else {
      _c.forward();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (MediaQuery.disableAnimationsOf(context)) return widget.child;
    return FadeTransition(
      opacity: _opacity,
      child: SlideTransition(position: _offset, child: widget.child),
    );
  }
}

class MrpEmptyState extends StatelessWidget {
  const MrpEmptyState({super.key, required this.icon, required this.message, this.action});
  final IconData icon;
  final String message;
  final Widget? action;
  @override
  Widget build(BuildContext context) {
    final isUrdu = Localizations.localeOf(context).languageCode == 'ur';
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.xxl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 56, color: AppColors.ink300),
            const SizedBox(height: AppSpacing.md),
            Text(
              message,
              textAlign: TextAlign.center,
              style: isUrdu ? AppTypography.bodyUr : AppTypography.bodyEn,
            ),
            if (action != null) ...[
              const SizedBox(height: AppSpacing.lg),
              action!,
            ],
          ],
        ),
      ),
    );
  }
}

Future<bool> mrpConfirmDialog(
  BuildContext context, {
  required String title,
  required String body,
  required String confirmLabel,
  bool danger = false,
}) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(body),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(false),
          child: Text(MaterialLocalizations.of(ctx).cancelButtonLabel),
        ),
        FilledButton(
          style: danger ? FilledButton.styleFrom(backgroundColor: AppColors.danger) : null,
          onPressed: () => Navigator.of(ctx).pop(true),
          child: Text(confirmLabel),
        ),
      ],
    ),
  );
  return result ?? false;
}

void mrpShowSnack(BuildContext context, String message, {bool isError = false}) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? AppColors.danger : AppColors.emerald800,
      ),
    );
}
