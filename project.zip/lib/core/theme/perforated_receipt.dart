import 'package:flutter/material.dart';

/// Zigzag (perforated / "دھاگے دار") edge clipper for paper receipts,
/// like official receipt apps. Clips triangles along the top and bottom.
class PerforatedEdgeClipper extends CustomClipper<Path> {
  const PerforatedEdgeClipper({
    this.toothWidth = 12,
    this.toothHeight = 8,
    this.top = true,
    this.bottom = true,
  });

  final double toothWidth;
  final double toothHeight;
  final bool top;
  final bool bottom;

  @override
  Path getClip(Size size) {
    final path = Path();
    final teeth = (size.width / toothWidth).floor();
    final actualWidth = size.width / teeth;

    // Start at top-left, after the top teeth.
    if (top) {
      path.moveTo(0, toothHeight);
      for (var i = 0; i < teeth; i++) {
        final x = i * actualWidth;
        path.lineTo(x + actualWidth / 2, 0);
        path.lineTo(x + actualWidth, toothHeight);
      }
    } else {
      path.moveTo(0, 0);
      path.lineTo(size.width, 0);
    }

    // Right edge down.
    path.lineTo(size.width, bottom ? size.height - toothHeight : size.height);

    // Bottom teeth (right to left).
    if (bottom) {
      for (var i = teeth - 1; i >= 0; i--) {
        final x = i * actualWidth;
        path.lineTo(x + actualWidth / 2, size.height);
        path.lineTo(x, size.height - toothHeight);
      }
    }

    // Left edge up.
    path.lineTo(0, top ? toothHeight : 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant PerforatedEdgeClipper oldClipper) =>
      oldClipper.toothWidth != toothWidth ||
      oldClipper.toothHeight != toothHeight ||
      oldClipper.top != top ||
      oldClipper.bottom != bottom;
}

/// A paper-receipt card with zigzag perforated top/bottom edges and a
/// soft shadow, like official receipt apps.
class PerforatedReceiptCard extends StatelessWidget {
  const PerforatedReceiptCard({
    super.key,
    required this.child,
    this.backgroundColor = Colors.white,
    this.toothWidth = 12,
    this.toothHeight = 8,
  });

  final Widget child;
  final Color backgroundColor;
  final double toothWidth;
  final double toothHeight;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.10),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: ClipPath(
        clipper: PerforatedEdgeClipper(
          toothWidth: toothWidth,
          toothHeight: toothHeight,
        ),
        child: Container(
          color: backgroundColor,
          padding: EdgeInsets.fromLTRB(
              20, 20 + toothHeight, 20, 20 + toothHeight),
          child: child,
        ),
      ),
    );
  }
}
