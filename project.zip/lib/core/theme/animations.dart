import 'package:flutter/material.dart';

/// Staggered fade-and-slide-up entrance animation.
/// Wrap list items with increasing [index] for a cascading effect,
/// like official apps.
class MrpFadeUp extends StatefulWidget {
  const MrpFadeUp({
    super.key,
    required this.child,
    this.index = 0,
    this.delayMs = 70,
    this.durationMs = 450,
    this.offsetY = 24,
  });

  final Widget child;
  final int index;
  final int delayMs;
  final int durationMs;
  final double offsetY;

  @override
  State<MrpFadeUp> createState() => _MrpFadeUpState();
}

class _MrpFadeUpState extends State<MrpFadeUp>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _opacity;
  late final Animation<Offset> _offset;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: widget.durationMs),
    );
    _opacity = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _offset = Tween<Offset>(
      begin: Offset(0, widget.offsetY / 100),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    Future.delayed(Duration(milliseconds: widget.index * widget.delayMs),
        () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void didUpdateWidget(covariant MrpFadeUp oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.index != widget.index) {
      _ctrl.reset();
      Future.delayed(
          Duration(milliseconds: widget.index * widget.delayMs), () {
        if (mounted) _ctrl.forward();
      });
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Respect the OS "reduce motion" setting.
    if (MediaQuery.of(context).disableAnimations) return widget.child;
    return FadeTransition(
      opacity: _opacity,
      child: SlideTransition(position: _offset, child: widget.child),
    );
  }
}

/// Scale-and-fade entrance for hero/header elements.
class MrpPopIn extends StatefulWidget {
  const MrpPopIn({super.key, required this.child, this.delayMs = 0});

  final Widget child;
  final int delayMs;

  @override
  State<MrpPopIn> createState() => _MrpPopInState();
}

class _MrpPopInState extends State<MrpPopIn>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _scale;
  late final Animation<double> _opacity;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _scale = Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(parent: _ctrl, curve: Curves.easeOutBack));
    _opacity =
        CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    Future.delayed(Duration(milliseconds: widget.delayMs), () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (MediaQuery.of(context).disableAnimations) return widget.child;
    return FadeTransition(
      opacity: _opacity,
      child: ScaleTransition(scale: _scale, child: widget.child),
    );
  }
}
