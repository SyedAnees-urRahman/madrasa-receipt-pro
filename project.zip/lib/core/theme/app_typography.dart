import 'package:flutter/material.dart';
import 'app_colors.dart';

/// Typography. Urdu text uses Jameel Noori Nastaleeq (bundled, works offline).
/// Noto Nastaliq Urdu kept as fallback. Latin/digits use the platform
/// default to keep the APK small. Nastaliq needs generous line height —
/// never compress it. Jameel Noori renders compact, so Urdu sizes are
/// bumped ~15% vs Latin for equal visual weight.
abstract final class AppTypography {
  static const String urduFont = 'JameelNooriNastaleeq';
  static const String urduFontFallback = 'NotoNastaliqUrdu';

  static const _urduFallbacks = <String>[urduFont, urduFontFallback];

  static TextStyle get displayUr => const TextStyle(
      fontFamily: urduFont,
      fontFamilyFallback: _urduFallbacks,
      fontSize: 30,
      height: 2.1,
      color: AppColors.ink900);
  static TextStyle get titleUr => const TextStyle(
      fontFamily: urduFont,
      fontFamilyFallback: _urduFallbacks,
      fontSize: 23,
      height: 2.0,
      color: AppColors.ink900);
  static TextStyle get bodyUr => const TextStyle(
      fontFamily: urduFont,
      fontFamilyFallback: _urduFallbacks,
      fontSize: 18,
      height: 2.0,
      color: AppColors.ink900);
  static TextStyle get captionUr => const TextStyle(
      fontFamily: urduFont,
      fontFamilyFallback: _urduFallbacks,
      fontSize: 15,
      height: 1.9,
      color: AppColors.ink500);

  static const TextStyle displayEn =
      TextStyle(fontSize: 26, fontWeight: FontWeight.w700, height: 1.25, color: AppColors.ink900);
  static const TextStyle titleEn =
      TextStyle(fontSize: 20, fontWeight: FontWeight.w600, height: 1.3, color: AppColors.ink900);
  static const TextStyle bodyEn =
      TextStyle(fontSize: 15, height: 1.5, color: AppColors.ink900);
  static const TextStyle captionEn =
      TextStyle(fontSize: 12.5, height: 1.4, color: AppColors.ink500);

  /// Amounts are always tabular Latin digits for audit clarity.
  static const TextStyle amount =
      TextStyle(fontSize: 18, fontWeight: FontWeight.w700, height: 1.3, color: AppColors.ink900);
  static const TextStyle amountLarge =
      TextStyle(fontSize: 26, fontWeight: FontWeight.w800, height: 1.2, color: AppColors.emerald800);
}

/// Spacing scale (4pt grid).
abstract final class AppSpacing {
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 16;
  static const double xl = 24;
  static const double xxl = 32;
  static const double radiusSm = 8;
  static const double radiusMd = 12;
  static const double radiusLg = 16;
  static const double radiusXl = 20;
}
