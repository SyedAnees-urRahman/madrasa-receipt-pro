import 'package:flutter/material.dart';

/// Design tokens: premium Islamic institutional palette.
/// Emerald green (primary), warm ivory (background), antique gold (accent),
/// deep navy/charcoal (text). All text colors meet strong contrast on ivory.
abstract final class AppColors {
  // Primary — deep emerald
  static const Color emerald900 = Color(0xFF06382A);
  static const Color emerald800 = Color(0xFF084F37);
  static const Color emerald700 = Color(0xFF0B6B4A);
  static const Color emerald600 = Color(0xFF0E7F57);
  static const Color emerald100 = Color(0xFFD9EDE2);
  static const Color emerald50 = Color(0xFFEDF6F0);

  // Background — warm ivory
  static const Color ivory = Color(0xFFFAF7EF);
  static const Color ivoryDeep = Color(0xFFF3EDDE);
  static const Color card = Color(0xFFFFFFFF);
  static const Color cardBorder = Color(0xFFE7DFCB);

  // Accent — restrained antique gold
  static const Color gold700 = Color(0xFF9A7B34);
  static const Color gold500 = Color(0xFFC6A15B);
  static const Color gold100 = Color(0xFFF3E9CF);

  // Text — deep navy / charcoal
  static const Color ink900 = Color(0xFF14213D);
  static const Color ink700 = Color(0xFF2B3A55);
  static const Color ink500 = Color(0xFF5B6B85);
  static const Color ink300 = Color(0xFF8B98B0);

  // Status
  static const Color success = Color(0xFF0E7F57);
  static const Color successBg = Color(0xFFE3F3EA);
  static const Color warning = Color(0xFFB7791F);
  static const Color warningBg = Color(0xFFFBF0D9);
  static const Color danger = Color(0xFFB3261E);
  static const Color dangerBg = Color(0xFFFBE7E4);
  static const Color info = Color(0xFF1D4ED8);
  static const Color infoBg = Color(0xFFE3ECFB);

  static const ColorScheme lightScheme = ColorScheme(
    brightness: Brightness.light,
    primary: emerald700,
    onPrimary: Colors.white,
    primaryContainer: emerald100,
    onPrimaryContainer: emerald900,
    secondary: gold700,
    onSecondary: Colors.white,
    secondaryContainer: gold100,
    onSecondaryContainer: ink900,
    tertiary: emerald600,
    surface: card,
    onSurface: ink900,
    surfaceContainerHighest: ivoryDeep,
    surfaceContainerLow: ivory,
    error: danger,
    onError: Colors.white,
    errorContainer: dangerBg,
    outline: cardBorder,
    outlineVariant: Color(0xFFD8CFB8),
  );
}
