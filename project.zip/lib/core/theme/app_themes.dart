import 'package:flutter/material.dart';
import 'app_typography.dart';

/// Dual theme system: Clay Blue (screenshot 6) + Light Neumorphic (screenshot 9).
/// The user picks in Settings; [themeModeProvider] holds the choice.

enum MrpThemeMode { fintech, clay, neumorphic }

/// FinTech (Velora-style) — clean off-white canvas, white elevated cards,
/// rich emerald gradient primaries with warm gold accents. Default theme.
class FintechTheme {
  static const bg = Color(0xFFF2F5FB);
  static const card = Color(0xFFFFFFFF);
  static const violet = Color(0xFF6C5CE7);
  static const blue = Color(0xFF4A6CF7);
  static const emerald = Color(0xFF059669);
  static const emeraldDeep = Color(0xFF047857);
  static const emeraldDark = Color(0xFF065F46);
  static const gold = Color(0xFFD97706);
  static const goldSoft = Color(0xFFFEF3C7);
  static const ink = Color(0xFF0F172A);
  static const inkSoft = Color(0xFF64748B);
  static const inkFaint = Color(0xFF94A3B8);
  static const border = Color(0xFFE2E8F0);
  static const emeraldSoft = Color(0xFFECFDF5);

  /// Hero gradient like the Velora reference (blue → violet).
  static const heroGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF4A6CF7), Color(0xFF8B5CF6)],
  );

  /// Soft, diffused card shadow like modern fintech apps.
  static List<BoxShadow> get softShadow => [
        BoxShadow(
          color: const Color(0xFF0F172A).withOpacity(0.06),
          blurRadius: 20,
          offset: const Offset(0, 6),
          spreadRadius: 0,
        ),
        BoxShadow(
          color: const Color(0xFF0F172A).withOpacity(0.04),
          blurRadius: 6,
          offset: const Offset(0, 2),
          spreadRadius: 0,
        ),
      ];

  static ThemeData get theme {
    final scheme = ColorScheme.light(
      primary: violet,
      onPrimary: Colors.white,
      secondary: gold,
      surface: card,
      onSurface: ink,
      surfaceContainerHighest: const Color(0xFFF1F5F9),
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: bg,
      fontFamily: AppTypography.urduFont,
      textTheme: const TextTheme(
        bodyLarge: TextStyle(fontFamily: AppTypography.urduFont, color: ink),
        bodyMedium: TextStyle(fontFamily: AppTypography.urduFont, color: ink),
        titleLarge: TextStyle(
            fontFamily: AppTypography.urduFont,
            color: ink,
            fontWeight: FontWeight.w800),
        titleMedium:
            TextStyle(fontFamily: AppTypography.urduFont, color: ink),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: bg,
        foregroundColor: ink,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(
            fontFamily: AppTypography.urduFont,
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: ink),
      ),
      cardTheme: CardThemeData(
        color: card,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: violet,
          foregroundColor: Colors.white,
          minimumSize: const Size(88, 56),
          textStyle: const TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w700,
              fontFamily: AppTypography.urduFont),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          elevation: 4,
          shadowColor: violet.withOpacity(0.35),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: violet,
          minimumSize: const Size(88, 56),
          textStyle: const TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w700,
              fontFamily: AppTypography.urduFont),
          side: const BorderSide(color: border, width: 1.5),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        hintStyle: const TextStyle(
            color: inkFaint,
            fontSize: 15,
            fontFamily: AppTypography.urduFont),
        labelStyle: const TextStyle(
            color: inkSoft,
            fontSize: 15,
            fontFamily: AppTypography.urduFont),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: violet, width: 2),
        ),
      ),
      chipTheme: ChipThemeData(
        color: WidgetStateProperty.all(emeraldSoft),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
        side: const BorderSide(color: border),
        labelStyle: const TextStyle(
            color: emeraldDeep, fontFamily: AppTypography.urduFont),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Colors.white,
        selectedItemColor: violet,
        unselectedItemColor: inkSoft,
        type: BottomNavigationBarType.fixed,
        elevation: 12,
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: ink,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: violet,
      ),
      dividerTheme: const DividerThemeData(color: border, thickness: 1),
    );
  }
}

/// Clay Blue — pixel-faithful claymorphism from the Multiiselect reference.
/// Soft sky-blue canvas, puffy white pill cards, vibrant blue actions.
class ClayTheme {
  // Canvas: soft sky blue like the reference background
  static const bg = Color(0xFF7FB3DE);
  static const bgDeep = Color(0xFF6BA3D4);
  // Container: lighter blue panel holding the content
  static const container = Color(0xFFA5CDEB);
  static const containerLight = Color(0xFFB8D8F0);
  // Cards: pure white, puffy
  static const card = Color(0xFFFFFFFF);
  // Primary: vibrant clay blue (buttons, selected states, accents)
  static const primary = Color(0xFF5B7FE8);
  static const primaryDark = Color(0xFF4A6BD8);
  static const primarySoft = Color(0xFFE3EBFD);
  // Ink
  static const ink = Color(0xFF1A2332);
  static const inkSoft = Color(0xFF5A6B82);
  static const inkFaint = Color(0xFF8A9BB0);

  /// The signature clay shadow: soft dark below-right + light above-left,
  /// making surfaces look inflated like modeling clay.
  static List<BoxShadow> clayShadow({double radius = 20}) => [
        BoxShadow(
          color: const Color(0xFF4A7AB5).withOpacity(0.30),
          blurRadius: 18,
          offset: const Offset(0, 8),
          spreadRadius: 0,
        ),
        const BoxShadow(
          color: Color(0xFFFFFFFF),
          blurRadius: 10,
          offset: Offset(0, -3),
          spreadRadius: 0,
        ),
      ];

  /// Inset (pressed) clay shadow.
  static List<BoxShadow> clayShadowInset() => [
        BoxShadow(
          color: const Color(0xFF4A7AB5).withOpacity(0.25),
          blurRadius: 12,
          offset: const Offset(4, 4),
        ),
        BoxShadow(
          color: Colors.white.withOpacity(0.9),
          blurRadius: 12,
          offset: const Offset(-4, -4),
        ),
      ];

  static ThemeData get theme {
    final scheme = ColorScheme.light(
      primary: primary,
      onPrimary: Colors.white,
      secondary: primaryDark,
      surface: card,
      onSurface: ink,
      surfaceContainerHighest: container,
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: bg,
      textTheme: const TextTheme(
        bodyLarge: TextStyle(fontFamily: AppTypography.urduFont, color: ink),
        bodyMedium: TextStyle(fontFamily: AppTypography.urduFont, color: ink),
        titleLarge: TextStyle(
            fontFamily: AppTypography.urduFont,
            color: ink,
            fontWeight: FontWeight.w800),
        titleMedium:
            TextStyle(fontFamily: AppTypography.urduFont, color: ink),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(
            fontFamily: AppTypography.urduFont,
            fontSize: 22,
            fontWeight: FontWeight.w800,
            color: Colors.white),
      ),
      cardTheme: CardThemeData(
        color: card,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
        ),
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
      // Primary action: vibrant clay blue pill
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: Colors.white,
          minimumSize: const Size(88, 58),
          textStyle: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              fontFamily: AppTypography.urduFont),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(29),
          ),
          elevation: 8,
          shadowColor: primaryDark.withOpacity(0.45),
        ),
      ),
      // Secondary: white pill with soft border
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: ink,
          minimumSize: const Size(88, 58),
          textStyle: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              fontFamily: AppTypography.urduFont),
          side: BorderSide.none,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(29),
          ),
          elevation: 6,
          shadowColor: const Color(0xFF4A7AB5).withOpacity(0.25),
        ),
      ),
      // Puffy white pill inputs like the reference search bar
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 22, vertical: 18),
        hintStyle: const TextStyle(
            color: inkFaint,
            fontSize: 16,
            fontFamily: AppTypography.urduFont),
        labelStyle: const TextStyle(
            color: inkSoft,
            fontSize: 16,
            fontFamily: AppTypography.urduFont),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(29),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(29),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(29),
          borderSide: const BorderSide(color: primary, width: 2.5),
        ),
      ),
      // Rounded-square clay checkboxes
      checkboxTheme: CheckboxThemeData(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        side: const BorderSide(color: primary, width: 2),
      ),
      chipTheme: ChipThemeData(
        color: WidgetStateProperty.all(primarySoft),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        side: BorderSide.none,
        labelStyle: const TextStyle(
            color: primaryDark, fontFamily: AppTypography.urduFont),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: container,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28),
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Colors.white,
        selectedItemColor: primary,
        unselectedItemColor: inkSoft,
        type: BottomNavigationBarType.fixed,
        elevation: 12,
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: ink,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
        ),
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: primary,
      ),
      dividerTheme:
          const DividerThemeData(color: Color(0xFFE3EBFD), thickness: 1),
    );
  }
}

/// Light Neumorphic — soft dual-shadow minimalism (screenshot 9).
class NeumorphicTheme {
  static const bg = Color(0xFFE4EAF2);
  static const card = Color(0xFFE4EAF2);
  static const primary = Color(0xFF3B82F6);
  static const primaryDark = Color(0xFF2563EB);
  static const ink = Color(0xFF1F2937);
  static const inkSoft = Color(0xFF6B7280);
  static const shadowDark = Color(0xFFB8C2D0);
  static const shadowLight = Color(0xFFFFFFFF);

  static ThemeData get theme {
    final scheme = ColorScheme.light(
      primary: primary,
      onPrimary: Colors.white,
      secondary: primaryDark,
      surface: bg,
      onSurface: ink,
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: bg,
      appBarTheme: const AppBarTheme(
        backgroundColor: bg,
        foregroundColor: ink,
        elevation: 0,
        centerTitle: true,
      ),
      cardTheme: CardThemeData(
        color: bg,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: Colors.white,
          minimumSize: const Size(88, 56),
          textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, fontFamily: AppTypography.urduFont),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
          elevation: 4,
          shadowColor: shadowDark.withOpacity(0.5),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: primaryDark,
          minimumSize: const Size(88, 56),
          side: const BorderSide(color: shadowDark, width: 1.5),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: bg,
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        hintStyle: const TextStyle(color: Color(0xFF9AA5B8), fontSize: 15),
        labelStyle: const TextStyle(color: Color(0xFF6B7280), fontSize: 15),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(color: primary, width: 2),
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: bg,
        selectedItemColor: primary,
        unselectedItemColor: inkSoft,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: bg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
      ),
    );
  }

  /// Neumorphic dual shadow for custom containers.
  static List<BoxShadow> get neuShadow => [
        BoxShadow(
          color: shadowDark.withOpacity(0.6),
          blurRadius: 16,
          offset: const Offset(6, 6),
        ),
        const BoxShadow(
          color: shadowLight,
          blurRadius: 16,
          offset: Offset(-6, -6),
        ),
      ];

  /// Inset (pressed) neumorphic shadow.
  static List<BoxShadow> get neuShadowInset => [
        BoxShadow(
          color: shadowDark.withOpacity(0.5),
          blurRadius: 12,
          offset: const Offset(4, 4),
        ),
        BoxShadow(
          color: shadowLight.withOpacity(0.9),
          blurRadius: 12,
          offset: const Offset(-4, -4),
        ),
      ];
}
