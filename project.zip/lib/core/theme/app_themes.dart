import 'package:flutter/material.dart';

/// Dual theme system: Clay Blue (screenshot 6) + Light Neumorphic (screenshot 9).
/// The user picks in Settings; [themeModeProvider] holds the choice.

enum MrpThemeMode { clay, neumorphic }

/// Clay Blue — soft 3D puffy cards on a gentle blue canvas (screenshot 6).
class ClayTheme {
  static const bg = Color(0xFF8FB4DD);
  static const bgLight = Color(0xFFA9C8E8);
  static const card = Color(0xFFFFFFFF);
  static const primary = Color(0xFF3D7BC4);
  static const primaryDark = Color(0xFF2E5FA3);
  static const ink = Color(0xFF1E2A3A);
  static const inkSoft = Color(0xFF5A6B82);

  static ThemeData get theme {
    final scheme = ColorScheme.light(
      primary: primary,
      onPrimary: Colors.white,
      secondary: primaryDark,
      surface: card,
      onSurface: ink,
      surfaceContainerHighest: bgLight,
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: bg,
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      cardTheme: CardThemeData(
        color: card,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: Colors.white,
          minimumSize: const Size(88, 56),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          elevation: 6,
          shadowColor: primaryDark.withOpacity(0.4),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: primaryDark,
          minimumSize: const Size(88, 56),
          side: const BorderSide(color: primary, width: 2),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: const BorderSide(color: primary, width: 2),
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Colors.white,
        selectedItemColor: primary,
        unselectedItemColor: inkSoft,
        type: BottomNavigationBarType.fixed,
        elevation: 12,
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28),
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
      ),
    );
  }

  /// Clay shadow for custom containers.
  static List<BoxShadow> get clayShadow => [
        BoxShadow(
          color: const Color(0xFF5A7FB5).withOpacity(0.35),
          blurRadius: 20,
          offset: const Offset(0, 10),
        ),
        const BoxShadow(
          color: Colors.white,
          blurRadius: 12,
          offset: Offset(0, -4),
        ),
      ];
}

/// Light Neumorphic — soft dual-shadow minimalism (screenshot 9).
class NeumorphicTheme {
  static const bg = Color(0xFFE4EAF2);
  static const card = Color(0xFFE4EAF2);
  static const primary = Color(0xFF3B82F6);
  static const primaryDark = Color(0xFF2563EB);
  static const ink = Color(0xFF1F2937);
  static const inkSoft = Color(0xFF6B7280);
  static const shadowDark = Color(0xFFB8C2D0);
  static const shadowLight = Color(0xFFFFFFFF);

  static ThemeData get theme {
    final scheme = ColorScheme.light(
      primary: primary,
      onPrimary: Colors.white,
      secondary: primaryDark,
      surface: bg,
      onSurface: ink,
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: bg,
      appBarTheme: const AppBarTheme(
        backgroundColor: bg,
        foregroundColor: ink,
        elevation: 0,
        centerTitle: true,
      ),
      cardTheme: CardThemeData(
        color: bg,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: Colors.white,
          minimumSize: const Size(88, 56),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
          elevation: 4,
          shadowColor: shadowDark.withOpacity(0.5),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: primaryDark,
          minimumSize: const Size(88, 56),
          side: const BorderSide(color: shadowDark, width: 1.5),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: bg,
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(color: primary, width: 2),
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: bg,
        selectedItemColor: primary,
        unselectedItemColor: inkSoft,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: bg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
      ),
    );
  }

  /// Neumorphic dual shadow for custom containers.
  static List<BoxShadow> get neuShadow => [
        BoxShadow(
          color: shadowDark.withOpacity(0.6),
          blurRadius: 16,
          offset: const Offset(6, 6),
        ),
        const BoxShadow(
          color: shadowLight,
          blurRadius: 16,
          offset: Offset(-6, -6),
        ),
      ];

  /// Inset (pressed) neumorphic shadow.
  static List<BoxShadow> get neuShadowInset => [
        BoxShadow(
          color: shadowDark.withOpacity(0.5),
          blurRadius: 12,
          offset: const Offset(4, 4),
        ),
        BoxShadow(
          color: shadowLight.withOpacity(0.9),
          blurRadius: 12,
          offset: const Offset(-4, -4),
        ),
      ];
}
