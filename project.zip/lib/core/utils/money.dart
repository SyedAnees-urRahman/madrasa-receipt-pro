/// Money: PKR stored as integer paisa. No floating point anywhere.
/// Money is ALWAYS stored and computed as integer paisa (1 PKR = 100 paisa).
/// Floating point is never used for money anywhere in the app.
abstract final class Money {
  static const int paisaPerRupee = 100;

  static int fromRupees(num rupees) => (rupees * paisaPerRupee).round();

  /// Parses user-typed PKR like "12,500" or "12500.50" into paisa.
  /// Returns null when the input is not a positive amount.
  static int? tryParsePkr(String input) {
    final cleaned = input.replaceAll(RegExp(r'[,\s٬]'), '').trim();
    if (cleaned.isEmpty) return null;
    final value = double.tryParse(cleaned);
    if (value == null || value <= 0) return null;
    return (value * paisaPerRupee).round();
  }

  /// "PKR 12,500" — Latin digits, Pakistani grouping (lakh/crore).
  static String formatPkr(int paisa, {bool symbol = true}) {
    // Pure integer arithmetic — never floating point for money.
    final rupees = paisa ~/ paisaPerRupee;
    final rem = paisa % paisaPerRupee;
    final grouped = _groupPakistani(rupees);
    final text = rem == 0
        ? grouped
        : '$grouped.${rem.toString().padLeft(2, '0')}';
    return symbol ? 'PKR $text' : text;
  }

  /// Pakistani digit grouping: first group of 3, then groups of 2
  /// (thousand → lakh → crore): 1,23,45,678.
  static String _groupPakistani(int n) {
    final s = n.toString();
    if (s.length <= 3) return s;
    final last3 = s.substring(s.length - 3);
    var rest = s.substring(0, s.length - 3);
    final parts = <String>[];
    while (rest.length > 2) {
      parts.add(rest.substring(rest.length - 2));
      rest = rest.substring(0, rest.length - 2);
    }
    if (rest.isNotEmpty) parts.add(rest);
    return '${parts.reversed.join(',')},$last3';
  }

  /// "روپے 12,500" — Urdu label, Latin digits (audit clarity).
  static String formatPkrUrdu(int paisa) => 'روپے ${formatPkr(paisa, symbol: false)}';

  static int add(int a, int b) => a + b;
  static int subtract(int a, int b) => a - b;
  static bool isPositive(int paisa) => paisa > 0;
}
