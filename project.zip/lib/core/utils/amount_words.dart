/// Amount-in-words for PKR, Pakistani numbering (lakh / crore).
/// Used on official receipts: digits AND words, in both languages.
abstract final class AmountWords {
  // ---------------- English ----------------
  static const _enOnes = [
    '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
    'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
    'Seventeen', 'Eighteen', 'Nineteen',
  ];
  static const _enTens = [
    '', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety',
  ];

  static String _enUnderThousand(int n) {
    final parts = <String>[];
    if (n >= 100) {
      parts.add('${_enOnes[n ~/ 100]} Hundred');
      n %= 100;
    }
    if (n >= 20) {
      parts.add(_enTens[n ~/ 10] + (n % 10 == 0 ? '' : '-${_enOnes[n % 10]}'));
    } else if (n > 0) {
      parts.add(_enOnes[n]);
    }
    return parts.join(' ');
  }

  static String english(int paisa) {
    var rupees = paisa ~/ 100;
    final paisaPart = paisa % 100;
    if (rupees == 0 && paisaPart == 0) return 'Zero Rupees Only';
    final parts = <String>[];
    const scales = [(10000000, 'Crore'), (100000, 'Lakh'), (1000, 'Thousand')];
    for (final (scale, name) in scales) {
      if (rupees >= scale) {
        parts.add('${_enUnderThousand(rupees ~/ scale)} $name');
        rupees %= scale;
      }
    }
    if (rupees > 0) parts.add(_enUnderThousand(rupees));
    var text = '${parts.join(' ')} Rupees';
    if (paisaPart > 0) text += ' and ${_enUnderThousand(paisaPart)} Paisa';
    return '$text Only';
  }

  // ---------------- Urdu ----------------
  static const _urOnes = [
    '', 'ایک', 'دو', 'تین', 'چار', 'پانچ', 'چھ', 'سات', 'آٹھ', 'نو',
    'دس', 'گیارہ', 'بارہ', 'تیرہ', 'چودہ', 'پندرہ', 'سولہ',
    'سترہ', 'اٹھارہ', 'انیس', 'بیس',
  ];
  static const _urTens = {
    30: 'تیس', 40: 'چالیس', 50: 'پچاس', 60: 'ساٹھ',
    70: 'ستر', 80: 'اسی', 90: 'نوے',
  };
  // 21-29, 31-39 ... compound forms
  static const _urCompounds = {
    21: 'اکیس', 22: 'بائیس', 23: 'تئیس', 24: 'چوبیس', 25: 'پچیس',
    26: 'چھببیس', 27: 'ستائیس', 28: 'اٹھائیس', 29: 'انتیس',
    31: 'اکتیس', 32: 'بتیس', 33: 'تینتیس', 34: 'چونتیس', 35: 'پینتیس',
    36: 'چھتیس', 37: 'سینتیس', 38: 'اڑتیس', 39: 'انتالیس',
    41: 'اکتالیس', 42: 'بیالیس', 43: 'تینتالیس', 44: 'چوالیس', 45: 'پینتالیس',
    46: 'چھیالیس', 47: 'سینتالیس', 48: 'اڑتالیس', 49: 'انچاس',
    51: 'اکیاون', 52: 'باون', 53: 'ترپن', 54: 'چون', 55: 'پچپن',
    56: 'چھپن', 57: 'ستاوَن', 58: 'اٹھاون', 59: 'انسٹھ',
    61: 'اکسٹھ', 62: 'باسٹھ', 63: 'تریسٹھ', 64: 'چوسٹھ', 65: 'پینسٹھ',
    66: 'چھیاسٹھ', 67: 'سڑسٹھ', 68: 'اٹھسٹھ', 69: 'انہتر',
    71: 'اکہتر', 72: 'بہتر', 73: 'تہتر', 74: 'چوہتر', 75: 'پچھتر',
    76: 'چھہتر', 77: 'ستتر', 78: 'اٹھتر', 79: 'اناسی',
    81: 'اکیاسی', 82: 'بیاسی', 83: 'تراسی', 84: 'چوراسی', 85: 'پچاسی',
    86: 'چھیاسی', 87: 'ستاسی', 88: 'اٹھاسی', 89: 'نواسی',
    91: 'اکانوے', 92: 'بانوے', 93: 'ترانوے', 94: 'چورانوے', 95: 'پچانوے',
    96: 'چھانوے', 97: 'ستانوے', 98: 'اٹھانوے', 99: 'نانوے',
  };

  static String _urUnderHundred(int n) {
    if (n <= 20) return _urOnes[n];
    if (_urCompounds.containsKey(n)) return _urCompounds[n]!;
    if (_urTens.containsKey(n)) return _urTens[n]!;
    return '';
  }

  static String _urUnderThousand(int n) {
    final parts = <String>[];
    if (n >= 100) {
      final h = n ~/ 100;
      parts.add(h == 1 ? 'سو' : '${_urUnderHundred(h)} سو');
      n %= 100;
    }
    if (n > 0) parts.add(_urUnderHundred(n));
    return parts.join(' ');
  }

  static String urdu(int paisa) {
    var rupees = paisa ~/ 100;
    final paisaPart = paisa % 100;
    if (rupees == 0 && paisaPart == 0) return 'صفر روپے فقط';
    final parts = <String>[];
    const scales = [(10000000, 'کروڑ'), (100000, 'لاکھ'), (1000, 'ہزار')];
    for (final (scale, name) in scales) {
      if (rupees >= scale) {
        final count = rupees ~/ scale;
        parts.add('${_urUnderThousand(count)} $name');
        rupees %= scale;
      }
    }
    if (rupees > 0) parts.add(_urUnderThousand(rupees));
    var text = '${parts.join(' ')} روپے';
    if (paisaPart > 0) text += ' اور ${_urUnderHundred(paisaPart)} پیسے';
    return '$text فقط';
  }
}
