/// Field validators. Messages are resolved by the UI via l10n keys.
abstract final class Validators {
  static String? required(String? v) =>
      (v == null || v.trim().isEmpty) ? 'errorRequired' : null;

  static String? positiveAmount(String? v) {
    if (v == null || v.trim().isEmpty) return 'errorRequired';
    final cleaned = v.replaceAll(RegExp(r'[,\s٬]'), '');
    final parsed = double.tryParse(cleaned);
    if (parsed == null || parsed <= 0) return 'errorInvalidAmount';
    return null;
  }

  static String? email(String? v) {
    if (v == null || v.trim().isEmpty) return null; // optional
    final ok = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(v.trim());
    return ok ? null : 'errorInvalidAmount';
  }

  static String? phone(String? v) {
    if (v == null || v.trim().isEmpty) return null; // optional
    final digits = v.replaceAll(RegExp(r'[\s\-+]'), '');
    return RegExp(r'^\d{7,15}$').hasMatch(digits) ? null : 'errorInvalidAmount';
  }
}
