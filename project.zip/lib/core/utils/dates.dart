import 'package:intl/intl.dart';

/// Localized dates. Urdu locale → Urdu month/day names; digits stay Latin.
abstract final class Dates {
  static String date(DateTime d, String locale) =>
      DateFormat.yMMMMd(locale).format(d);

  static String dateTime(DateTime d, String locale) =>
      DateFormat.yMMMMd(locale).add_jm().format(d);

  static String short(DateTime d) => DateFormat('yyyy-MM-dd').format(d);

  /// Financial-year label, e.g. "FY 2026-27".
  static String fyLabel(DateTime fyStart, DateTime fyEnd) =>
      'FY ${fyStart.year}-${fyEnd.year.toString().substring(2)}';
}
