/// Typed failures — never raw strings thrown across layers.
sealed class Failure {
  const Failure(this.messageKey);
  final String messageKey;
}

class ValidationFailure extends Failure {
  const ValidationFailure(super.messageKey);
}

class PermissionFailure extends Failure {
  const PermissionFailure() : super('errorPermission');
}

class NetworkFailure extends Failure {
  const NetworkFailure() : super('errorNetwork');
}

class ConflictFailure extends Failure {
  const ConflictFailure() : super('syncConflicts');
}

class DatabaseFailure extends Failure {
  const DatabaseFailure() : super('commonError');
}

/// Simple Result type for use-case outcomes.
sealed class Result<T> {
  const Result();
  bool get isOk => this is Ok<T>;
  bool get isErr => this is Err<T>;
  T get value => (this as Ok<T>).data;
  Failure get failure => (this as Err<T>).error;
}

final class Ok<T> extends Result<T> {
  const Ok(this.data);
  final T data;
}

final class Err<T> extends Result<T> {
  const Err(this.error);
  final Failure error;
}
