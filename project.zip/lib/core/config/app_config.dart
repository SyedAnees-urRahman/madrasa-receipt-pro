/// App-wide configuration. Secrets NEVER live here — only the
/// Supabase URL and anon key are read from `--dart-define` at build time
/// (see .env.example). The service-role key must never be bundled.
abstract final class AppConfig {
  static const String supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: '',
  );
  static const String supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: '',
  );

  static bool get isSupabaseConfigured =>
      supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;

  /// Public verification base URL embedded in receipt QR codes.
  /// The verification page reveals only: institution, receipt no, date,
  /// amount, funds, status — never donor PII.
  static const String verifyBaseUrl = String.fromEnvironment(
    'VERIFY_BASE_URL',
    defaultValue: 'https://verify.madrasa.example',
  );

  static const int qrHmacHexLength = 16;
  static const int maxEvidenceBytes = 10 * 1024 * 1024; // 10 MB
  static const List<String> allowedEvidenceMime = [
    'image/jpeg',
    'image/png',
    'image/webp',
    'application/pdf',
  ];

  /// Sync retry schedule: bounded exponential backoff, then manual.
  static const List<Duration> syncBackoff = [
    Duration(seconds: 5),
    Duration(seconds: 30),
    Duration(minutes: 2),
    Duration(minutes: 10),
    Duration(minutes: 60),
  ];
  static const int maxSyncAttempts = 8;
}
