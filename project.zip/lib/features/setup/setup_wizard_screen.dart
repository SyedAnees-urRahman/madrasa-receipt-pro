import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../../../app_providers.dart';
import '../../../data/repositories/institution_repository_impl.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/widgets.dart';
import '../../../domain/entities/enums.dart';
import '../../../domain/repositories/repositories.dart';
import '../../services/backup/backup_service.dart';
import 'package:shared_storage/shared_storage.dart' as saf;

/// First-run wizard: institution, registration, FY, numbering, language,
/// signatories, payment methods + accounts, funds + purposes, approvals,
/// backup/sync, and the clearly-labeled DEMO workspace option.
class SetupWizardScreen extends ConsumerStatefulWidget {
  const SetupWizardScreen({super.key});
  @override
  ConsumerState<SetupWizardScreen> createState() => _SetupWizardScreenState();
}

class _SetupWizardScreenState extends ConsumerState<SetupWizardScreen> {
  int _step = 0;
  bool _busy = false;

  final _nameUr = TextEditingController();
  final _nameEn = TextEditingController();
  final _address = TextEditingController();
  final _phone = TextEditingController();
  final _email = TextEditingController();
  final _regNo = TextEditingController();
  final _ntn = TextEditingController();
  final _prefix = TextEditingController(text: 'MD');
  final _threshold = TextEditingController(text: '100000');
  final _adminName = TextEditingController(text: 'ایڈمن');
  final _adminPin = TextEditingController(text: '1234');

  String? _logoPath;
  int _fyMonth = 7, _fyDay = 1;
  String _receiptLang = 'bilingual';
  String _printFormat = 'a4';
  final _methods = <PaymentMethod>{PaymentMethod.cash, PaymentMethod.bankTransfer};
  final _signatories = <SignatoryDraft>[];
  final _accounts = <AccountDraft>[const AccountDraft(type: AccountType.cash, title: 'نقد — Cash in hand')];
  final _funds = <FundDraft>[...defaultFundDrafts];
  final _purposes = <PurposeDraft>[...defaultPurposeDrafts];
  bool _autoSync = true;
  bool _seedDemo = false;

  @override
  void dispose() {
    for (final c in [_nameUr, _nameEn, _address, _phone, _email, _regNo, _ntn, _prefix, _threshold, _adminName, _adminPin]) {
      c.dispose();
    }
    super.dispose();
  }

  static const _titles = [
    'خوش آمدید', 'ادارہ', 'رجسٹریشن', 'مالی سال', 'رسید نمبرنگ',
    'رسید کی زبان', 'دستخط کنندگان', 'ادائیگی کے طریقے', 'فنڈز و مصارف',
    'منظوری کے اصول', 'بیک اپ و مطابقت', 'مکمل کریں',
  ];

  bool _validStep() {
    switch (_step) {
      case 1:
        return _nameUr.text.trim().isNotEmpty && _nameEn.text.trim().isNotEmpty;
      case 4:
        return _prefix.text.trim().isNotEmpty;
      case 11:
        return _adminPin.text.trim().length >= 4;
      default:
        return true;
    }
  }

  Future<void> _pickLogo() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked == null) return;
    final dir = await getApplicationDocumentsDirectory();
    final dest = p.join(dir.path, 'logo${p.extension(picked.path)}');
    await File(picked.path).copy(dest);
    setState(() => _logoPath = dest);
  }

  /// WhatsApp-style restore: pick the Drive folder, choose a backup, restore.
  Future<void> _restoreFromBackup() async {
    final svc = ref.read(backupServiceProvider);
    setState(() => _busy = true);
    try {
      if (!await svc.hasDriveFolder) {
        final ok = await svc.pickDriveFolder();
        if (!ok) {
          if (mounted) {
            setState(() => _busy = false);
            mrpShowSnack(context, 'کوئی فولڈر منتخب نہیں ہوا',
                isError: true);
          }
          return;
        }
      }
      final backups = await svc.listDriveBackups();
      if (!mounted) return;
      setState(() => _busy = false);
      if (backups.isEmpty) {
        mrpShowSnack(context, 'اس فولڈر میں کوئی بیک اپ نہیں ملا',
            isError: true);
        return;
      }
      final picked = await showDialog<saf.DocumentFile>(
        context: context,
        builder: (ctx) => SimpleDialog(
          title: const Text('بیک اپ منتخب کریں'),
          children: [
            for (final b in backups)
              SimpleDialogOption(
                onPressed: () => Navigator.pop(ctx, b),
                child: Text(b.name ?? '',
                    textDirection: TextDirection.ltr),
              ),
          ],
        ),
      );
      if (picked == null || !mounted) return;
      setState(() => _busy = true);
      final zip = await svc.downloadDriveBackup(picked);
      // Fresh install: DB is empty, safe to replace.
      final db = ref.read(appDatabaseProvider);
      try {
        await db.close();
      } catch (_) {}
      await svc.restoreFromZip(zip);
      ref.invalidate(appDatabaseProvider);
      if (!mounted) return;
      setState(() => _busy = false);
      mrpShowSnack(context, 'بیک اپ بحال ہو گیا ✓');
      context.go('/login');
    } catch (e) {
      ref.invalidate(appDatabaseProvider);
      if (!mounted) return;
      setState(() => _busy = false);
      mrpShowSnack(context, 'بحالی ناکام: $e', isError: true);
    }
  }

  Future<void> _finish() async {    setState(() => _busy = true);
    final draft = SetupDraft(
      nameUr: _nameUr.text.trim(),
      nameEn: _nameEn.text.trim(),
      logoPath: _logoPath,
      address: _address.text.trim().isEmpty ? null : _address.text.trim(),
      phone: _phone.text.trim().isEmpty ? null : _phone.text.trim(),
      email: _email.text.trim().isEmpty ? null : _email.text.trim(),
      registrationNo: _regNo.text.trim().isEmpty ? null : _regNo.text.trim(),
      ntn: _ntn.text.trim().isEmpty ? null : _ntn.text.trim(),
      fyStartMonth: _fyMonth,
      fyStartDay: _fyDay,
      receiptPrefix: _prefix.text.trim(),
      receiptLanguage: _receiptLang,
      printFormat: _printFormat,
      acceptedMethods: _methods.toList(),
      signatories: _signatories,
      dualApprovalThresholdPaisa:
          (int.tryParse(_threshold.text.replaceAll(',', '')) ?? 100000) * 100,
      autoSync: _autoSync,
      funds: _funds,
      purposes: _purposes,
      accounts: _accounts,
      seedDemo: _seedDemo,
      adminName: _adminName.text.trim(),
      adminPin: _adminPin.text.trim(),
    );
    final res = await ref.read(institutionRepositoryProvider).completeSetup(draft);
    if (!mounted) return;
    setState(() => _busy = false);
    if (res.isOk) {
      context.go('/login');
    } else {
      mrpShowSnack(context, 'سیٹ اپ محفوظ نہیں ہو سکا', isError: true);
    }
  }

  void _next() {
    if (!_validStep()) {
      mrpShowSnack(context, 'لازمی خانے پُر کریں', isError: true);
      return;
    }
    if (_step == _titles.length - 1) {
      _finish();
    } else {
      setState(() => _step++);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_step]),
        automaticallyImplyLeading: false,
      ),
      body: Column(
        children: [
          LinearProgressIndicator(
            value: (_step + 1) / _titles.length,
            backgroundColor: AppColors.emerald100,
            color: AppColors.gold500,
            minHeight: 6,
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: _buildStep(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                if (_step > 0)
                  Expanded(
                    child: MrpSecondaryButton(
                      label: 'پیچھے',
                      onPressed: () => setState(() => _step--),
                    ),
                  ),
                if (_step > 0) const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: MrpPrimaryButton(
                    label: _step == _titles.length - 1 ? 'سیٹ اپ مکمل کریں' : 'آگے',
                    loading: _busy,
                    onPressed: _next,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStep() {
    switch (_step) {
      case 0:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.mosque, size: 72, color: AppColors.emerald700),
            const SizedBox(height: 16),
            Text('چند مراحل میں اپنا مدرسہ ترتیب دیں۔',
                textAlign: TextAlign.center, style: AppTypography.bodyUr),
            const SizedBox(height: 8),
            Text('بعد میں ترتیبات سے سب کچھ بدلا جا سکتا ہے۔',
                textAlign: TextAlign.center, style: AppTypography.captionUr),
            const SizedBox(height: 24),
            const Divider(),
            const SizedBox(height: 8),
            Text('کیا آپ کے پاس پرانا بیک اپ ہے؟',
                textAlign: TextAlign.center, style: AppTypography.titleUr),
            const SizedBox(height: 4),
            Text('نیا موبائل یا دوبارہ انسٹال کی صورت میں Drive سے بحال کریں — بالکل واٹس ایپ کی طرح۔',
                textAlign: TextAlign.center, style: AppTypography.captionUr),
            const SizedBox(height: 12),
            MrpSecondaryButton(
              label: 'بیک اپ سے بحال کریں',
              icon: Icons.cloud_download_outlined,
              onPressed: _restoreFromBackup,
            ),
          ],
        );
      case 1:
        return Column(
          children: [
            GestureDetector(
              onTap: _pickLogo,
              child: Container(
                width: 110,
                height: 110,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.cardBorder),
                ),
                clipBehavior: Clip.antiAlias,
                child: _logoPath != null
                    ? Image.file(File(_logoPath!), fit: BoxFit.cover)
                    : const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.add_a_photo_outlined,
                              color: AppColors.ink500),
                          SizedBox(height: 4),
                          Text('لوگو منتخب کریں',
                              style: TextStyle(fontFamily: AppTypography.urduFont, fontSize: 12, color: AppColors.ink500)),
                        ],
                      ),
              ),
            ),
            const SizedBox(height: 16),
            MrpTextField(controller: _nameUr, label: 'ادارے کا نام (اردو) *'),
            const SizedBox(height: 12),
            MrpTextField(
                controller: _nameEn,
                label: 'Institution name (English) *',
                textDirection: TextDirection.ltr),
            const SizedBox(height: 12),
            MrpTextField(controller: _address, label: 'پتہ', maxLines: 2),
            const SizedBox(height: 12),
            MrpTextField(
                controller: _phone,
                label: 'فون',
                keyboardType: TextInputType.phone,
                textDirection: TextDirection.ltr),
            const SizedBox(height: 12),
            MrpTextField(
                controller: _email,
                label: 'ای میل',
                keyboardType: TextInputType.emailAddress,
                textDirection: TextDirection.ltr),
          ],
        );
      case 2:
        return Column(
          children: [
            MrpTextField(controller: _regNo, label: 'رجسٹریشن نمبر'),
            const SizedBox(height: 12),
            MrpTextField(
                controller: _ntn,
                label: 'NTN (اگر ہو)',
                textDirection: TextDirection.ltr),
          ],
        );
      case 3:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('مالی سال کا آغاز', style: AppTypography.bodyUr),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<int>(
                    value: _fyMonth,
                    decoration:
                        const InputDecoration(labelText: 'مہینہ'),
                    items: List.generate(
                        12,
                        (i) => DropdownMenuItem(
                            value: i + 1, child: Text('${i + 1}'))),
                    onChanged: (v) => setState(() => _fyMonth = v ?? 7),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<int>(
                    value: _fyDay,
                    decoration: const InputDecoration(labelText: 'دن'),
                    items: List.generate(
                        28,
                        (i) => DropdownMenuItem(
                            value: i + 1, child: Text('${i + 1}'))),
                    onChanged: (v) => setState(() => _fyDay = v ?? 1),
                  ),
                ),
              ],
            ),
          ],
        );
      case 4:
        return Column(
          children: [
            MrpTextField(
                controller: _prefix,
                label: 'رسید کا سابقہ * (مثلاً MD)',
                textDirection: TextDirection.ltr),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.emerald50,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                'فارمیٹ: ${_prefix.text.trim().isEmpty ? 'MD' : _prefix.text.trim()}-2026-000001',
                style: AppTypography.amount,
                textDirection: TextDirection.ltr,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'سرکاری نمبر ہمیشہ سرور جاری کرتا ہے۔ آف لائن رسیدیں عارضی رہتی ہیں۔',
              style: AppTypography.captionUr,
            ),
          ],
        );
      case 5:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('رسید کی زبان', style: AppTypography.bodyUr),
            for (final opt in const [
              ('bilingual', 'دو لسانی (اردو + انگریزی)'),
              ('ur', 'صرف اردو'),
              ('en', 'English only'),
            ])
              RadioListTile<String>(
                title: Text(opt.$2),
                value: opt.$1,
                groupValue: _receiptLang,
                activeColor: AppColors.emerald700,
                onChanged: (v) => setState(() => _receiptLang = v!),
              ),
            const SizedBox(height: 8),
            Text('پرنٹ فارمیٹ', style: AppTypography.bodyUr),
            for (final opt in const [
              ('a4', 'A4'),
              ('thermal80', 'تھرمل 80mm'),
            ])
              RadioListTile<String>(
                title: Text(opt.$2),
                value: opt.$1,
                groupValue: _printFormat,
                activeColor: AppColors.emerald700,
                onChanged: (v) => setState(() => _printFormat = v!),
              ),
          ],
        );
      case 6:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            for (var i = 0; i < _signatories.length; i++)
              Card(
                child: ListTile(
                  title: Text(_signatories[i].name),
                  subtitle: Text(_signatories[i].title),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline,
                        color: AppColors.danger),
                    onPressed: () =>
                        setState(() => _signatories.removeAt(i)),
                  ),
                ),
              ),
            MrpSecondaryButton(
              label: 'دستخط کنندہ شامل کریں',
              icon: Icons.add,
              onPressed: _addSignatory,
            ),
          ],
        );
      case 7:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('قبول شدہ طریقے', style: AppTypography.bodyUr),
            Wrap(
              spacing: 8,
              children: PaymentMethod.values.map((m) {
                final selected = _methods.contains(m);
                return FilterChip(
                  label: Text(_methodLabel(m)),
                  selected: selected,
                  selectedColor: AppColors.emerald100,
                  onSelected: (v) => setState(() {
                    v ? _methods.add(m) : _methods.remove(m);
                  }),
                );
              }).toList(),
            ),
            const SizedBox(height: 16),
            Text('اکاؤنٹس', style: AppTypography.bodyUr),
            const SizedBox(height: 8),
            for (var i = 0; i < _accounts.length; i++)
              Card(
                child: ListTile(
                  title: Text(_accounts[i].title),
                  subtitle: Text(_accounts[i].bankName ??
                      _accountTypeLabel(_accounts[i].type)),
                  trailing: _accounts.length > 1
                      ? IconButton(
                          icon: const Icon(Icons.delete_outline,
                              color: AppColors.danger),
                          onPressed: () =>
                              setState(() => _accounts.removeAt(i)),
                        )
                      : null,
                ),
              ),
            MrpSecondaryButton(
              label: 'اکاؤنٹ شامل کریں',
              icon: Icons.add,
              onPressed: _addAccount,
            ),
          ],
        );
      case 8:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('فنڈز', style: AppTypography.bodyUr),
            for (var i = 0; i < _funds.length; i++)
              Card(
                child: ListTile(
                  title: Text('${_funds[i].nameUr} — ${_funds[i].nameEn}'),
                  subtitle: Text(_funds[i].code,
                      textDirection: TextDirection.ltr),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline,
                        color: AppColors.danger),
                    onPressed: () =>
                        setState(() => _funds.removeAt(i)),
                  ),
                ),
              ),
            MrpSecondaryButton(
                label: 'فنڈ شامل کریں',
                icon: Icons.add,
                onPressed: _addFund),
            const SizedBox(height: 16),
            Text('مصارف', style: AppTypography.bodyUr),
            for (var i = 0; i < _purposes.length; i++)
              Card(
                child: ListTile(
                  title: Text(
                      '${_purposes[i].nameUr} — ${_purposes[i].nameEn}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline,
                        color: AppColors.danger),
                    onPressed: () =>
                        setState(() => _purposes.removeAt(i)),
                  ),
                ),
              ),
            MrpSecondaryButton(
                label: 'مصرف شامل کریں',
                icon: Icons.add,
                onPressed: _addPurpose),
          ],
        );
      case 9:
        return Column(
          children: [
            MrpTextField(
              controller: _threshold,
              label: 'دو افراد کی منظوری اس رقم سے زائد (روپے)',
              keyboardType: TextInputType.number,
              textDirection: TextDirection.ltr,
            ),
            const SizedBox(height: 8),
            Text(
              'اس حد سے زائد اخراجات پر بنانے والے کے علاوہ کسی دوسرے مجاز شخص کی منظوری لازمی ہوگی۔ اپنی منظوری ہرگز جائز نہیں۔',
              style: AppTypography.captionUr,
            ),
          ],
        );
      case 10:
        return Column(
          children: [
            SwitchListTile(
              title: const Text('آن لائن ہوتے ہی خودکار مطابقت'),
              value: _autoSync,
              activeColor: AppColors.emerald700,
              onChanged: (v) => setState(() => _autoSync = v),
            ),
            Text(
              'بیک اپ خفیہ کردہ کلاؤڈ مطابقت کے ذریعے ہوتا ہے۔ مقامی زیرِ التواء ریکارڈ محفوظ مطابقت سے پہلے کبھی حذف نہیں ہوتا۔',
              style: AppTypography.captionUr,
            ),
          ],
        );
      default:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            MrpCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text('ایڈمن لاگ اِن', style: AppTypography.titleUr),
                  const SizedBox(height: 8),
                  Text(
                    'ایپ کھولنے کے لیے یہ نام اور PIN استعمال ہوگا۔',
                    style: AppTypography.captionUr,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _adminName,
                    decoration: const InputDecoration(
                      labelText: 'ایڈمن کا نام',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _adminPin,
                    decoration: const InputDecoration(
                      labelText: 'PIN (کم از کم 4 ہندسے)',
                      border: OutlineInputBorder(),
                    ),
                    keyboardType: TextInputType.number,
                    obscureText: true,
                    maxLength: 8,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            MrpCard(
              child: CheckboxListTile(
                title: const Text('ڈیمو ورک اسپیس بنائیں'),
                subtitle: const Text(
                    'نمونہ ڈیٹا صرف ڈیمو ورک اسپیس میں رہتا ہے، حقیقی ریکارڈ سے کبھی نہیں ملتا۔'),
                value: _seedDemo,
                activeColor: AppColors.emerald700,
                onChanged: (v) => setState(() => _seedDemo = v ?? false),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              _seedDemo
                  ? 'ڈیمو ورک اسپیس "DEMO" بیج کے ساتھ بنے گی۔'
                  : 'حقیقی ورک اسپیس بنے گی۔ ڈیمو بعد میں ترتیبات سے شامل کیا جا سکتا ہے۔',
              textAlign: TextAlign.center,
              style: AppTypography.captionUr,
            ),
          ],
        );
    }
  }

  String _methodLabel(PaymentMethod m) => switch (m) {
        PaymentMethod.cash => 'نقد',
        PaymentMethod.bankTransfer => 'بینک ٹرانسفر',
        PaymentMethod.cheque => 'چیک',
        PaymentMethod.wallet => 'موبائل والٹ',
      };

  String _accountTypeLabel(AccountType t) => switch (t) {
        AccountType.cash => 'نقد',
        AccountType.bank => 'بینک',
        AccountType.wallet => 'والٹ',
      };

  Future<void> _addSignatory() async {
    final name = TextEditingController();
    final title = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('دستخط کنندہ'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            MrpTextField(controller: name, label: 'نام'),
            const SizedBox(height: 8),
            MrpTextField(controller: title, label: 'عہدہ'),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('منسوخ')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('شامل کریں')),
        ],
      ),
    );
    if (ok == true && name.text.trim().isNotEmpty) {
      setState(() => _signatories.add(SignatoryDraft(
          name: name.text.trim(), title: title.text.trim())));
    }
  }

  Future<void> _addAccount() async {
    final title = TextEditingController();
    final bank = TextEditingController();
    var type = AccountType.bank;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('اکاؤنٹ'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<AccountType>(
                value: type,
                decoration: const InputDecoration(labelText: 'قسم'),
                items: AccountType.values
                    .map((t) => DropdownMenuItem(
                        value: t, child: Text(_accountTypeLabel(t))))
                    .toList(),
                onChanged: (v) => setS(() => type = v ?? AccountType.bank),
              ),
              const SizedBox(height: 8),
              MrpTextField(controller: title, label: 'عنوان'),
              const SizedBox(height: 8),
              MrpTextField(controller: bank, label: 'بینک کا نام (اختیاری)'),
            ],
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('منسوخ')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('شامل کریں')),
          ],
        ),
      ),
    );
    if (ok == true && title.text.trim().isNotEmpty) {
      setState(() => _accounts.add(AccountDraft(
            type: type,
            title: title.text.trim(),
            bankName:
                bank.text.trim().isEmpty ? null : bank.text.trim(),
          )));
    }
  }

  Future<void> _addFund() async {
    final ur = TextEditingController();
    final en = TextEditingController();
    final code = TextEditingController();
    var category = FundCategory.lillah;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('فنڈ'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              MrpTextField(controller: code, label: 'کوڈ (مثلاً ZAKAT)'),
              const SizedBox(height: 8),
              MrpTextField(controller: ur, label: 'نام (اردو)'),
              const SizedBox(height: 8),
              MrpTextField(
                  controller: en,
                  label: 'Name (English)',
                  textDirection: TextDirection.ltr),
            ],
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('منسوخ')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('شامل کریں')),
          ],
        ),
      ),
    );
    if (ok == true && ur.text.trim().isNotEmpty) {
      setState(() => _funds.add(FundDraft(
            code: code.text.trim().isEmpty
                ? 'F${_funds.length + 1}'
                : code.text.trim().toUpperCase(),
            nameUr: ur.text.trim(),
            nameEn: en.text.trim().isEmpty ? ur.text.trim() : en.text.trim(),
            category: category,
          )));
    }
  }

  Future<void> _addPurpose() async {
    final ur = TextEditingController();
    final en = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('مصرف'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            MrpTextField(controller: ur, label: 'نام (اردو)'),
            const SizedBox(height: 8),
            MrpTextField(
                controller: en,
                label: 'Name (English)',
                textDirection: TextDirection.ltr),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('منسوخ')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('شامل کریں')),
        ],
      ),
    );
    if (ok == true && ur.text.trim().isNotEmpty) {
      setState(() => _purposes.add(PurposeDraft(
            nameUr: ur.text.trim(),
            nameEn: en.text.trim().isEmpty ? ur.text.trim() : en.text.trim(),
          )));
    }
  }
}
