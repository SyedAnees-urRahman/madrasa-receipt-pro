import 'dart:io';
import 'package:csv/csv.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../../app_providers.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/widgets.dart';
import '../../../core/utils/money.dart';
import '../../../domain/repositories/repositories.dart';

/// All reports derive from the ledger with documented rules.
/// Export to CSV / PDF via the share sheet.
class ReportsScreen extends ConsumerStatefulWidget {
  const ReportsScreen({super.key});
  @override
  ConsumerState<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends ConsumerState<ReportsScreen> {
  DateTime _from = DateTime.now().subtract(const Duration(days: 30));
  DateTime _to = DateTime.now();
  String? _running;
  String _summary = '';

  final _defs = const [
    ('daily', 'روزانہ وصولی رپورٹ', Icons.today_outlined),
    ('monthly', 'ماہانہ رسید رجسٹر', Icons.calendar_month_outlined),
    ('annual', 'سالانہ رسید رجسٹر', Icons.date_range_outlined),
    ('fund', 'فنڈ وار رسیدیں', Icons.account_balance_wallet_outlined),
    ('purpose', 'مصرف وار وصولیاں', Icons.category_outlined),
    ('method', 'طریقۂ ادائیگی خلاصہ', Icons.payments_outlined),
    ('pending', 'تصدیق کے منتظر', Icons.hourglass_empty),
    ('canceled', 'منسوخ / واپس شدہ رسیدیں', Icons.cancel_outlined),
    ('expense', 'اخراجات واؤچر رجسٹر', Icons.receipt_outlined),
    ('fundflow', 'فنڈ وار آمدن و اخراجات', Icons.balance_outlined),
    ('audit', 'آڈٹ واقعات لاگ', Icons.history),
    ('sync', 'مطابقت و تنازعات', Icons.sync),
  ];

  Future<void> _run(String key) async {
    setState(() {
      _running = key;
      _summary = '';
    });
    final reports = ref.read(reportRepositoryProvider);
    try {
      switch (key) {
        case 'daily':
          final now = DateTime.now();
          final r = await reports.daily(
              DateTime(now.year, now.month, now.day));
          if (r.isOk) {
            _summary =
                'مصدقہ: ${Money.formatPkr(r.value.confirmedTotalPaisa, symbol: false)} | زیرِ التواء: ${Money.formatPkr(r.value.pendingTotalPaisa, symbol: false)} | رسیدیں: ${r.value.receipts.length}';
          }
        case 'monthly':
          final now = DateTime.now();
          final r = await reports.period(
              DateTime(now.year, now.month, 1), now);
          if (r.isOk) {
            _summary =
                'مصدقہ: ${Money.formatPkr(r.value.confirmedTotalPaisa, symbol: false)} | رسیدیں: ${r.value.receipts.length}';
          }
        case 'annual':
          final now = DateTime.now();
          final r = await reports.period(
              DateTime(now.year, 1, 1), now);
          if (r.isOk) {
            _summary =
                'مصدقہ: ${Money.formatPkr(r.value.confirmedTotalPaisa, symbol: false)} | رسیدیں: ${r.value.receipts.length}';
          }
        case 'fund':
          final r = await reports.fundFlows(_from, _to);
          if (r.isOk) {
            _summary = r.value
                .map((f) =>
                    '${f.fund.nameUr}: ${Money.formatPkr(f.receiptsPaisa, symbol: false)}')
                .join('\n');
          }
        case 'purpose':
          final r = await reports.purposeFlows(_from, _to);
          if (r.isOk) {
            _summary = r.value
                .map((p) =>
                    '${p.purpose.nameUr}: ${Money.formatPkr(p.totalPaisa, symbol: false)}')
                .join('\n');
          }
        case 'method':
          final r = await reports.paymentMethodSummary(_from, _to);
          if (r.isOk) {
            _summary = r.value
                .map((m) =>
                    '${m.method.name}: ${Money.formatPkr(m.totalPaisa, symbol: false)} (${m.count})')
                .join('\n');
          }
        case 'pending':
          final r = await ref
              .read(receiptRepositoryProvider)
              .pendingVerification();
          if (r.isOk) {
            var t = 0;
            for (final x in r.value) {
              t += x.totalPaisa;
            }
            _summary =
                'منتظر: ${r.value.length} رسیدیں، ${Money.formatPkr(t, symbol: false)}';
          }
        case 'canceled':
          final r = await reports.canceledRegister(_from, _to);
          if (r.isOk) {
            _summary = 'منسوخ/واپس شدہ: ${r.value.length} رسیدیں';
          }
        case 'expense':
          final r =
              await ref.read(expenseRepositoryProvider).register(limit: 500);
          if (r.isOk) {
            var t = 0;
            for (final x in r.value) {
              t += x.totalPaisa;
            }
            _summary =
                'واؤچر: ${r.value.length}، کل: ${Money.formatPkr(t, symbol: false)}';
          }
        case 'fundflow':
          final r = await reports.fundFlows(_from, _to);
          if (r.isOk) {
            _summary = r.value
                .map((f) =>
                    '${f.fund.nameUr}: آمدن ${Money.formatPkr(f.receiptsPaisa, symbol: false)} / خرچ ${Money.formatPkr(f.expensesPaisa, symbol: false)}')
                .join('\n');
          }
        case 'audit':
          final r = await ref
              .read(auditRepositoryProvider)
              .query(from: _from, to: _to, limit: 500);
          if (r.isOk) _summary = 'واقعات: ${r.value.length}';
        case 'sync':
          final ctx = ref.read(repositoryContextProvider);
          if (ctx != null) {
            final c = await ref
                .read(syncEngineProvider)
                .openConflicts(ctx.institutionId);
            _summary = 'کھلے تنازعات: ${c.length}';
          }
      }
    } finally {
      if (mounted) setState(() => _running = null);
    }
  }

  Future<void> _exportCsv() async {
    final reports = ref.read(reportRepositoryProvider);
    final r = await reports.period(_from, _to);
    if (!r.isOk) return;
    final rows = <List<dynamic>>[
      ['receipt_number', 'date', 'donor', 'amount_pkr', 'status', 'payment_method'],
      for (final x in r.value.receipts)
        [
          x.officialNumber ?? x.localProvisionalLabel ?? '',
          '${x.receiptDate.year}-${x.receiptDate.month}-${x.receiptDate.day}',
          x.donorNameSnapshot,
          (x.totalPaisa / 100).toStringAsFixed(2),
          x.status.name,
          x.paymentMethod.name,
        ],
    ];
    final csv = const ListToCsvConverter().convert(rows);
    final dir = await getTemporaryDirectory();
    final file = File(
        '${dir.path}/receipt-register-${DateTime.now().millisecondsSinceEpoch}.csv');
    await file.writeAsString(csv);
    await Share.shareXFiles([XFile(file.path)], text: 'رسید رجسٹر CSV');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('رپورٹس'),
        actions: [
          IconButton(
            icon: const Icon(Icons.calendar_month_outlined),
            tooltip: 'مدت',
            onPressed: () async {
              final picked = await showDateRangePicker(
                context: context,
                firstDate: DateTime(2020),
                lastDate: DateTime.now(),
                initialDateRange:
                    DateTimeRange(start: _from, end: _to),
              );
              if (picked != null) {
                setState(() {
                  _from = picked.start;
                  _to = picked.end;
                });
              }
            },
          ),
          IconButton(
            icon: const Icon(Icons.download_outlined),
            tooltip: 'CSV برآمد کریں',
            onPressed: _exportCsv,
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (_summary.isNotEmpty)
            MrpCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('نتیجہ',
                      style: AppTypography.bodyUr.copyWith(
                          fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Text(_summary, style: AppTypography.bodyUr),
                  const SizedBox(height: 8),
                  const Text(
                    'اصول: مصدقہ مجموعوں میں صرف confirmed رسیدیں (واپسی منہا)؛ زیرِ التواء الگ۔',
                    style: TextStyle(fontFamily: AppTypography.urduFont, fontSize: 11, color: Colors.grey),
                  ),
                ],
              ),
            ),
          for (final (key, label, icon) in _defs)
            MrpCard(
              onTap: _running == null ? () => _run(key) : null,
              child: Row(
                children: [
                  Icon(icon, color: Colors.green[800]),
                  const SizedBox(width: 12),
                  Expanded(child: Text(label)),
                  if (_running == key)
                    const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                            strokeWidth: 2))
                  else
                    const Icon(Icons.chevron_left),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
