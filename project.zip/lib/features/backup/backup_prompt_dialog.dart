import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/widgets.dart';
import '../../services/backup/backup_service.dart';

/// Auto backup reminder popup (daily / weekly / monthly).
/// Shows a friendly dialog with a one-tap backup button.
class BackupPromptDialog extends ConsumerStatefulWidget {
  const BackupPromptDialog({super.key});

  @override
  ConsumerState<BackupPromptDialog> createState() =>
      _BackupPromptDialogState();
}

class _BackupPromptDialogState extends ConsumerState<BackupPromptDialog> {
  bool _busy = false;
  double _progress = 0;
  String? _error;

  Future<void> _doBackup() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final svc = ref.read(backupServiceProvider);
      final zip = await svc.createLocalBackup(
          onProgress: (p) => mounted ? setState(() => _progress = p * 0.7) : null);
      // If a Drive folder was picked earlier, upload silently too.
      if (await svc.hasDriveFolder) {
        await svc.uploadToDrive(zip,
            onProgress: (p) =>
                mounted ? setState(() => _progress = 0.7 + p * 0.3) : null);
      }
      await svc.markPromptShown();
      if (!mounted) return;
      Navigator.of(context).pop(true);
      mrpShowSnack(context, 'بیک اپ محفوظ ہو گیا ✓');
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = 'بیک اپ ناکام: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppSpacing.radiusLg)),
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.emerald700.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.cloud_upload_outlined,
                color: AppColors.emerald700, size: 28),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text('بیک اپ یاد دہانی',
                style: AppTypography.titleUr),
          ),
        ],
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'آپ کے مدرسے کا ڈیٹا قیمتی ہے۔ ابھی بیک اپ لے لیں تاکہ موبائل گم ہونے یا ایپ ڈیلیٹ ہونے پر بھی محفوظ رہے۔',
            style: AppTypography.bodyUr,
          ),
          if (_busy) ...[
            const SizedBox(height: 16),
            LinearProgressIndicator(
              value: _progress == 0 ? null : _progress,
              color: AppColors.emerald700,
              backgroundColor: AppColors.emerald700.withValues(alpha: 0.15),
            ),
            const SizedBox(height: 8),
            Text('بیک اپ بن رہا ہے…',
                textAlign: TextAlign.center,
                style: AppTypography.captionUr),
          ],
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!,
                style: const TextStyle(fontFamily: AppTypography.urduFont, color: AppColors.danger, fontSize: 14),
                textAlign: TextAlign.center),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: _busy
              ? null
              : () async {
                  await ref
                      .read(backupServiceProvider)
                      .markPromptShown();
                  if (context.mounted) Navigator.of(context).pop(false);
                },
          child: Text('بعد میں', style: AppTypography.bodyUr),
        ),
        ElevatedButton.icon(
          onPressed: _busy ? null : _doBackup,
          icon: const Icon(Icons.backup_outlined),
          label: Text('ابھی بیک اپ لیں',
              style: AppTypography.bodyUr
                  .copyWith(color: Colors.white)),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.emerald700,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
            padding:
                const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          ),
        ),
      ],
    );
  }
}

/// Checks on app start whether the backup reminder should pop up.
Future<void> maybeShowBackupPrompt(BuildContext context, WidgetRef ref) async {
  try {
    final svc = ref.read(backupServiceProvider);
    if (!await svc.shouldPromptBackup()) return;
    if (!context.mounted) return;
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const BackupPromptDialog(),
    );
  } catch (_) {}
}
