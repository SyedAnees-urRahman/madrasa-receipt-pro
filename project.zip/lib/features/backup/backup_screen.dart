import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_storage/shared_storage.dart' as saf;
import '../../../app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/widgets.dart';
import '../../services/backup/backup_service.dart';

/// Backup & restore screen: local backups, Google Drive folder, frequency.
class BackupScreen extends ConsumerStatefulWidget {
  const BackupScreen({super.key});

  @override
  ConsumerState<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends ConsumerState<BackupScreen> {
  bool _busy = false;
  double _progress = 0;
  String? _status;
  List<File> _local = [];
  List<saf.DocumentFile> _drive = [];
  bool _driveLoading = false;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final svc = ref.read(backupServiceProvider);
    final local = await svc.listLocalBackups();
    List<saf.DocumentFile> drive = [];
    if (await svc.hasDriveFolder) {
      if (mounted) setState(() => _driveLoading = true);
      drive = await svc.listDriveBackups();
    }
    if (mounted) {
      setState(() {
        _local = local;
        _drive = drive;
        _driveLoading = false;
      });
    }
  }

  Future<void> _doBackup() async {
    setState(() {
      _busy = true;
      _status = null;
      _progress = 0;
    });    try {
      final svc = ref.read(backupServiceProvider);
      final zip = await svc.createLocalBackup(
          onProgress: (p) =>
              mounted ? setState(() => _progress = p * 0.7) : null);
      if (await svc.hasDriveFolder) {
        if (mounted) setState(() => _status = 'Drive پر اپلوڈ ہو رہا ہے…');
        await svc.uploadToDrive(zip,
            onProgress: (p) =>
                mounted ? setState(() => _progress = 0.7 + p * 0.3) : null);
      }
      if (!mounted) return;
      setState(() {
        _busy = false;
        _status = 'بیک اپ محفوظ ہو گیا ✓';
      });
      await _refresh();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _status = 'ناکام: $e';
      });
    }
  }

  Future<void> _pickDrive() async {
    final svc = ref.read(backupServiceProvider);
    final ok = await svc.pickDriveFolder();
    if (!mounted) return;
    if (ok) {
      mrpShowSnack(context, 'Drive فولڈر منتخب ہو گیا ✓');
    } else {
      mrpShowSnack(context, 'کوئی فولڈر منتخب نہیں ہوا', isError: true);
    }
    await _refresh();
  }

  Future<void> _pickLocalFolder() async {
    final svc = ref.read(backupServiceProvider);
    final ok = await svc.pickLocalFolder();
    if (!mounted) return;
    if (ok) {
      mrpShowSnack(context, 'بیک اپ فولڈر منتخب ہو گیا ✓');
      ref.invalidate(_localFolderNameProvider);
    } else {
      mrpShowSnack(context, 'کوئی فولڈر منتخب نہیں ہوا', isError: true);
    }
  }

  Future<void> _restoreLocal(File zip) async {
    final meta = await ref.read(backupServiceProvider).readMetadata(zip);
    final name = meta?['institutionName'] ?? 'نامعلوم';
    final date = meta?['createdAt'] ?? '';
    if (!mounted) return;
    final ok = await mrpConfirmDialog(
      context,
      title: 'بیک اپ بحال کریں؟',
      body: 'ادارہ: $name\nتاریخ: $date\n\nموجودہ ڈیٹا مٹ جائے گا۔',
      confirmLabel: 'بحال کریں',
      danger: true,
    );
    if (!ok) return;
    await _performRestore(zip);
  }

  Future<void> _performRestore(File zip) async {
    if (mounted) {
      setState(() {
        _busy = true;
        _status = 'بحال ہو رہا ہے…';
      });
    }
    try {
      final db = ref.read(appDatabaseProvider);
      await db.close();
      await ref.read(backupServiceProvider).restoreFromZip(zip);
      ref.invalidate(appDatabaseProvider);
      if (!mounted) return;
      setState(() {
        _busy = false;
        _status = 'بحال ہو گیا ✓';
      });
      mrpShowSnack(context, 'بیک اپ بحال ہو گیا ✓');
      if (mounted) context.go('/splash');
    } catch (e) {
      ref.invalidate(appDatabaseProvider);
      if (!mounted) return;
      setState(() {
        _busy = false;
        _status = 'بحالی ناکام: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = ref.watch(workspaceStoreProvider);
    final freq = store.getString(BackupService.frequencyPref) ?? 'weekly';
    final lastBackup = store.getString(BackupService.lastBackupPref);
    final hasDrive = ref.watch(_driveFolderProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('بیک اپ و بحالی')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          MrpCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    const Icon(Icons.cloud_upload_outlined,
                        color: AppColors.emerald700, size: 28),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('ڈیٹا کی حفاظت',
                              style: AppTypography.titleUr),
                          Text(
                            lastBackup == null
                                ? 'ابھی تک کوئی بیک اپ نہیں'
                                : 'آخری بیک اپ: ${_fmtDate(lastBackup)}',
                            style: AppTypography.captionUr,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                if (_busy) ...[
                  LinearProgressIndicator(
                    value: _progress == 0 ? null : _progress,
                    color: AppColors.emerald700,
                  ),
                  const SizedBox(height: 8),
                ],
                if (_status != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Text(_status!,
                        textAlign: TextAlign.center,
                        style: AppTypography.bodyUr),
                  ),
                MrpPrimaryButton(
                  label: 'ابھی بیک اپ لیں',
                  icon: Icons.backup_outlined,
                  loading: _busy,
                  onPressed: _busy ? () {} : _doBackup,
                ),
                const SizedBox(height: 12),
                // Local folder picker
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.folder_open_outlined,
                      color: AppColors.emerald700),
                  title: Text('بیک اپ فولڈر',
                      style: AppTypography.bodyUr),
                  subtitle: Text(
                    ref.watch(_localFolderNameProvider),
                    style: AppTypography.captionUr,
                  ),
                  trailing: TextButton(
                    onPressed: _pickLocalFolder,
                    child: const Text('تبدیل کریں'),
                  ),
                ),
              ],
            ),
          ),
          MrpSectionHeader(title: 'خودکار یاد دہانی'),
          MrpCard(
            child: Column(
              children: [
                _freqTile('روزانہ', 'daily', freq, store),
                _freqTile('ہفتہ وار', 'weekly', freq, store),
                _freqTile('ماہانہ', 'monthly', freq, store),
                _freqTile('بند', 'off', freq, store),
              ],
            ),
          ),
          MrpSectionHeader(title: 'Google Drive'),
          MrpCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'ایک بار Drive کا فولڈر چنیں۔ اس کے بعد ہر بیک اپ خودکار وہاں بھی اپلوڈ ہوگا۔ نیا موبائل لینے پر یہیں سے بحال کر سکیں گے۔',
                  style: AppTypography.bodyUr,
                ),
                const SizedBox(height: 12),
                MrpSecondaryButton(
                  label: hasDrive
                      ? 'Drive فولڈر تبدیل کریں'
                      : 'Drive فولڈر منتخب کریں',
                  icon: Icons.folder_open_outlined,
                  onPressed: _pickDrive,
                ),
                if (_driveLoading)
                  const Padding(
                    padding: EdgeInsets.only(top: 12),
                    child: Center(child: CircularProgressIndicator()),
                  ),
                for (final d in _drive)
                  ListTile(
                    leading: const Icon(Icons.cloud_done_outlined,
                        color: AppColors.emerald700),
                    title: Text(d.name ?? '',
                        textDirection: TextDirection.ltr,
                        style: const TextStyle(fontFamily: AppTypography.urduFont, fontSize: 13)),
                    trailing: TextButton(
                      child: const Text('بحال کریں'),
                      onPressed: () async {
                        final svc = ref.read(backupServiceProvider);
                        final file = await svc.downloadDriveBackup(d);
                        await _restoreLocal(file);
                      },
                    ),
                  ),
              ],
            ),
          ),
          MrpSectionHeader(title: 'موبائل میں محفوظ بیک اپ'),
          if (_local.isEmpty)
            const MrpCard(
                child: Text('ابھی کوئی بیک اپ نہیں بنایا گیا۔',
                    textAlign: TextAlign.center)),
          for (final f in _local)
            MrpCard(
              onTap: () => _restoreLocal(f),
              child: Row(
                children: [
                  const Icon(Icons.archive_outlined,
                      color: AppColors.emerald700),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      f.uri.pathSegments.last,
                      textDirection: TextDirection.ltr,
                      style: const TextStyle(fontFamily: AppTypography.urduFont, fontSize: 13),
                    ),
                  ),
                  const Icon(Icons.restore, color: AppColors.ink300),
                ],
              ),
            ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _freqTile(
      String label, String value, String group, dynamic store) {
    return RadioListTile<String>(
      title: Text(label, style: AppTypography.bodyUr),
      value: value,
      groupValue: group,
      activeColor: AppColors.emerald700,
      onChanged: (v) async {
        await store.setString(BackupService.frequencyPref, v!);
        setState(() {});
      },
    );
  }

  String _fmtDate(String iso) {
    final d = DateTime.tryParse(iso);
    if (d == null) return iso;
    return '${d.day}/${d.month}/${d.year} ${d.hour}:${d.minute.toString().padLeft(2, '0')}';
  }
}

final _driveFolderProvider =
    Provider<bool>((ref) => ref.watch(backupServiceProvider).driveFolderUri != null);

final _localFolderNameProvider = Provider<String>(
    (ref) => ref.watch(backupServiceProvider).localFolderName);
