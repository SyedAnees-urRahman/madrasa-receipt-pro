import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_themes.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/widgets.dart';

/// Settings: language (persistent), appearance/accessibility, workspace
/// switching, institution profile, sign-out.
class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final session = ref.watch(sessionProvider);
    final locale = ref.watch(localeProvider);
    final themeMode = ref.watch(themeModeProvider);
    final store = ref.watch(workspaceStoreProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('ترتیبات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (session != null)
            MrpCard(
              child: Row(
                children: [
                  const CircleAvatar(
                      child: Icon(Icons.person_outline)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        Text(session.displayName,
                            style: AppTypography.bodyUr
                                .copyWith(
                                    fontWeight:
                                        FontWeight.w600)),
                        Text(session.email,
                            style:
                                AppTypography.captionEn,
                            textDirection:
                                TextDirection.ltr),
                        Text(session.role.name,
                            style: const TextStyle(fontFamily: AppTypography.urduFont, fontSize: 11,
                                color: AppColors.ink500),
                            textDirection:
                                TextDirection.ltr),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          MrpSectionHeader(title: 'زبان'),
          MrpCard(
            child: Column(
              children: [
                RadioListTile<String>(
                  title: const Text('اردو'),
                  value: 'ur',
                  groupValue: locale.languageCode,
                  activeColor: AppColors.emerald700,
                  onChanged: (v) =>
                      _setLocale(ref, store, v!),
                ),
                RadioListTile<String>(
                  title: const Text('English'),
                  value: 'en',
                  groupValue: locale.languageCode,
                  activeColor: AppColors.emerald700,
                  onChanged: (v) =>
                      _setLocale(ref, store, v!),
                ),
              ],
            ),
          ),
          MrpSectionHeader(title: 'تھیم'),
          MrpCard(
            child: Column(
              children: [
                RadioListTile<MrpThemeMode>(
                  title: const Text('کلے بلیو (نرم 3D)'),
                  subtitle: const Text('نیلا، گول، نرم',
                      style: TextStyle(fontFamily: AppTypography.urduFont, fontSize: 12)),
                  value: MrpThemeMode.clay,
                  groupValue: themeMode,
                  onChanged: (v) => _setTheme(ref, store, v!),
                ),
                RadioListTile<MrpThemeMode>(
                  title: const Text('نیومورفک (ہلکا)'),
                  subtitle: const Text('صاف، ہلکا نیلا',
                      style: TextStyle(fontFamily: AppTypography.urduFont, fontSize: 12)),
                  value: MrpThemeMode.neumorphic,
                  groupValue: themeMode,
                  onChanged: (v) => _setTheme(ref, store, v!),
                ),
              ],
            ),
          ),
          MrpSectionHeader(title: 'ادارہ'),
          _tile(context, Icons.business_outlined, 'ادارے کی پروفائل',
              () => context.push('/institution')),
          _tile(context, Icons.backup_outlined, 'بیک اپ و بحالی',
              () => context.push('/backup')),
          _tile(context, Icons.swap_horiz, 'ورک اسپیس بدلیں',
              () => _switchWorkspace(context, ref)),
          MrpSectionHeader(title: 'رسائی'),
          const MrpCard(
            child: Text(
              'فون کی ترتیبات سے ٹیکسٹ سائز، بولڈ ٹیکسٹ اور "اینیمیشن کم کریں" کا احترام کیا جاتا ہے۔ تمام بٹن کم از کم 48dp کے ہیں۔',
              style:
                  TextStyle(fontFamily: AppTypography.urduFont, fontSize: 13, color: AppColors.ink500),
            ),
          ),
          const SizedBox(height: 16),
          MrpSecondaryButton(
            label: 'لاگ آؤٹ',
            icon: Icons.logout,
            onPressed: () async {
              final ok = await mrpConfirmDialog(context,
                  title: 'لاگ آؤٹ کریں؟',
                  body:
                      'اس ڈیوائس سے لاگ آؤٹ ہو جائیں گے۔ مقامی ڈیٹا محفوظ رہے گا۔',
                  confirmLabel: 'لاگ آؤٹ');
              if (!ok) return;
              await ref.read(authRepositoryProvider).signOut();
              ref.read(sessionProvider.notifier).state = null;
              if (context.mounted) context.go('/login');
            },
          ),
          const SizedBox(height: 24),
          const Center(
            child: Text('Madrasa Receipt Pro v1.1.0',
                style: TextStyle(fontFamily: AppTypography.urduFont, fontSize: 11, color: AppColors.ink300),
                textDirection: TextDirection.ltr),
          ),
        ],
      ),
    );
  }

  void _setLocale(WidgetRef ref, dynamic store, String code) {
    store.setLocaleCode(code);
    ref.read(localeProvider.notifier).state = Locale(code);
  }

  void _setTheme(WidgetRef ref, dynamic store, MrpThemeMode mode) {
    store.setString('theme_mode',
        mode == MrpThemeMode.neumorphic ? 'neumorphic' : 'clay');
    ref.read(themeModeProvider.notifier).state = mode;
  }

  Widget _tile(
      BuildContext context, IconData icon, String label, VoidCallback onTap) {
    return MrpCard(
      onTap: onTap,
      child: Row(
        children: [
          Icon(icon, color: AppColors.emerald700),
          const SizedBox(width: 12),
          Expanded(child: Text(label)),
          const Icon(Icons.chevron_left, color: AppColors.ink300),
        ],
      ),
    );
  }

  Future<void> _switchWorkspace(
      BuildContext context, WidgetRef ref) async {
    final res =
        await ref.read(institutionRepositoryProvider).listWorkspaces();
    if (!context.mounted || !res.isOk) return;
    final current =
        ref.read(workspaceStoreProvider).currentInstitutionId;
    final picked = await showDialog<String>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: const Text('ورک اسپیس'),
        children: [
          for (final w in res.value)
            SimpleDialogOption(
              onPressed: () => Navigator.pop(ctx, w.id),
              child: Row(
                children: [
                  Expanded(
                      child: Text(
                          '${w.nameUr}${w.isDemo ? ' (DEMO)' : ''}')),
                  if (w.id == current)
                    const Icon(Icons.check,
                        color: AppColors.success),
                ],
              ),
            ),
        ],
      ),
    );
    if (picked != null && picked != current) {
      await ref
          .read(institutionRepositoryProvider)
          .switchWorkspace(picked);
      if (context.mounted) context.go('/home');
    }
  }
}
