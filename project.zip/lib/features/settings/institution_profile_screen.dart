import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../app_providers.dart';
import '../../../core/theme/widgets.dart';
import '../../../domain/entities/entities.dart';

/// Institution profile: editable by admins (audited). Branding configured
/// here flows into every receipt PDF.
class InstitutionProfileScreen extends ConsumerStatefulWidget {
  const InstitutionProfileScreen({super.key});
  @override
  ConsumerState<InstitutionProfileScreen> createState() =>
      _InstitutionProfileScreenState();
}

class _InstitutionProfileScreenState
    extends ConsumerState<InstitutionProfileScreen> {
  Institution? _inst;
  final _nameUr = TextEditingController();
  final _nameEn = TextEditingController();
  final _address = TextEditingController();
  final _phone = TextEditingController();
  final _email = TextEditingController();
  final _regNo = TextEditingController();
  final _ntn = TextEditingController();
  final _prefix = TextEditingController();
  bool _loading = true;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in
        [_nameUr, _nameEn, _address, _phone, _email, _regNo, _ntn, _prefix]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    final res =
        await ref.read(institutionRepositoryProvider).getCurrent();
    if (!mounted) return;
    final inst = res.isOk ? res.value : null;
    setState(() {
      _inst = inst;
      _loading = false;
      if (inst != null) {
        _nameUr.text = inst.nameUr;
        _nameEn.text = inst.nameEn;
        _address.text = inst.address ?? '';
        _phone.text = inst.phone ?? '';
        _email.text = inst.email ?? '';
        _regNo.text = inst.registrationNo ?? '';
        _ntn.text = inst.ntn ?? '';
        _prefix.text = inst.receiptPrefix;
      }
    });
  }

  Future<void> _save() async {
    final inst = _inst;
    if (inst == null ||
        _nameUr.text.trim().isEmpty ||
        _nameEn.text.trim().isEmpty) {
      mrpShowSnack(context, 'نام لازمی ہے', isError: true);
      return;
    }
    setState(() => _busy = true);
    final updated = Institution(
      id: inst.id,
      nameUr: _nameUr.text.trim(),
      nameEn: _nameEn.text.trim(),
      logoPath: inst.logoPath,
      address: _address.text.trim().isEmpty ? null : _address.text.trim(),
      phone: _phone.text.trim().isEmpty ? null : _phone.text.trim(),
      email: _email.text.trim().isEmpty ? null : _email.text.trim(),
      registrationNo:
          _regNo.text.trim().isEmpty ? null : _regNo.text.trim(),
      ntn: _ntn.text.trim().isEmpty ? null : _ntn.text.trim(),
      fyStartMonth: inst.fyStartMonth,
      fyStartDay: inst.fyStartDay,
      receiptPrefix: _prefix.text.trim().isEmpty
          ? inst.receiptPrefix
          : _prefix.text.trim(),
      numberingFormat: inst.numberingFormat,
      receiptLanguage: inst.receiptLanguage,
      printFormat: inst.printFormat,
      acceptedMethods: inst.acceptedMethods,
      dualApprovalThresholdPaisa: inst.dualApprovalThresholdPaisa,
      autoSync: inst.autoSync,
      isDemo: inst.isDemo,
      signatoriesJson: inst.signatoriesJson,
      createdAt: inst.createdAt,
      updatedAt: DateTime.now(),
    );
    final res =
        await ref.read(institutionRepositoryProvider).save(updated);
    if (!mounted) return;
    setState(() => _busy = false);
    if (res.isOk) {
      mrpShowSnack(context, 'پروفائل محفوظ ہو گئی');
      _load();
    } else {
      mrpShowSnack(context, 'محفوظ نہیں ہو سکی', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ادارے کی پروفائل')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                MrpTextField(
                    controller: _nameUr,
                    label: 'ادارے کا نام (اردو) *'),
                const SizedBox(height: 12),
                MrpTextField(
                    controller: _nameEn,
                    label: 'Institution name (English) *',
                    textDirection: TextDirection.ltr),
                const SizedBox(height: 12),
                MrpTextField(
                    controller: _address,
                    label: 'پتہ',
                    maxLines: 2),
                const SizedBox(height: 12),
                MrpTextField(
                    controller: _phone,
                    label: 'فون',
                    keyboardType: TextInputType.phone,
                    textDirection: TextDirection.ltr),
                const SizedBox(height: 12),
                MrpTextField(
                    controller: _email,
                    label: 'ای میل',
                    keyboardType: TextInputType.emailAddress,
                    textDirection: TextDirection.ltr),
                const SizedBox(height: 12),
                MrpTextField(
                    controller: _regNo,
                    label: 'رجسٹریشن نمبر'),
                const SizedBox(height: 12),
                MrpTextField(
                    controller: _ntn,
                    label: 'NTN',
                    textDirection: TextDirection.ltr),
                const SizedBox(height: 12),
                MrpTextField(
                    controller: _prefix,
                    label: 'رسید کا سابقہ',
                    textDirection: TextDirection.ltr),
                const SizedBox(height: 20),
                MrpPrimaryButton(
                    label: 'محفوظ کریں',
                    loading: _busy,
                    onPressed: _save),
              ],
            ),
    );
  }
}
