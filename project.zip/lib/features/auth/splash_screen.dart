import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../app_providers.dart';
import '../../../core/theme/app_colors.dart';

/// Decides the first screen: setup → login → home.
class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});
  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _decide();
  }

  Future<void> _decide() async {
    await Future.delayed(const Duration(milliseconds: 600));
    if (!mounted) return;
    final store = ref.read(workspaceStoreProvider);
    if (!store.setupComplete) {
      context.go('/setup');
      return;
    }
    final session = await ref.read(authRepositoryProvider).currentSession();
    if (!mounted) return;
    if (session.isOk && session.value != null) {
      ref.read(sessionProvider.notifier).state = session.value;
      // Restore workspace from the session's institution.
      await store.setCurrentInstitutionId(session.value!.institutionId);
      context.go('/home');
    } else {
      context.go('/login');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.emerald800,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(24),
                border:
                    Border.all(color: AppColors.gold500, width: 2),
              ),
              child: const Icon(Icons.mosque,
                  color: Colors.white, size: 52),
            ),
            const SizedBox(height: 20),
            const Text(
              'مدرسہ رسید پرو',
              style: TextStyle(
                fontFamily: 'JameelNooriNastaleeq',
                        fontFamilyFallback: const ['JameelNooriNastaleeq', 'NotoNastaliqUrdu'],
                fontSize: 30,
                height: 1.8,
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Madrasa Receipt Pro',
              style: TextStyle(
                color: Colors.white.withValues(alpha: 0.85),
                fontSize: 16,
                letterSpacing: 1.2,
              ),
            ),
            const SizedBox(height: 28),
            const SizedBox(
              width: 28,
              height: 28,
              child: CircularProgressIndicator(
                color: AppColors.gold500,
                strokeWidth: 3,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
