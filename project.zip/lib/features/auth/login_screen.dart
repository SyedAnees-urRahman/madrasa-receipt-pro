import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../app_providers.dart';
import '../../../core/config/app_config.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/widgets.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});
  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _busy = false;
  String? _error;
  bool _biometricAvailable = false;

  @override
  void initState() {
    super.initState();
    _checkBiometric();
  }

  Future<void> _checkBiometric() async {
    final res = await ref.read(authRepositoryProvider).biometricAvailable();
    if (mounted && res.isOk) {
      setState(() => _biometricAvailable = res.value);
    }
  }

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _signIn() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    final res = await ref
        .read(authRepositoryProvider)
        .signIn(_email.text, _password.text);
    if (!mounted) return;
    setState(() => _busy = false);
    if (res.isOk) {
      ref.read(sessionProvider.notifier).state = res.value;
      await ref
          .read(workspaceStoreProvider)
          .setCurrentInstitutionId(res.value.institutionId);
      context.go('/home');
    } else {
      setState(() => _error = 'لاگ اِن ناکام۔ ای میل اور پاس ورڈ چیک کریں۔');
    }
  }

  Future<void> _biometricLogin() async {
    final authOk =
        await ref.read(authRepositoryProvider).authenticateBiometric();
    if (!mounted || !authOk.isOk || !authOk.value) return;
    final session =
        await ref.read(authRepositoryProvider).currentSession();
    if (!mounted) return;
    if (session.isOk && session.value != null) {
      ref.read(sessionProvider.notifier).state = session.value;
      await ref
          .read(workspaceStoreProvider)
          .setCurrentInstitutionId(session.value!.institutionId);
      context.go('/home');
    }
  }

  @override
  Widget build(BuildContext context) {
    final offline = !AppConfig.isSupabaseConfigured;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Icon(Icons.mosque,
                        size: 64, color: AppColors.emerald700),
                    const SizedBox(height: 16),
                    const Text(
                      'مدرسہ رسید پرو',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'JameelNooriNastaleeq',
                        fontFamilyFallback: const ['JameelNooriNastaleeq', 'NotoNastaliqUrdu'],
                        fontSize: 28,
                        height: 1.8,
                        color: AppColors.emerald900,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 24),
                    if (offline) ...[
                      MrpTextField(
                        controller: _password,
                        label: 'ایڈمن PIN',
                        obscureText: true,
                        keyboardType: TextInputType.number,
                        textDirection: TextDirection.ltr,
                        validator: (v) => (v == null || v.isEmpty)
                            ? 'PIN درج کریں'
                            : null,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'یہ وہی PIN ہے جو سیٹ اپ میں بنایا تھا۔',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            color: Colors.grey, fontSize: 13),
                      ),
                    ] else ...[
                      MrpTextField(
                        controller: _email,
                        label: 'ای میل',
                        keyboardType: TextInputType.emailAddress,
                        textDirection: TextDirection.ltr,
                        validator: (v) =>
                            (v == null || !v.contains('@'))
                                ? 'درست ای میل درج کریں'
                                : null,
                      ),
                      const SizedBox(height: 12),
                      MrpTextField(
                        controller: _password,
                        label: 'پاس ورڈ',
                        obscureText: true,
                        textDirection: TextDirection.ltr,
                        validator: (v) => (v == null || v.isEmpty)
                            ? 'پاس ورڈ درج کریں'
                            : null,
                      ),
                    ],
                    if (_error != null) ...[
                      const SizedBox(height: 12),
                      Text(_error!,
                          style: const TextStyle(
                              color: AppColors.danger, fontSize: 14),
                          textAlign: TextAlign.center),
                    ],
                    const SizedBox(height: 20),
                    MrpPrimaryButton(
                      label: 'لاگ اِن',
                      loading: _busy,
                      onPressed: _signIn,
                    ),
                    if (_biometricAvailable) ...[
                      const SizedBox(height: 12),
                      MrpSecondaryButton(
                        label: 'بائیومیٹرک سے داخل ہوں',
                        icon: Icons.fingerprint,
                        onPressed: _biometricLogin,
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
