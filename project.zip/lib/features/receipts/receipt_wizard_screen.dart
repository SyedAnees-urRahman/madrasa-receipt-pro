import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import '../../../app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/widgets.dart';
import '../../../core/utils/amount_words.dart';
import '../../../core/utils/money.dart';
import '../../../domain/entities/entities.dart';
import '../../../domain/entities/enums.dart';
import '../../../domain/repositories/repositories.dart';
import '../../../services/pdf/receipt_document.dart';
import 'dart:typed_data';

class _AllocationRow {
  String? fundId;
  String? purposeId;
  final amountCtrl = TextEditingController();
}

class ReceiptWizardScreen extends ConsumerStatefulWidget {
  const ReceiptWizardScreen({super.key});
  @override
  ConsumerState<ReceiptWizardScreen> createState() =>
      _ReceiptWizardScreenState();
}

class _ReceiptWizardScreenState extends ConsumerState<ReceiptWizardScreen> {
  int _stage = 0;
  bool _busy = false;

  // Stage 1
  TxType _txType = TxType.cash;
  // Stage 2
  final _donorName = TextEditingController();
  final _donorPhone = TextEditingController();
  final _donorEmail = TextEditingController();
  final _donorAddress = TextEditingController();
  bool _anonymous = false;
  String? _donorId;
  List<Donor> _donorMatches = const [];
  // Stage 3
  final _totalCtrl = TextEditingController();
  final _allocs = <_AllocationRow>[_AllocationRow()];
  // Stage 4
  PaymentMethod _method = PaymentMethod.cash;
  String? _accountId;
  final _reference = TextEditingController();
  DateTime _receiptDate = DateTime.now();
  final _staffNotes = TextEditingController();
  final _donorNote = TextEditingController();
  String? _evidencePath;
  // Data
  List<FundType> _funds = const [];
  List<Purpose> _purposes = const [];
  List<BankAccount> _accounts = const [];
  Institution? _institution;
  List<PaymentMethod> _acceptedMethods = const [PaymentMethod.cash];
  // Stage 5/6
  Receipt? _saved;
  List<Receipt> _duplicates = const [];
  Uint8List? _pdfBytes;
  bool _pdfBusy = false;

  static const _stageTitles = [
    'لین دین کی قسم',
    'عطیہ دہندہ',
    'رقم و تقسیم',
    'ادائیگی کی تفصیل',
    'جائزہ',
    'رسید جاری کریں',
  ];

  @override
  void initState() {
    super.initState();
    _loadRefs();
    _donorName.addListener(_searchDonors);
  }

  @override
  void dispose() {
    _donorName.dispose();
    _donorPhone.dispose();
    _donorEmail.dispose();
    _donorAddress.dispose();
    _totalCtrl.dispose();
    _reference.dispose();
    _staffNotes.dispose();
    _donorNote.dispose();
    for (final a in _allocs) {
      a.amountCtrl.dispose();
    }
    super.dispose();
  }

  Future<void> _loadRefs() async {
    final funds = await ref.read(fundRepositoryProvider).funds();
    final purposes = await ref.read(fundRepositoryProvider).purposes();
    final accounts = await ref.read(accountRepositoryProvider).accounts();
    final inst = await ref.read(institutionRepositoryProvider).getCurrent();
    if (!mounted) return;
    setState(() {
      _funds = funds.isOk ? funds.value : const [];
      _purposes = purposes.isOk ? purposes.value : const [];
      _accounts = accounts.isOk ? accounts.value : const [];
      _institution = inst.isOk ? inst.value : null;
      _acceptedMethods = _institution?.acceptedMethods ?? const [PaymentMethod.cash];
      if (!_acceptedMethods.contains(_method)) _method = _acceptedMethods.first;
      if (_allocs.first.fundId == null && _funds.isNotEmpty) {
        _allocs.first.fundId = _funds.first.id;
      }
      final cashAcct = _accounts.where((a) => a.type == AccountType.cash);
      _accountId = cashAcct.isNotEmpty ? cashAcct.first.id : _accounts.firstOrNull?.id;
    });
  }

  Future<void> _searchDonors() async {
    final q = _donorName.text.trim();
    if (q.length < 2 || _anonymous) {
      setState(() => _donorMatches = const []);
      return;
    }
    final res = await ref.read(donorRepositoryProvider).search(q, limit: 6);
    if (mounted && res.isOk) setState(() => _donorMatches = res.value);
  }

  int get _totalPaisa => Money.tryParsePkr(_totalCtrl.text) ?? 0;

  int get _allocatedPaisa {
    var sum = 0;
    for (final a in _allocs) {
      sum += Money.tryParsePkr(a.amountCtrl.text) ?? 0;
    }
    return sum;
  }

  bool get _allocationOk =>
      _totalPaisa > 0 &&
      _allocs.every((a) =>
          a.fundId != null && (Money.tryParsePkr(a.amountCtrl.text) ?? 0) > 0) &&
      _allocatedPaisa == _totalPaisa;

  bool _validStage() {
    switch (_stage) {
      case 1:
        return _anonymous || _donorName.text.trim().isNotEmpty;
      case 2:
        return _allocationOk;
      case 3:
        return _accountId != null;
      default:
        return true;
    }
  }

  Future<void> _next() async {
    if (!_validStage()) {
      mrpShowSnack(context, 'لازمی خانے درست کریں', isError: true);
      return;
    }
    if (_stage == 4) {
      await _checkDuplicates();
    }
    if (_stage < 5) {
      setState(() => _stage++);
    }
  }

  Future<void> _checkDuplicates() async {
    final draft = _buildDraft();
    if (draft == null) return;
    final res =
        await ref.read(receiptRepositoryProvider).findPossibleDuplicates(draft);
    if (mounted && res.isOk) setState(() => _duplicates = res.value);
  }

  ReceiptDraft? _buildDraft() {
    final total = _totalPaisa;
    if (total <= 0) return null;
    return ReceiptDraft(
      txType: _txType,
      donorId: _donorId,
      donorName: _anonymous ? '' : _donorName.text.trim(),
      donorPhone: _donorPhone.text.trim().isEmpty ? null : _donorPhone.text.trim(),
      donorEmail: _donorEmail.text.trim().isEmpty ? null : _donorEmail.text.trim(),
      donorAddress:
          _donorAddress.text.trim().isEmpty ? null : _donorAddress.text.trim(),
      isAnonymous: _anonymous,
      totalPaisa: total,
      allocations: [
        for (final a in _allocs)
          AllocationDraft(
            fundTypeId: a.fundId!,
            purposeId: a.purposeId,
            amountPaisa: Money.tryParsePkr(a.amountCtrl.text) ?? 0,
          ),
      ],
      receiptDate: _receiptDate,
      paymentMethod: _method,
      bankAccountId: _accountId,
      referenceNo:
          _reference.text.trim().isEmpty ? null : _reference.text.trim(),
      evidencePath: _evidencePath,
      staffNotes:
          _staffNotes.text.trim().isEmpty ? null : _staffNotes.text.trim(),
      donorNote:
          _donorNote.text.trim().isEmpty ? null : _donorNote.text.trim(),
    );
  }

  Future<void> _save() async {
    final draft = _buildDraft();
    if (draft == null || !_allocationOk) {
      mrpShowSnack(context, 'تقسیم کا مجموعہ رقم کے برابر ہونا چاہیے',
          isError: true);
      return;
    }
    setState(() => _busy = true);
    final repo = ref.read(receiptRepositoryProvider);
    final created = await repo.createDraft(draft);
    if (!mounted) {
      return;
    }
    if (!created.isOk) {
      setState(() => _busy = false);
      mrpShowSnack(context, 'رسید محفوظ نہیں ہو سکی', isError: true);
      return;
    }
    var receipt = created.value;
    // Pledges stay drafts; everything else moves to pending verification.
    if (_txType != TxType.pledge) {
      final submitted = await repo.submitForVerification(receipt.id);
      if (submitted.isOk) receipt = submitted.value;
    }
    setState(() {
      _busy = false;
      _saved = receipt;
      _stage = 5;
      _pdfBytes = null;
    });
    // Best-effort: try to sync + number immediately when online.
    _tryAutoNumber();
  }

  Future<void> _tryAutoNumber() async {
    final receipt = _saved;
    final ctx = ref.read(repositoryContextProvider);
    if (receipt == null || ctx == null) return;
    if (receipt.status != ReceiptStatus.confirmed) return;
    try {
      final engine = ref.read(syncEngineProvider);
      final result = await engine.runOnce(
          institutionId: ctx.institutionId, actorId: ctx.actorId);
      if (result.numbered > 0 && mounted) {
        final fresh =
            await ref.read(receiptRepositoryProvider).getById(receipt.id);
        if (fresh.isOk && fresh.value != null) {
          setState(() => _saved = fresh.value);
        }
      }
    } catch (_) {
      // Offline or failed — the receipt stays provisional; sync center
      // will number it later. Never an error to the user here.
    }
  }

  Future<Uint8List?> _buildPdf() async {
    final receipt = _saved;
    final inst = _institution;
    if (receipt == null || inst == null) return null;
    setState(() => _pdfBusy = true);
    try {
      final fundNames = {for (final f in _funds) f.id: f};
      final purposeNames = {for (final p in _purposes) p.id: p};
      final qr = await ref
          .read(qrVerificationProvider)
          .buildPayload(receipt: receipt, institutionId: inst.id);
      final data = ReceiptDocumentData(
        institution: inst,
        receipt: receipt,
        allocations: [
          for (final a in receipt.allocations)
            AllocationLine(
              fundUr: fundNames[a.fundTypeId]?.nameUr ?? '',
              fundEn: fundNames[a.fundTypeId]?.nameEn ?? '',
              purposeUr: a.purposeId == null
                  ? null
                  : purposeNames[a.purposeId]?.nameUr,
              purposeEn: a.purposeId == null
                  ? null
                  : purposeNames[a.purposeId]?.nameEn,
              amountPaisa: a.amountPaisa,
            ),
        ],
        qrPayload: qr,
        locale: inst.receiptLanguage,
      );
      final bytes = await ref.read(receiptPdfServiceProvider).buildReceiptPdf(
            context: context,
            data: data,
          );
      if (mounted) setState(() => _pdfBytes = bytes);
      return bytes;
    } finally {
      if (mounted) setState(() => _pdfBusy = false);
    }
  }

  Future<void> _previewPdf() async {
    final bytes = _pdfBytes ?? await _buildPdf();
    if (bytes == null || !mounted) return;
    await showDialog(
      context: context,
      builder: (ctx) => Dialog(
        insetPadding: const EdgeInsets.all(12),
        child: SizedBox(
          width: double.infinity,
          height: MediaQuery.of(ctx).size.height * 0.85,
          child: Column(
            children: [
              AppBar(
                title: const Text('رسید کا پیش نظارہ'),
                automaticallyImplyLeading: false,
                actions: [
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
              Expanded(
                child: PdfPreview(
                  build: (_) async => bytes,
                  allowPrinting: true,
                  allowSharing: true,
                  canChangePageFormat: false,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _sharePdf() async {
    final bytes = _pdfBytes ?? await _buildPdf();
    if (bytes == null || !mounted) return;
    final dir = await getTemporaryDirectory();
    final name =
        'receipt-${_saved?.officialNumber ?? _saved?.localProvisionalLabel ?? 'draft'}.pdf';
    final file = File('${dir.path}/$name');
    await file.writeAsBytes(bytes);
    await Share.shareXFiles([XFile(file.path)],
        text: 'رسید — ${_institution?.nameUr ?? ''}');
  }

  Future<void> _savePdfLocally() async {
    final bytes = _pdfBytes ?? await _buildPdf();
    if (bytes == null || !mounted) return;
    try {
      final dir = await getDownloadsDirectory() ??
          await getApplicationDocumentsDirectory();
      final name =
          'receipt-${_saved?.officialNumber ?? _saved?.localProvisionalLabel ?? 'draft'}.pdf';
      final file = File('${dir.path}/$name');
      await file.writeAsBytes(bytes);
      if (mounted) mrpShowSnack(context, 'محفوظ ہو گیا: $name');
    } catch (_) {
      if (mounted) mrpShowSnack(context, 'محفوظ نہیں ہو سکا', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_stageTitles[_stage]),
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () async {
            final ok = await mrpConfirmDialog(context,
                title: 'وزرڈ بند کریں؟',
                body: 'غیر محفوظ شدہ رسید ضائع ہو جائے گی۔',
                confirmLabel: 'بند کریں',
                danger: true);
            if (ok && mounted) context.pop();
          },
        ),
      ),
      body: Column(
        children: [
          _stepper(),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: _buildStage(),
            ),
          ),
          _bottomBar(),
        ],
      ),
    );
  }

  Widget _stepper() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
      color: Colors.white,
      child: Row(
        children: List.generate(_stageTitles.length * 2 - 1, (i) {
          if (i.isOdd) {
            return Expanded(
                child: Container(
                    height: 2,
                    color: i ~/ 2 < _stage
                        ? AppColors.emerald700
                        : AppColors.cardBorder));
          }
          final n = i ~/ 2;
          final done = n < _stage;
          final current = n == _stage;
          return Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: done || current
                  ? AppColors.emerald700
                  : AppColors.ivoryDeep,
              border: Border.all(
                  color: current
                      ? AppColors.gold500
                      : AppColors.cardBorder,
                  width: 2),
            ),
            child: Center(
              child: done
                  ? const Icon(Icons.check, size: 16, color: Colors.white)
                  : Text('${n + 1}',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: current
                              ? Colors.white
                              : AppColors.ink500)),
            ),
          );
        }),
      ),
    );
  }

  Widget _bottomBar() {
    if (_stage == 5) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Row(
        children: [
          if (_stage > 0)
            Expanded(
              child: MrpSecondaryButton(
                label: 'پیچھے',
                onPressed: () => setState(() => _stage--),
              ),
            ),
          if (_stage > 0) const SizedBox(width: 12),
          Expanded(
            flex: 2,
            child: _stage == 4
                ? MrpPrimaryButton(
                    label: 'محفوظ کریں',
                    loading: _busy,
                    onPressed: _save,
                  )
                : MrpPrimaryButton(
                    label: 'آگے',
                    onPressed: _next,
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildStage() {
    switch (_stage) {
      case 0:
        return _stageTxType();
      case 1:
        return _stageDonor();
      case 2:
        return _stageAmount();
      case 3:
        return _stagePayment();
      case 4:
        return _stageReview();
      default:
        return _stageIssued();
    }
  }

  // ---------------- stage 1: tx type ----------------
  Widget _stageTxType() {
    final options = [
      (TxType.cash, 'نقد وصول', 'رقم ہاتھ میں موصول ہوئی', Icons.payments_outlined),
      (TxType.bankTransfer, 'بینک ٹرانسفر', 'بینک میں منتقل شدہ رقم', Icons.account_balance_outlined),
      (TxType.cheque, 'چیک', 'کلیئر ہونے کے بعد ہی مصدقہ', Icons.receipt_outlined),
      (TxType.wallet, 'موبائل والٹ', 'جیز کیش / ایزی پیسہ وغیرہ', Icons.smartphone_outlined),
      (TxType.pendingBankWallet, 'منتظر ادائیگی', 'بینک/والٹ ادائیگی ابھی نہیں آئی', Icons.hourglass_empty),
      (TxType.pledge, 'وعدہ', 'متوقع عطیہ — یہ رسید نہیں', Icons.handshake_outlined),
    ];
    return Column(
      children: [
        for (final (type, title, sub, icon) in options)
          MrpAnimatedEntry(
            child: MrpCard(
              onTap: () => setState(() => _txType = type),
              child: Row(
                children: [
                  Radio<TxType>(
                    value: type,
                    groupValue: _txType,
                    activeColor: AppColors.emerald700,
                    onChanged: (v) => setState(() => _txType = v!),
                  ),
                  Icon(icon, color: AppColors.emerald700, size: 28),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title,
                            style: AppTypography.bodyUr.copyWith(
                                fontWeight: FontWeight.w700)),
                        Text(sub, style: AppTypography.captionUr),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        if (_txType == TxType.pledge)
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.warningBg,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Text(
              'وعدہ کبھی مصدقہ رسید نہیں ہوتا۔ ادائیگی آنے پر اصل رسید بنائیں۔',
              style: TextStyle(color: AppColors.warning),
            ),
          ),
      ],
    );
  }

  // ---------------- stage 2: donor ----------------
  Widget _stageDonor() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        CheckboxListTile(
          title: const Text('گمنام عطیہ'),
          value: _anonymous,
          activeColor: AppColors.emerald700,
          onChanged: (v) => setState(() {
            _anonymous = v ?? false;
            if (_anonymous) {
              _donorId = null;
              _donorMatches = const [];
            }
          }),
        ),
        if (!_anonymous) ...[
          MrpTextField(
            controller: _donorName,
            label: 'عطیہ دہندہ کا نام *',
            onChanged: (_) {},
          ),
          if (_donorMatches.isNotEmpty)
            Card(
              child: Column(
                children: [
                  for (final d in _donorMatches)
                    ListTile(
                      dense: true,
                      title: Text(d.name),
                      subtitle:
                          d.phone != null ? Text(d.phone!) : null,
                      onTap: () {
                        setState(() {
                          _donorId = d.id;
                          _donorName.text = d.name;
                          _donorPhone.text = d.phone ?? '';
                          _donorEmail.text = d.email ?? '';
                          _donorMatches = const [];
                        });
                      },
                    ),
                ],
              ),
            ),
          const SizedBox(height: 12),
          MrpTextField(
            controller: _donorPhone,
            label: 'فون (اختیاری)',
            keyboardType: TextInputType.phone,
            textDirection: TextDirection.ltr,
          ),
          const SizedBox(height: 12),
          MrpTextField(
            controller: _donorEmail,
            label: 'ای میل (اختیاری)',
            keyboardType: TextInputType.emailAddress,
            textDirection: TextDirection.ltr,
          ),
          const SizedBox(height: 12),
          MrpTextField(
              controller: _donorAddress, label: 'پتہ (اختیاری)', maxLines: 2),
        ],
      ],
    );
  }

  // ---------------- stage 3: amount & allocation ----------------
  Widget _stageAmount() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        MrpTextField(
          controller: _totalCtrl,
          label: 'کل رقم (روپے) *',
          keyboardType:
              const TextInputType.numberWithOptions(decimal: true),
          textDirection: TextDirection.ltr,
          onChanged: (_) => setState(() {}),
        ),
        if (_totalPaisa > 0) ...[
          const SizedBox(height: 8),
          Text(AmountWords.urdu(_totalPaisa),
              style: AppTypography.bodyUr
                  .copyWith(color: AppColors.emerald800)),
          Text(AmountWords.english(_totalPaisa),
              style: AppTypography.captionEn
                  .copyWith(fontStyle: FontStyle.italic),
              textDirection: TextDirection.ltr),
        ],
        const SizedBox(height: 16),
        Text('فنڈ کی تقسیم *', style: AppTypography.bodyUr),
        const SizedBox(height: 8),
        for (var i = 0; i < _allocs.length; i++) _allocationEditor(i),
        MrpSecondaryButton(
          label: 'تقسیم شامل کریں',
          icon: Icons.add,
          onPressed: () => setState(() {
            final row = _AllocationRow();
            if (_funds.isNotEmpty) row.fundId = _funds.first.id;
            _allocs.add(row);
          }),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: _allocationOk
                ? AppColors.successBg
                : AppColors.warningBg,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('تقسیم کا مجموعہ',
                  style: AppTypography.bodyUr
                      .copyWith(fontWeight: FontWeight.w600)),
              Text(
                Money.formatPkr(_allocatedPaisa, symbol: false),
                style: AppTypography.amount,
                textDirection: TextDirection.ltr,
              ),
            ],
          ),
        ),
        if (!_allocationOk && _totalPaisa > 0)
          const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text(
              'تقسیم کا مجموعہ رسید کی رقم کے بالکل برابر ہونا چاہیے۔',
              style: TextStyle(color: AppColors.danger, fontSize: 13),
            ),
          ),
      ],
    );
  }

  Widget _allocationEditor(int i) {
    final row = _allocs[i];
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  flex: 3,
                  child: DropdownButtonFormField<String>(
                    value: row.fundId,
                    decoration:
                        const InputDecoration(labelText: 'فنڈ'),
                    items: _funds
                        .map((f) => DropdownMenuItem(
                            value: f.id,
                            child: Text(f.nameUr,
                                overflow: TextOverflow.ellipsis)))
                        .toList(),
                    onChanged: (v) =>
                        setState(() => row.fundId = v),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.delete_outline,
                      color: AppColors.danger),
                  onPressed: _allocs.length > 1
                      ? () => setState(() {
                            row.amountCtrl.dispose();
                            _allocs.removeAt(i);
                          })
                      : null,
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  flex: 3,
                  child: DropdownButtonFormField<String>(
                    value: row.purposeId,
                    decoration: const InputDecoration(
                        labelText: 'مصرف (اختیاری)'),
                    items: [
                      const DropdownMenuItem<String>(
                          value: null, child: Text('—')),
                      ..._purposes.map((p) => DropdownMenuItem(
                          value: p.id,
                          child: Text(p.nameUr,
                              overflow:
                                  TextOverflow.ellipsis))),
                    ],
                    onChanged: (v) =>
                        setState(() => row.purposeId = v),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  flex: 2,
                  child: MrpTextField(
                    controller: row.amountCtrl,
                    label: 'رقم',
                    keyboardType:
                        const TextInputType.numberWithOptions(
                            decimal: true),
                    textDirection: TextDirection.ltr,
                    onChanged: (_) => setState(() {}),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ---------------- stage 4: payment ----------------
  Widget _stagePayment() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('ادائیگی کا طریقہ', style: AppTypography.bodyUr),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: _acceptedMethods.map((m) {
            final selected = _method == m;
            return ChoiceChip(
              label: Text(_methodLabel(m)),
              selected: selected,
              selectedColor: AppColors.emerald100,
              onSelected: (_) => setState(() => _method = m),
            );
          }).toList(),
        ),
        const SizedBox(height: 16),
        DropdownButtonFormField<String>(
          value: _accountId,
          decoration:
              const InputDecoration(labelText: 'وصول کنندہ اکاؤنٹ *'),
          items: _accounts
              .map((a) => DropdownMenuItem(
                  value: a.id, child: Text(a.title)))
              .toList(),
          onChanged: (v) => setState(() => _accountId = v),
        ),
        const SizedBox(height: 12),
        MrpTextField(
          controller: _reference,
          label: 'لین دین / چیک حوالہ (اختیاری)',
          textDirection: TextDirection.ltr,
        ),
        const SizedBox(height: 12),
        ListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('لین دین کی تاریخ'),
          subtitle: Text(
              '${_receiptDate.year}-${_receiptDate.month.toString().padLeft(2, '0')}-${_receiptDate.day.toString().padLeft(2, '0')}',
              textDirection: TextDirection.ltr),
          trailing: const Icon(Icons.calendar_month_outlined),
          onTap: () async {
            final picked = await showDatePicker(
              context: context,
              initialDate: _receiptDate,
              firstDate: DateTime(2020),
              lastDate: DateTime.now(),
            );
            if (picked != null) setState(() => _receiptDate = picked);
          },
        ),
        MrpTextField(
          controller: _donorNote,
          label: 'عطیہ دہندہ کے لیے نوٹ (رسید پر ظاہر ہوگا)',
          maxLines: 2,
        ),
        const SizedBox(height: 12),
        MrpTextField(
          controller: _staffNotes,
          label: 'عملے کے نوٹس (عطیہ دہندہ کو نظر نہیں آئیں گے)',
          maxLines: 2,
        ),
      ],
    );
  }

  String _methodLabel(PaymentMethod m) => switch (m) {
        PaymentMethod.cash => 'نقد',
        PaymentMethod.bankTransfer => 'بینک ٹرانسفر',
        PaymentMethod.cheque => 'چیک',
        PaymentMethod.wallet => 'موبائل والٹ',
      };

  // ---------------- stage 5: review ----------------
  Widget _stageReview() {
    final warnings = <String>[];
    if (_duplicates.isNotEmpty) {
      warnings.add(
          '${_duplicates.length} اسی جیسی رسیدیں موجود ہیں — ممکنہ نقل۔');
    }
    if (_txType == TxType.bankTransfer ||
        _txType == TxType.wallet ||
        _txType == TxType.cheque ||
        _txType == TxType.pendingBankWallet) {
      warnings.add(
          'ادائیگی کی ابھی تصدیق نہیں ہوئی۔ صرف عارضی رسید جاری ہوگی۔');
    }
    if (_txType == TxType.pledge) {
      warnings.add('یہ وعدہ ہے — مصدقہ رسید نہیں بنے گی۔');
    }
    String fundName(String? id) =>
        _funds.where((f) => f.id == id).firstOrNull?.nameUr ?? '';
    String purposeName(String? id) =>
        _purposes.where((p) => p.id == id).firstOrNull?.nameUr ?? '—';
    String accountName(String? id) =>
        _accounts.where((a) => a.id == id).firstOrNull?.title ?? '';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (warnings.isNotEmpty)
          Container(
            padding: const EdgeInsets.all(12),
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(
              color: AppColors.warningBg,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.warning),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('تنبیہات',
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: AppColors.warning)),
                for (final w in warnings)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text('• $w',
                        style: const TextStyle(
                            color: AppColors.warning,
                            fontSize: 13)),
                  ),
              ],
            ),
          ),
        _reviewRow('قسم', _txTypeLabel(_txType)),
        _reviewRow('عطیہ دہندہ',
            _anonymous ? 'گمنام عطیہ' : _donorName.text.trim()),
        _reviewRow('رقم', Money.formatPkr(_totalPaisa)),
        _reviewRow('لفظوں میں', AmountWords.urdu(_totalPaisa)),
        const SizedBox(height: 8),
        Text('تقسیم', style: AppTypography.bodyUr),
        for (final a in _allocs)
          _reviewRow('• ${fundName(a.fundId)} (${purposeName(a.purposeId)})',
              Money.formatPkr(Money.tryParsePkr(a.amountCtrl.text) ?? 0)),
        _reviewRow('طریقہ', _methodLabel(_method)),
        _reviewRow('اکاؤنٹ', accountName(_accountId)),
        if (_reference.text.trim().isNotEmpty)
          _reviewRow('حوالہ', _reference.text.trim()),
      ],
    );
  }

  String _txTypeLabel(TxType t) => switch (t) {
        TxType.cash => 'نقد وصول',
        TxType.bankTransfer => 'بینک ٹرانسفر',
        TxType.cheque => 'چیک',
        TxType.wallet => 'موبائل والٹ',
        TxType.pendingBankWallet => 'منتظر ادائیگی',
        TxType.pledge => 'وعدہ',
      };

  Widget _reviewRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
              width: 150,
              child: Text(label, style: AppTypography.captionUr)),
          Expanded(
              child: Text(value,
                  style: AppTypography.bodyUr
                      .copyWith(fontWeight: FontWeight.w600))),
        ],
      ),
    );
  }

  // ---------------- stage 6: issued ----------------
  Widget _stageIssued() {
    final r = _saved;
    if (r == null) {
      return const Center(child: CircularProgressIndicator());
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: AppColors.successBg,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.success),
          ),
          child: Column(
            children: [
              const Icon(Icons.check_circle,
                  color: AppColors.success, size: 56),
              const SizedBox(height: 8),
              const Text('رسید محفوظ ہو گئی',
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: AppColors.success)),
              const SizedBox(height: 8),
              Text(
                r.officialNumber ?? r.localProvisionalLabel ?? '',
                style: AppTypography.amountLarge,
                textDirection: TextDirection.ltr,
              ),
              const SizedBox(height: 4),
              Text(
                r.isProvisional
                    ? 'عارضی — سرکاری نمبر مطابقت پر جاری ہوگا'
                    : 'سرکاری رسید',
                style: const TextStyle(color: AppColors.ink500),
              ),
              const SizedBox(height: 4),
              Text(Money.formatPkr(r.totalPaisa),
                  style: AppTypography.amount,
                  textDirection: TextDirection.ltr),
            ],
          ),
        ),
        const SizedBox(height: 16),
        MrpPrimaryButton(
          label: 'رسید کا پیش نظارہ',
          icon: Icons.preview_outlined,
          loading: _pdfBusy,
          onPressed: _previewPdf,
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: MrpSecondaryButton(
                label: 'پرنٹ',
                icon: Icons.print_outlined,
                onPressed: () async {
                  final bytes = _pdfBytes ?? await _buildPdf();
                  if (bytes != null && mounted) {
                    await ref.read(receiptPdfServiceProvider).printPdf(
                        bytes,
                        'receipt-${r.officialNumber ?? 'draft'}');
                  }
                },
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: MrpSecondaryButton(
                label: 'شیئر',
                icon: Icons.share_outlined,
                onPressed: _sharePdf,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        MrpSecondaryButton(
          label: 'فون میں محفوظ کریں',
          icon: Icons.download_outlined,
          onPressed: _savePdfLocally,
        ),
        const SizedBox(height: 10),
        MrpPrimaryButton(
          label: 'نئی رسید بنائیں',
          onPressed: () => context.go('/receipt/new'),
        ),
        TextButton(
          onPressed: () => context.go('/receipts/${r.id}'),
          child: const Text('رسید کی تفصیل دیکھیں'),
        ),
      ],
    );
  }
}
