import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../app_providers.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/widgets.dart';
import '../../../core/utils/money.dart';
import '../../../domain/entities/entities.dart';

/// Payment verification queue: receipts awaiting an independent check.
/// A payment screenshot alone is not proof — the verifier attests against
/// actual records (bank statement / cash in hand).
class VerificationQueueScreen extends ConsumerStatefulWidget {
  const VerificationQueueScreen({super.key});
  @override
  ConsumerState<VerificationQueueScreen> createState() =>
      _VerificationQueueScreenState();
}

class _VerificationQueueScreenState
    extends ConsumerState<VerificationQueueScreen> {
  List<Receipt> _rows = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final res =
        await ref.read(receiptRepositoryProvider).pendingVerification();
    if (mounted) {
      setState(() {
        _rows = res.isOk ? res.value : const [];
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ادائیگی کی تصدیق')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _rows.isEmpty
              ? const MrpEmptyState(
                  icon: Icons.verified_outlined,
                  message: 'تصدیق کے لیے کوئی رسید منتظر نہیں')
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.builder(
                    itemCount: _rows.length,
                    itemBuilder: (_, i) {
                      final r = _rows[i];
                      return MrpCard(
                        onTap: () =>
                            context.push('/receipts/${r.id}'),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    r.localProvisionalLabel ?? '',
                                    style: AppTypography.amount
                                        .copyWith(fontSize: 15),
                                    textDirection:
                                        TextDirection.ltr,
                                  ),
                                  Text(r.donorNameSnapshot,
                                      style:
                                          AppTypography.captionUr),
                                  Text(
                                    'طریقہ: ${_methodLabel(r.paymentMethod)}',
                                    style:
                                        AppTypography.captionUr,
                                  ),
                                ],
                              ),
                            ),
                            Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment.end,
                              children: [
                                Text(
                                  Money.formatPkr(r.totalPaisa,
                                      symbol: false),
                                  style: AppTypography.amount,
                                  textDirection:
                                      TextDirection.ltr,
                                ),
                                const SizedBox(height: 6),
                                const MrpStatusBadge(
                                    label: 'تصدیق کریں',
                                    kind:
                                        MrpStatusKind.warning),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
    );
  }

  String _methodLabel(dynamic m) => m.toString().split('.').last;
}
