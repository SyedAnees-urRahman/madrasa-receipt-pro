import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../../app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/perforated_receipt.dart';
import '../../../core/theme/widgets.dart';
import '../../../core/utils/amount_words.dart';
import '../../../core/utils/money.dart';
import '../../../domain/auth/permissions.dart';
import '../../../domain/entities/entities.dart';
import '../../../domain/entities/enums.dart';
import '../../../domain/repositories/repositories.dart';
import '../../../services/pdf/receipt_document.dart';

/// Receipt detail + full history: verification trail, audit events,
/// and authorized actions (verify / void / reverse / PDF).
class ReceiptDetailScreen extends ConsumerStatefulWidget {
  const ReceiptDetailScreen({super.key, required this.receiptId});
  final String receiptId;
  @override
  ConsumerState<ReceiptDetailScreen> createState() =>
      _ReceiptDetailScreenState();
}

class _ReceiptDetailScreenState extends ConsumerState<ReceiptDetailScreen> {
  Receipt? _receipt;
  List<PaymentVerification> _history = const [];
  List<AuditEvent> _audit = const [];
  Map<String, String> _fundNames = const {};
  bool _loading = true;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final repo = ref.read(receiptRepositoryProvider);
    final res = await repo.getById(widget.receiptId);
    final hist = await repo.verificationHistory(widget.receiptId);
    final auditRes = await ref.read(auditRepositoryProvider).query(
          entityType: 'receipt',
          entityId: widget.receiptId,
          limit: 50,
        );
    final funds = await ref.read(fundRepositoryProvider).funds(activeOnly: false);
    if (!mounted) return;
    setState(() {
      _receipt = res.isOk ? res.value : null;
      _history = hist.isOk ? hist.value : const [];
      _audit = auditRes.isOk ? auditRes.value : const [];
      _fundNames = funds.isOk
          ? {for (final f in funds.value) f.id: f.nameUr}
          : const {};
      _loading = false;
    });
  }

  bool _can(String p) {
    final role = ref.read(sessionProvider)?.role;
    return role != null && Permissions.can(role, p);
  }

  Future<void> _verify() async {
    final evidence = TextEditingController();
    final note = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ادائیگی کی تصدیق'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'تصدیق کریں کہ رقم واقعی موصول ہوئی ہے (نقد ہاتھ میں، یا بینک ریکارڈ سے)۔',
              style: TextStyle(fontFamily: AppTypography.urduFont, fontSize: 13),
            ),
            const SizedBox(height: 8),
            MrpTextField(
                controller: evidence,
                label: 'ثبوت کی تفصیل *',
                maxLines: 2),
            const SizedBox(height: 8),
            MrpTextField(controller: note, label: 'نوٹ (اختیاری)'),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('منسوخ')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('تصدیق کریں')),
        ],
      ),
    );
    if (ok != true || evidence.text.trim().isEmpty) return;
    setState(() => _busy = true);
    final session = ref.read(sessionProvider);
    final res = await ref.read(receiptRepositoryProvider).verifyPayment(
          receiptId: widget.receiptId,
          verifierId: session!.id,
          evidenceSummary: evidence.text.trim(),
          note: note.text.trim().isEmpty ? null : note.text.trim(),
        );
    if (!mounted) return;
    setState(() => _busy = false);
    if (res.isOk) {
      mrpShowSnack(context, 'ادائیگی کی تصدیق ہو گئی');
      _load();
    } else {
      mrpShowSnack(context, 'تصدیق نہیں ہو سکی', isError: true);
    }
  }

  Future<void> _void() async {
    final reason = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('رسید منسوخ کریں'),
        content: MrpTextField(
            controller: reason, label: 'وجہ (لازمی) *', maxLines: 2),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('منسوخ')),
          FilledButton(
              style: FilledButton.styleFrom(
                  backgroundColor: AppColors.danger),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('منسوخ کریں')),
        ],
      ),
    );
    if (ok != true || reason.text.trim().isEmpty) return;
    setState(() => _busy = true);
    final session = ref.read(sessionProvider);
    final res = await ref.read(receiptRepositoryProvider).voidReceipt(
          receiptId: widget.receiptId,
          actorId: session!.id,
          reason: reason.text.trim(),
        );
    if (!mounted) return;
    setState(() => _busy = false);
    if (res.isOk) {
      mrpShowSnack(context, 'رسید منسوخ کر دی گئی');
      _load();
    } else {
      mrpShowSnack(context, 'منسوخی ناکام', isError: true);
    }
  }

  Future<void> _reverse() async {
    final reason = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('رسید واپس لیں (Reversal)'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'اصل رسید محفوظ رہے گی؛ اس کے مقابل ایک منسلک واپسی اندراج بنے گا۔',
              style: TextStyle(fontFamily: AppTypography.urduFont, fontSize: 13),
            ),
            const SizedBox(height: 8),
            MrpTextField(
                controller: reason, label: 'وجہ (لازمی) *', maxLines: 2),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('منسوخ')),
          FilledButton(
              style: FilledButton.styleFrom(
                  backgroundColor: AppColors.danger),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('واپس لیں')),
        ],
      ),
    );
    if (ok != true || reason.text.trim().isEmpty) return;
    setState(() => _busy = true);
    final session = ref.read(sessionProvider);
    final res = await ref.read(receiptRepositoryProvider).reverseReceipt(
          receiptId: widget.receiptId,
          actorId: session!.id,
          reason: reason.text.trim(),
        );
    if (!mounted) return;
    setState(() => _busy = false);
    if (res.isOk) {
      mrpShowSnack(context, 'واپسی اندراج بن گیا');
      _load();
    } else {
      mrpShowSnack(context, 'واپسی ناکام', isError: true);
    }
  }

  Future<Uint8List?> _buildPdfBytes() async {
    final r = _receipt;
    if (r == null) return null;
    final inst = await ref.read(institutionRepositoryProvider).getCurrent();
    if (!mounted) return null;
    if (!inst.isOk || inst.value == null) {
      mrpShowSnack(context, 'ادارے کی معلومات نہیں ملیں', isError: true);
      return null;
    }
    try {
      final qr = await ref
          .read(qrVerificationProvider)
          .buildPayload(receipt: r, institutionId: inst.value!.id);
      // Pre-render QR to image bytes (avoids off-screen widget issues)
      final qrBytes = await renderQrPng(qr);
      // Resolve institution logo file if set
      File? logoFile;
      final logoPath = inst.value!.logoPath;
      if (logoPath != null && logoPath.isNotEmpty) {
        final f = File(logoPath);
        if (await f.exists()) logoFile = f;
      }
      final data = ReceiptDocumentData(
        institution: inst.value!,
        receipt: r,
        allocations: [
          for (final a in r.allocations)
            AllocationLine(
              fundUr: _fundNames[a.fundTypeId] ?? '',
              fundEn: _fundNames[a.fundTypeId] ?? '',
              amountPaisa: a.amountPaisa,
            ),
        ],
        qrPayload: qr,
        locale: inst.value!.receiptLanguage,
        logoFile: logoFile,
        qrImageBytes: qrBytes,
      );
      return await ref
          .read(receiptPdfServiceProvider)
          .buildReceiptPdf(context: context, data: data);
    } catch (e) {
      if (mounted) mrpShowSnack(context, 'PDF بنانے میں خرابی: $e', isError: true);
      return null;
    }
  }

  String _pdfFileName() {
    final r = _receipt;
    final num = r?.officialNumber ?? r?.localProvisionalLabel ?? 'draft';
    return 'receipt-$num.pdf';
  }

  Future<void> _sharePdf() async {
    final r = _receipt;
    if (r == null) return;
    setState(() => _busy = true);
    try {
      final bytes = await _buildPdfBytes();
      if (!mounted || bytes == null) return;
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/${_pdfFileName()}');
      await file.writeAsBytes(bytes);
      await Share.shareXFiles([XFile(file.path)], text: 'رسید ${_pdfFileName()}');
      if (mounted) mrpShowSnack(context, 'شیئر شیٹ کھل گئی');
    } catch (e) {
      if (mounted) mrpShowSnack(context, 'شیئر ناکام: $e', isError: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _savePdf() async {
    final r = _receipt;
    if (r == null) return;
    setState(() => _busy = true);
    try {
      final bytes = await _buildPdfBytes();
      if (!mounted || bytes == null) return;
      // Save to app documents (always writable) + try Downloads via shared_storage
      final dir = await getApplicationDocumentsDirectory();
      final receiptsDir = Directory('${dir.path}/Receipts');
      if (!await receiptsDir.exists()) await receiptsDir.create(recursive: true);
      final file = File('${receiptsDir.path}/${_pdfFileName()}');
      await file.writeAsBytes(bytes);
      if (mounted) {
        mrpShowSnack(context, 'محفوظ ہو گئی: Receipts/${_pdfFileName()}');
      }
    } catch (e) {
      if (mounted) mrpShowSnack(context, 'محفوظ کرنا ناکام: $e', isError: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _printPdf() async {
    final r = _receipt;
    if (r == null) return;
    setState(() => _busy = true);
    try {
      final bytes = await _buildPdfBytes();
      if (!mounted || bytes == null) return;
      await ref
          .read(receiptPdfServiceProvider)
          .printPdf(bytes, _pdfFileName());
    } catch (e) {
      if (mounted) mrpShowSnack(context, 'پرنٹ ناکام: $e', isError: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _openPdf() => _sharePdf();

  @override
  Widget build(BuildContext context) {
    final r = _receipt;
    return Scaffold(
      appBar: AppBar(title: const Text('رسید کی تفصیل')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : r == null
              ? const MrpEmptyState(
                  icon: Icons.receipt_long_outlined,
                  message: 'رسید نہیں ملی')
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    PerforatedReceiptCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  r.officialNumber ??
                                      r.localProvisionalLabel ??
                                      '',
                                  style: AppTypography.amountLarge
                                      .copyWith(fontSize: 20),
                                  textDirection: TextDirection.ltr,
                                ),
                              ),
                              if (r.isProvisional)
                                const MrpStatusBadge(
                                    label: 'عارضی',
                                    kind: MrpStatusKind.warning),
                            ],
                          ),
                          const SizedBox(height: 8),
                          _row('عطیہ دہندہ', r.donorNameSnapshot),
                          _row('رقم', Money.formatPkr(r.totalPaisa)),
                          _row('لفظوں میں',
                              AmountWords.urdu(r.totalPaisa)),
                          _row('تاریخ',
                              '${r.receiptDate.year}-${r.receiptDate.month}-${r.receiptDate.day}'),
                          _row('حیثیت', _statusLabel(r.status)),
                          if (r.voidReason != null)
                            _row('وجہ', r.voidReason!),
                          if (r.referenceNo != null)
                            _row('حوالہ', r.referenceNo!),
                          if (r.donorNote != null)
                            _row('نوٹ', r.donorNote!),
                        ],
                      ),
                    ),
                    MrpSectionHeader(title: 'فنڈ کی تقسیم'),
                    for (final a in r.allocations)
                      MrpCard(
                        child: Row(
                          children: [
                            Expanded(
                                child: Text(
                                    _fundNames[a.fundTypeId] ?? '')),
                            Text(
                                Money.formatPkr(a.amountPaisa,
                                    symbol: false),
                                style: AppTypography.amount,
                                textDirection: TextDirection.ltr),
                          ],
                        ),
                      ),
                    if (_history.isNotEmpty) ...[
                      MrpSectionHeader(title: 'تصدیق کی تاریخ'),
                      for (final h in _history)
                        MrpCard(
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,
                            children: [
                              Text(h.evidenceSummary,
                                  style: AppTypography.bodyUr),
                              if (h.note != null)
                                Text(h.note!,
                                    style:
                                        AppTypography.captionUr),
                              Text(
                                  '${h.verifiedAt.year}-${h.verifiedAt.month}-${h.verifiedAt.day}',
                                  style: AppTypography.captionEn,
                                  textDirection:
                                      TextDirection.ltr),
                            ],
                          ),
                        ),
                    ],
                    MrpSectionHeader(title: 'آڈٹ واقعات'),
                    for (final e in _audit)
                      ListTile(
                        dense: true,
                        title: Text(e.action,
                            textDirection: TextDirection.ltr,
                            style: const TextStyle(fontFamily: AppTypography.urduFont, fontSize: 13)),
                        subtitle: e.reason != null
                            ? Text(e.reason!)
                            : null,
                        trailing: Text(
                            '${e.occurredAt.day}/${e.occurredAt.month}',
                            style: AppTypography.captionEn),
                      ),
                    const SizedBox(height: 16),
                    if (_busy)
                      const Center(
                          child: CircularProgressIndicator()),
                    if (!_busy) ...[
                      if (_can('receipt.verify') &&
                          (r.status ==
                                  ReceiptStatus.draft ||
                              r.status ==
                                  ReceiptStatus
                                      .pendingVerification))
                        MrpPrimaryButton(
                          label: 'ادائیگی کی تصدیق کریں',
                          icon: Icons.verified_outlined,
                          onPressed: _verify,
                        ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: MrpSecondaryButton(
                              label: 'شیئر',
                              icon: Icons.share_outlined,
                              onPressed: _sharePdf,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: MrpSecondaryButton(
                              label: 'محفوظ',
                              icon: Icons.save_alt_outlined,
                              onPressed: _savePdf,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: MrpSecondaryButton(
                              label: 'پرنٹ',
                              icon: Icons.print_outlined,
                              onPressed: _printPdf,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      if (_can('receipt.void') &&
                          r.status != ReceiptStatus.voided &&
                          r.status != ReceiptStatus.reversed)
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton.icon(
                                icon: const Icon(
                                    Icons.cancel_outlined,
                                    color: AppColors.danger),
                                label: const Text('منسوخ کریں',
                                    style: TextStyle(fontFamily: AppTypography.urduFont, color:
                                            AppColors.danger)),
                                onPressed: _void,
                              ),
                            ),
                            const SizedBox(width: 8),
                            if (r.status ==
                                ReceiptStatus.confirmed)
                              Expanded(
                                child: OutlinedButton.icon(
                                  icon: const Icon(
                                      Icons.undo,
                                      color:
                                          AppColors.warning),
                                  label: const Text('واپس لیں',
                                      style: TextStyle(fontFamily: AppTypography.urduFont, color:
                                              AppColors.warning)),
                                  onPressed: _reverse,
                                ),
                              ),
                          ],
                        ),
                    ],
                    const SizedBox(height: 24),
                  ],
                ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
              width: 110,
              child:
                  Text(label, style: AppTypography.captionUr)),
          Expanded(
              child: Text(value,
                  style: AppTypography.bodyUr
                      .copyWith(fontWeight: FontWeight.w600))),
        ],
      ),
    );
  }

  String _statusLabel(ReceiptStatus s) => switch (s) {
        ReceiptStatus.draft => 'مسودہ',
        ReceiptStatus.pendingVerification => 'تصدیق منتظر',
        ReceiptStatus.confirmed => 'مصدقہ',
        ReceiptStatus.voided => 'منسوخ',
        ReceiptStatus.reversed => 'واپس شدہ',
      };
}
