import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/widgets.dart';
import '../../../core/utils/money.dart';
import '../../../domain/entities/enums.dart';
import '../../../domain/entities/entities.dart';

class ReceiptRegisterScreen extends ConsumerStatefulWidget {
  const ReceiptRegisterScreen({super.key});
  @override
  ConsumerState<ReceiptRegisterScreen> createState() =>
      _ReceiptRegisterScreenState();
}

class _ReceiptRegisterScreenState
    extends ConsumerState<ReceiptRegisterScreen> {
  final _search = TextEditingController();
  ReceiptStatus? _filter;
  List<Receipt> _rows = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final res = await ref.read(receiptRepositoryProvider).register(
          status: _filter,
          donorQuery: _search.text.trim().isEmpty
              ? null
              : _search.text.trim(),
          limit: 200,
        );
    if (mounted) {
      setState(() {
        _rows = res.isOk ? res.value : const [];
        _loading = false;
      });
    }
  }

  MrpStatusKind _kind(ReceiptStatus s) => switch (s) {
        ReceiptStatus.confirmed => MrpStatusKind.success,
        ReceiptStatus.draft => MrpStatusKind.neutral,
        ReceiptStatus.pendingVerification => MrpStatusKind.warning,
        ReceiptStatus.voided => MrpStatusKind.danger,
        ReceiptStatus.reversed => MrpStatusKind.info,
      };

  String _label(ReceiptStatus s) => switch (s) {
        ReceiptStatus.draft => 'مسودہ',
        ReceiptStatus.pendingVerification => 'تصدیق منتظر',
        ReceiptStatus.confirmed => 'مصدقہ',
        ReceiptStatus.voided => 'منسوخ',
        ReceiptStatus.reversed => 'واپس شدہ',
      };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('رسیدیں')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: MrpTextField(
              controller: _search,
              hint: 'عطیہ دہندہ / رسید نمبر سے تلاش کریں',
              prefixIcon: Icons.search,
              onChanged: (_) => _load(),
            ),
          ),
          SizedBox(
            height: 44,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                _filterChip(null, 'سب'),
                for (final s in ReceiptStatus.values)
                  _filterChip(s, _label(s)),
              ],
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _rows.isEmpty
                    ? const MrpEmptyState(
                        icon: Icons.receipt_long_outlined,
                        message: 'کوئی رسید نہیں ملی')
                    : RefreshIndicator(
                        onRefresh: _load,
                        child: ListView.builder(
                          itemCount: _rows.length,
                          itemBuilder: (_, i) {
                            final r = _rows[i];
                            return MrpAnimatedEntry(
                              delayMs: (i * 30).clamp(0, 240),
                              child: MrpCard(
                                onTap: () =>
                                    context.push('/receipts/${r.id}'),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            r.officialNumber ??
                                                r.localProvisionalLabel ??
                                                '',
                                            style: AppTypography.amount
                                                .copyWith(fontSize: 15),
                                            textDirection:
                                                TextDirection.ltr,
                                          ),
                                          const SizedBox(height: 2),
                                          Text(r.donorNameSnapshot,
                                              style: AppTypography
                                                  .captionUr),
                                          const SizedBox(height: 6),
                                          MrpStatusBadge(
                                              label: _label(r.status),
                                              kind: _kind(r.status)),
                                        ],
                                      ),
                                    ),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          Money.formatPkr(
                                              r.totalPaisa,
                                              symbol: false),
                                          style: AppTypography.amount,
                                          textDirection:
                                              TextDirection.ltr,
                                        ),
                                        Text(
                                          '${r.receiptDate.year}-${r.receiptDate.month.toString().padLeft(2, '0')}-${r.receiptDate.day.toString().padLeft(2, '0')}',
                                          style:
                                              AppTypography.captionEn,
                                          textDirection:
                                              TextDirection.ltr,
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),
    );
  }

  Widget _filterChip(ReceiptStatus? s, String label) {
    final selected = _filter == s;
    return Padding(
      padding: const EdgeInsets.only(left: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        selectedColor: AppColors.emerald100,
        onSelected: (_) {
          setState(() => _filter = s);
          _load();
        },
      ),
    );
  }
}
