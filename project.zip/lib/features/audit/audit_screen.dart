import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/widgets.dart';
import '../../../domain/entities/entities.dart';

/// Audit history: append-only event log with hash-chain verification.
/// Ordinary users cannot edit or delete events (no UI, no API, RLS denies).
class AuditScreen extends ConsumerStatefulWidget {
  const AuditScreen({super.key});
  @override
  ConsumerState<AuditScreen> createState() => _AuditScreenState();
}

class _AuditScreenState extends ConsumerState<AuditScreen> {
  List<AuditEvent> _rows = const [];
  bool _loading = true;
  bool? _chainOk;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final res =
        await ref.read(auditRepositoryProvider).query(limit: 200);
    final chain = await ref.read(auditRepositoryProvider).verifyChain();
    if (mounted) {
      setState(() {
        _rows = res.isOk ? res.value : const [];
        _chainOk = chain.isOk ? chain.value : null;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('آڈٹ تاریخ')),
      body: Column(
        children: [
          if (_chainOk != null)
            Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _chainOk!
                    ? AppColors.successBg
                    : AppColors.dangerBg,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Icon(
                      _chainOk!
                          ? Icons.verified_outlined
                          : Icons.warning_amber,
                      color: _chainOk!
                          ? AppColors.success
                          : AppColors.danger),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _chainOk!
                          ? 'آڈٹ زنجیر درست ہے — کوئی ردوبدل نہیں ملی۔'
                          : 'زنجیر ٹوٹی ہوئی ہے! فوری جائزہ لیں۔',
                      style: TextStyle(fontFamily: AppTypography.urduFont, color: _chainOk!
                              ? AppColors.success
                              : AppColors.danger,
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
          Expanded(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator())
                : _rows.isEmpty
                    ? const MrpEmptyState(
                        icon: Icons.history,
                        message: 'کوئی آڈٹ واقعہ نہیں')
                    : RefreshIndicator(
                        onRefresh: _load,
                        child: ListView.builder(
                          itemCount: _rows.length,
                          itemBuilder: (_, i) {
                            final e = _rows[i];
                            return ListTile(
                              dense: true,
                              title: Text(e.action,
                                  textDirection:
                                      TextDirection.ltr,
                                  style: const TextStyle(fontFamily: AppTypography.urduFont, fontSize: 13,
                                      fontWeight:
                                          FontWeight.w600)),
                              subtitle: e.reason != null
                                  ? Text(e.reason!,
                                      maxLines: 2,
                                      overflow:
                                          TextOverflow.ellipsis)
                                  : Text(
                                      '${e.entityType}:${(e.entityId as String).substring(0, 8)}',
                                      textDirection:
                                          TextDirection.ltr,
                                      style:
                                          AppTypography.captionEn),
                              trailing: Text(
                                '${e.occurredAt.day}/${e.occurredAt.month} ${e.occurredAt.hour}:${e.occurredAt.minute.toString().padLeft(2, '0')}',
                                style:
                                    AppTypography.captionEn,
                                textDirection:
                                    TextDirection.ltr,
                              ),
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),
    );
  }
}
