import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/widgets.dart';
import '../../../core/utils/dates.dart';
import '../../../data/sync/sync_engine.dart';
import '../../../domain/entities/enums.dart';
import '../../../data/local/app_database.dart' as db;
import 'package:drift/drift.dart' hide Column;

/// Sync Center: queue status, per-record state, manual retry, conflict
/// review queue, last-sync timestamp. Nothing is deleted locally before
/// the server acknowledges.
class SyncCenterScreen extends ConsumerStatefulWidget {
  const SyncCenterScreen({super.key});
  @override
  ConsumerState<SyncCenterScreen> createState() =>
      _SyncCenterScreenState();
}

class _SyncCenterScreenState extends ConsumerState<SyncCenterScreen> {
  bool _busy = false;
  SyncResult? _lastResult;
  List<db.SyncOutboxData> _queue = const [];
  List<db.SyncConflict> _conflicts = const [];
  DateTime? _lastSync;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final ctx = ref.read(repositoryContextProvider);
    if (ctx == null) return;
    final database = ref.read(appDatabaseProvider);
    final queue = await (database.select(database.syncOutbox)
          ..where((t) =>
              t.institutionId.equals(ctx.institutionId) &
              t.status.isInValues([SyncStatus.pending, SyncStatus.failed]))
          ..orderBy([(t) => OrderingTerm(expression: t.createdAt)])
          ..limit(100))
        .get();
    final conflicts =
        await ref.read(syncEngineProvider).openConflicts(ctx.institutionId);
    final lastSync = await ref
        .read(syncStateStoreProvider)
        .lastSync(ctx.institutionId);
    if (mounted) {
      setState(() {
        _queue = queue;
        _conflicts = conflicts;
        _lastSync = lastSync;
      });
    }
  }

  Future<void> _runSync() async {
    final ctx = ref.read(repositoryContextProvider);
    if (ctx == null) return;
    setState(() {
      _busy = true;
      _lastResult = null;
    });
    try {
      final result = await ref.read(syncEngineProvider).runOnce(
          institutionId: ctx.institutionId, actorId: ctx.actorId);
      if (mounted) {
        setState(() => _lastResult = result);
        if (result.offline) {
          mrpShowSnack(context, 'انٹرنیٹ نہیں — کام مقامی طور پر محفوظ ہے');
        } else if (result.errors.isEmpty) {
          mrpShowSnack(context,
              'مطابقت مکمل: ${result.pushed} بھیجے، ${result.pulled} موصول');
        } else {
          mrpShowSnack(context,
              '${result.errors.length} خرابیاں — تفصیل نیچے دیکھیں',
              isError: true);
        }
      }
    } finally {
      if (mounted) setState(() => _busy = false);
      _load();
    }
  }

  Future<void> _retryFailed() async {
    final ctx = ref.read(repositoryContextProvider);
    if (ctx == null) return;
    await ref.read(syncEngineProvider).retryFailed(ctx.institutionId);
    _runSync();
  }

  Future<void> _resolve(dynamic conflict) async {
    final choice = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تنازع کا حل'),
        content: const Text(
          'مقامی رکھیں: آپ کی تبدیلی سرور پر بھیجی جائے گی۔\nسرور رکھیں: مقامی تبدیلی ختم ہو جائے گی۔\nمصدقہ مالی ریکارڈ پر خاموش تحریر کبھی نہیں ہوتی — فیصلہ آڈٹ میں درج ہوگا۔',
          style: TextStyle(fontFamily: AppTypography.urduFont, fontSize: 13),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, null),
              child: const Text('منسوخ')),
          TextButton(
              onPressed: () => Navigator.pop(ctx, 'keep_remote'),
              child: const Text('سرور رکھیں')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, 'keep_local'),
              child: const Text('مقامی رکھیں')),
        ],
      ),
    );
    if (choice == null) return;
    final ctx = ref.read(repositoryContextProvider);
    final session = ref.read(sessionProvider);
    if (ctx == null || session == null) return;
    await ref.read(syncEngineProvider).resolveConflict(
          conflictId: conflict.id as String,
          resolution: choice,
          institutionId: ctx.institutionId,
          actorId: session.id,
        );
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('مطابقت مرکز')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          MrpCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('حیثیت', style: AppTypography.bodyUr),
                const SizedBox(height: 8),
                Text(
                  _lastSync == null
                      ? 'کبھی مطابقت نہیں ہوئی'
                      : 'آخری کامیاب مطابقت: ${Dates.dateTime(_lastSync!, 'ur')}',
                  style: AppTypography.captionUr,
                ),
                const SizedBox(height: 12),
                MrpPrimaryButton(
                  label: 'ابھی مطابقت کریں',
                  loading: _busy,
                  icon: Icons.sync,
                  onPressed: _runSync,
                ),
                if (_lastResult != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    _lastResult!.offline
                        ? 'آف لائن — بعد میں دوبارہ کوشش کریں۔'
                        : 'بھیجے: ${_lastResult!.pushed}، موصول: ${_lastResult!.pulled}، نمبر جاری: ${_lastResult!.numbered}، تنازعات: ${_lastResult!.conflicts}',
                    style: AppTypography.captionUr,
                  ),
                  for (final e in _lastResult!.errors.take(5))
                    Text(e,
                        style: const TextStyle(fontFamily: AppTypography.urduFont, color: AppColors.danger,
                            fontSize: 11),
                        textDirection: TextDirection.ltr),
                ],
              ],
            ),
          ),
          MrpSectionHeader(
            title: 'قطار (${_queue.length})',
            action: TextButton(
                onPressed: _retryFailed,
                child: const Text('ناکام دوبارہ چلائیں')),
          ),
          for (final q in _queue)
            ListTile(
              dense: true,
              leading: Icon(
                q.status == SyncStatus.failed
                    ? Icons.error_outline
                    : Icons.cloud_upload_outlined,
                color: q.status == SyncStatus.failed
                    ? AppColors.danger
                    : AppColors.info,
              ),
              title: Text('${q.entityType} — ${(q.entityId as String).substring(0, 8)}',
                  textDirection: TextDirection.ltr,
                  style: const TextStyle(fontFamily: AppTypography.urduFont, fontSize: 13)),
              subtitle: q.lastError != null
                  ? Text(q.lastError!,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontFamily: AppTypography.urduFont, fontSize: 11,
                          color: AppColors.danger))
                  : Text(
                      'کوششیں: ${q.attempts} — ${q.status.name}',
                      style:
                          const TextStyle(fontFamily: AppTypography.urduFont, fontSize: 11)),
            ),
          MrpSectionHeader(title: 'تنازعات (${_conflicts.length})'),
          if (_conflicts.isEmpty)
            const Padding(
              padding: EdgeInsets.all(8),
              child: Text('کوئی کھلا تنازع نہیں',
                  style: TextStyle(fontFamily: AppTypography.urduFont, color: AppColors.ink500)),
            ),
          for (final c in _conflicts)
            MrpCard(
              onTap: () => _resolve(c),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${c.entityType} — ${(c.entityId as String).substring(0, 8)}',
                      textDirection: TextDirection.ltr,
                      style: const TextStyle(fontFamily: AppTypography.urduFont, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                  const Text('جائزے کے لیے تھپتھپائیں',
                      style: TextStyle(fontFamily: AppTypography.urduFont, fontSize: 12,
                          color: AppColors.warning)),
                ],
              ),
            ),
          const SizedBox(height: 16),
          const Text(
            'اصول: مقامی زیرِ التواء ڈیٹا سرور کی تصدیق سے پہلے حذف نہیں ہوتا۔ مصدقہ ریکارڈ کبھی خاموشی سے تحریر نہیں ہوتا۔',
            style: TextStyle(fontFamily: AppTypography.urduFont, fontSize: 11, color: AppColors.ink500),
          ),
        ],
      ),
    );
  }
}
