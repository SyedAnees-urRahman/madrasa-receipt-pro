import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/animations.dart';
import '../../../core/theme/widgets.dart';
import '../../../core/utils/dates.dart';
import '../../../core/utils/money.dart';
import '../../../domain/auth/permissions.dart';
import '../../../domain/entities/enums.dart';
import '../../../domain/entities/entities.dart';
import '../backup/backup_prompt_dialog.dart';
import 'package:drift/drift.dart' hide Column;
import '../../../domain/repositories/repositories.dart';

class DashboardScreen extends ConsumerStatefulWidget {
  const DashboardScreen({super.key});
  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen> {
  bool _loading = true;
  int _todayTotal = 0;
  int _monthTotal = 0;
  int _pendingVerification = 0;
  int _outboxPending = 0;
  int _outboxFailed = 0;
  int _conflicts = 0;
  DateTime? _lastSync;
  List<FundBalance> _fundBalances = const [];
  List<Receipt> _recentReceipts = const [];
  List<ExpenseVoucher> _recentExpenses = const [];
  List<AuditEvent> _recentAudit = const [];
  bool _isDemo = false;
  String _institutionName = '';

  @override
  void initState() {
    super.initState();
    _load();
    // Auto backup reminder popup (daily/weekly/monthly) — after first frame.
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await Future.delayed(const Duration(seconds: 2));
      if (mounted) await maybeShowBackupPrompt(context, ref);
    });
  }

  Future<void> _load() async {
    final reports = ref.read(reportRepositoryProvider);
    final receipts = ref.read(receiptRepositoryProvider);
    final expenses = ref.read(expenseRepositoryProvider);
    final funds = ref.read(fundRepositoryProvider);
    final audit = ref.read(auditRepositoryProvider);
    final engine = ref.read(syncEngineProvider);
    final inst = await ref.read(institutionRepositoryProvider).getCurrent();

    final now = DateTime.now();
    final dayStart = DateTime(now.year, now.month, now.day);
    final monthStart = DateTime(now.year, now.month, 1);

    final daily = await reports.daily(dayStart);
    final monthly = await reports.period(monthStart, now);
    final pending = await receipts.pendingVerification();
    final recentR = await receipts.register(limit: 5);
    final recentE = await expenses.register(limit: 5);
    final balances = await funds.allBalances();
    final auditRows = await audit.query(limit: 5);
    final ctx = ref.read(repositoryContextProvider);

    var outPending = 0, outFailed = 0;
    if (ctx != null) {
      final db = ref.read(appDatabaseProvider);
      outPending = (await (db.select(db.syncOutbox)
                ..where((t) =>
                    t.institutionId.equals(ctx.institutionId) &
                    t.status.equalsValue(SyncStatus.pending)))
              .get())
          .length;
      outFailed = (await (db.select(db.syncOutbox)
                ..where((t) =>
                    t.institutionId.equals(ctx.institutionId) &
                    t.status.equalsValue(SyncStatus.failed)))
              .get())
          .length;
      _conflicts =
          (await engine.openConflicts(ctx.institutionId)).length;
      _lastSync = await ref
          .read(syncStateStoreProvider)
          .lastSync(ctx.institutionId);
    }

    if (!mounted) return;
    setState(() {
      _todayTotal = daily.isOk ? daily.value.confirmedTotalPaisa : 0;
      _monthTotal = monthly.isOk ? monthly.value.confirmedTotalPaisa : 0;
      _pendingVerification = pending.isOk ? pending.value.length : 0;
      _outboxPending = outPending;
      _outboxFailed = outFailed;
      _fundBalances = balances.isOk ? balances.value : const [];
      _recentReceipts = recentR.isOk ? recentR.value : const [];
      _recentExpenses = recentE.isOk ? recentE.value : const [];
      _recentAudit = auditRows.isOk ? auditRows.value : const [];
      _isDemo = inst.isOk && inst.value?.isDemo == true;
      _institutionName = inst.isOk ? (inst.value?.nameUr ?? '') : '';
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final session = ref.watch(sessionProvider);
    final role = session?.role;
    final can = (String p) =>
        role != null && Permissions.can(role, p);

    return Scaffold(
      appBar: AppBar(
        title: Text(_institutionName.isEmpty ? 'ہوم' : _institutionName),
        actions: [
          IconButton(
            icon: const Icon(Icons.sync),
            tooltip: 'مطابقت',
            onPressed: () => context.push('/sync'),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                children: [
                  if (_isDemo)
                    Container(
                      margin: const EdgeInsets.all(16),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.warningBg,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppColors.warning),
                      ),
                      child: const Text(
                        'ڈیمو ورک اسپیس — صرف نمونہ ڈیٹا۔ یہ حقیقی مالی ریکارڈ نہیں۔',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: AppColors.warning,
                            fontWeight: FontWeight.w700),
                      ),
                    ),
                  if (_lastSync != null &&
                      DateTime.now()
                              .difference(_lastSync!)
                              .inHours >
                          24)
                    Container(
                      margin:
                          const EdgeInsets.symmetric(horizontal: 16),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppColors.infoBg,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        'اعداد پرانے ہو سکتے ہیں — آخری مطابقت: ${Dates.dateTime(_lastSync!, 'ur')}',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            color: AppColors.info, fontSize: 12),
                      ),
                    ),
                  MrpSectionHeader(title: 'خلاصہ'),
                  Padding(
                    padding:
                        const EdgeInsets.fromLTRB(16, 0, 16, 12),
                    child: MrpPopIn(
                      child: Builder(builder: (context) {
                        final bg = Theme.of(context).scaffoldBackgroundColor;
                        final isClay = bg.value == const Color(0xFF8FB4DD).value;
                        final isNeu = bg.value == const Color(0xFFE4EAF2).value;
                        final c1 = isClay
                            ? const Color(0xFF2E5FA3)
                            : isNeu
                                ? const Color(0xFF3B82F6)
                                : AppColors.emerald900;
                        final c2 = isClay
                            ? const Color(0xFF3D7BC4)
                            : isNeu
                                ? const Color(0xFF60A5FA)
                                : AppColors.emerald700;
                        return Container(
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [c1, c2],
                          ),
                          borderRadius: BorderRadius.circular(24),
                          boxShadow: [
                            BoxShadow(
                              color: c1.withValues(alpha: 0.35),
                              blurRadius: 20,
                              offset: const Offset(0, 8),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment:
                              CrossAxisAlignment.stretch,
                          children: [
                            Text(
                              'کل بیلنس',
                              style: AppTypography.bodyUr.copyWith(
                                color: Colors.white
                                    .withValues(alpha: 0.85),
                              ),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              Money.formatPkr(
                                  _todayTotal + _monthTotal,
                                  symbol: true),
                              style: AppTypography.displayEn.copyWith(
                                color: Colors.white,
                                fontSize: 36,
                                fontWeight: FontWeight.w800,
                              ),
                              textAlign: TextAlign.center,
                              textDirection: TextDirection.ltr,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              _institutionName.isEmpty
                                  ? 'خوش آمدید'
                                  : _institutionName,
                              style: AppTypography.captionUr.copyWith(
                                color: Colors.white
                                    .withValues(alpha: 0.75),
                              ),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 20),
                            Row(
                              mainAxisAlignment:
                                  MainAxisAlignment.spaceEvenly,
                              children: [
                                _circleAction(
                                  context,
                                  icon: Icons.receipt_long_outlined,
                                  label: 'نئی رسید',
                                  onTap: () =>
                                      context.push('/receipts/new'),
                                ),
                                _circleAction(
                                  context,
                                  icon:
                                      Icons.money_off_outlined,
                                  label: 'اخراجات',
                                  onTap: () =>
                                      context.push('/expenses'),
                                ),
                                _circleAction(
                                  context,
                                  icon:
                                      Icons.bar_chart_outlined,
                                  label: 'رپورٹس',
                                  onTap: () =>
                                      context.push('/reports'),
                                ),
                              ],
                            ),
                          ],
                        ),
                        );
                      }),
                    ),
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16),
                    child: GridView.count(
                      crossAxisCount: 2,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      mainAxisSpacing: 4,
                      crossAxisSpacing: 4,
                      childAspectRatio: 1.35,
                      children: [
                        MrpAnimatedEntry(
                          child: MrpKpiCard(
                            title: 'آج کی مصدقہ وصولیاں',
                            value: Money.formatPkr(_todayTotal,
                                symbol: false),
                            icon: Icons.today_outlined,
                          ),
                        ),
                        MrpAnimatedEntry(
                          delayMs: 60,
                          child: MrpKpiCard(
                            title: 'اس ماہ کی مصدقہ وصولیاں',
                            value: Money.formatPkr(_monthTotal,
                                symbol: false),
                            icon: Icons.calendar_month_outlined,
                            accent: AppColors.gold700,
                          ),
                        ),
                        MrpAnimatedEntry(
                          delayMs: 120,
                          child: MrpKpiCard(
                            title: 'تصدیق کے منتظر',
                            value: '$_pendingVerification',
                            icon: Icons.hourglass_empty,
                            accent: AppColors.warning,
                            onTap: can('receipt.verify')
                                ? () => context.push('/verify')
                                : null,
                          ),
                        ),
                        MrpAnimatedEntry(
                          delayMs: 180,
                          child: MrpKpiCard(
                            title: 'آف لائن — مطابقت باقی',
                            value: '${_outboxPending + _outboxFailed}',
                            icon: Icons.cloud_off_outlined,
                            accent: _outboxFailed > 0
                                ? AppColors.danger
                                : AppColors.info,
                            onTap: () => context.push('/sync'),
                          ),
                        ),
                      ],
                    ),
                  ),
                  MrpSectionHeader(
                    title: 'فنڈ بیلنس',
                    action: TextButton(
                      onPressed: () => context.push('/funds'),
                      child: const Text('سب دیکھیں'),
                    ),
                  ),
                  for (final b in _fundBalances.take(4))
                    MrpAnimatedEntry(
                      child: MrpCard(
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  Text(b.fund.nameUr,
                                      style: AppTypography.bodyUr
                                          .copyWith(
                                              fontWeight:
                                                  FontWeight.w600)),
                                  Text(b.fund.nameEn,
                                      style:
                                          AppTypography.captionEn),
                                ],
                              ),
                            ),
                            Text(
                              Money.formatPkr(b.closingPaisa,
                                  symbol: false),
                              style: AppTypography.amount,
                              textDirection: TextDirection.ltr,
                            ),
                          ],
                        ),
                      ),
                    ),
                  MrpSectionHeader(title: 'مینیو'),
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16),
                    child: GridView.count(
                      crossAxisCount: 3,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      mainAxisSpacing: 8,
                      crossAxisSpacing: 8,
                      childAspectRatio: 1.05,
                      children: [
                        if (can('receipt.verify'))
                          _menuTile(context, Icons.verified_outlined,
                              'تصدیق', '/verify', AppColors.emerald700),
                        _menuTile(context, Icons.people_outline,
                            'عطیہ دہندگان', '/donors', AppColors.info),
                        _menuTile(context, Icons.account_balance_wallet_outlined,
                            'فنڈز', '/funds', AppColors.gold700),
                        if (can('expense.create'))
                          _menuTile(context, Icons.receipt_outlined,
                              'اخراجات', '/expenses', AppColors.ink700),
                        _menuTile(context, Icons.book_outlined,
                            'کتب', '/books', AppColors.emerald600),
                        if (can('reconcile.run'))
                          _menuTile(context, Icons.balance_outlined,
                              'مفاہمت', '/reconciliation', AppColors.info),
                        if (can('audit.view'))
                          _menuTile(context, Icons.history,
                              'آڈٹ', '/audit', AppColors.ink500),
                        _menuTile(context, Icons.sync,
                            'مطابقت', '/sync', AppColors.warning),
                        if (can('users.manage'))
                          _menuTile(context, Icons.group_outlined,
                              'عملہ', '/staff', AppColors.ink700),
                        if (can('backup.run'))
                          _menuTile(context, Icons.backup_outlined,
                              'بیک اپ', '/backup', AppColors.emerald700),
                      ],
                    ),
                  ),
                  MrpSectionHeader(
                    title: 'حالیہ رسیدیں',
                    action: TextButton(
                      onPressed: () => context.push('/receipts'),
                      child: const Text('سب دیکھیں'),
                    ),
                  ),
                  for (final r in _recentReceipts)
                    MrpCard(
                      onTap: () =>
                          context.push('/receipts/${r.id}'),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment.start,
                              children: [
                                Text(
                                  r.officialNumber ??
                                      r.localProvisionalLabel ??
                                      '',
                                  style: AppTypography.amount
                                      .copyWith(fontSize: 15),
                                  textDirection:
                                      TextDirection.ltr,
                                ),
                                Text(r.donorNameSnapshot,
                                    style:
                                        AppTypography.captionUr),
                              ],
                            ),
                          ),
                          Text(
                            Money.formatPkr(r.totalPaisa,
                                symbol: false),
                            style: AppTypography.amount,
                            textDirection: TextDirection.ltr,
                          ),
                        ],
                      ),
                    ),
                  const SizedBox(height: 24),
                ],
              ),
      ),
    );
  }

  Widget _menuTile(BuildContext context, IconData icon, String label,
      String route, Color color) {
    return MrpCard(
      padding: const EdgeInsets.all(8),
      onTap: () => context.push(route),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 30),
          const SizedBox(height: 6),
          Text(label,
              textAlign: TextAlign.center,
              style: AppTypography.captionUr
                  .copyWith(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  /// Circular action button like the reference design (screenshot 5).
  Widget _circleAction(
    BuildContext context, {
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.gold500.withValues(alpha: 0.20),
              border: Border.all(
                color: AppColors.gold500.withValues(alpha: 0.50),
                width: 1.5,
              ),
            ),
            child: Icon(icon, color: AppColors.gold500, size: 28),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: AppTypography.captionUr.copyWith(
              color: Colors.white,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}
