import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/widgets.dart';
import '../../../core/utils/money.dart';
import '../../../domain/entities/entities.dart';
import '../../../domain/repositories/repositories.dart';

/// Cashbook & bankbook: opening balance, dated in/out lines, closing.
/// Derived from the ledger — confirmed receipts (net of reversals) in,
/// paid expenses out.
class BooksScreen extends ConsumerStatefulWidget {
  const BooksScreen({super.key});
  @override
  ConsumerState<BooksScreen> createState() => _BooksScreenState();
}

class _BooksScreenState extends ConsumerState<BooksScreen> {
  List<BankAccount> _accounts = const [];
  String? _accountId;
  DateTime _from = DateTime.now().subtract(const Duration(days: 30));
  DateTime _to = DateTime.now();
  CashBook? _book;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadAccounts();
  }

  Future<void> _loadAccounts() async {
    final res = await ref.read(accountRepositoryProvider).accounts();
    if (!mounted) return;
    setState(() {
      _accounts = res.isOk ? res.value : const [];
      _accountId = _accounts.firstOrNull?.id;
    });
    _loadBook();
  }

  Future<void> _loadBook() async {
    if (_accountId == null) {
      setState(() => _loading = false);
      return;
    }
    setState(() => _loading = true);
    final res = await ref
        .read(reportRepositoryProvider)
        .cashBook(_from, _to, _accountId!);
    if (mounted) {
      setState(() {
        _book = res.isOk ? res.value : null;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('کیش و بینک کتب')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  flex: 2,
                  child: DropdownButtonFormField<String>(
                    value: _accountId,
                    decoration:
                        const InputDecoration(labelText: 'اکاؤنٹ'),
                    items: _accounts
                        .map((a) => DropdownMenuItem(
                            value: a.id,
                            child: Text(a.title,
                                overflow:
                                    TextOverflow.ellipsis)))
                        .toList(),
                    onChanged: (v) {
                      setState(() => _accountId = v);
                      _loadBook();
                    },
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.calendar_month_outlined),
                  tooltip: 'مدت منتخب کریں',
                  onPressed: () async {
                    final picked = await showDateRangePicker(
                      context: context,
                      firstDate: DateTime(2020),
                      lastDate: DateTime.now(),
                      initialDateRange:
                          DateTimeRange(start: _from, end: _to),
                    );
                    if (picked != null) {
                      setState(() {
                        _from = picked.start;
                        _to = picked.end;
                      });
                      _loadBook();
                    }
                  },
                ),
              ],
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator())
                : _book == null
                    ? const MrpEmptyState(
                        icon: Icons.book_outlined,
                        message: 'کوئی لین دین نہیں ملا')
                    : Builder(builder: (context) {
                        final book = _book!;
                        return ListView(
                          children: [
                            MrpCard(
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text('ابتدائی بیلنس',
                                      style:
                                          AppTypography.bodyUr),
                                  Text(
                                      Money.formatPkr(
                                          book.openingPaisa,
                                          symbol: false),
                                      style:
                                          AppTypography.amount,
                                      textDirection:
                                          TextDirection.ltr),
                                ],
                              ),
                            ),
                            for (final l in book.lines)
                              ListTile(
                                title: Text(l.label,
                                    maxLines: 1,
                                    overflow:
                                        TextOverflow.ellipsis),
                                subtitle: Text(l.reference,
                                    textDirection:
                                        TextDirection.ltr,
                                    style:
                                        AppTypography.captionEn),
                                trailing: Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.center,
                                  crossAxisAlignment:
                                      CrossAxisAlignment.end,
                                  children: [
                                    if (l.inPaisa > 0)
                                      Text(
                                          '+ ${Money.formatPkr(l.inPaisa, symbol: false)}',
                                          style: const TextStyle(
                                              color: AppColors
                                                  .success,
                                              fontWeight:
                                                  FontWeight.w700),
                                          textDirection:
                                              TextDirection.ltr),
                                    if (l.outPaisa > 0)
                                      Text(
                                          '- ${Money.formatPkr(l.outPaisa, symbol: false)}',
                                          style: const TextStyle(
                                              color: AppColors
                                                  .danger,
                                              fontWeight:
                                                  FontWeight.w700),
                                          textDirection:
                                              TextDirection.ltr),
                                  ],
                                ),
                              ),
                            MrpCard(
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text('اختتامی بیلنس',
                                      style: AppTypography.bodyUr
                                          .copyWith(
                                              fontWeight:
                                                  FontWeight
                                                      .w700)),
                                  Text(
                                      Money.formatPkr(
                                          book.closingPaisa,
                                          symbol: false),
                                      style: AppTypography.amount
                                          .copyWith(
                                              fontWeight:
                                                  FontWeight
                                                      .w700),
                                      textDirection:
                                          TextDirection.ltr),
                                ],
                              ),
                            ),
                          ],
                        );
                      }),
          ),
        ],
      ),
    );
  }
}
