import 'package:drift/drift.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../../../app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/widgets.dart';
import '../../../core/utils/money.dart';
import '../../../data/local/app_database.dart' as db;
import '../../../domain/entities/entities.dart';
import '../../../domain/entities/enums.dart';

/// Bank reconciliation: compare the book balance (from the ledger) with
/// the bank statement balance; record the difference and notes.
class ReconciliationScreen extends ConsumerStatefulWidget {
  const ReconciliationScreen({super.key});
  @override
  ConsumerState<ReconciliationScreen> createState() =>
      _ReconciliationScreenState();
}

class _ReconciliationScreenState
    extends ConsumerState<ReconciliationScreen> {
  List<BankAccount> _accounts = const [];
  String? _accountId;
  final _statementBalance = TextEditingController();
  final _notes = TextEditingController();
  int? _bookBalance;
  bool _busy = false;
  List<db.Reconciliation> _history = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _statementBalance.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final res = await ref.read(accountRepositoryProvider).accounts();
    if (!mounted) return;
    setState(() {
      _accounts = res.isOk
          ? res.value
              .where((a) => a.type != AccountType.cash)
              .toList()
          : const [];
      // Fallback: keep all if filter emptied (type is enum here).
      if (_accounts.isEmpty && res.isOk) _accounts = res.value;
      _accountId ??= _accounts.firstOrNull?.id;
    });
    await _loadBook();
    await _loadHistory();
  }

  Future<void> _loadBook() async {
    if (_accountId == null) return;
    final ctx = ref.read(repositoryContextProvider);
    if (ctx == null) return;
    final database = ref.read(appDatabaseProvider);
    // Book balance as of now via the shared helper logic.
    final acct = await (database.select(database.bankAccounts)
          ..where((t) => t.id.equals(_accountId!)))
        .getSingleOrNull();
    if (acct == null || !mounted) return;
    var bal = acct.openingBalancePaisa;
    final inQ = database.select(database.receipts)
      ..where((t) =>
          t.institutionId.equals(ctx.institutionId) &
          t.status.equalsValue(ReceiptStatus.confirmed) &
          t.bankAccountId.equals(_accountId!));
    for (final row in await inQ.get()) {
      bal += row.reversesId == null ? row.totalPaisa : -row.totalPaisa;
    }
    final outQ = database.select(database.expenseVouchers)
      ..where((t) =>
          t.institutionId.equals(ctx.institutionId) &
          t.status.equalsValue(ExpenseStatus.paid) &
          t.bankAccountId.equals(_accountId!));
    for (final row in await outQ.get()) {
      bal -= row.totalPaisa;
    }
    if (mounted) setState(() => _bookBalance = bal);
  }

  Future<void> _loadHistory() async {
    final ctx = ref.read(repositoryContextProvider);
    if (ctx == null || _accountId == null) return;
    final database = ref.read(appDatabaseProvider);
    final rows = await (database.select(database.reconciliations)
          ..where((t) =>
              t.institutionId.equals(ctx.institutionId) &
              t.bankAccountId.equals(_accountId!))
          ..orderBy([(t) => OrderingTerm.desc(t.statementDate)])
          ..limit(20))
        .get();
    if (mounted) setState(() => _history = rows);
  }

  Future<void> _save() async {
    final stmt = Money.tryParsePkr(_statementBalance.text);
    if (_accountId == null || stmt == null || _bookBalance == null) {
      mrpShowSnack(context, 'اکاؤنٹ اور اسٹیٹمنٹ بیلنس درج کریں',
          isError: true);
      return;
    }
    final ctx = ref.read(repositoryContextProvider);
    if (ctx == null) return;
    setState(() => _busy = true);
    final database = ref.read(appDatabaseProvider);
    final now = DateTime.now();
    await database.into(database.reconciliations).insert(
          db.ReconciliationsCompanion.insert(
            id: const Uuid().v4(),
            institutionId: ctx.institutionId,
            bankAccountId: _accountId!,
            statementDate: now,
            statementBalancePaisa: stmt,
            bookBalancePaisa: _bookBalance!,
            differencePaisa: stmt - _bookBalance!,
            createdBy: Value(ctx.actorId),
            notes: Value(_notes.text.trim().isEmpty
                ? null
                : _notes.text.trim()),
            createdAt: now,
          ),
        );
    if (!mounted) return;
    setState(() {
      _busy = false;
      _statementBalance.clear();
      _notes.clear();
    });
    mrpShowSnack(context, 'مفاہمت محفوظ ہو گئی');
    _loadHistory();
  }

  @override
  Widget build(BuildContext context) {
    final diff = (_bookBalance != null &&
            Money.tryParsePkr(_statementBalance.text) != null)
        ? Money.tryParsePkr(_statementBalance.text)! - _bookBalance!
        : null;
    return Scaffold(
      appBar: AppBar(title: const Text('بینک مفاہمت')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          DropdownButtonFormField<String>(
            value: _accountId,
            decoration:
                const InputDecoration(labelText: 'بینک اکاؤنٹ'),
            items: _accounts
                .map((a) => DropdownMenuItem(
                    value: a.id, child: Text(a.title)))
                .toList(),
            onChanged: (v) {
              setState(() => _accountId = v);
              _loadBook();
              _loadHistory();
            },
          ),
          const SizedBox(height: 12),
          MrpCard(
            child: Row(
              mainAxisAlignment:
                  MainAxisAlignment.spaceBetween,
              children: [
                Text('کتاب کے مطابق بیلنس',
                    style: AppTypography.bodyUr),
                Text(
                    _bookBalance == null
                        ? '—'
                        : Money.formatPkr(_bookBalance!,
                            symbol: false),
                    style: AppTypography.amount,
                    textDirection: TextDirection.ltr),
              ],
            ),
          ),
          MrpTextField(
            controller: _statementBalance,
            label: 'بینک اسٹیٹمنٹ بیلنس (روپے) *',
            keyboardType:
                const TextInputType.numberWithOptions(decimal: true),
            textDirection: TextDirection.ltr,
            onChanged: (_) => setState(() {}),
          ),
          if (diff != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                'فرق: ${Money.formatPkr(diff, symbol: false)}',
                style: TextStyle(fontFamily: AppTypography.urduFont, color: diff == 0
                        ? AppColors.success
                        : AppColors.danger,
                    fontWeight: FontWeight.w700),
                textDirection: TextDirection.ltr,
              ),
            ),
          const SizedBox(height: 12),
          MrpTextField(
              controller: _notes, label: 'نوٹس', maxLines: 2),
          const SizedBox(height: 16),
          MrpPrimaryButton(
              label: 'مفاہمت محفوظ کریں',
              loading: _busy,
              onPressed: _save),
          MrpSectionHeader(title: 'سابقہ مفاہمتیں'),
          for (final h in _history)
            ListTile(
              title: Text(
                  'فرق: ${Money.formatPkr(h.differencePaisa, symbol: false)}',
                  textDirection: TextDirection.ltr),
              subtitle: Text(
                  '${h.statementDate.year}-${h.statementDate.month}-${h.statementDate.day}${h.notes != null ? ' — ${h.notes}' : ''}'),
              trailing: h.differencePaisa == 0
                  ? const Icon(Icons.check_circle,
                      color: AppColors.success)
                  : const Icon(Icons.warning_amber,
                      color: AppColors.warning),
            ),
        ],
      ),
    );
  }
}
