import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/widgets.dart';
import '../../../domain/auth/permissions.dart';
import '../../../domain/entities/enums.dart';
import '../../../data/local/app_database.dart' as db;
import 'package:drift/drift.dart' hide Column;

/// Staff & permissions: read-only roster here (user provisioning happens
/// via Supabase Auth admin + set_user_app_metadata). Role changes are
/// audited server-side.
class StaffScreen extends ConsumerStatefulWidget {
  const StaffScreen({super.key});
  @override
  ConsumerState<StaffScreen> createState() => _StaffScreenState();
}

class _StaffScreenState extends ConsumerState<StaffScreen> {
  List<db.UserProfile> _rows = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final ctx = ref.read(repositoryContextProvider);
    if (ctx == null) {
      setState(() => _loading = false);
      return;
    }
    final database = ref.read(appDatabaseProvider);
    final rows = await (database.select(database.userProfiles)
          ..where((t) => t.institutionId.equals(ctx.institutionId))
          ..orderBy([(t) => OrderingTerm(expression: t.displayName)]))
        .get();
    if (mounted) {
      setState(() {
        _rows = rows;
        _loading = false;
      });
    }
  }

  bool get _isAdmin {
    final role = ref.read(sessionProvider)?.role;
    return role != null && Permissions.can(role, 'users.manage');
  }

  String _roleLabel(UserRole r) => switch (r) {
        UserRole.admin => 'منتظم',
        UserRole.accountant => 'محاسب',
        UserRole.receiptOperator => 'رسید آپریٹر',
        UserRole.paymentVerifier => 'ادائیگی تصدیق کنندہ',
        UserRole.auditor => 'آڈیٹر',
      };

  static const _rolePermissions = {
    'منتظم': 'ترتیبات، عملہ، تمام مالی امور',
    'محاسب': 'رسید، تصدیق، اخراجات، مفاہمت، رپورٹس',
    'رسید آپریٹر': 'رسید بنانا، اخراجات کا مسودہ',
    'ادائیگی تصدیق کنندہ': 'ادائیگی کی تصدیق، رپورٹس دیکھنا',
    'آڈیٹر': 'صرف دیکھنا (رسید، رپورٹ، آڈٹ)',
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('عملہ و اجازتیں')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                for (final u in _rows)
                  MrpCard(
                    child: Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: u.isActive
                              ? AppColors.emerald100
                              : AppColors.ivoryDeep,
                          child: Text(
                              (u.displayName as String).isNotEmpty
                                  ? (u.displayName as String)[0]
                                  : '?',
                              style: const TextStyle(
                                  color: AppColors.emerald800,
                                  fontWeight: FontWeight.w700)),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,
                            children: [
                              Text(u.displayName,
                                  style: AppTypography.bodyUr
                                      .copyWith(
                                          fontWeight:
                                              FontWeight.w600)),
                              Text(u.email,
                                  style:
                                      AppTypography.captionEn,
                                  textDirection:
                                      TextDirection.ltr),
                            ],
                          ),
                        ),
                        Column(
                          crossAxisAlignment:
                              CrossAxisAlignment.end,
                          children: [
                            MrpStatusBadge(
                              label: _roleLabel(u.role),
                              kind: u.isActive
                                  ? MrpStatusKind.success
                                  : MrpStatusKind.neutral,
                            ),
                            if (!u.isActive)
                              const Text('غیر فعال',
                                  style: TextStyle(
                                      fontSize: 11,
                                      color: AppColors.danger)),
                          ],
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 8),
                MrpSectionHeader(title: 'کرداروں کی اجازتیں'),
                for (final e in _rolePermissions.entries)
                  ListTile(
                    dense: true,
                    title: Text(e.key,
                        style: const TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 14)),
                    subtitle: Text(e.value,
                        style:
                            const TextStyle(fontSize: 12)),
                  ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.infoBg,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    _isAdmin
                        ? 'نئے عملے کو Supabase Auth سے مدعو کریں، پھر set_user_app_metadata سے کردار لگائیں۔ تمام تبدیلیاں سرور پر آڈٹ ہوتی ہیں۔'
                        : 'عملے کا انتظام صرف منتظم کر سکتا ہے۔',
                    style: const TextStyle(
                        color: AppColors.info, fontSize: 12),
                  ),
                ),
              ],
            ),
    );
  }
}
