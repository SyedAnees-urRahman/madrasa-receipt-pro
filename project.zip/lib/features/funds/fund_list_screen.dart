import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/widgets.dart';
import '../../../core/utils/money.dart';
import '../../../domain/auth/permissions.dart';
import '../../../domain/entities/entities.dart';
import '../../../domain/repositories/repositories.dart';

/// Fund management: per-fund opening, confirmed receipts, expenses,
/// pending (separate), closing balance. Restricted funds are flagged.
class FundListScreen extends ConsumerStatefulWidget {
  const FundListScreen({super.key});
  @override
  ConsumerState<FundListScreen> createState() => _FundListScreenState();
}

class _FundListScreenState extends ConsumerState<FundListScreen> {
  List<FundBalance> _balances = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final res = await ref.read(fundRepositoryProvider).allBalances();
    if (mounted) {
      setState(() {
        _balances = res.isOk ? res.value : const [];
        _loading = false;
      });
    }
  }

  bool get _canManage {
    final role = ref.read(sessionProvider)?.role;
    return role != null && Permissions.can(role, 'funds.manage');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('فنڈز')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView.builder(
                itemCount: _balances.length,
                itemBuilder: (_, i) {
                  final b = _balances[i];
                  return MrpAnimatedEntry(
                    delayMs: (i * 40).clamp(0, 240),
                    child: MrpCard(
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Flexible(
                                          child: Text(b.fund.nameUr,
                                              style: AppTypography
                                                  .bodyUr
                                                  .copyWith(
                                                      fontWeight:
                                                          FontWeight
                                                              .w700)),
                                        ),
                                        if (b.fund.isRestricted) ...[
                                          const SizedBox(width: 6),
                                          const MrpStatusBadge(
                                              label: 'مخصوص',
                                              kind: MrpStatusKind
                                                  .warning),
                                        ],
                                      ],
                                    ),
                                    Text(b.fund.nameEn,
                                        style:
                                            AppTypography.captionEn),
                                  ],
                                ),
                              ),
                              Text(
                                Money.formatPkr(b.closingPaisa,
                                    symbol: false),
                                style: AppTypography.amountLarge
                                    .copyWith(fontSize: 20),
                                textDirection:
                                    TextDirection.ltr,
                              ),
                            ],
                          ),
                          const Divider(),
                          _line('ابتدائی بیلنس', b.openingPaisa),
                          _line('مصدقہ وصولیاں',
                              b.confirmedReceiptsPaisa),
                          _line('مجاز اخراجات',
                              -b.authorizedExpensesPaisa),
                          _line('زیرِ التواء (غیر مصدقہ)',
                              b.pendingPaisa,
                              pending: true),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
    );
  }

  Widget _line(String label, int paisa, {bool pending = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style: AppTypography.captionUr.copyWith(
                  color: pending
                      ? AppColors.warning
                      : AppColors.ink500)),
          Text(
            Money.formatPkr(paisa, symbol: false),
            style: AppTypography.captionEn.copyWith(
                color:
                    pending ? AppColors.warning : AppColors.ink700,
                fontWeight: FontWeight.w600),
            textDirection: TextDirection.ltr,
          ),
        ],
      ),
    );
  }
}
