import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../app_providers.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/widgets.dart';
import '../../../core/utils/money.dart';
import '../../../domain/repositories/repositories.dart';
import '../../../domain/entities/entities.dart';

class DonorListScreen extends ConsumerStatefulWidget {
  const DonorListScreen({super.key});
  @override
  ConsumerState<DonorListScreen> createState() => _DonorListScreenState();
}

class _DonorListScreenState extends ConsumerState<DonorListScreen> {
  final _search = TextEditingController();
  List<Donor> _rows = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final res = await ref
        .read(donorRepositoryProvider)
        .search(_search.text.trim());
    if (mounted) {
      setState(() {
        _rows = res.isOk ? res.value : const [];
        _loading = false;
      });
    }
  }

  Future<void> _showHistory(dynamic donor) async {
    final res = await ref
        .read(reportRepositoryProvider)
        .donorHistory(donor.id as String);
    if (!mounted || !res.isOk) return;
    final rows = res.value;
    var total = 0;
    for (final r in rows) {
      total += r.receipt.totalPaisa;
    }
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(donor.name as String),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('کل عطیات: ${Money.formatPkr(total, symbol: false)}',
                  style: AppTypography.amount,
                  textDirection: TextDirection.ltr),
              const SizedBox(height: 8),
              Flexible(
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    for (final h in rows.take(20))
                      ListTile(
                        dense: true,
                        title: Text(
                            h.receipt.officialNumber ??
                                h.receipt.localProvisionalLabel ??
                                '',
                            textDirection: TextDirection.ltr),
                        subtitle: Text(h.fundNames.join('، ')),
                        trailing: Text(
                            Money.formatPkr(h.receipt.totalPaisa,
                                symbol: false),
                            textDirection: TextDirection.ltr),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('بند کریں')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('عطیہ دہندگان')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: MrpTextField(
              controller: _search,
              hint: 'نام یا فون سے تلاش کریں',
              prefixIcon: Icons.search,
              onChanged: (_) => _load(),
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _rows.isEmpty
                    ? const MrpEmptyState(
                        icon: Icons.people_outline,
                        message: 'کوئی عطیہ دہندہ نہیں ملا')
                    : ListView.builder(
                        itemCount: _rows.length,
                        itemBuilder: (_, i) {
                          final d = _rows[i];
                          return MrpCard(
                            onTap: () => _showHistory(d),
                            child: Row(
                              children: [
                                const CircleAvatar(
                                    child: Icon(Icons.person_outline)),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(d.name,
                                          style: AppTypography
                                              .bodyUr
                                              .copyWith(
                                                  fontWeight:
                                                      FontWeight
                                                          .w600)),
                                      if (d.phone != null)
                                        Text(d.phone!,
                                            style: AppTypography
                                                .captionEn,
                                            textDirection:
                                                TextDirection.ltr),
                                    ],
                                  ),
                                ),
                                const Icon(Icons.history),
                              ],
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final name = TextEditingController();
          final ok = await showDialog<bool>(
            context: context,
            builder: (ctx) => AlertDialog(
              title: const Text('نیا عطیہ دہندہ'),
              content:
                  MrpTextField(controller: name, label: 'نام *'),
              actions: [
                TextButton(
                    onPressed: () =>
                        Navigator.pop(ctx, false),
                    child: const Text('منسوخ')),
                FilledButton(
                    onPressed: () =>
                        Navigator.pop(ctx, true),
                    child: const Text('محفوظ کریں')),
              ],
            ),
          );
          if (ok == true && name.text.trim().isNotEmpty) {
            final ctx = ref.read(repositoryContextProvider);
            if (ctx == null) return;
            await ref.read(donorRepositoryProvider).create(
                  Donor(
                    id: '',
                    institutionId: ctx.institutionId,
                    name: name.text.trim(),
                    createdBy: ctx.actorId,
                    createdAt: DateTime.now(),
                    updatedAt: DateTime.now(),
                  ),
                );
            _load();
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
