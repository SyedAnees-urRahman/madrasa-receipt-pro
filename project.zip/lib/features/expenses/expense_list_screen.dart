import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../app_providers.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/widgets.dart';
import '../../../core/utils/money.dart';
import '../../../domain/entities/enums.dart';
import '../../../domain/entities/entities.dart';

class ExpenseListScreen extends ConsumerStatefulWidget {
  const ExpenseListScreen({super.key});
  @override
  ConsumerState<ExpenseListScreen> createState() =>
      _ExpenseListScreenState();
}

class _ExpenseListScreenState extends ConsumerState<ExpenseListScreen> {
  List<ExpenseVoucher> _rows = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final res = await ref.read(expenseRepositoryProvider).register(limit: 200);
    if (mounted) {
      setState(() {
        _rows = res.isOk ? res.value : const [];
        _loading = false;
      });
    }
  }

  MrpStatusKind _kind(ExpenseStatus s) => switch (s) {
        ExpenseStatus.approved => MrpStatusKind.success,
        ExpenseStatus.paid => MrpStatusKind.info,
        ExpenseStatus.draft => MrpStatusKind.neutral,
        ExpenseStatus.pendingApproval => MrpStatusKind.warning,
        ExpenseStatus.rejected => MrpStatusKind.danger,
      };

  String _label(ExpenseStatus s) => switch (s) {
        ExpenseStatus.draft => 'مسودہ',
        ExpenseStatus.pendingApproval => 'منظوری منتظر',
        ExpenseStatus.approved => 'منظور شدہ',
        ExpenseStatus.paid => 'ادا شدہ',
        ExpenseStatus.rejected => 'مسترد',
      };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('اخراجات')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _rows.isEmpty
              ? const MrpEmptyState(
                  icon: Icons.receipt_outlined,
                  message: 'کوئی واؤچر نہیں ملا')
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.builder(
                    itemCount: _rows.length,
                    itemBuilder: (_, i) {
                      final v = _rows[i];
                      return MrpCard(
                        onTap: () =>
                            _showDetail(v),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  Text(v.voucherNumber,
                                      style: AppTypography.amount
                                          .copyWith(fontSize: 15),
                                      textDirection:
                                          TextDirection.ltr),
                                  Text(v.payee,
                                      style:
                                          AppTypography.captionUr),
                                  const SizedBox(height: 6),
                                  MrpStatusBadge(
                                      label: _label(v.status),
                                      kind: _kind(v.status)),
                                ],
                              ),
                            ),
                            Text(
                              Money.formatPkr(v.totalPaisa,
                                  symbol: false),
                              style: AppTypography.amount,
                              textDirection: TextDirection.ltr,
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => context.push('/expenses/new'),
        child: const Icon(Icons.add),
      ),
    );
  }

  Future<void> _showDetail(ExpenseVoucher v) async {
    final session = ref.read(sessionProvider);
    final canApprove = session != null &&
        (session.role == UserRole.admin ||
            session.role == UserRole.accountant);
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(v.voucherNumber,
            textDirection: TextDirection.ltr),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('وصول کنندہ: ${v.payee}'),
            Text('تفصیل: ${v.description}'),
            Text(
                'رقم: ${Money.formatPkr(v.totalPaisa, symbol: false)}',
                textDirection: TextDirection.ltr),
            Text('حیثیت: ${_label(v.status)}'),
          ],
        ),
        actions: [
          if (canApprove &&
              (v.status == ExpenseStatus.draft ||
                  v.status == ExpenseStatus.pendingApproval))
            FilledButton(
              onPressed: () async {
                Navigator.pop(ctx);
                final res = await ref
                    .read(expenseRepositoryProvider)
                    .approve(
                        voucherId: v.id,
                        approverId: session!.id);
                if (mounted) {
                  mrpShowSnack(context,
                      res.isOk ? 'منظور ہو گیا' : 'منظوری ناکام',
                      isError: !res.isOk);
                  _load();
                }
              },
              child: const Text('منظور کریں'),
            ),
          if (canApprove && v.status == ExpenseStatus.approved)
            FilledButton(
              onPressed: () async {
                Navigator.pop(ctx);
                final res = await ref
                    .read(expenseRepositoryProvider)
                    .markPaid(
                        voucherId: v.id,
                        actorId: session!.id);
                if (mounted) {
                  mrpShowSnack(context,
                      res.isOk ? 'ادا شدہ قرار دیا گیا' : 'ناکام',
                      isError: !res.isOk);
                  _load();
                }
              },
              child: const Text('ادا شدہ قرار دیں'),
            ),
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('بند کریں')),
        ],
      ),
    );
  }
}
