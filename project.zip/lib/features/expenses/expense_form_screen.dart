import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/widgets.dart';
import '../../../core/utils/money.dart';
import '../../../domain/entities/entities.dart';
import '../../../domain/entities/enums.dart';
import '../../../domain/repositories/repositories.dart';

/// Expense voucher creation: payee, description, amount, fund allocation
/// (must balance), payment method, account. Warns when exceeding the
/// available fund balance; blocks silently-over-budget restricted spending
/// only with an explicit warning (admin may still proceed with reason).
class ExpenseFormScreen extends ConsumerStatefulWidget {
  const ExpenseFormScreen({super.key});
  @override
  ConsumerState<ExpenseFormScreen> createState() =>
      _ExpenseFormScreenState();
}

class _AllocRow {
  String? fundId;
  final amountCtrl = TextEditingController();
}

class _ExpenseFormScreenState extends ConsumerState<ExpenseFormScreen> {
  final _payee = TextEditingController();
  final _description = TextEditingController();
  final _total = TextEditingController();
  final _allocs = <_AllocRow>[_AllocRow()];
  PaymentMethod _method = PaymentMethod.cash;
  String? _accountId;
  DateTime _date = DateTime.now();
  List<FundType> _funds = const [];
  List<BankAccount> _accounts = const [];
  Map<String, int> _fundAvailable = const {};
  bool _busy = false;
  bool _overBudgetAck = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _payee.dispose();
    _description.dispose();
    _total.dispose();
    for (final a in _allocs) {
      a.amountCtrl.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    final funds = await ref.read(fundRepositoryProvider).funds();
    final accounts = await ref.read(accountRepositoryProvider).accounts();
    final balances = await ref.read(fundRepositoryProvider).allBalances();
    if (!mounted) return;
    setState(() {
      _funds = funds.isOk ? funds.value : const [];
      _accounts = accounts.isOk ? accounts.value : const [];
      _fundAvailable = balances.isOk
          ? {for (final b in balances.value) b.fund.id: b.closingPaisa}
          : const {};
      if (_allocs.first.fundId == null && _funds.isNotEmpty) {
        _allocs.first.fundId = _funds.first.id;
      }
      _accountId = _accounts.firstOrNull?.id;
    });
  }

  int get _totalPaisa => Money.tryParsePkr(_total.text) ?? 0;

  int _allocSum() {
    var s = 0;
    for (final a in _allocs) {
      s += Money.tryParsePkr(a.amountCtrl.text) ?? 0;
    }
    return s;
  }

  bool get _balanced =>
      _totalPaisa > 0 &&
      _allocs.every((a) =>
          a.fundId != null &&
          (Money.tryParsePkr(a.amountCtrl.text) ?? 0) > 0) &&
      _allocSum() == _totalPaisa;

  bool get _overBudget {
    for (final a in _allocs) {
      final amt = Money.tryParsePkr(a.amountCtrl.text) ?? 0;
      final avail = _fundAvailable[a.fundId] ?? 0;
      if (amt > avail) return true;
    }
    return false;
  }

  Future<void> _save() async {
    if (_payee.text.trim().isEmpty ||
        _description.text.trim().isEmpty ||
        !_balanced) {
      mrpShowSnack(context, 'خانے درست کریں — تقسیم رقم کے برابر ہو',
          isError: true);
      return;
    }
    if (_overBudget && !_overBudgetAck) {
      final ok = await mrpConfirmDialog(context,
          title: 'بجٹ سے زائد',
          body:
              'یہ خرچ متعلقہ فنڈ کے دستیاب بیلنس سے زیادہ ہے۔ کیا واقعی جاری رکھنا ہے؟',
          confirmLabel: 'جی، جاری رکھیں',
          danger: true);
      if (!ok) return;
      _overBudgetAck = true;
    }
    setState(() => _busy = true);
    final res = await ref.read(expenseRepositoryProvider).create(
          ExpenseDraft(
            voucherDate: _date,
            payee: _payee.text.trim(),
            description: _description.text.trim(),
            totalPaisa: _totalPaisa,
            allocations: [
              for (final a in _allocs)
                AllocationDraft(
                  fundTypeId: a.fundId!,
                  amountPaisa:
                      Money.tryParsePkr(a.amountCtrl.text) ?? 0,
                ),
            ],
            paymentMethod: _method,
            bankAccountId: _accountId,
          ),
        );
    if (!mounted) return;
    setState(() => _busy = false);
    if (res.isOk) {
      mrpShowSnack(context, 'واؤچر بن گیا: ${res.value.voucherNumber}');
      context.pop();
    } else {
      mrpShowSnack(context, 'واؤچر نہیں بن سکا', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('نیا اخراجات واؤچر')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          MrpTextField(controller: _payee, label: 'وصول کنندہ / دکاندار *'),
          const SizedBox(height: 12),
          MrpTextField(
              controller: _description, label: 'تفصیل *', maxLines: 2),
          const SizedBox(height: 12),
          MrpTextField(
            controller: _total,
            label: 'کل رقم (روپے) *',
            keyboardType:
                const TextInputType.numberWithOptions(decimal: true),
            textDirection: TextDirection.ltr,
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 16),
          Text('فنڈ کی تقسیم *', style: AppTypography.bodyUr),
          const SizedBox(height: 8),
          for (var i = 0; i < _allocs.length; i++) _allocEditor(i),
          MrpSecondaryButton(
            label: 'تقسیم شامل کریں',
            icon: Icons.add,
            onPressed: () => setState(() {
              final r = _AllocRow();
              if (_funds.isNotEmpty) r.fundId = _funds.first.id;
              _allocs.add(r);
            }),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color:
                  _balanced ? AppColors.successBg : AppColors.warningBg,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('تقسیم کا مجموعہ'),
                Text(Money.formatPkr(_allocSum(), symbol: false),
                    style: AppTypography.amount,
                    textDirection: TextDirection.ltr),
              ],
            ),
          ),
          if (_overBudget)
            const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Text(
                'تنبیہ: یہ خرچ فنڈ کے دستیاب بیلنس سے زیادہ ہے۔',
                style:
                    TextStyle(fontFamily: AppTypography.urduFont, color: AppColors.danger, fontSize: 13),
              ),
            ),
          const SizedBox(height: 16),
          Text('ادائیگی کا طریقہ', style: AppTypography.bodyUr),
          Wrap(
            spacing: 8,
            children: PaymentMethod.values.map((m) {
              return ChoiceChip(
                label: Text(m.name),
                selected: _method == m,
                selectedColor: AppColors.emerald100,
                onSelected: (_) =>
                    setState(() => _method = m),
              );
            }).toList(),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _accountId,
            decoration:
                const InputDecoration(labelText: 'ادائیگی اکاؤنٹ'),
            items: _accounts
                .map((a) => DropdownMenuItem(
                    value: a.id, child: Text(a.title)))
                .toList(),
            onChanged: (v) => setState(() => _accountId = v),
          ),
          const SizedBox(height: 20),
          MrpPrimaryButton(
              label: 'واؤچر محفوظ کریں',
              loading: _busy,
              onPressed: _save),
          const SizedBox(height: 8),
          Text(
            'واؤچر بننے سے رقم ادا نہیں ہوتی — منظوری کے بعد "ادا شدہ" قرار دیں۔',
            style: AppTypography.captionUr,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _allocEditor(int i) {
    final row = _allocs[i];
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Expanded(
              flex: 3,
              child: DropdownButtonFormField<String>(
                value: row.fundId,
                decoration:
                    const InputDecoration(labelText: 'فنڈ'),
                items: _funds
                    .map((f) => DropdownMenuItem(
                          value: f.id,
                          child: Text(
                              '${f.nameUr} (${Money.formatPkr(_fundAvailable[f.id] ?? 0, symbol: false)})',
                              overflow: TextOverflow.ellipsis),
                        ))
                    .toList(),
                onChanged: (v) =>
                    setState(() => row.fundId = v),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              flex: 2,
              child: MrpTextField(
                controller: row.amountCtrl,
                label: 'رقم',
                keyboardType:
                    const TextInputType.numberWithOptions(
                        decimal: true),
                textDirection: TextDirection.ltr,
                onChanged: (_) => setState(() {}),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.delete_outline,
                  color: AppColors.danger),
              onPressed: _allocs.length > 1
                  ? () => setState(() {
                        row.amountCtrl.dispose();
                        _allocs.removeAt(i);
                      })
                  : null,
            ),
          ],
        ),
      ),
    );
  }
}
