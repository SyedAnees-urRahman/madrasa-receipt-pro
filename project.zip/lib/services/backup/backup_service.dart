import 'dart:convert';
import 'dart:io';
import 'package:archive/archive_io.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_storage/shared_storage.dart' as saf;
import '../../data/local/app_database.dart';
import '../../data/local/workspace_store.dart';

/// Backup & restore: local ZIP in the app folder + optional Google Drive
/// folder (picked once via the system file picker, permission persisted).
///
/// The ZIP contains the SQLite files plus metadata.json. Restore replaces
/// the database files; the caller must invalidate providers / restart.
class BackupService {
  BackupService(this._db, this._store);
  final AppDatabase _db;
  final WorkspaceStore _store;

  static const String backupExtension = '.mrpbackup.zip';
  static const String driveFolderPref = 'backup_drive_folder_uri';
  static const String lastBackupPref = 'last_backup_time';
  static const String lastPromptPref = 'last_backup_prompt_time';
  static const String frequencyPref = 'backup_frequency'; // daily|weekly|monthly|off

  /// The app's own folder on the phone: <external>/MadrasaReceiptPro/
  Future<Directory> appFolder() async {
    final base = await getExternalStorageDirectory() ??
        await getApplicationDocumentsDirectory();
    final dir = Directory('${base.path}/MadrasaReceiptPro');
    if (!await dir.exists()) await dir.create(recursive: true);
    final backups = Directory('${dir.path}/Backups');
    if (!await backups.exists()) await backups.create(recursive: true);
    return dir;
  }

  Future<Directory> _backupsDir() async =>
      Directory('${(await appFolder()).path}/Backups');

  /// Create a timestamped ZIP backup in the app folder. Returns the file.
  Future<File> createLocalBackup({void Function(double)? onProgress}) async {
    onProgress?.call(0.1);
    // Checkpoint WAL so the main db file is self-contained.
    try {
      await _db.customStatement('PRAGMA wal_checkpoint(TRUNCATE)');
    } catch (_) {}
    onProgress?.call(0.3);

    final dbPath = await _dbFilePath();
    final dbFile = File(dbPath);
    if (!await dbFile.exists()) {
      throw StateError('ڈیٹا بیس فائل نہیں ملی');
    }

    final now = DateTime.now();
    final stamp =
        '${now.year}${_p(now.month)}${_p(now.day)}-${_p(now.hour)}${_p(now.minute)}';
    final institutionName = await _institutionName();
    final zipName = 'backup-$stamp$backupExtension';

    final encoder = ZipFileEncoder();
    final tmpZip = File('${(await _backupsDir()).path}/.$zipName.tmp');
    encoder.create(tmpZip.path);

    // SQLite files (db + wal + shm when present).
    encoder.addFile(dbFile, 'madrasa.db');
    for (final suffix in ['-wal', '-shm']) {
      final f = File('$dbPath$suffix');
      if (await f.exists()) encoder.addFile(f, 'madrasa.db$suffix');
    }
    onProgress?.call(0.6);

    final meta = jsonEncode({
      'app': 'madrasa_receipt_pro',
      'version': 1,
      'createdAt': now.toIso8601String(),
      'institutionName': institutionName,
      'institutionId': _store.currentInstitutionId,
    });
    encoder.addArchiveFile(
        ArchiveFile('metadata.json', meta.length, utf8.encode(meta)));
    encoder.close();
    onProgress?.call(0.9);

    final dest = File('${(await _backupsDir()).path}/$zipName');
    if (await dest.exists()) await dest.delete();
    await tmpZip.rename(dest.path);
    await _store.setString(lastBackupPref, now.toIso8601String());
    onProgress?.call(1.0);

    // Also copy to user-picked visible folder (if set)
    try {
      if (await hasLocalFolder) {
        await copyToLocalFolder(dest);
      }
    } catch (_) {
      // Non-fatal: backup is safe in app folder
    }
    return dest;
  }

  /// List local backups, newest first.
  Future<List<File>> listLocalBackups() async {
    final dir = await _backupsDir();
    final files = dir
        .listSync()
        .whereType<File>()
        .where((f) => f.path.endsWith(backupExtension))
        .toList();
    files.sort((a, b) => b.path.compareTo(a.path));
    return files;
  }

  /// Read metadata.json from a backup ZIP without extracting.
  Future<Map<String, dynamic>?> readMetadata(File zip) async {
    try {
      final bytes = await zip.readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);
      final meta = archive.files
          .where((f) => f.name == 'metadata.json')
          .firstOrNull;
      if (meta == null) return null;
      return jsonDecode(utf8.decode(meta.content as List<int>))
          as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  /// Restore a backup ZIP over the current database. The database MUST be
  /// closed by the caller first (or this is a fresh install).
  Future<void> restoreFromZip(File zip) async {
    final bytes = await zip.readAsBytes();
    final archive = ZipDecoder().decodeBytes(bytes);
    final tmpDir =
        await Directory.systemTemp.createTemp('mrp_restore_');
    try {
      for (final file in archive.files) {
        if (!file.isFile) continue;
        final out = File('${tmpDir.path}/${file.name}');
        await out.writeAsBytes(file.content as List<int>);
      }
      final metaFile = File('${tmpDir.path}/metadata.json');
      if (!await metaFile.exists()) {
        throw StateError('بیک اپ فائل خراب ہے');
      }
      final meta = jsonDecode(await metaFile.readAsString())
          as Map<String, dynamic>;
      final dbPath = await _dbFilePath();
      // Replace db files.
      for (final name in ['madrasa.db', 'madrasa.db-wal', 'madrasa.db-shm']) {
        final src = File('${tmpDir.path}/$name');
        final destName =
            name == 'madrasa.db' ? dbPath : '$dbPath${name.substring(10)}';
        final dest = File(destName);
        if (await src.exists()) {
          if (await dest.exists()) await dest.delete();
          await src.copy(dest.path);
        } else if (await dest.exists() && name != 'madrasa.db') {
          await dest.delete();
        }
      }
      final institutionId = meta['institutionId'] as String?;
      if (institutionId != null && institutionId.isNotEmpty) {
        await _store.setCurrentInstitutionId(institutionId);
      }
      await _store.setSetupComplete(true);
      await _store.setString(
          lastBackupPref, DateTime.now().toIso8601String());
    } finally {
      try {
        await tmpDir.delete(recursive: true);
      } catch (_) {}
    }
  }

  // ---------- Google Drive via Storage Access Framework ----------

  /// Let the user pick a Drive folder once; permission is persisted so
  /// later uploads happen silently. Returns true when a folder is saved.
  Future<bool> pickDriveFolder() async {
    final uri = await saf.openDocumentTree();
    if (uri == null) return false;
    await _store.setString(driveFolderPref, uri.toString());
    return true;
  }

  // ---------- Local backup folder (user-visible) ----------

  static const String localFolderPref = 'backup_local_folder_uri';
  static const String localFolderNamePref = 'backup_local_folder_name';

  /// Let the user pick a visible local folder (e.g. Download) for backups.
  /// Uses SAF so it works on Android 10+ scoped storage.
  Future<bool> pickLocalFolder() async {
    final uri = await saf.openDocumentTree();
    if (uri == null) return false;
    await _store.setString(localFolderPref, uri.toString());
    // Try to get a friendly name
    try {
      final doc = await saf.DocumentFile.fromTreeUri(Uri.parse(uri.toString()));
      final name = doc?.name ?? 'منتخب فولڈر';
      await _store.setString(localFolderNamePref, name);
    } catch (_) {
      await _store.setString(localFolderNamePref, 'منتخب فولڈر');
    }
    return true;
  }

  String? get localFolderUri => _store.getString(localFolderPref);
  String get localFolderName =>
      _store.getString(localFolderNamePref) ?? 'ایپ فولڈر (پوشیدہ)';

  Future<bool> get hasLocalFolder async {
    final uriStr = localFolderUri;
    if (uriStr == null) return false;
    final perms = await saf.persistedUriPermissions() ?? [];
    return perms.any(
        (p) => p.uri.toString() == uriStr && p.isWritePermission);
  }

  /// Copy a backup ZIP into the user-picked local folder.
  Future<void> copyToLocalFolder(File zip) async {
    final uriStr = localFolderUri;
    if (uriStr == null) return;
    final bytes = await zip.readAsBytes();
    final name = zip.path.split('/').last;
    await saf.createFileAsBytes(
      Uri.parse(uriStr),
      bytes: bytes,
      displayName: name,
      mimeType: 'application/zip',
    );
  }

  String? get driveFolderUri =>
      _store.getString(driveFolderPref);

  Future<bool> get hasDriveFolder async {
    final uriStr = driveFolderUri;
    if (uriStr == null) return false;
    final perms = await saf.persistedUriPermissions() ?? [];
    return perms.any(
        (p) => p.uri.toString() == uriStr && p.isWritePermission);
  }

  /// Upload the latest local backup ZIP into the picked Drive folder.
  Future<void> uploadToDrive(File zip,
      {void Function(double)? onProgress}) async {
    final uriStr = driveFolderUri;
    if (uriStr == null) throw StateError('Drive فولڈر منتخب نہیں');
    onProgress?.call(0.1);
    final tree = await saf.DocumentFile.fromTreeUri(Uri.parse(uriStr));
    if (tree == null) throw StateError('Drive فولڈر دستیاب نہیں');
    onProgress?.call(0.3);
    final bytes = await zip.readAsBytes();
    final name = zip.uri.pathSegments.last;
    onProgress?.call(0.5);
    // Replace same-day file if present to avoid duplicates.
    final existing = await tree.child(name);
    if (existing != null) await existing.delete();
    await tree.createFileAsBytes(
      mimeType: 'application/zip',
      displayName: name,
      bytes: bytes,
    );
    onProgress?.call(1.0);
  }

  /// List backup ZIPs inside the picked Drive folder.
  Future<List<saf.DocumentFile>> listDriveBackups() async {
    final uriStr = driveFolderUri;
    if (uriStr == null) return [];
    final treeUri = Uri.parse(uriStr);
    final children = await saf
        .listFiles(treeUri, columns: [saf.DocumentFileColumn.displayName])
        .toList();
    final backups = children
        .where((f) => (f.name ?? '').endsWith(backupExtension))
        .toList();
    backups.sort((a, b) => (b.name ?? '').compareTo(a.name ?? ''));
    return backups;
  }

  /// Download a Drive backup file into the app folder for restore.
  Future<File> downloadDriveBackup(saf.DocumentFile doc) async {
    final bytes = await doc.getContent();
    if (bytes == null) throw StateError('ڈاؤن لوڈ ناکام');
    final dir = await _backupsDir();
    final dest = File('${dir.path}/${doc.name ?? 'drive$backupExtension'}');
    await dest.writeAsBytes(bytes);
    return dest;
  }

  // ---------- Auto-prompt ----------

  /// Whether a backup reminder should pop up now (respects frequency and
  /// a 24h quiet period after the last prompt).
  Future<bool> shouldPromptBackup() async {
    final freq = _store.getString(frequencyPref) ?? 'weekly';
    if (freq == 'off') return false;
    final interval = switch (freq) {
      'daily' => const Duration(days: 1),
      'monthly' => const Duration(days: 30),
      _ => const Duration(days: 7),
    };
    final now = DateTime.now();
    final lastPrompt = _parseTime(_store.getString(lastPromptPref));
    if (lastPrompt != null &&
        now.difference(lastPrompt) < const Duration(hours: 24)) {
      return false;
    }
    final lastBackup = _parseTime(_store.getString(lastBackupPref));
    if (lastBackup == null) return true; // never backed up
    return now.difference(lastBackup) >= interval;
  }

  Future<void> markPromptShown() async {
    await _store.setString(
        lastPromptPref, DateTime.now().toIso8601String());
  }

  // ---------- helpers ----------

  Future<String> _dbFilePath() async {
    final dir = await getApplicationDocumentsDirectory();
    // drift_flutter stores the db as <docs>/madrasa_receipt_pro.sqlite
    // Try both known locations.
    const candidates = ['madrasa_receipt_pro.sqlite', 'madrasa.db'];
    for (final name in candidates) {
      final f = File('${dir.path}/$name');
      if (await f.exists()) return f.path;
    }
    // Fallback: first sqlite file in the documents dir.
    final files = dir
        .listSync()
        .whereType<File>()
        .where((f) => f.path.endsWith('.sqlite'))
        .toList();
    if (files.isNotEmpty) return files.first.path;
    return '${dir.path}/madrasa_receipt_pro.sqlite';
  }

  Future<String> _institutionName() async {
    try {
      final rows = await (_db.select(_db.institutions)..limit(1)).get();
      if (rows.isNotEmpty) return rows.first.nameUr;
    } catch (_) {}
    return '';
  }

  DateTime? _parseTime(String? s) =>
      s == null ? null : DateTime.tryParse(s);

  String _p(int v) => v.toString().padLeft(2, '0');
}
