import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'receipt_document.dart';
import 'widget_to_image.dart';

/// Builds the official receipt PDF.
///
/// Pipeline: [ReceiptDocumentWidget] → high-res PNG → sliced into page
/// chunks → embedded into a [pw.Document]. Vector text is deliberately
/// NOT used for Urdu (the pdf package cannot shape Nastaliq); the image
/// pipeline is what makes the Urdu correct.
class ReceiptPdfService {
  /// A4 portrait. Content width in logical px for capture.
  static const double a4WidthPx = 760;
  static const double a4Aspect = 210 / 297;

  /// 80mm thermal.
  static const double thermalWidthPx = 512;

  Future<Uint8List> buildReceiptPdf({
    required BuildContext context,
    required ReceiptDocumentData data,
  }) async {
    final thermal = data.institution.printFormat == 'thermal80';
    final widthPx = thermal ? thermalWidthPx : a4WidthPx;

    final png = await WidgetToImage.capturePng(
      context: context,
      widget: ReceiptDocumentWidget(data: data, width: widthPx),
      logicalWidth: widthPx,
      pixelRatio: 3.0,
    );

    final doc = pw.Document(
      title: 'Receipt ${data.receipt.officialNumber ?? data.receipt.localProvisionalLabel}',
      author: data.institution.nameEn,
    );

    if (thermal) {
      final page = await _imagePage(png, widthPx, chunkAspect: null);
      doc.addPage(pw.Page(
        pageFormat: PdfPageFormat(
          80 * PdfPageFormat.mm,
          page.heightPt,
          marginAll: 4 * PdfPageFormat.mm,
        ),
        build: (_) => page.widget,
      ));
    } else {
      final chunks = _sliceForA4(png);
      for (final chunk in chunks) {
        final jpeg = Uint8List.fromList(
            img.encodeJpg(img.decodePng(chunk.bytes)!, quality: 95));
        final image = pw.MemoryImage(jpeg);
        doc.addPage(pw.Page(
          pageFormat: PdfPageFormat.a4,
          build: (_) => pw.Center(
            child: pw.Image(image, fit: pw.BoxFit.contain),
          ),
        ));
      }
    }
    return doc.save();
  }

  /// Shares via the Android share sheet; also used for "save locally".
  Future<void> sharePdf(Uint8List pdfBytes, String fileName) async {
    await Printing.sharePdf(bytes: pdfBytes, filename: fileName);
  }

  Future<void> printPdf(Uint8List pdfBytes, String name) async {
    await Printing.layoutPdf(
      name: name,
      onLayout: (_) async => pdfBytes,
    );
  }

  // ---------------- internals ----------------

  /// Slices the tall receipt image into A4-aspect chunks (top → bottom).
  List<_Chunk> _sliceForA4(Uint8List pngBytes) {
    final decoded = img.decodePng(pngBytes)!;
    final w = decoded.width;
    final chunkH = (w / a4Aspect).round();
    final chunks = <_Chunk>[];
    var y = 0;
    while (y < decoded.height) {
      final h = (y + chunkH > decoded.height) ? decoded.height - y : chunkH;
      final crop = img.copyCrop(decoded, x: 0, y: y, width: w, height: h);
      // Pad the last chunk to full A4 aspect with white.
      final page = img.Image(width: w, height: chunkH);
      img.fill(page, color: img.ColorRgb8(255, 255, 255));
      img.compositeImage(page, crop, dstY: 0);
      chunks.add(_Chunk(Uint8List.fromList(img.encodePng(page))));
      y += chunkH;
    }
    return chunks;
  }

  Future<_ThermalPage> _imagePage(Uint8List pngBytes, double widthPx,
      {double? chunkAspect}) async {
    final decoded = img.decodePng(pngBytes)!;
    // 80mm wide; height proportional, capped sensibly.
    const mmW = 80.0;
    final mmH = mmW * decoded.height / decoded.width;
    final jpeg =
        Uint8List.fromList(img.encodeJpg(decoded, quality: 95));
    return _ThermalPage(
      widget: pw.Image(pw.MemoryImage(jpeg), fit: pw.BoxFit.contain),
      heightPt: mmH * PdfPageFormat.mm + 8 * PdfPageFormat.mm,
    );
  }
}

class _Chunk {
  _Chunk(this.bytes);
  final Uint8List bytes;
}

class _ThermalPage {
  _ThermalPage({required this.widget, required this.heightPt});
  final pw.Widget widget;
  final double heightPt;
}
