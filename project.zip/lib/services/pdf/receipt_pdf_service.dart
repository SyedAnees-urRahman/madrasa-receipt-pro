import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'receipt_document.dart';
import 'widget_to_image.dart';

/// Builds the official receipt PDF.
///
/// Pipeline: [ReceiptDocumentWidget] → high-res PNG → sliced into page
/// chunks → embedded into a [pw.Document]. Vector text is deliberately
/// NOT used for Urdu (the pdf package cannot shape Nastaliq); the image
/// pipeline is what makes the Urdu correct.
class ReceiptPdfService {
  /// A4 portrait. Content width in logical px for capture.
  static const double a4WidthPx = 760;
  static const double a4Aspect = 210 / 297;

  /// 80mm thermal.
  static const double thermalWidthPx = 512;

  Future<Uint8List> buildReceiptPdf({
    required BuildContext context,
    required ReceiptDocumentData data,
  }) async {
    final thermal = data.institution.printFormat == 'thermal80';
    final widthPx = thermal ? thermalWidthPx : a4WidthPx;

    // Try the high-fidelity widget capture first; fall back to a simple
    // text PDF if off-screen rendering fails on the device.
    try {
      return await _buildImagePdf(context, data, thermal, widthPx);
    } catch (e) {
      debugPrint('Widget-capture PDF failed ($e); using text fallback');
      return _buildTextFallbackPdf(data, thermal);
    }
  }

  Future<Uint8List> _buildImagePdf(
    BuildContext context,
    ReceiptDocumentData data,
    bool thermal,
    double widthPx,
  ) async {
    // Try capture with retry; lower pixel ratio is more reliable on
    // low-memory devices.
    Uint8List? png;
    Exception? lastError;
    for (final ratio in [2.0, 1.5]) {
      try {
        png = await WidgetToImage.capturePng(
          context: context,
          widget: ReceiptDocumentWidget(data: data, width: widthPx),
          logicalWidth: widthPx,
          pixelRatio: ratio,
        );
        break;
      } catch (e) {
        lastError = e is Exception ? e : Exception(e.toString());
        debugPrint('PDF capture failed at ratio $ratio: $e');
      }
    }
    if (png == null) throw lastError ?? Exception('capture failed');

    final doc = pw.Document(
      title: 'Receipt ${data.receipt.officialNumber ?? data.receipt.localProvisionalLabel}',
      author: data.institution.nameEn,
    );

    if (thermal) {
      final page = await _imagePage(png, widthPx, chunkAspect: null);
      doc.addPage(pw.Page(
        pageFormat: PdfPageFormat(
          80 * PdfPageFormat.mm,
          page.heightPt,
          marginAll: 4 * PdfPageFormat.mm,
        ),
        build: (_) => page.widget,
      ));
    } else {
      final chunks = _sliceForA4(png);
      for (final chunk in chunks) {
        final jpeg = Uint8List.fromList(
            img.encodeJpg(img.decodePng(chunk.bytes)!, quality: 95));
        final image = pw.MemoryImage(jpeg);
        doc.addPage(pw.Page(
          pageFormat: PdfPageFormat.a4,
          build: (_) => pw.Center(
            child: pw.Image(image, fit: pw.BoxFit.contain),
          ),
        ));
      }
    }
    return doc.save();
  }

  /// Shares via the Android share sheet; also used for "save locally".
  Future<void> sharePdf(Uint8List pdfBytes, String fileName) async {
    await Printing.sharePdf(bytes: pdfBytes, filename: fileName);
  }

  Future<void> printPdf(Uint8List pdfBytes, String name) async {
    await Printing.layoutPdf(
      name: name,
      onLayout: (_) async => pdfBytes,
    );
  }

  // ---------------- internals ----------------

  /// Slices the tall receipt image into A4-aspect chunks (top → bottom).
  List<_Chunk> _sliceForA4(Uint8List pngBytes) {
    final decoded = img.decodePng(pngBytes)!;
    final w = decoded.width;
    final chunkH = (w / a4Aspect).round();
    final chunks = <_Chunk>[];
    var y = 0;
    while (y < decoded.height) {
      final h = (y + chunkH > decoded.height) ? decoded.height - y : chunkH;
      final crop = img.copyCrop(decoded, x: 0, y: y, width: w, height: h);
      // Pad the last chunk to full A4 aspect with white.
      final page = img.Image(width: w, height: chunkH);
      img.fill(page, color: img.ColorRgb8(255, 255, 255));
      img.compositeImage(page, crop, dstY: 0);
      chunks.add(_Chunk(Uint8List.fromList(img.encodePng(page))));
      y += chunkH;
    }
    return chunks;
  }

  Future<_ThermalPage> _imagePage(Uint8List pngBytes, double widthPx,
      {double? chunkAspect}) async {
    final decoded = img.decodePng(pngBytes)!;
    // 80mm wide; height proportional, capped sensibly.
    const mmW = 80.0;
    final mmH = mmW * decoded.height / decoded.width;
    final jpeg =
        Uint8List.fromList(img.encodeJpg(decoded, quality: 95));
    return _ThermalPage(
      widget: pw.Image(pw.MemoryImage(jpeg), fit: pw.BoxFit.contain),
      heightPt: mmH * PdfPageFormat.mm + 8 * PdfPageFormat.mm,
    );
  }

  /// Simple text-based fallback PDF when widget capture fails.
  /// Uses embedded Jameel Noori font for Urdu text.
  Future<Uint8List> _buildTextFallbackPdf(
      ReceiptDocumentData data, bool thermal) async {
    // Load Noto Nastaliq for Urdu text (small font = reliable embedding;
    // the 14MB Jameel Noori can fail to embed on low-memory devices).
    pw.Font? urduFont;
    try {
      final fontData = await rootBundle
          .load('assets/fonts/NotoNastaliqUrdu-Regular.ttf');
      urduFont = pw.Font.ttf(fontData);
    } catch (_) {
      // Fall back to default if font load fails
    }

    final doc = pw.Document(
      title: 'Receipt ${data.receipt.officialNumber ?? 'draft'}',
      author: data.institution.nameEn,
    );
    final r = data.receipt;
    final inst = data.institution;
    final amount = (r.totalPaisa / 100).toStringAsFixed(0);
    final useUrdu = data.locale == 'ur' || data.locale == 'bilingual';

    final titleStyle = pw.TextStyle(
      font: urduFont,
      fontSize: 20,
      fontWeight: pw.FontWeight.bold,
    );
    final labelStyle = pw.TextStyle(
      font: urduFont,
      fontSize: 13,
    );
    final valueStyle = pw.TextStyle(
      font: urduFont,
      fontSize: 13,
      fontWeight: pw.FontWeight.bold,
    );

    pw.Widget row(String labelUr, String labelEn, String value) {
      final label = useUrdu ? labelUr : labelEn;
      return pw.Directionality(
        textDirection:
            useUrdu ? pw.TextDirection.rtl : pw.TextDirection.ltr,
        child: pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text(label, style: labelStyle),
            pw.Text(value, style: valueStyle),
          ],
        ),
      );
    }

    final instName = useUrdu && inst.nameUr.isNotEmpty
        ? inst.nameUr
        : inst.nameEn;

    doc.addPage(
      pw.Page(
        pageFormat: thermal
            ? PdfPageFormat(80 * PdfPageFormat.mm, double.infinity)
            : PdfPageFormat.a4,
        build: (_) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.stretch,
          children: [
            pw.Directionality(
              textDirection:
                  useUrdu ? pw.TextDirection.rtl : pw.TextDirection.ltr,
              child: pw.Center(
                child: pw.Text(instName, style: titleStyle),
              ),
            ),
            pw.SizedBox(height: 8),
            pw.Divider(),
            row('رسید نمبر', 'Receipt No',
                r.officialNumber ?? r.localProvisionalLabel ?? '-'),
            row('تاریخ', 'Date',
                '${r.receiptDate.year}-${r.receiptDate.month}-${r.receiptDate.day}'),
            row('عطیہ دہندہ', 'Donor', r.donorNameSnapshot),
            row('رقم (روپے)', 'Amount (PKR)', amount),
            row('حیثیت', 'Status', r.status.name),
            pw.SizedBox(height: 12),
            pw.Directionality(
              textDirection:
                  useUrdu ? pw.TextDirection.rtl : pw.TextDirection.ltr,
              child: pw.Text(
                useUrdu ? 'فنڈ کی تقسیم:' : 'Fund allocation:',
                style: pw.TextStyle(
                    font: urduFont,
                    fontSize: 14,
                    fontWeight: pw.FontWeight.bold),
              ),
            ),
            for (final a in data.allocations)
              row('', '', '${a.fundUr.isNotEmpty ? a.fundUr : a.fundEn}: ${(a.amountPaisa / 100).toStringAsFixed(0)}'),
            pw.SizedBox(height: 12),
            pw.Divider(),
            pw.Directionality(
              textDirection:
                  useUrdu ? pw.TextDirection.rtl : pw.TextDirection.ltr,
              child: pw.Center(
                child: pw.Text(
                  useUrdu
                      ? 'اللہ تعالیٰ آپ کا عطیہ قبول فرمائے'
                      : 'Thank you',
                  style: pw.TextStyle(font: urduFont, fontSize: 13),
                ),
              ),
            ),
          ],
        ),
      ),
    );
    return doc.save();
  }
}

class _Chunk {
  _Chunk(this.bytes);
  final Uint8List bytes;
}

class _ThermalPage {
  _ThermalPage({required this.widget, required this.heightPt});
  final pw.Widget widget;
  final double heightPt;
}
