import 'dart:async';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

/// Renders an arbitrary widget off-screen to a high-resolution image.
///
/// Used for receipts: Flutter's text engine shapes Urdu Nastaliq correctly,
/// so capturing the laid-out widget guarantees the PDF matches the screen.
class WidgetToImage {
  /// Captures [widget] at [logicalWidth] logical pixels wide; height is
  /// intrinsic to the content. Returns PNG bytes.
  static Future<Uint8List> capturePng({
    required BuildContext context,
    required Widget widget,
    required double logicalWidth,
    double pixelRatio = 3.0,
    Duration timeout = const Duration(seconds: 15),
  }) async {
    final image = await capture(
      context: context,
      widget: widget,
      logicalWidth: logicalWidth,
      pixelRatio: pixelRatio,
      timeout: timeout,
    );
    final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
    if (byteData == null) {
      throw StateError('Failed to encode captured widget as PNG');
    }
    return byteData.buffer.asUint8List();
  }

  static Future<ui.Image> capture({
    required BuildContext context,
    required Widget widget,
    required double logicalWidth,
    double pixelRatio = 3.0,
    Duration timeout = const Duration(seconds: 15),
  }) async {
    final boundaryKey = GlobalKey();
    final completer = Completer<ui.Image>();
    late final OverlayEntry entry;

    entry = OverlayEntry(
      builder: (_) => Stack(
        children: [
          Positioned(
            // On-screen origin but invisible: extreme negative offsets
            // break rasterization on some GPUs (Impeller). Ancestor
            // opacity does not affect RepaintBoundary.toImage output.
            left: 0,
            top: 0,
            child: IgnorePointer(
              child: Opacity(
                opacity: 0,
                child: UnconstrainedBox(
                  constrainedAxis: Axis.vertical,
                  child: RepaintBoundary(
                    key: boundaryKey,
                    child: SizedBox(
                      width: logicalWidth,
                      child: MediaQuery(
                        // Deterministic rendering: ignore the host's text scale.
                        data: MediaQuery.of(context)
                            .copyWith(textScaler: TextScaler.noScaling),
                        child: Directionality(
                          textDirection: TextDirection.ltr,
                          child: widget,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );

    Overlay.of(context).insert(entry);
    try {
      // Let layout + paint settle (fonts, QR, images).
      await Future.delayed(const Duration(milliseconds: 400));
      await WidgetsBinding.instance.endOfFrame;

      final boundary = boundaryKey.currentContext?.findRenderObject()
          as RenderRepaintBoundary?;
      if (boundary == null) {
        throw StateError('Receipt widget did not lay out');
      }
      if (boundary.debugNeedsPaint) {
        await Future.delayed(const Duration(milliseconds: 300));
      }
      final image = await boundary
          .toImage(pixelRatio: pixelRatio)
          .timeout(timeout);
      completer.complete(image);
    } catch (e) {
      completer.completeError(e);
    } finally {
      entry.remove();
    }
    return completer.future;
  }
}
