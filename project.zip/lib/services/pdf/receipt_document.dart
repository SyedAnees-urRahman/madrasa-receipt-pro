import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/utils/amount_words.dart';
import '../../../core/utils/dates.dart';
import '../../../core/utils/money.dart';
import '../../../domain/entities/entities.dart';
import '../../../domain/entities/enums.dart';

/// All data the receipt renderer needs — no database access inside the widget.
class ReceiptDocumentData {
  const ReceiptDocumentData({
    required this.institution,
    required this.receipt,
    required this.allocations, // (fundNameUr, fundNameEn, purposeNameUr?, amountPaisa)
    required this.qrPayload,
    required this.locale, // 'ur' | 'en' | 'bilingual'
    this.isDuplicate = false,
    this.logoFile,
    this.qrImageBytes,
  });
  final Institution institution;
  final Receipt receipt;
  final List<AllocationLine> allocations;
  final String qrPayload;
  final String locale;
  final bool isDuplicate;
  final File? logoFile;
  final Uint8List? qrImageBytes;
}

/// Pre-renders QR payload to PNG bytes (avoids QrImageView widget
/// rendering issues during off-screen capture).
Future<Uint8List?> renderQrPng(String payload, {double size = 276}) async {
  try {
    final qrValidationResult = QrValidator.validate(
      data: payload,
      version: QrVersions.auto,
      errorCorrectionLevel: QrErrorCorrectLevel.M,
    );
    if (qrValidationResult.status != QrValidationStatus.valid) return null;
    final painter = QrPainter.withQr(
      qr: qrValidationResult.qrCode!,
      color: const Color(0xFF000000),
      emptyColor: const Color(0xFFFFFFFF),
      gapless: true,
    );
    final picData = await painter.toImageData(size);
    return picData?.buffer.asUint8List();
  } catch (_) {
    return null;
  }
}

class AllocationLine {
  const AllocationLine({
    required this.fundUr,
    required this.fundEn,
    this.purposeUr,
    this.purposeEn,
    required this.amountPaisa,
  });
  final String fundUr;
  final String fundEn;
  final String? purposeUr;
  final String? purposeEn;
  final int amountPaisa;
}

/// The official receipt, laid out as a Flutter widget.
///
/// WHY A WIDGET (not pdf-package vector text): the Dart `pdf` package has
/// no complex-script shaping engine — Urdu Nastaliq drawn as vector text
/// comes out disconnected or as tofu. Flutter's own text engine shapes
/// Nastaliq correctly, so the receipt is rendered as a widget, captured
/// to a high-resolution image, and embedded into the PDF. The PDF therefore
/// looks EXACTLY like the on-screen receipt — verified by inspecting the
/// rendered output (see test/widget/receipt_pdf_test.dart).
class ReceiptDocumentWidget extends StatelessWidget {
  const ReceiptDocumentWidget({super.key, required this.data, required this.width});
  final ReceiptDocumentData data;
  final double width;

  bool get _ur => data.locale == 'ur' || data.locale == 'bilingual';
  bool get _en => data.locale == 'en' || data.locale == 'bilingual';

  /// Thermal (narrow) receipts need larger text to stay readable.
  /// A4 width = 760, thermal = 512 → scale up ~1.35x on thermal.
  double get _ts => width < 600 ? 1.35 : 1.0;

  @override
  Widget build(BuildContext context) {
    final r = data.receipt;
    final inst = data.institution;
    return Container(
      width: width,
      color: Colors.white,
      padding: const EdgeInsets.all(36),
      child: Directionality(
        textDirection: _ur ? TextDirection.rtl : TextDirection.ltr,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            _header(inst),
            const SizedBox(height: 12),
            Container(height: 3, color: AppColors.gold500),
            const SizedBox(height: 4),
            Container(height: 1.5, color: AppColors.emerald700),
            const SizedBox(height: 16),
            if (r.isProvisional) _banner(data.locale == 'en'
                ? 'PROVISIONAL — NOT AN OFFICIAL RECEIPT'
                : 'عارضی رسید — یہ سرکاری رسید نہیں ہے'),
            if (data.isDuplicate) _banner(data.locale == 'en'
                ? 'DUPLICATE COPY'
                : 'نقل — ڈپلیکیٹ کاپی'),
            _metaRow(r),
            const SizedBox(height: 12),
            _donorBlock(r),
            const SizedBox(height: 12),
            _amountBlock(r),
            const SizedBox(height: 12),
            _allocationTable(),
            const SizedBox(height: 12),
            _paymentBlock(r),
            if ((r.donorNote ?? '').isNotEmpty) ...[
              const SizedBox(height: 8),
              _noteBlock(r.donorNote!),
            ],
            const SizedBox(height: 20),
            _signatoryRow(),
            const SizedBox(height: 16),
            _thankYou(),
            const SizedBox(height: 12),
            _qrBlock(r),
            const SizedBox(height: 8),
            _footer(),
          ],
        ),
      ),
    );
  }

  Widget _header(Institution inst) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        if (data.logoFile != null && data.logoFile!.existsSync())
          Container(
            width: 76,
            height: 76,
            decoration: BoxDecoration(
              border: Border.all(color: AppColors.gold500, width: 2),
              borderRadius: BorderRadius.circular(12),
            ),
            clipBehavior: Clip.antiAlias,
            child: Image.file(data.logoFile!, fit: BoxFit.cover),
          )
        else
          Container(
            width: 76,
            height: 76,
            decoration: BoxDecoration(
              color: AppColors.emerald800,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.gold500, width: 2),
            ),
            child: const Icon(Icons.mosque, color: Colors.white, size: 40),
          ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment:
                _ur ? CrossAxisAlignment.end : CrossAxisAlignment.start,
            children: [
              if (_ur)
                Text(inst.nameUr,
                    style: AppTypography.titleUr
                        .copyWith(color: AppColors.emerald900, fontSize: 24 * _ts),
                    textAlign: TextAlign.right),
              if (_en)
                Text(inst.nameEn,
                    style: AppTypography.titleEn
                        .copyWith(color: AppColors.emerald900),
                    textAlign: _ur ? TextAlign.right : TextAlign.left),
              if ((inst.address ?? '').isNotEmpty)
                Text(inst.address!,
                    style: _ur
                        ? AppTypography.captionUr
                        : AppTypography.captionEn),
              if ((inst.phone ?? '').isNotEmpty)
                Text(inst.phone!,
                    style: AppTypography.captionEn,
                    textDirection: TextDirection.ltr),
            ],
          ),
        ),
      ],
    );
  }

  Widget _banner(String text) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
      decoration: BoxDecoration(
        color: AppColors.warningBg,
        border: Border.all(color: AppColors.warning, width: 1.5),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: (_ur ? AppTypography.bodyUr : AppTypography.bodyEn).copyWith(
          color: AppColors.warning,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  Widget _metaRow(Receipt r) {
    final num = r.officialNumber ?? r.localProvisionalLabel ?? r.id;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.emerald50,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.emerald100),
      ),
      child: Column(
        children: [
          _kv(_ur ? 'رسید نمبر' : 'Receipt No.',
              num, AppTypography.amount.copyWith(fontSize: 17 * _ts)),
          const SizedBox(height: 6),
          _kv(_ur ? 'تاریخ' : 'Date',
              Dates.date(r.receiptDate, _ur ? 'ur' : 'en'), null),
          const SizedBox(height: 6),
          _kv(
              _ur ? 'حیثیت' : 'Status',
              _ur ? _statusUr(r.status) : r.status.name,
              TextStyle(
                  fontWeight: FontWeight.w700,
                  color: r.status == ReceiptStatus.confirmed
                      ? AppColors.success
                      : AppColors.warning)),
        ],
      ),
    );
  }

  String _statusUr(ReceiptStatus s) => switch (s) {
        ReceiptStatus.draft => 'مسودہ',
        ReceiptStatus.pendingVerification => 'تصدیق منتظر',
        ReceiptStatus.confirmed => 'مصدقہ وصول شدہ',
        ReceiptStatus.voided => 'منسوخ',
        ReceiptStatus.reversed => 'واپس شدہ',
      };

  Widget _kv(String label, String value, TextStyle? valueStyle,
      {TextDirection? valueDirection}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 110,
          child: Text(label,
              style: (_ur ? AppTypography.captionUr : AppTypography.captionEn)
                  .copyWith(fontWeight: FontWeight.w600)),
        ),
        Expanded(
          child: Text(value,
              textDirection: valueDirection,
              style: valueStyle ??
                  (_ur ? AppTypography.bodyUr : AppTypography.bodyEn)),
        ),
      ],
    );
  }

  Widget _donorBlock(Receipt r) {
    final name = r.isAnonymous
        ? (_ur ? 'گمنام عطیہ دہندہ' : 'Anonymous donor')
        : r.donorNameSnapshot;
    return _kv(_ur ? 'عطیہ دہندہ' : 'Donor', name,
        (_ur ? AppTypography.bodyUr : AppTypography.bodyEn)
            .copyWith(fontWeight: FontWeight.w700, fontSize: 17 * _ts));
  }

  Widget _amountBlock(Receipt r) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.gold500, width: 1.5),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(Money.formatPkr(r.totalPaisa),
              textAlign: TextAlign.center,
              style: AppTypography.amountLarge,
              textDirection: TextDirection.ltr),
          const SizedBox(height: 6),
          if (_ur)
            Text(AmountWords.urdu(r.totalPaisa),
                textAlign: TextAlign.center, style: AppTypography.bodyUr),
          if (_en)
            Text(AmountWords.english(r.totalPaisa),
                textAlign: TextAlign.center,
                style: AppTypography.bodyEn
                    .copyWith(fontStyle: FontStyle.italic)),
        ],
      ),
    );
  }

  Widget _allocationTable() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(_ur ? 'فنڈ کی تقسیم' : 'Fund allocation',
            style: (_ur ? AppTypography.titleUr : AppTypography.titleEn)
                .copyWith(fontSize: 16 * _ts, color: AppColors.emerald900)),
        const SizedBox(height: 6),
        Table(
          border: TableBorder.all(color: AppColors.cardBorder),
          columnWidths: const {
            0: FlexColumnWidth(3),
            1: FlexColumnWidth(3),
            2: FlexColumnWidth(2),
          },
          children: [
            TableRow(
              decoration:
                  const BoxDecoration(color: AppColors.emerald800),
              children: [
                _cell(_ur ? 'فنڈ' : 'Fund', header: true),
                _cell(_ur ? 'مصرف' : 'Purpose', header: true),
                _cell(_ur ? 'رقم' : 'Amount', header: true),
              ],
            ),
            for (final a in data.allocations)
              TableRow(
                children: [
                  _cell(_ur ? a.fundUr : a.fundEn),
                  _cell(_ur
                      ? (a.purposeUr ?? '—')
                      : (a.purposeEn ?? '—')),
                  _cell(Money.formatPkr(a.amountPaisa, symbol: false),
                      ltr: true),
                ],
              ),
            TableRow(
              decoration:
                  const BoxDecoration(color: AppColors.emerald50),
              children: [
                _cell(_ur ? 'کل' : 'Total', header: true),
                _cell(''),
                _cell(
                    Money.formatPkr(data.receipt.totalPaisa, symbol: false),
                    header: true,
                    ltr: true),
              ],
            ),
          ],
        ),
      ],
    );
  }

  Widget _cell(String text, {bool header = false, bool ltr = false}) {
    final base = _ur ? AppTypography.bodyUr : AppTypography.bodyEn;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
      child: Text(
        text,
        textDirection: ltr ? TextDirection.ltr : null,
        textAlign: ltr ? TextAlign.right : TextAlign.start,
        style: base.copyWith(
          fontSize: 14 * _ts,
          fontWeight: header ? FontWeight.w700 : FontWeight.normal,
          color: header ? Colors.white : AppColors.ink900,
        ),
      ),
    );
  }

  Widget _paymentBlock(Receipt r) {
    return Column(
      children: [
        _kv(_ur ? 'طریقۂ ادائیگی' : 'Payment method',
            _ur ? _methodUr(r.paymentMethod) : r.paymentMethod.name, null),
        if ((r.referenceNo ?? '').isNotEmpty) ...[
          const SizedBox(height: 6),
          _kv(_ur ? 'حوالہ' : 'Reference', r.referenceNo!,
              null, valueDirection: TextDirection.ltr),
        ],
      ],
    );
  }

  String _methodUr(PaymentMethod m) => switch (m) {
        PaymentMethod.cash => 'نقد',
        PaymentMethod.bankTransfer => 'بینک ٹرانسفر',
        PaymentMethod.cheque => 'چیک',
        PaymentMethod.wallet => 'موبائل والٹ',
      };

  Widget _noteBlock(String note) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.ivoryDeep,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(note,
          style: _ur ? AppTypography.bodyUr : AppTypography.bodyEn),
    );
  }

  Widget _signatoryRow() {
    Widget box(String label) => Expanded(
          child: Column(
            children: [
              Container(height: 64),
              Container(height: 1.5, color: AppColors.ink500),
              const SizedBox(height: 4),
              Text(label,
                  style:
                      _ur ? AppTypography.captionUr : AppTypography.captionEn),
            ],
          ),
        );
    return Row(
      children: [
        box(_ur ? 'مجاز دستخط' : 'Authorized signature'),
        const SizedBox(width: 32),
        box(_ur ? 'مہر' : 'Stamp'),
      ],
    );
  }

  Widget _thankYou() {
    return Text(
      _ur
          ? 'اللہ تعالیٰ آپ کا عطیہ قبول فرمائے اور اجرِ عظیم عطا فرمائے۔'
          : 'May Allah accept your donation and reward you abundantly.',
      textAlign: TextAlign.center,
      style: (_ur ? AppTypography.bodyUr : AppTypography.bodyEn).copyWith(
        color: AppColors.emerald800,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget _qrBlock(Receipt r) {
    // Use pre-rendered QR image (robust) instead of QrImageView widget.
    final qrBytes = data.qrImageBytes;
    final qrSize = 92.0 * _ts;
    final Widget qr = qrBytes != null
        ? Image.memory(qrBytes, width: qrSize, height: qrSize)
        : Container(
            width: qrSize,
            height: qrSize,
            color: Colors.grey.shade200,
            child: const Icon(Icons.qr_code, size: 48),
          );
    return Row(
      children: [
        qr,
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            _ur
                ? 'تصدیق کے لیے اسکین کریں۔ یہ کوڈ صرف رسید نمبر، تاریخ، رقم اور حیثیت ظاہر کرتا ہے — ذاتی معلومات نہیں۔'
                : 'Scan to verify. This code reveals only the receipt number, date, amount and status — no personal data.',
            style: _ur ? AppTypography.captionUr : AppTypography.captionEn,
          ),
        ),
      ],
    );
  }

  Widget _footer() {
    return Column(
      children: [
        Container(height: 1, color: AppColors.cardBorder),
        const SizedBox(height: 6),
        Text(
          _ur
              ? 'یہ کمپیوٹر سے تیار کردہ رسید ہے۔'
              : 'This is a computer-generated receipt.',
          textAlign: TextAlign.center,
          style: _ur ? AppTypography.captionUr : AppTypography.captionEn,
        ),
      ],
    );
  }
}
