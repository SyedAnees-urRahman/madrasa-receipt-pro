import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:uuid/uuid.dart';
import '../../core/config/app_config.dart';
import '../../domain/entities/entities.dart';

/// Receipt QR verification payloads.
///
/// The QR reveals ONLY: receipt id, official number (or provisional label),
/// date, amount, status — signed with HMAC-SHA256 so a verification page
/// can detect forgery. It NEVER contains donor phone/email/address,
/// staff notes, bank details, or evidence references.
///
/// Payload: `MRP1:<receiptId>:<totalPaisa>:<officialNumber|->:<hmac16>`
/// where hmac16 = first 16 hex chars of
///   HMAC_SHA256(key=institutionSecret, msg="<receiptId>|<totalPaisa>|<officialNumber|->").
/// Minimal secret storage abstraction so the service is unit-testable
/// without platform channels.
abstract class SecretStore {
  Future<String?> read(String key);
  Future<void> write(String key, String value);
}

class SecureSecretStore implements SecretStore {
  SecureSecretStore({FlutterSecureStorage? storage})
      : _storage = storage ?? const FlutterSecureStorage();
  final FlutterSecureStorage _storage;
  @override
  Future<String?> read(String key) => _storage.read(key: key);
  @override
  Future<void> write(String key, String value) =>
      _storage.write(key: key, value: value);
}

class QrVerificationService {
  QrVerificationService({SecretStore? store})
      : _store = store ?? SecureSecretStore();

  final SecretStore _store;
  static const _keyName = 'mrp_institution_secret';

  /// Per-installation secret, generated once at setup, kept in the
  /// Android Keystore via flutter_secure_storage. Never synced, never logged.
  Future<String> _secret(String institutionId) async {
    final name = '${_keyName}_$institutionId';
    var secret = await _store.read(name);
    if (secret == null) {
      secret = const Uuid().v4() + const Uuid().v4();
      await _store.write(name, secret);
    }
    return secret;
  }

  Future<String> buildPayload({
    required Receipt receipt,
    required String institutionId,
  }) async {
    final number = receipt.officialNumber ?? '-';
    final msg = '${receipt.id}|${receipt.totalPaisa}|$number';
    final secret = await _secret(institutionId);
    final hmac = Hmac(sha256, utf8.encode(secret));
    final digest = hmac.convert(utf8.encode(msg)).toString();
    final short = digest.substring(0, AppConfig.qrHmacHexLength);
    return 'MRP1:${receipt.id}:${receipt.totalPaisa}:$number:$short';
  }

  /// Server-side (or verifier-app) check. Returns the parsed fields when
  /// the signature is valid, null otherwise.
  Future<QrPayload?> verifyPayload(String payload, String institutionId) async {
    final parts = payload.split(':');
    if (parts.length != 5 || parts[0] != 'MRP1') return null;
    final rebuilt =
        'MRP1:${parts[1]}:${parts[2]}:${parts[3]}:${parts[4]}';
    if (rebuilt != payload) return null;
    final msg = '${parts[1]}|${parts[2]}|${parts[3]}';
    final secret = await _secret(institutionId);
    final hmac = Hmac(sha256, utf8.encode(secret));
    final digest = hmac.convert(utf8.encode(msg)).toString();
    if (digest.substring(0, AppConfig.qrHmacHexLength) != parts[4]) {
      return null;
    }
    return QrPayload(
      receiptId: parts[1],
      totalPaisa: int.tryParse(parts[2]) ?? 0,
      officialNumber: parts[3] == '-' ? null : parts[3],
    );
  }

  /// Public verification URL (for the printed "verify online" hint).
  /// The verification page itself is a separate server deployment and
  /// must only expose the minimal fields documented above.
  String verificationUrl(String payload) =>
      '${AppConfig.verifyBaseUrl}/r/${Uri.encodeComponent(payload)}';
}

class QrPayload {
  const QrPayload({
    required this.receiptId,
    required this.totalPaisa,
    this.officialNumber,
  });
  final String receiptId;
  final int totalPaisa;
  final String? officialNumber;
}
