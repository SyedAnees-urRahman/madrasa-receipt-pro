import 'package:drift/drift.dart';
import '../../../domain/entities/enums.dart';

/// Local SQLite schema (Drift). PostgreSQL mirror lives in
/// supabase/migrations/. Money = INTEGER paisa, never REAL.
/// All tables use UUID TEXT primary keys for offline-first identity.
class Institutions extends Table {
  TextColumn get id => text()();
  TextColumn get nameUr => text()();
  TextColumn get nameEn => text()();
  TextColumn get logoPath => text().nullable()();
  TextColumn get address => text().nullable()();
  TextColumn get phone => text().nullable()();
  TextColumn get email => text().nullable()();
  TextColumn get registrationNo => text().nullable()();
  TextColumn get ntn => text().nullable()();
  IntColumn get fyStartMonth => integer().withDefault(const Constant(7))();
  IntColumn get fyStartDay => integer().withDefault(const Constant(1))();
  TextColumn get receiptPrefix => text().withDefault(const Constant('MD'))();
  TextColumn get numberingFormat =>
      text().withDefault(const Constant('{prefix}-{yyyy}-{seq:06d}'))();
  TextColumn get receiptLanguage => text().withDefault(const Constant('bilingual'))();
  TextColumn get printFormat => text().withDefault(const Constant('a4'))();
  TextColumn get acceptedMethodsJson => text().withDefault(const Constant('["cash"]'))();
  TextColumn get signatoriesJson => text().nullable()();
  IntColumn get dualApprovalThresholdPaisa =>
      integer().withDefault(const Constant(10000000))(); // 100,000 PKR
  BoolColumn get autoSync => boolean().withDefault(const Constant(true))();
  BoolColumn get isDemo => boolean().withDefault(const Constant(false))();
  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get updatedAt => dateTime()();
  // Sync bookkeeping
  DateTimeColumn get serverUpdatedAt => dateTime().nullable()();
  BoolColumn get isDirty => boolean().withDefault(const Constant(false))();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'institutions';
}

class UserProfiles extends Table {
  TextColumn get id => text()(); // == auth user id
  TextColumn get institutionId => text().references(Institutions, #id)();
  TextColumn get displayName => text()();
  TextColumn get email => text()();
  TextColumn get role => textEnum<UserRole>()();
  TextColumn get pinHash => text().nullable()(); // SHA-256 of PIN, for offline login
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get serverUpdatedAt => dateTime().nullable()();
  BoolColumn get isDirty => boolean().withDefault(const Constant(false))();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'user_profiles';
}

@TableIndex(name: 'idx_donors_institution_name', columns: {#institutionId, #name})
class Donors extends Table {
  TextColumn get id => text()();
  TextColumn get institutionId => text().references(Institutions, #id)();
  TextColumn get name => text()();
  TextColumn get phone => text().nullable()();
  TextColumn get email => text().nullable()();
  TextColumn get address => text().nullable()();
  TextColumn get notes => text().nullable()();
  TextColumn get createdBy => text().nullable()();
  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get updatedAt => dateTime()();
  DateTimeColumn get serverUpdatedAt => dateTime().nullable()();
  BoolColumn get isDirty => boolean().withDefault(const Constant(false))();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'donors';
}

class FundTypes extends Table {
  TextColumn get id => text()();
  TextColumn get institutionId => text().references(Institutions, #id)();
  TextColumn get code => text()();
  TextColumn get nameUr => text()();
  TextColumn get nameEn => text()();
  TextColumn get category => textEnum<FundCategory>()();
  BoolColumn get isRestricted => boolean().withDefault(const Constant(false))();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  IntColumn get openingBalancePaisa => integer().withDefault(const Constant(0))();
  IntColumn get sortOrder => integer().withDefault(const Constant(0))();
  DateTimeColumn get serverUpdatedAt => dateTime().nullable()();
  BoolColumn get isDirty => boolean().withDefault(const Constant(false))();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'fund_types';
  @override
  List<String> get customConstraints => [
        'UNIQUE (institution_id, code)',
      ];
}

class Purposes extends Table {
  TextColumn get id => text()();
  TextColumn get institutionId => text().references(Institutions, #id)();
  TextColumn get nameUr => text()();
  TextColumn get nameEn => text()();
  TextColumn get description => text().nullable()();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get serverUpdatedAt => dateTime().nullable()();
  BoolColumn get isDirty => boolean().withDefault(const Constant(false))();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'purposes';
}

class BankAccounts extends Table {
  TextColumn get id => text()();
  TextColumn get institutionId => text().references(Institutions, #id)();
  TextColumn get type => textEnum<AccountType>()();
  TextColumn get title => text()();
  TextColumn get bankName => text().nullable()();
  TextColumn get accountNoMasked => text().nullable()();
  IntColumn get openingBalancePaisa => integer().withDefault(const Constant(0))();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get serverUpdatedAt => dateTime().nullable()();
  BoolColumn get isDirty => boolean().withDefault(const Constant(false))();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'bank_accounts';
}

@TableIndex(name: 'idx_receipts_institution_date', columns: {#institutionId, #receiptDate})
@TableIndex(name: 'idx_receipts_status', columns: {#institutionId, #status})
@TableIndex(name: 'idx_receipts_idempotency', columns: {#idempotencyKey})
class Receipts extends Table {
  TextColumn get id => text()();
  TextColumn get institutionId => text().references(Institutions, #id)();
  /// Assigned ONLY by the trusted server. NULL = provisional/offline.
  TextColumn get officialNumber => text().nullable().unique()();
  TextColumn get localProvisionalLabel => text().nullable()();
  TextColumn get status => textEnum<ReceiptStatus>()();
  TextColumn get txType => textEnum<TxType>()();
  TextColumn get donorId => text().nullable().references(Donors, #id)();
  TextColumn get donorNameSnapshot => text()();
  BoolColumn get isAnonymous => boolean().withDefault(const Constant(false))();
  IntColumn get totalPaisa => integer()();
  DateTimeColumn get receiptDate => dateTime()();
  TextColumn get paymentMethod => textEnum<PaymentMethod>()();
  TextColumn get bankAccountId => text().nullable().references(BankAccounts, #id)();
  TextColumn get referenceNo => text().nullable()();
  TextColumn get evidencePath => text().nullable()();
  TextColumn get staffNotes => text().nullable()();
  TextColumn get donorNote => text().nullable()();
  TextColumn get createdBy => text().nullable()();
  TextColumn get verifiedBy => text().nullable()();
  DateTimeColumn get verifiedAt => dateTime().nullable()();
  TextColumn get voidReason => text().nullable()();
  TextColumn get replacedById => text().nullable()();
  TextColumn get reversesId => text().nullable()();
  TextColumn get idempotencyKey => text().unique()();
  BoolColumn get serverAck => boolean().withDefault(const Constant(false))();
  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get updatedAt => dateTime()();
  DateTimeColumn get serverUpdatedAt => dateTime().nullable()();
  BoolColumn get isDirty => boolean().withDefault(const Constant(false))();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'receipts';
  @override
  List<String> get customConstraints => [
        'CHECK (total_paisa > 0)',
        // A voided or reversed receipt must carry a reason.
        'CHECK (status NOT IN (\'voided\', \'reversed\') OR void_reason IS NOT NULL)',
      ];
}

class ReceiptAllocations extends Table {
  TextColumn get id => text()();
  TextColumn get receiptId => text().references(Receipts, #id, onDelete: KeyAction.cascade)();
  TextColumn get fundTypeId => text().references(FundTypes, #id)();
  TextColumn get purposeId => text().nullable().references(Purposes, #id)();
  IntColumn get amountPaisa => integer()();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'receipt_allocations';
  @override
  List<String> get customConstraints => [
        'CHECK (amount_paisa > 0)',
      ];
}

class PaymentVerifications extends Table {
  TextColumn get id => text()();
  TextColumn get receiptId => text().references(Receipts, #id, onDelete: KeyAction.cascade)();
  TextColumn get verifiedBy => text()();
  DateTimeColumn get verifiedAt => dateTime()();
  TextColumn get evidenceSummary => text()();
  TextColumn get note => text().nullable()();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'payment_verifications';
}

/// Local mirror of the server-side sequence (informational only).
class ReceiptSequences extends Table {
  TextColumn get id => text()();
  TextColumn get institutionId => text().references(Institutions, #id)();
  TextColumn get prefix => text()();
  IntColumn get year => integer()();
  IntColumn get lastNumber => integer().withDefault(const Constant(0))();
  DateTimeColumn get updatedAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'receipt_sequences';
  @override
  List<String> get customConstraints => [
        'UNIQUE (institution_id, prefix, year)',
      ];
}

@TableIndex(name: 'idx_expenses_institution_date', columns: {#institutionId, #voucherDate})
class ExpenseVouchers extends Table {
  TextColumn get id => text()();
  TextColumn get institutionId => text().references(Institutions, #id)();
  TextColumn get voucherNumber => text()();
  DateTimeColumn get voucherDate => dateTime()();
  TextColumn get payee => text()();
  TextColumn get description => text()();
  IntColumn get totalPaisa => integer()();
  TextColumn get paymentMethod => textEnum<PaymentMethod>()();
  TextColumn get bankAccountId => text().nullable().references(BankAccounts, #id)();
  TextColumn get attachmentPath => text().nullable()();
  TextColumn get status => textEnum<ExpenseStatus>()();
  TextColumn get createdBy => text().nullable()();
  TextColumn get approvedBy => text().nullable()();
  DateTimeColumn get approvedAt => dateTime().nullable()();
  TextColumn get rejectionReason => text().nullable()();
  TextColumn get idempotencyKey => text().unique()();
  BoolColumn get serverAck => boolean().withDefault(const Constant(false))();
  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get updatedAt => dateTime()();
  DateTimeColumn get serverUpdatedAt => dateTime().nullable()();
  BoolColumn get isDirty => boolean().withDefault(const Constant(false))();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'expense_vouchers';
  @override
  List<String> get customConstraints => [
        'CHECK (total_paisa > 0)',
        'UNIQUE (institution_id, voucher_number)',
        // Approval bookkeeping: an approved voucher names its approver.
        'CHECK (status NOT IN (\'approved\', \'paid\') OR approved_by IS NOT NULL)',
      ];
}

class ExpenseAllocations extends Table {
  TextColumn get id => text()();
  TextColumn get voucherId =>
      text().references(ExpenseVouchers, #id, onDelete: KeyAction.cascade)();
  TextColumn get fundTypeId => text().references(FundTypes, #id)();
  TextColumn get purposeId => text().nullable().references(Purposes, #id)();
  IntColumn get amountPaisa => integer()();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'expense_allocations';
  @override
  List<String> get customConstraints => [
        'CHECK (amount_paisa > 0)',
      ];
}

@TableIndex(name: 'idx_approvals_entity', columns: {#entityType, #entityId})
class Approvals extends Table {
  TextColumn get id => text()();
  TextColumn get institutionId => text().references(Institutions, #id)();
  TextColumn get entityType => text()(); // 'receipt' | 'expense'
  TextColumn get entityId => text()();
  TextColumn get action => text()(); // 'verify' | 'approve' | 'pay' ...
  TextColumn get decision => textEnum<ApprovalDecision>()();
  TextColumn get actorId => text()();
  DateTimeColumn get decidedAt => dateTime()();
  TextColumn get reason => text().nullable()();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'approvals';
}

class Reconciliations extends Table {
  TextColumn get id => text()();
  TextColumn get institutionId => text().references(Institutions, #id)();
  TextColumn get bankAccountId => text().references(BankAccounts, #id)();
  DateTimeColumn get statementDate => dateTime()();
  IntColumn get statementBalancePaisa => integer()();
  IntColumn get bookBalancePaisa => integer()();
  IntColumn get differencePaisa => integer()();
  TextColumn get status => text().withDefault(const Constant('open'))();
  TextColumn get createdBy => text().nullable()();
  TextColumn get notes => text().nullable()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'reconciliations';
}

class EvidenceFiles extends Table {
  TextColumn get id => text()();
  TextColumn get institutionId => text().references(Institutions, #id)();
  TextColumn get entityType => text()();
  TextColumn get entityId => text()();
  TextColumn get localPath => text().nullable()();
  TextColumn get remotePath => text().nullable()();
  TextColumn get mime => text()();
  IntColumn get sizeBytes => integer()();
  TextColumn get sha256 => text().nullable()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'evidence_files';
  @override
  List<String> get customConstraints => [
        'CHECK (size_bytes <= 10485760)',
      ];
}

/// Append-only audit log. The DAO exposes insert + select only —
/// there is deliberately NO update or delete API.
@TableIndex(name: 'idx_audit_entity', columns: {#institutionId, #entityType, #entityId})
@TableIndex(name: 'idx_audit_time', columns: {#institutionId, #occurredAt})
class AuditEvents extends Table {
  TextColumn get id => text()();
  TextColumn get institutionId => text().references(Institutions, #id)();
  // Monotonic per-institution sequence: the chain's canonical order.
  // Timestamps alone are NOT a safe order (two events can share a ms).
  IntColumn get sequence => integer()();
  TextColumn get entityType => text()();
  TextColumn get entityId => text()();
  TextColumn get action => text()();
  TextColumn get actorId => text()();
  DateTimeColumn get occurredAt => dateTime()();
  TextColumn get reason => text().nullable()();
  TextColumn get beforeJson => text().nullable()();
  TextColumn get afterJson => text().nullable()();
  TextColumn get prevHash => text()();
  TextColumn get hash => text()();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'audit_events';
  @override
  List<Set<Column>> get uniqueKeys => [
        {institutionId, sequence},
      ];
}

class Devices extends Table {
  TextColumn get id => text()();
  TextColumn get institutionId => text().references(Institutions, #id)();
  TextColumn get deviceName => text()();
  TextColumn get platform => text()();
  TextColumn get appVersion => text()();
  TextColumn get registeredBy => text().nullable()();
  DateTimeColumn get registeredAt => dateTime()();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  IntColumn get rangeStart => integer().nullable()();
  IntColumn get rangeEnd => integer().nullable()();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'devices';
}

/// Durable sync queue. A row is written in the SAME transaction as the
/// local mutation it describes; it is deleted only after the server
/// acknowledges and the resulting state is committed locally.
@TableIndex(name: 'idx_outbox_status', columns: {#status, #nextRetryAt})
class SyncOutbox extends Table {
  TextColumn get id => text()();
  TextColumn get institutionId => text()();
  TextColumn get entityType => text()();
  TextColumn get entityId => text()();
  TextColumn get operation => textEnum<OutboxOperation>()();
  TextColumn get payloadJson => text()();
  TextColumn get idempotencyKey => text().unique()();
  IntColumn get attempts => integer().withDefault(const Constant(0))();
  DateTimeColumn get nextRetryAt => dateTime()();
  TextColumn get status => textEnum<SyncStatus>()();
  TextColumn get lastError => text().nullable()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'sync_outbox';
}

@TableIndex(name: 'idx_conflicts_status', columns: {#status})
class SyncConflicts extends Table {
  TextColumn get id => text()();
  TextColumn get institutionId => text()();
  TextColumn get entityType => text()();
  TextColumn get entityId => text()();
  TextColumn get localJson => text()();
  TextColumn get remoteJson => text()();
  DateTimeColumn get detectedAt => dateTime()();
  TextColumn get status => text().withDefault(const Constant('open'))();
  TextColumn get resolvedBy => text().nullable()();
  DateTimeColumn get resolvedAt => dateTime().nullable()();
  TextColumn get resolutionNote => text().nullable()();

  @override
  Set<Column> get primaryKey => {id};
  @override
  String get tableName => 'sync_conflicts';
}
