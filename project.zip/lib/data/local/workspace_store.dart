import 'package:shared_preferences/shared_preferences.dart';

/// Tiny key-value store for app state (NOT financial data):
/// workspace selection, locale, setup completion, last-sync timestamps.
class WorkspaceStore {
  WorkspaceStore(this._prefs);
  final SharedPreferences _prefs;

  static const _kSetupComplete = 'setup_complete';
  static const _kInstitutionId = 'current_institution_id';
  static const _kLocale = 'locale_code';

  bool get setupComplete => _prefs.getBool(_kSetupComplete) ?? false;
  Future<void> setSetupComplete(bool v) =>
      _prefs.setBool(_kSetupComplete, v);

  String? get currentInstitutionId => _prefs.getString(_kInstitutionId);
  Future<void> setCurrentInstitutionId(String id) =>
      _prefs.setString(_kInstitutionId, id);

  String get localeCode => _prefs.getString(_kLocale) ?? 'ur';
  Future<void> setLocaleCode(String code) =>
      _prefs.setString(_kLocale, code);

  // ---- Backup bookkeeping (key-value, not financial data) ----
  String? getString(String key) => _prefs.getString(key);
  Future<void> setString(String key, String value) =>
      _prefs.setString(key, value);
}
