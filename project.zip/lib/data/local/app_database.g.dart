// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_database.dart';

// ignore_for_file: type=lint
class $InstitutionsTable extends Institutions
    with TableInfo<$InstitutionsTable, Institution> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $InstitutionsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameUrMeta = const VerificationMeta('nameUr');
  @override
  late final GeneratedColumn<String> nameUr = GeneratedColumn<String>(
      'name_ur', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameEnMeta = const VerificationMeta('nameEn');
  @override
  late final GeneratedColumn<String> nameEn = GeneratedColumn<String>(
      'name_en', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _logoPathMeta =
      const VerificationMeta('logoPath');
  @override
  late final GeneratedColumn<String> logoPath = GeneratedColumn<String>(
      'logo_path', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _addressMeta =
      const VerificationMeta('address');
  @override
  late final GeneratedColumn<String> address = GeneratedColumn<String>(
      'address', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _phoneMeta = const VerificationMeta('phone');
  @override
  late final GeneratedColumn<String> phone = GeneratedColumn<String>(
      'phone', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _registrationNoMeta =
      const VerificationMeta('registrationNo');
  @override
  late final GeneratedColumn<String> registrationNo = GeneratedColumn<String>(
      'registration_no', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _ntnMeta = const VerificationMeta('ntn');
  @override
  late final GeneratedColumn<String> ntn = GeneratedColumn<String>(
      'ntn', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _fyStartMonthMeta =
      const VerificationMeta('fyStartMonth');
  @override
  late final GeneratedColumn<int> fyStartMonth = GeneratedColumn<int>(
      'fy_start_month', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(7));
  static const VerificationMeta _fyStartDayMeta =
      const VerificationMeta('fyStartDay');
  @override
  late final GeneratedColumn<int> fyStartDay = GeneratedColumn<int>(
      'fy_start_day', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _receiptPrefixMeta =
      const VerificationMeta('receiptPrefix');
  @override
  late final GeneratedColumn<String> receiptPrefix = GeneratedColumn<String>(
      'receipt_prefix', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('MD'));
  static const VerificationMeta _numberingFormatMeta =
      const VerificationMeta('numberingFormat');
  @override
  late final GeneratedColumn<String> numberingFormat = GeneratedColumn<String>(
      'numbering_format', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('{prefix}-{yyyy}-{seq:06d}'));
  static const VerificationMeta _receiptLanguageMeta =
      const VerificationMeta('receiptLanguage');
  @override
  late final GeneratedColumn<String> receiptLanguage = GeneratedColumn<String>(
      'receipt_language', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('bilingual'));
  static const VerificationMeta _printFormatMeta =
      const VerificationMeta('printFormat');
  @override
  late final GeneratedColumn<String> printFormat = GeneratedColumn<String>(
      'print_format', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('a4'));
  static const VerificationMeta _acceptedMethodsJsonMeta =
      const VerificationMeta('acceptedMethodsJson');
  @override
  late final GeneratedColumn<String> acceptedMethodsJson =
      GeneratedColumn<String>('accepted_methods_json', aliasedName, false,
          type: DriftSqlType.string,
          requiredDuringInsert: false,
          defaultValue: const Constant('["cash"]'));
  static const VerificationMeta _signatoriesJsonMeta =
      const VerificationMeta('signatoriesJson');
  @override
  late final GeneratedColumn<String> signatoriesJson = GeneratedColumn<String>(
      'signatories_json', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _dualApprovalThresholdPaisaMeta =
      const VerificationMeta('dualApprovalThresholdPaisa');
  @override
  late final GeneratedColumn<int> dualApprovalThresholdPaisa =
      GeneratedColumn<int>('dual_approval_threshold_paisa', aliasedName, false,
          type: DriftSqlType.int,
          requiredDuringInsert: false,
          defaultValue: const Constant(10000000));
  static const VerificationMeta _autoSyncMeta =
      const VerificationMeta('autoSync');
  @override
  late final GeneratedColumn<bool> autoSync = GeneratedColumn<bool>(
      'auto_sync', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("auto_sync" IN (0, 1))'),
      defaultValue: const Constant(true));
  static const VerificationMeta _isDemoMeta = const VerificationMeta('isDemo');
  @override
  late final GeneratedColumn<bool> isDemo = GeneratedColumn<bool>(
      'is_demo', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_demo" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _serverUpdatedAtMeta =
      const VerificationMeta('serverUpdatedAt');
  @override
  late final GeneratedColumn<DateTime> serverUpdatedAt =
      GeneratedColumn<DateTime>('server_updated_at', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _isDirtyMeta =
      const VerificationMeta('isDirty');
  @override
  late final GeneratedColumn<bool> isDirty = GeneratedColumn<bool>(
      'is_dirty', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_dirty" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nameUr,
        nameEn,
        logoPath,
        address,
        phone,
        email,
        registrationNo,
        ntn,
        fyStartMonth,
        fyStartDay,
        receiptPrefix,
        numberingFormat,
        receiptLanguage,
        printFormat,
        acceptedMethodsJson,
        signatoriesJson,
        dualApprovalThresholdPaisa,
        autoSync,
        isDemo,
        createdAt,
        updatedAt,
        serverUpdatedAt,
        isDirty
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'institutions';
  @override
  VerificationContext validateIntegrity(Insertable<Institution> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('name_ur')) {
      context.handle(_nameUrMeta,
          nameUr.isAcceptableOrUnknown(data['name_ur']!, _nameUrMeta));
    } else if (isInserting) {
      context.missing(_nameUrMeta);
    }
    if (data.containsKey('name_en')) {
      context.handle(_nameEnMeta,
          nameEn.isAcceptableOrUnknown(data['name_en']!, _nameEnMeta));
    } else if (isInserting) {
      context.missing(_nameEnMeta);
    }
    if (data.containsKey('logo_path')) {
      context.handle(_logoPathMeta,
          logoPath.isAcceptableOrUnknown(data['logo_path']!, _logoPathMeta));
    }
    if (data.containsKey('address')) {
      context.handle(_addressMeta,
          address.isAcceptableOrUnknown(data['address']!, _addressMeta));
    }
    if (data.containsKey('phone')) {
      context.handle(
          _phoneMeta, phone.isAcceptableOrUnknown(data['phone']!, _phoneMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('registration_no')) {
      context.handle(
          _registrationNoMeta,
          registrationNo.isAcceptableOrUnknown(
              data['registration_no']!, _registrationNoMeta));
    }
    if (data.containsKey('ntn')) {
      context.handle(
          _ntnMeta, ntn.isAcceptableOrUnknown(data['ntn']!, _ntnMeta));
    }
    if (data.containsKey('fy_start_month')) {
      context.handle(
          _fyStartMonthMeta,
          fyStartMonth.isAcceptableOrUnknown(
              data['fy_start_month']!, _fyStartMonthMeta));
    }
    if (data.containsKey('fy_start_day')) {
      context.handle(
          _fyStartDayMeta,
          fyStartDay.isAcceptableOrUnknown(
              data['fy_start_day']!, _fyStartDayMeta));
    }
    if (data.containsKey('receipt_prefix')) {
      context.handle(
          _receiptPrefixMeta,
          receiptPrefix.isAcceptableOrUnknown(
              data['receipt_prefix']!, _receiptPrefixMeta));
    }
    if (data.containsKey('numbering_format')) {
      context.handle(
          _numberingFormatMeta,
          numberingFormat.isAcceptableOrUnknown(
              data['numbering_format']!, _numberingFormatMeta));
    }
    if (data.containsKey('receipt_language')) {
      context.handle(
          _receiptLanguageMeta,
          receiptLanguage.isAcceptableOrUnknown(
              data['receipt_language']!, _receiptLanguageMeta));
    }
    if (data.containsKey('print_format')) {
      context.handle(
          _printFormatMeta,
          printFormat.isAcceptableOrUnknown(
              data['print_format']!, _printFormatMeta));
    }
    if (data.containsKey('accepted_methods_json')) {
      context.handle(
          _acceptedMethodsJsonMeta,
          acceptedMethodsJson.isAcceptableOrUnknown(
              data['accepted_methods_json']!, _acceptedMethodsJsonMeta));
    }
    if (data.containsKey('signatories_json')) {
      context.handle(
          _signatoriesJsonMeta,
          signatoriesJson.isAcceptableOrUnknown(
              data['signatories_json']!, _signatoriesJsonMeta));
    }
    if (data.containsKey('dual_approval_threshold_paisa')) {
      context.handle(
          _dualApprovalThresholdPaisaMeta,
          dualApprovalThresholdPaisa.isAcceptableOrUnknown(
              data['dual_approval_threshold_paisa']!,
              _dualApprovalThresholdPaisaMeta));
    }
    if (data.containsKey('auto_sync')) {
      context.handle(_autoSyncMeta,
          autoSync.isAcceptableOrUnknown(data['auto_sync']!, _autoSyncMeta));
    }
    if (data.containsKey('is_demo')) {
      context.handle(_isDemoMeta,
          isDemo.isAcceptableOrUnknown(data['is_demo']!, _isDemoMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    } else if (isInserting) {
      context.missing(_updatedAtMeta);
    }
    if (data.containsKey('server_updated_at')) {
      context.handle(
          _serverUpdatedAtMeta,
          serverUpdatedAt.isAcceptableOrUnknown(
              data['server_updated_at']!, _serverUpdatedAtMeta));
    }
    if (data.containsKey('is_dirty')) {
      context.handle(_isDirtyMeta,
          isDirty.isAcceptableOrUnknown(data['is_dirty']!, _isDirtyMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Institution map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Institution(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      nameUr: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name_ur'])!,
      nameEn: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name_en'])!,
      logoPath: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logo_path']),
      address: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}address']),
      phone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}phone']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      registrationNo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}registration_no']),
      ntn: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ntn']),
      fyStartMonth: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}fy_start_month'])!,
      fyStartDay: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}fy_start_day'])!,
      receiptPrefix: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}receipt_prefix'])!,
      numberingFormat: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}numbering_format'])!,
      receiptLanguage: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}receipt_language'])!,
      printFormat: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}print_format'])!,
      acceptedMethodsJson: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}accepted_methods_json'])!,
      signatoriesJson: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}signatories_json']),
      dualApprovalThresholdPaisa: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}dual_approval_threshold_paisa'])!,
      autoSync: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}auto_sync'])!,
      isDemo: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_demo'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
      serverUpdatedAt: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}server_updated_at']),
      isDirty: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_dirty'])!,
    );
  }

  @override
  $InstitutionsTable createAlias(String alias) {
    return $InstitutionsTable(attachedDatabase, alias);
  }
}

class Institution extends DataClass implements Insertable<Institution> {
  final String id;
  final String nameUr;
  final String nameEn;
  final String? logoPath;
  final String? address;
  final String? phone;
  final String? email;
  final String? registrationNo;
  final String? ntn;
  final int fyStartMonth;
  final int fyStartDay;
  final String receiptPrefix;
  final String numberingFormat;
  final String receiptLanguage;
  final String printFormat;
  final String acceptedMethodsJson;
  final String? signatoriesJson;
  final int dualApprovalThresholdPaisa;
  final bool autoSync;
  final bool isDemo;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? serverUpdatedAt;
  final bool isDirty;
  const Institution(
      {required this.id,
      required this.nameUr,
      required this.nameEn,
      this.logoPath,
      this.address,
      this.phone,
      this.email,
      this.registrationNo,
      this.ntn,
      required this.fyStartMonth,
      required this.fyStartDay,
      required this.receiptPrefix,
      required this.numberingFormat,
      required this.receiptLanguage,
      required this.printFormat,
      required this.acceptedMethodsJson,
      this.signatoriesJson,
      required this.dualApprovalThresholdPaisa,
      required this.autoSync,
      required this.isDemo,
      required this.createdAt,
      required this.updatedAt,
      this.serverUpdatedAt,
      required this.isDirty});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['name_ur'] = Variable<String>(nameUr);
    map['name_en'] = Variable<String>(nameEn);
    if (!nullToAbsent || logoPath != null) {
      map['logo_path'] = Variable<String>(logoPath);
    }
    if (!nullToAbsent || address != null) {
      map['address'] = Variable<String>(address);
    }
    if (!nullToAbsent || phone != null) {
      map['phone'] = Variable<String>(phone);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || registrationNo != null) {
      map['registration_no'] = Variable<String>(registrationNo);
    }
    if (!nullToAbsent || ntn != null) {
      map['ntn'] = Variable<String>(ntn);
    }
    map['fy_start_month'] = Variable<int>(fyStartMonth);
    map['fy_start_day'] = Variable<int>(fyStartDay);
    map['receipt_prefix'] = Variable<String>(receiptPrefix);
    map['numbering_format'] = Variable<String>(numberingFormat);
    map['receipt_language'] = Variable<String>(receiptLanguage);
    map['print_format'] = Variable<String>(printFormat);
    map['accepted_methods_json'] = Variable<String>(acceptedMethodsJson);
    if (!nullToAbsent || signatoriesJson != null) {
      map['signatories_json'] = Variable<String>(signatoriesJson);
    }
    map['dual_approval_threshold_paisa'] =
        Variable<int>(dualApprovalThresholdPaisa);
    map['auto_sync'] = Variable<bool>(autoSync);
    map['is_demo'] = Variable<bool>(isDemo);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    if (!nullToAbsent || serverUpdatedAt != null) {
      map['server_updated_at'] = Variable<DateTime>(serverUpdatedAt);
    }
    map['is_dirty'] = Variable<bool>(isDirty);
    return map;
  }

  InstitutionsCompanion toCompanion(bool nullToAbsent) {
    return InstitutionsCompanion(
      id: Value(id),
      nameUr: Value(nameUr),
      nameEn: Value(nameEn),
      logoPath: logoPath == null && nullToAbsent
          ? const Value.absent()
          : Value(logoPath),
      address: address == null && nullToAbsent
          ? const Value.absent()
          : Value(address),
      phone:
          phone == null && nullToAbsent ? const Value.absent() : Value(phone),
      email:
          email == null && nullToAbsent ? const Value.absent() : Value(email),
      registrationNo: registrationNo == null && nullToAbsent
          ? const Value.absent()
          : Value(registrationNo),
      ntn: ntn == null && nullToAbsent ? const Value.absent() : Value(ntn),
      fyStartMonth: Value(fyStartMonth),
      fyStartDay: Value(fyStartDay),
      receiptPrefix: Value(receiptPrefix),
      numberingFormat: Value(numberingFormat),
      receiptLanguage: Value(receiptLanguage),
      printFormat: Value(printFormat),
      acceptedMethodsJson: Value(acceptedMethodsJson),
      signatoriesJson: signatoriesJson == null && nullToAbsent
          ? const Value.absent()
          : Value(signatoriesJson),
      dualApprovalThresholdPaisa: Value(dualApprovalThresholdPaisa),
      autoSync: Value(autoSync),
      isDemo: Value(isDemo),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      serverUpdatedAt: serverUpdatedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(serverUpdatedAt),
      isDirty: Value(isDirty),
    );
  }

  factory Institution.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Institution(
      id: serializer.fromJson<String>(json['id']),
      nameUr: serializer.fromJson<String>(json['nameUr']),
      nameEn: serializer.fromJson<String>(json['nameEn']),
      logoPath: serializer.fromJson<String?>(json['logoPath']),
      address: serializer.fromJson<String?>(json['address']),
      phone: serializer.fromJson<String?>(json['phone']),
      email: serializer.fromJson<String?>(json['email']),
      registrationNo: serializer.fromJson<String?>(json['registrationNo']),
      ntn: serializer.fromJson<String?>(json['ntn']),
      fyStartMonth: serializer.fromJson<int>(json['fyStartMonth']),
      fyStartDay: serializer.fromJson<int>(json['fyStartDay']),
      receiptPrefix: serializer.fromJson<String>(json['receiptPrefix']),
      numberingFormat: serializer.fromJson<String>(json['numberingFormat']),
      receiptLanguage: serializer.fromJson<String>(json['receiptLanguage']),
      printFormat: serializer.fromJson<String>(json['printFormat']),
      acceptedMethodsJson:
          serializer.fromJson<String>(json['acceptedMethodsJson']),
      signatoriesJson: serializer.fromJson<String?>(json['signatoriesJson']),
      dualApprovalThresholdPaisa:
          serializer.fromJson<int>(json['dualApprovalThresholdPaisa']),
      autoSync: serializer.fromJson<bool>(json['autoSync']),
      isDemo: serializer.fromJson<bool>(json['isDemo']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
      serverUpdatedAt: serializer.fromJson<DateTime?>(json['serverUpdatedAt']),
      isDirty: serializer.fromJson<bool>(json['isDirty']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'nameUr': serializer.toJson<String>(nameUr),
      'nameEn': serializer.toJson<String>(nameEn),
      'logoPath': serializer.toJson<String?>(logoPath),
      'address': serializer.toJson<String?>(address),
      'phone': serializer.toJson<String?>(phone),
      'email': serializer.toJson<String?>(email),
      'registrationNo': serializer.toJson<String?>(registrationNo),
      'ntn': serializer.toJson<String?>(ntn),
      'fyStartMonth': serializer.toJson<int>(fyStartMonth),
      'fyStartDay': serializer.toJson<int>(fyStartDay),
      'receiptPrefix': serializer.toJson<String>(receiptPrefix),
      'numberingFormat': serializer.toJson<String>(numberingFormat),
      'receiptLanguage': serializer.toJson<String>(receiptLanguage),
      'printFormat': serializer.toJson<String>(printFormat),
      'acceptedMethodsJson': serializer.toJson<String>(acceptedMethodsJson),
      'signatoriesJson': serializer.toJson<String?>(signatoriesJson),
      'dualApprovalThresholdPaisa':
          serializer.toJson<int>(dualApprovalThresholdPaisa),
      'autoSync': serializer.toJson<bool>(autoSync),
      'isDemo': serializer.toJson<bool>(isDemo),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
      'serverUpdatedAt': serializer.toJson<DateTime?>(serverUpdatedAt),
      'isDirty': serializer.toJson<bool>(isDirty),
    };
  }

  Institution copyWith(
          {String? id,
          String? nameUr,
          String? nameEn,
          Value<String?> logoPath = const Value.absent(),
          Value<String?> address = const Value.absent(),
          Value<String?> phone = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> registrationNo = const Value.absent(),
          Value<String?> ntn = const Value.absent(),
          int? fyStartMonth,
          int? fyStartDay,
          String? receiptPrefix,
          String? numberingFormat,
          String? receiptLanguage,
          String? printFormat,
          String? acceptedMethodsJson,
          Value<String?> signatoriesJson = const Value.absent(),
          int? dualApprovalThresholdPaisa,
          bool? autoSync,
          bool? isDemo,
          DateTime? createdAt,
          DateTime? updatedAt,
          Value<DateTime?> serverUpdatedAt = const Value.absent(),
          bool? isDirty}) =>
      Institution(
        id: id ?? this.id,
        nameUr: nameUr ?? this.nameUr,
        nameEn: nameEn ?? this.nameEn,
        logoPath: logoPath.present ? logoPath.value : this.logoPath,
        address: address.present ? address.value : this.address,
        phone: phone.present ? phone.value : this.phone,
        email: email.present ? email.value : this.email,
        registrationNo:
            registrationNo.present ? registrationNo.value : this.registrationNo,
        ntn: ntn.present ? ntn.value : this.ntn,
        fyStartMonth: fyStartMonth ?? this.fyStartMonth,
        fyStartDay: fyStartDay ?? this.fyStartDay,
        receiptPrefix: receiptPrefix ?? this.receiptPrefix,
        numberingFormat: numberingFormat ?? this.numberingFormat,
        receiptLanguage: receiptLanguage ?? this.receiptLanguage,
        printFormat: printFormat ?? this.printFormat,
        acceptedMethodsJson: acceptedMethodsJson ?? this.acceptedMethodsJson,
        signatoriesJson: signatoriesJson.present
            ? signatoriesJson.value
            : this.signatoriesJson,
        dualApprovalThresholdPaisa:
            dualApprovalThresholdPaisa ?? this.dualApprovalThresholdPaisa,
        autoSync: autoSync ?? this.autoSync,
        isDemo: isDemo ?? this.isDemo,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        serverUpdatedAt: serverUpdatedAt.present
            ? serverUpdatedAt.value
            : this.serverUpdatedAt,
        isDirty: isDirty ?? this.isDirty,
      );
  Institution copyWithCompanion(InstitutionsCompanion data) {
    return Institution(
      id: data.id.present ? data.id.value : this.id,
      nameUr: data.nameUr.present ? data.nameUr.value : this.nameUr,
      nameEn: data.nameEn.present ? data.nameEn.value : this.nameEn,
      logoPath: data.logoPath.present ? data.logoPath.value : this.logoPath,
      address: data.address.present ? data.address.value : this.address,
      phone: data.phone.present ? data.phone.value : this.phone,
      email: data.email.present ? data.email.value : this.email,
      registrationNo: data.registrationNo.present
          ? data.registrationNo.value
          : this.registrationNo,
      ntn: data.ntn.present ? data.ntn.value : this.ntn,
      fyStartMonth: data.fyStartMonth.present
          ? data.fyStartMonth.value
          : this.fyStartMonth,
      fyStartDay:
          data.fyStartDay.present ? data.fyStartDay.value : this.fyStartDay,
      receiptPrefix: data.receiptPrefix.present
          ? data.receiptPrefix.value
          : this.receiptPrefix,
      numberingFormat: data.numberingFormat.present
          ? data.numberingFormat.value
          : this.numberingFormat,
      receiptLanguage: data.receiptLanguage.present
          ? data.receiptLanguage.value
          : this.receiptLanguage,
      printFormat:
          data.printFormat.present ? data.printFormat.value : this.printFormat,
      acceptedMethodsJson: data.acceptedMethodsJson.present
          ? data.acceptedMethodsJson.value
          : this.acceptedMethodsJson,
      signatoriesJson: data.signatoriesJson.present
          ? data.signatoriesJson.value
          : this.signatoriesJson,
      dualApprovalThresholdPaisa: data.dualApprovalThresholdPaisa.present
          ? data.dualApprovalThresholdPaisa.value
          : this.dualApprovalThresholdPaisa,
      autoSync: data.autoSync.present ? data.autoSync.value : this.autoSync,
      isDemo: data.isDemo.present ? data.isDemo.value : this.isDemo,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      serverUpdatedAt: data.serverUpdatedAt.present
          ? data.serverUpdatedAt.value
          : this.serverUpdatedAt,
      isDirty: data.isDirty.present ? data.isDirty.value : this.isDirty,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Institution(')
          ..write('id: $id, ')
          ..write('nameUr: $nameUr, ')
          ..write('nameEn: $nameEn, ')
          ..write('logoPath: $logoPath, ')
          ..write('address: $address, ')
          ..write('phone: $phone, ')
          ..write('email: $email, ')
          ..write('registrationNo: $registrationNo, ')
          ..write('ntn: $ntn, ')
          ..write('fyStartMonth: $fyStartMonth, ')
          ..write('fyStartDay: $fyStartDay, ')
          ..write('receiptPrefix: $receiptPrefix, ')
          ..write('numberingFormat: $numberingFormat, ')
          ..write('receiptLanguage: $receiptLanguage, ')
          ..write('printFormat: $printFormat, ')
          ..write('acceptedMethodsJson: $acceptedMethodsJson, ')
          ..write('signatoriesJson: $signatoriesJson, ')
          ..write('dualApprovalThresholdPaisa: $dualApprovalThresholdPaisa, ')
          ..write('autoSync: $autoSync, ')
          ..write('isDemo: $isDemo, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('serverUpdatedAt: $serverUpdatedAt, ')
          ..write('isDirty: $isDirty')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        nameUr,
        nameEn,
        logoPath,
        address,
        phone,
        email,
        registrationNo,
        ntn,
        fyStartMonth,
        fyStartDay,
        receiptPrefix,
        numberingFormat,
        receiptLanguage,
        printFormat,
        acceptedMethodsJson,
        signatoriesJson,
        dualApprovalThresholdPaisa,
        autoSync,
        isDemo,
        createdAt,
        updatedAt,
        serverUpdatedAt,
        isDirty
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Institution &&
          other.id == this.id &&
          other.nameUr == this.nameUr &&
          other.nameEn == this.nameEn &&
          other.logoPath == this.logoPath &&
          other.address == this.address &&
          other.phone == this.phone &&
          other.email == this.email &&
          other.registrationNo == this.registrationNo &&
          other.ntn == this.ntn &&
          other.fyStartMonth == this.fyStartMonth &&
          other.fyStartDay == this.fyStartDay &&
          other.receiptPrefix == this.receiptPrefix &&
          other.numberingFormat == this.numberingFormat &&
          other.receiptLanguage == this.receiptLanguage &&
          other.printFormat == this.printFormat &&
          other.acceptedMethodsJson == this.acceptedMethodsJson &&
          other.signatoriesJson == this.signatoriesJson &&
          other.dualApprovalThresholdPaisa == this.dualApprovalThresholdPaisa &&
          other.autoSync == this.autoSync &&
          other.isDemo == this.isDemo &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.serverUpdatedAt == this.serverUpdatedAt &&
          other.isDirty == this.isDirty);
}

class InstitutionsCompanion extends UpdateCompanion<Institution> {
  final Value<String> id;
  final Value<String> nameUr;
  final Value<String> nameEn;
  final Value<String?> logoPath;
  final Value<String?> address;
  final Value<String?> phone;
  final Value<String?> email;
  final Value<String?> registrationNo;
  final Value<String?> ntn;
  final Value<int> fyStartMonth;
  final Value<int> fyStartDay;
  final Value<String> receiptPrefix;
  final Value<String> numberingFormat;
  final Value<String> receiptLanguage;
  final Value<String> printFormat;
  final Value<String> acceptedMethodsJson;
  final Value<String?> signatoriesJson;
  final Value<int> dualApprovalThresholdPaisa;
  final Value<bool> autoSync;
  final Value<bool> isDemo;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<DateTime?> serverUpdatedAt;
  final Value<bool> isDirty;
  final Value<int> rowid;
  const InstitutionsCompanion({
    this.id = const Value.absent(),
    this.nameUr = const Value.absent(),
    this.nameEn = const Value.absent(),
    this.logoPath = const Value.absent(),
    this.address = const Value.absent(),
    this.phone = const Value.absent(),
    this.email = const Value.absent(),
    this.registrationNo = const Value.absent(),
    this.ntn = const Value.absent(),
    this.fyStartMonth = const Value.absent(),
    this.fyStartDay = const Value.absent(),
    this.receiptPrefix = const Value.absent(),
    this.numberingFormat = const Value.absent(),
    this.receiptLanguage = const Value.absent(),
    this.printFormat = const Value.absent(),
    this.acceptedMethodsJson = const Value.absent(),
    this.signatoriesJson = const Value.absent(),
    this.dualApprovalThresholdPaisa = const Value.absent(),
    this.autoSync = const Value.absent(),
    this.isDemo = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.serverUpdatedAt = const Value.absent(),
    this.isDirty = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  InstitutionsCompanion.insert({
    required String id,
    required String nameUr,
    required String nameEn,
    this.logoPath = const Value.absent(),
    this.address = const Value.absent(),
    this.phone = const Value.absent(),
    this.email = const Value.absent(),
    this.registrationNo = const Value.absent(),
    this.ntn = const Value.absent(),
    this.fyStartMonth = const Value.absent(),
    this.fyStartDay = const Value.absent(),
    this.receiptPrefix = const Value.absent(),
    this.numberingFormat = const Value.absent(),
    this.receiptLanguage = const Value.absent(),
    this.printFormat = const Value.absent(),
    this.acceptedMethodsJson = const Value.absent(),
    this.signatoriesJson = const Value.absent(),
    this.dualApprovalThresholdPaisa = const Value.absent(),
    this.autoSync = const Value.absent(),
    this.isDemo = const Value.absent(),
    required DateTime createdAt,
    required DateTime updatedAt,
    this.serverUpdatedAt = const Value.absent(),
    this.isDirty = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        nameUr = Value(nameUr),
        nameEn = Value(nameEn),
        createdAt = Value(createdAt),
        updatedAt = Value(updatedAt);
  static Insertable<Institution> custom({
    Expression<String>? id,
    Expression<String>? nameUr,
    Expression<String>? nameEn,
    Expression<String>? logoPath,
    Expression<String>? address,
    Expression<String>? phone,
    Expression<String>? email,
    Expression<String>? registrationNo,
    Expression<String>? ntn,
    Expression<int>? fyStartMonth,
    Expression<int>? fyStartDay,
    Expression<String>? receiptPrefix,
    Expression<String>? numberingFormat,
    Expression<String>? receiptLanguage,
    Expression<String>? printFormat,
    Expression<String>? acceptedMethodsJson,
    Expression<String>? signatoriesJson,
    Expression<int>? dualApprovalThresholdPaisa,
    Expression<bool>? autoSync,
    Expression<bool>? isDemo,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<DateTime>? serverUpdatedAt,
    Expression<bool>? isDirty,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nameUr != null) 'name_ur': nameUr,
      if (nameEn != null) 'name_en': nameEn,
      if (logoPath != null) 'logo_path': logoPath,
      if (address != null) 'address': address,
      if (phone != null) 'phone': phone,
      if (email != null) 'email': email,
      if (registrationNo != null) 'registration_no': registrationNo,
      if (ntn != null) 'ntn': ntn,
      if (fyStartMonth != null) 'fy_start_month': fyStartMonth,
      if (fyStartDay != null) 'fy_start_day': fyStartDay,
      if (receiptPrefix != null) 'receipt_prefix': receiptPrefix,
      if (numberingFormat != null) 'numbering_format': numberingFormat,
      if (receiptLanguage != null) 'receipt_language': receiptLanguage,
      if (printFormat != null) 'print_format': printFormat,
      if (acceptedMethodsJson != null)
        'accepted_methods_json': acceptedMethodsJson,
      if (signatoriesJson != null) 'signatories_json': signatoriesJson,
      if (dualApprovalThresholdPaisa != null)
        'dual_approval_threshold_paisa': dualApprovalThresholdPaisa,
      if (autoSync != null) 'auto_sync': autoSync,
      if (isDemo != null) 'is_demo': isDemo,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (serverUpdatedAt != null) 'server_updated_at': serverUpdatedAt,
      if (isDirty != null) 'is_dirty': isDirty,
      if (rowid != null) 'rowid': rowid,
    });
  }

  InstitutionsCompanion copyWith(
      {Value<String>? id,
      Value<String>? nameUr,
      Value<String>? nameEn,
      Value<String?>? logoPath,
      Value<String?>? address,
      Value<String?>? phone,
      Value<String?>? email,
      Value<String?>? registrationNo,
      Value<String?>? ntn,
      Value<int>? fyStartMonth,
      Value<int>? fyStartDay,
      Value<String>? receiptPrefix,
      Value<String>? numberingFormat,
      Value<String>? receiptLanguage,
      Value<String>? printFormat,
      Value<String>? acceptedMethodsJson,
      Value<String?>? signatoriesJson,
      Value<int>? dualApprovalThresholdPaisa,
      Value<bool>? autoSync,
      Value<bool>? isDemo,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<DateTime?>? serverUpdatedAt,
      Value<bool>? isDirty,
      Value<int>? rowid}) {
    return InstitutionsCompanion(
      id: id ?? this.id,
      nameUr: nameUr ?? this.nameUr,
      nameEn: nameEn ?? this.nameEn,
      logoPath: logoPath ?? this.logoPath,
      address: address ?? this.address,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      registrationNo: registrationNo ?? this.registrationNo,
      ntn: ntn ?? this.ntn,
      fyStartMonth: fyStartMonth ?? this.fyStartMonth,
      fyStartDay: fyStartDay ?? this.fyStartDay,
      receiptPrefix: receiptPrefix ?? this.receiptPrefix,
      numberingFormat: numberingFormat ?? this.numberingFormat,
      receiptLanguage: receiptLanguage ?? this.receiptLanguage,
      printFormat: printFormat ?? this.printFormat,
      acceptedMethodsJson: acceptedMethodsJson ?? this.acceptedMethodsJson,
      signatoriesJson: signatoriesJson ?? this.signatoriesJson,
      dualApprovalThresholdPaisa:
          dualApprovalThresholdPaisa ?? this.dualApprovalThresholdPaisa,
      autoSync: autoSync ?? this.autoSync,
      isDemo: isDemo ?? this.isDemo,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      serverUpdatedAt: serverUpdatedAt ?? this.serverUpdatedAt,
      isDirty: isDirty ?? this.isDirty,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (nameUr.present) {
      map['name_ur'] = Variable<String>(nameUr.value);
    }
    if (nameEn.present) {
      map['name_en'] = Variable<String>(nameEn.value);
    }
    if (logoPath.present) {
      map['logo_path'] = Variable<String>(logoPath.value);
    }
    if (address.present) {
      map['address'] = Variable<String>(address.value);
    }
    if (phone.present) {
      map['phone'] = Variable<String>(phone.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (registrationNo.present) {
      map['registration_no'] = Variable<String>(registrationNo.value);
    }
    if (ntn.present) {
      map['ntn'] = Variable<String>(ntn.value);
    }
    if (fyStartMonth.present) {
      map['fy_start_month'] = Variable<int>(fyStartMonth.value);
    }
    if (fyStartDay.present) {
      map['fy_start_day'] = Variable<int>(fyStartDay.value);
    }
    if (receiptPrefix.present) {
      map['receipt_prefix'] = Variable<String>(receiptPrefix.value);
    }
    if (numberingFormat.present) {
      map['numbering_format'] = Variable<String>(numberingFormat.value);
    }
    if (receiptLanguage.present) {
      map['receipt_language'] = Variable<String>(receiptLanguage.value);
    }
    if (printFormat.present) {
      map['print_format'] = Variable<String>(printFormat.value);
    }
    if (acceptedMethodsJson.present) {
      map['accepted_methods_json'] =
          Variable<String>(acceptedMethodsJson.value);
    }
    if (signatoriesJson.present) {
      map['signatories_json'] = Variable<String>(signatoriesJson.value);
    }
    if (dualApprovalThresholdPaisa.present) {
      map['dual_approval_threshold_paisa'] =
          Variable<int>(dualApprovalThresholdPaisa.value);
    }
    if (autoSync.present) {
      map['auto_sync'] = Variable<bool>(autoSync.value);
    }
    if (isDemo.present) {
      map['is_demo'] = Variable<bool>(isDemo.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (serverUpdatedAt.present) {
      map['server_updated_at'] = Variable<DateTime>(serverUpdatedAt.value);
    }
    if (isDirty.present) {
      map['is_dirty'] = Variable<bool>(isDirty.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('InstitutionsCompanion(')
          ..write('id: $id, ')
          ..write('nameUr: $nameUr, ')
          ..write('nameEn: $nameEn, ')
          ..write('logoPath: $logoPath, ')
          ..write('address: $address, ')
          ..write('phone: $phone, ')
          ..write('email: $email, ')
          ..write('registrationNo: $registrationNo, ')
          ..write('ntn: $ntn, ')
          ..write('fyStartMonth: $fyStartMonth, ')
          ..write('fyStartDay: $fyStartDay, ')
          ..write('receiptPrefix: $receiptPrefix, ')
          ..write('numberingFormat: $numberingFormat, ')
          ..write('receiptLanguage: $receiptLanguage, ')
          ..write('printFormat: $printFormat, ')
          ..write('acceptedMethodsJson: $acceptedMethodsJson, ')
          ..write('signatoriesJson: $signatoriesJson, ')
          ..write('dualApprovalThresholdPaisa: $dualApprovalThresholdPaisa, ')
          ..write('autoSync: $autoSync, ')
          ..write('isDemo: $isDemo, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('serverUpdatedAt: $serverUpdatedAt, ')
          ..write('isDirty: $isDirty, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $UserProfilesTable extends UserProfiles
    with TableInfo<$UserProfilesTable, UserProfile> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $UserProfilesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _institutionIdMeta =
      const VerificationMeta('institutionId');
  @override
  late final GeneratedColumn<String> institutionId = GeneratedColumn<String>(
      'institution_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _displayNameMeta =
      const VerificationMeta('displayName');
  @override
  late final GeneratedColumn<String> displayName = GeneratedColumn<String>(
      'display_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  @override
  late final GeneratedColumnWithTypeConverter<UserRole, String> role =
      GeneratedColumn<String>('role', aliasedName, false,
              type: DriftSqlType.string, requiredDuringInsert: true)
          .withConverter<UserRole>($UserProfilesTable.$converterrole);
  static const VerificationMeta _pinHashMeta =
      const VerificationMeta('pinHash');
  @override
  late final GeneratedColumn<String> pinHash = GeneratedColumn<String>(
      'pin_hash', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _isActiveMeta =
      const VerificationMeta('isActive');
  @override
  late final GeneratedColumn<bool> isActive = GeneratedColumn<bool>(
      'is_active', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_active" IN (0, 1))'),
      defaultValue: const Constant(true));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _serverUpdatedAtMeta =
      const VerificationMeta('serverUpdatedAt');
  @override
  late final GeneratedColumn<DateTime> serverUpdatedAt =
      GeneratedColumn<DateTime>('server_updated_at', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _isDirtyMeta =
      const VerificationMeta('isDirty');
  @override
  late final GeneratedColumn<bool> isDirty = GeneratedColumn<bool>(
      'is_dirty', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_dirty" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        id,
        institutionId,
        displayName,
        email,
        role,
        pinHash,
        isActive,
        createdAt,
        serverUpdatedAt,
        isDirty
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'user_profiles';
  @override
  VerificationContext validateIntegrity(Insertable<UserProfile> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('institution_id')) {
      context.handle(
          _institutionIdMeta,
          institutionId.isAcceptableOrUnknown(
              data['institution_id']!, _institutionIdMeta));
    } else if (isInserting) {
      context.missing(_institutionIdMeta);
    }
    if (data.containsKey('display_name')) {
      context.handle(
          _displayNameMeta,
          displayName.isAcceptableOrUnknown(
              data['display_name']!, _displayNameMeta));
    } else if (isInserting) {
      context.missing(_displayNameMeta);
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    } else if (isInserting) {
      context.missing(_emailMeta);
    }
    if (data.containsKey('pin_hash')) {
      context.handle(_pinHashMeta,
          pinHash.isAcceptableOrUnknown(data['pin_hash']!, _pinHashMeta));
    }
    if (data.containsKey('is_active')) {
      context.handle(_isActiveMeta,
          isActive.isAcceptableOrUnknown(data['is_active']!, _isActiveMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    if (data.containsKey('server_updated_at')) {
      context.handle(
          _serverUpdatedAtMeta,
          serverUpdatedAt.isAcceptableOrUnknown(
              data['server_updated_at']!, _serverUpdatedAtMeta));
    }
    if (data.containsKey('is_dirty')) {
      context.handle(_isDirtyMeta,
          isDirty.isAcceptableOrUnknown(data['is_dirty']!, _isDirtyMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  UserProfile map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return UserProfile(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      institutionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}institution_id'])!,
      displayName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}display_name'])!,
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email'])!,
      role: $UserProfilesTable.$converterrole.fromSql(attachedDatabase
          .typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}role'])!),
      pinHash: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pin_hash']),
      isActive: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_active'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      serverUpdatedAt: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}server_updated_at']),
      isDirty: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_dirty'])!,
    );
  }

  @override
  $UserProfilesTable createAlias(String alias) {
    return $UserProfilesTable(attachedDatabase, alias);
  }

  static JsonTypeConverter2<UserRole, String, String> $converterrole =
      const EnumNameConverter<UserRole>(UserRole.values);
}

class UserProfile extends DataClass implements Insertable<UserProfile> {
  final String id;
  final String institutionId;
  final String displayName;
  final String email;
  final UserRole role;
  final String? pinHash;
  final bool isActive;
  final DateTime createdAt;
  final DateTime? serverUpdatedAt;
  final bool isDirty;
  const UserProfile(
      {required this.id,
      required this.institutionId,
      required this.displayName,
      required this.email,
      required this.role,
      this.pinHash,
      required this.isActive,
      required this.createdAt,
      this.serverUpdatedAt,
      required this.isDirty});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['institution_id'] = Variable<String>(institutionId);
    map['display_name'] = Variable<String>(displayName);
    map['email'] = Variable<String>(email);
    {
      map['role'] =
          Variable<String>($UserProfilesTable.$converterrole.toSql(role));
    }
    if (!nullToAbsent || pinHash != null) {
      map['pin_hash'] = Variable<String>(pinHash);
    }
    map['is_active'] = Variable<bool>(isActive);
    map['created_at'] = Variable<DateTime>(createdAt);
    if (!nullToAbsent || serverUpdatedAt != null) {
      map['server_updated_at'] = Variable<DateTime>(serverUpdatedAt);
    }
    map['is_dirty'] = Variable<bool>(isDirty);
    return map;
  }

  UserProfilesCompanion toCompanion(bool nullToAbsent) {
    return UserProfilesCompanion(
      id: Value(id),
      institutionId: Value(institutionId),
      displayName: Value(displayName),
      email: Value(email),
      role: Value(role),
      pinHash: pinHash == null && nullToAbsent
          ? const Value.absent()
          : Value(pinHash),
      isActive: Value(isActive),
      createdAt: Value(createdAt),
      serverUpdatedAt: serverUpdatedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(serverUpdatedAt),
      isDirty: Value(isDirty),
    );
  }

  factory UserProfile.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return UserProfile(
      id: serializer.fromJson<String>(json['id']),
      institutionId: serializer.fromJson<String>(json['institutionId']),
      displayName: serializer.fromJson<String>(json['displayName']),
      email: serializer.fromJson<String>(json['email']),
      role: $UserProfilesTable.$converterrole
          .fromJson(serializer.fromJson<String>(json['role'])),
      pinHash: serializer.fromJson<String?>(json['pinHash']),
      isActive: serializer.fromJson<bool>(json['isActive']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      serverUpdatedAt: serializer.fromJson<DateTime?>(json['serverUpdatedAt']),
      isDirty: serializer.fromJson<bool>(json['isDirty']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'institutionId': serializer.toJson<String>(institutionId),
      'displayName': serializer.toJson<String>(displayName),
      'email': serializer.toJson<String>(email),
      'role': serializer
          .toJson<String>($UserProfilesTable.$converterrole.toJson(role)),
      'pinHash': serializer.toJson<String?>(pinHash),
      'isActive': serializer.toJson<bool>(isActive),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'serverUpdatedAt': serializer.toJson<DateTime?>(serverUpdatedAt),
      'isDirty': serializer.toJson<bool>(isDirty),
    };
  }

  UserProfile copyWith(
          {String? id,
          String? institutionId,
          String? displayName,
          String? email,
          UserRole? role,
          Value<String?> pinHash = const Value.absent(),
          bool? isActive,
          DateTime? createdAt,
          Value<DateTime?> serverUpdatedAt = const Value.absent(),
          bool? isDirty}) =>
      UserProfile(
        id: id ?? this.id,
        institutionId: institutionId ?? this.institutionId,
        displayName: displayName ?? this.displayName,
        email: email ?? this.email,
        role: role ?? this.role,
        pinHash: pinHash.present ? pinHash.value : this.pinHash,
        isActive: isActive ?? this.isActive,
        createdAt: createdAt ?? this.createdAt,
        serverUpdatedAt: serverUpdatedAt.present
            ? serverUpdatedAt.value
            : this.serverUpdatedAt,
        isDirty: isDirty ?? this.isDirty,
      );
  UserProfile copyWithCompanion(UserProfilesCompanion data) {
    return UserProfile(
      id: data.id.present ? data.id.value : this.id,
      institutionId: data.institutionId.present
          ? data.institutionId.value
          : this.institutionId,
      displayName:
          data.displayName.present ? data.displayName.value : this.displayName,
      email: data.email.present ? data.email.value : this.email,
      role: data.role.present ? data.role.value : this.role,
      pinHash: data.pinHash.present ? data.pinHash.value : this.pinHash,
      isActive: data.isActive.present ? data.isActive.value : this.isActive,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      serverUpdatedAt: data.serverUpdatedAt.present
          ? data.serverUpdatedAt.value
          : this.serverUpdatedAt,
      isDirty: data.isDirty.present ? data.isDirty.value : this.isDirty,
    );
  }

  @override
  String toString() {
    return (StringBuffer('UserProfile(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('displayName: $displayName, ')
          ..write('email: $email, ')
          ..write('role: $role, ')
          ..write('pinHash: $pinHash, ')
          ..write('isActive: $isActive, ')
          ..write('createdAt: $createdAt, ')
          ..write('serverUpdatedAt: $serverUpdatedAt, ')
          ..write('isDirty: $isDirty')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, institutionId, displayName, email, role,
      pinHash, isActive, createdAt, serverUpdatedAt, isDirty);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is UserProfile &&
          other.id == this.id &&
          other.institutionId == this.institutionId &&
          other.displayName == this.displayName &&
          other.email == this.email &&
          other.role == this.role &&
          other.pinHash == this.pinHash &&
          other.isActive == this.isActive &&
          other.createdAt == this.createdAt &&
          other.serverUpdatedAt == this.serverUpdatedAt &&
          other.isDirty == this.isDirty);
}

class UserProfilesCompanion extends UpdateCompanion<UserProfile> {
  final Value<String> id;
  final Value<String> institutionId;
  final Value<String> displayName;
  final Value<String> email;
  final Value<UserRole> role;
  final Value<String?> pinHash;
  final Value<bool> isActive;
  final Value<DateTime> createdAt;
  final Value<DateTime?> serverUpdatedAt;
  final Value<bool> isDirty;
  final Value<int> rowid;
  const UserProfilesCompanion({
    this.id = const Value.absent(),
    this.institutionId = const Value.absent(),
    this.displayName = const Value.absent(),
    this.email = const Value.absent(),
    this.role = const Value.absent(),
    this.pinHash = const Value.absent(),
    this.isActive = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.serverUpdatedAt = const Value.absent(),
    this.isDirty = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  UserProfilesCompanion.insert({
    required String id,
    required String institutionId,
    required String displayName,
    required String email,
    required UserRole role,
    this.pinHash = const Value.absent(),
    this.isActive = const Value.absent(),
    required DateTime createdAt,
    this.serverUpdatedAt = const Value.absent(),
    this.isDirty = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        institutionId = Value(institutionId),
        displayName = Value(displayName),
        email = Value(email),
        role = Value(role),
        createdAt = Value(createdAt);
  static Insertable<UserProfile> custom({
    Expression<String>? id,
    Expression<String>? institutionId,
    Expression<String>? displayName,
    Expression<String>? email,
    Expression<String>? role,
    Expression<String>? pinHash,
    Expression<bool>? isActive,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? serverUpdatedAt,
    Expression<bool>? isDirty,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (institutionId != null) 'institution_id': institutionId,
      if (displayName != null) 'display_name': displayName,
      if (email != null) 'email': email,
      if (role != null) 'role': role,
      if (pinHash != null) 'pin_hash': pinHash,
      if (isActive != null) 'is_active': isActive,
      if (createdAt != null) 'created_at': createdAt,
      if (serverUpdatedAt != null) 'server_updated_at': serverUpdatedAt,
      if (isDirty != null) 'is_dirty': isDirty,
      if (rowid != null) 'rowid': rowid,
    });
  }

  UserProfilesCompanion copyWith(
      {Value<String>? id,
      Value<String>? institutionId,
      Value<String>? displayName,
      Value<String>? email,
      Value<UserRole>? role,
      Value<String?>? pinHash,
      Value<bool>? isActive,
      Value<DateTime>? createdAt,
      Value<DateTime?>? serverUpdatedAt,
      Value<bool>? isDirty,
      Value<int>? rowid}) {
    return UserProfilesCompanion(
      id: id ?? this.id,
      institutionId: institutionId ?? this.institutionId,
      displayName: displayName ?? this.displayName,
      email: email ?? this.email,
      role: role ?? this.role,
      pinHash: pinHash ?? this.pinHash,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt ?? this.createdAt,
      serverUpdatedAt: serverUpdatedAt ?? this.serverUpdatedAt,
      isDirty: isDirty ?? this.isDirty,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (institutionId.present) {
      map['institution_id'] = Variable<String>(institutionId.value);
    }
    if (displayName.present) {
      map['display_name'] = Variable<String>(displayName.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (role.present) {
      map['role'] =
          Variable<String>($UserProfilesTable.$converterrole.toSql(role.value));
    }
    if (pinHash.present) {
      map['pin_hash'] = Variable<String>(pinHash.value);
    }
    if (isActive.present) {
      map['is_active'] = Variable<bool>(isActive.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (serverUpdatedAt.present) {
      map['server_updated_at'] = Variable<DateTime>(serverUpdatedAt.value);
    }
    if (isDirty.present) {
      map['is_dirty'] = Variable<bool>(isDirty.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('UserProfilesCompanion(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('displayName: $displayName, ')
          ..write('email: $email, ')
          ..write('role: $role, ')
          ..write('pinHash: $pinHash, ')
          ..write('isActive: $isActive, ')
          ..write('createdAt: $createdAt, ')
          ..write('serverUpdatedAt: $serverUpdatedAt, ')
          ..write('isDirty: $isDirty, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $DonorsTable extends Donors with TableInfo<$DonorsTable, Donor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $DonorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _institutionIdMeta =
      const VerificationMeta('institutionId');
  @override
  late final GeneratedColumn<String> institutionId = GeneratedColumn<String>(
      'institution_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _phoneMeta = const VerificationMeta('phone');
  @override
  late final GeneratedColumn<String> phone = GeneratedColumn<String>(
      'phone', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _addressMeta =
      const VerificationMeta('address');
  @override
  late final GeneratedColumn<String> address = GeneratedColumn<String>(
      'address', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _notesMeta = const VerificationMeta('notes');
  @override
  late final GeneratedColumn<String> notes = GeneratedColumn<String>(
      'notes', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdByMeta =
      const VerificationMeta('createdBy');
  @override
  late final GeneratedColumn<String> createdBy = GeneratedColumn<String>(
      'created_by', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _serverUpdatedAtMeta =
      const VerificationMeta('serverUpdatedAt');
  @override
  late final GeneratedColumn<DateTime> serverUpdatedAt =
      GeneratedColumn<DateTime>('server_updated_at', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _isDirtyMeta =
      const VerificationMeta('isDirty');
  @override
  late final GeneratedColumn<bool> isDirty = GeneratedColumn<bool>(
      'is_dirty', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_dirty" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        id,
        institutionId,
        name,
        phone,
        email,
        address,
        notes,
        createdBy,
        createdAt,
        updatedAt,
        serverUpdatedAt,
        isDirty
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'donors';
  @override
  VerificationContext validateIntegrity(Insertable<Donor> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('institution_id')) {
      context.handle(
          _institutionIdMeta,
          institutionId.isAcceptableOrUnknown(
              data['institution_id']!, _institutionIdMeta));
    } else if (isInserting) {
      context.missing(_institutionIdMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('phone')) {
      context.handle(
          _phoneMeta, phone.isAcceptableOrUnknown(data['phone']!, _phoneMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('address')) {
      context.handle(_addressMeta,
          address.isAcceptableOrUnknown(data['address']!, _addressMeta));
    }
    if (data.containsKey('notes')) {
      context.handle(
          _notesMeta, notes.isAcceptableOrUnknown(data['notes']!, _notesMeta));
    }
    if (data.containsKey('created_by')) {
      context.handle(_createdByMeta,
          createdBy.isAcceptableOrUnknown(data['created_by']!, _createdByMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    } else if (isInserting) {
      context.missing(_updatedAtMeta);
    }
    if (data.containsKey('server_updated_at')) {
      context.handle(
          _serverUpdatedAtMeta,
          serverUpdatedAt.isAcceptableOrUnknown(
              data['server_updated_at']!, _serverUpdatedAtMeta));
    }
    if (data.containsKey('is_dirty')) {
      context.handle(_isDirtyMeta,
          isDirty.isAcceptableOrUnknown(data['is_dirty']!, _isDirtyMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Donor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Donor(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      institutionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}institution_id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      phone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}phone']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      address: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}address']),
      notes: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}notes']),
      createdBy: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_by']),
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
      serverUpdatedAt: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}server_updated_at']),
      isDirty: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_dirty'])!,
    );
  }

  @override
  $DonorsTable createAlias(String alias) {
    return $DonorsTable(attachedDatabase, alias);
  }
}

class Donor extends DataClass implements Insertable<Donor> {
  final String id;
  final String institutionId;
  final String name;
  final String? phone;
  final String? email;
  final String? address;
  final String? notes;
  final String? createdBy;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? serverUpdatedAt;
  final bool isDirty;
  const Donor(
      {required this.id,
      required this.institutionId,
      required this.name,
      this.phone,
      this.email,
      this.address,
      this.notes,
      this.createdBy,
      required this.createdAt,
      required this.updatedAt,
      this.serverUpdatedAt,
      required this.isDirty});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['institution_id'] = Variable<String>(institutionId);
    map['name'] = Variable<String>(name);
    if (!nullToAbsent || phone != null) {
      map['phone'] = Variable<String>(phone);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || address != null) {
      map['address'] = Variable<String>(address);
    }
    if (!nullToAbsent || notes != null) {
      map['notes'] = Variable<String>(notes);
    }
    if (!nullToAbsent || createdBy != null) {
      map['created_by'] = Variable<String>(createdBy);
    }
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    if (!nullToAbsent || serverUpdatedAt != null) {
      map['server_updated_at'] = Variable<DateTime>(serverUpdatedAt);
    }
    map['is_dirty'] = Variable<bool>(isDirty);
    return map;
  }

  DonorsCompanion toCompanion(bool nullToAbsent) {
    return DonorsCompanion(
      id: Value(id),
      institutionId: Value(institutionId),
      name: Value(name),
      phone:
          phone == null && nullToAbsent ? const Value.absent() : Value(phone),
      email:
          email == null && nullToAbsent ? const Value.absent() : Value(email),
      address: address == null && nullToAbsent
          ? const Value.absent()
          : Value(address),
      notes:
          notes == null && nullToAbsent ? const Value.absent() : Value(notes),
      createdBy: createdBy == null && nullToAbsent
          ? const Value.absent()
          : Value(createdBy),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      serverUpdatedAt: serverUpdatedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(serverUpdatedAt),
      isDirty: Value(isDirty),
    );
  }

  factory Donor.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Donor(
      id: serializer.fromJson<String>(json['id']),
      institutionId: serializer.fromJson<String>(json['institutionId']),
      name: serializer.fromJson<String>(json['name']),
      phone: serializer.fromJson<String?>(json['phone']),
      email: serializer.fromJson<String?>(json['email']),
      address: serializer.fromJson<String?>(json['address']),
      notes: serializer.fromJson<String?>(json['notes']),
      createdBy: serializer.fromJson<String?>(json['createdBy']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
      serverUpdatedAt: serializer.fromJson<DateTime?>(json['serverUpdatedAt']),
      isDirty: serializer.fromJson<bool>(json['isDirty']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'institutionId': serializer.toJson<String>(institutionId),
      'name': serializer.toJson<String>(name),
      'phone': serializer.toJson<String?>(phone),
      'email': serializer.toJson<String?>(email),
      'address': serializer.toJson<String?>(address),
      'notes': serializer.toJson<String?>(notes),
      'createdBy': serializer.toJson<String?>(createdBy),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
      'serverUpdatedAt': serializer.toJson<DateTime?>(serverUpdatedAt),
      'isDirty': serializer.toJson<bool>(isDirty),
    };
  }

  Donor copyWith(
          {String? id,
          String? institutionId,
          String? name,
          Value<String?> phone = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> address = const Value.absent(),
          Value<String?> notes = const Value.absent(),
          Value<String?> createdBy = const Value.absent(),
          DateTime? createdAt,
          DateTime? updatedAt,
          Value<DateTime?> serverUpdatedAt = const Value.absent(),
          bool? isDirty}) =>
      Donor(
        id: id ?? this.id,
        institutionId: institutionId ?? this.institutionId,
        name: name ?? this.name,
        phone: phone.present ? phone.value : this.phone,
        email: email.present ? email.value : this.email,
        address: address.present ? address.value : this.address,
        notes: notes.present ? notes.value : this.notes,
        createdBy: createdBy.present ? createdBy.value : this.createdBy,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        serverUpdatedAt: serverUpdatedAt.present
            ? serverUpdatedAt.value
            : this.serverUpdatedAt,
        isDirty: isDirty ?? this.isDirty,
      );
  Donor copyWithCompanion(DonorsCompanion data) {
    return Donor(
      id: data.id.present ? data.id.value : this.id,
      institutionId: data.institutionId.present
          ? data.institutionId.value
          : this.institutionId,
      name: data.name.present ? data.name.value : this.name,
      phone: data.phone.present ? data.phone.value : this.phone,
      email: data.email.present ? data.email.value : this.email,
      address: data.address.present ? data.address.value : this.address,
      notes: data.notes.present ? data.notes.value : this.notes,
      createdBy: data.createdBy.present ? data.createdBy.value : this.createdBy,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      serverUpdatedAt: data.serverUpdatedAt.present
          ? data.serverUpdatedAt.value
          : this.serverUpdatedAt,
      isDirty: data.isDirty.present ? data.isDirty.value : this.isDirty,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Donor(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('name: $name, ')
          ..write('phone: $phone, ')
          ..write('email: $email, ')
          ..write('address: $address, ')
          ..write('notes: $notes, ')
          ..write('createdBy: $createdBy, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('serverUpdatedAt: $serverUpdatedAt, ')
          ..write('isDirty: $isDirty')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      institutionId,
      name,
      phone,
      email,
      address,
      notes,
      createdBy,
      createdAt,
      updatedAt,
      serverUpdatedAt,
      isDirty);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Donor &&
          other.id == this.id &&
          other.institutionId == this.institutionId &&
          other.name == this.name &&
          other.phone == this.phone &&
          other.email == this.email &&
          other.address == this.address &&
          other.notes == this.notes &&
          other.createdBy == this.createdBy &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.serverUpdatedAt == this.serverUpdatedAt &&
          other.isDirty == this.isDirty);
}

class DonorsCompanion extends UpdateCompanion<Donor> {
  final Value<String> id;
  final Value<String> institutionId;
  final Value<String> name;
  final Value<String?> phone;
  final Value<String?> email;
  final Value<String?> address;
  final Value<String?> notes;
  final Value<String?> createdBy;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<DateTime?> serverUpdatedAt;
  final Value<bool> isDirty;
  final Value<int> rowid;
  const DonorsCompanion({
    this.id = const Value.absent(),
    this.institutionId = const Value.absent(),
    this.name = const Value.absent(),
    this.phone = const Value.absent(),
    this.email = const Value.absent(),
    this.address = const Value.absent(),
    this.notes = const Value.absent(),
    this.createdBy = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.serverUpdatedAt = const Value.absent(),
    this.isDirty = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  DonorsCompanion.insert({
    required String id,
    required String institutionId,
    required String name,
    this.phone = const Value.absent(),
    this.email = const Value.absent(),
    this.address = const Value.absent(),
    this.notes = const Value.absent(),
    this.createdBy = const Value.absent(),
    required DateTime createdAt,
    required DateTime updatedAt,
    this.serverUpdatedAt = const Value.absent(),
    this.isDirty = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        institutionId = Value(institutionId),
        name = Value(name),
        createdAt = Value(createdAt),
        updatedAt = Value(updatedAt);
  static Insertable<Donor> custom({
    Expression<String>? id,
    Expression<String>? institutionId,
    Expression<String>? name,
    Expression<String>? phone,
    Expression<String>? email,
    Expression<String>? address,
    Expression<String>? notes,
    Expression<String>? createdBy,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<DateTime>? serverUpdatedAt,
    Expression<bool>? isDirty,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (institutionId != null) 'institution_id': institutionId,
      if (name != null) 'name': name,
      if (phone != null) 'phone': phone,
      if (email != null) 'email': email,
      if (address != null) 'address': address,
      if (notes != null) 'notes': notes,
      if (createdBy != null) 'created_by': createdBy,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (serverUpdatedAt != null) 'server_updated_at': serverUpdatedAt,
      if (isDirty != null) 'is_dirty': isDirty,
      if (rowid != null) 'rowid': rowid,
    });
  }

  DonorsCompanion copyWith(
      {Value<String>? id,
      Value<String>? institutionId,
      Value<String>? name,
      Value<String?>? phone,
      Value<String?>? email,
      Value<String?>? address,
      Value<String?>? notes,
      Value<String?>? createdBy,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<DateTime?>? serverUpdatedAt,
      Value<bool>? isDirty,
      Value<int>? rowid}) {
    return DonorsCompanion(
      id: id ?? this.id,
      institutionId: institutionId ?? this.institutionId,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      address: address ?? this.address,
      notes: notes ?? this.notes,
      createdBy: createdBy ?? this.createdBy,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      serverUpdatedAt: serverUpdatedAt ?? this.serverUpdatedAt,
      isDirty: isDirty ?? this.isDirty,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (institutionId.present) {
      map['institution_id'] = Variable<String>(institutionId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (phone.present) {
      map['phone'] = Variable<String>(phone.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (address.present) {
      map['address'] = Variable<String>(address.value);
    }
    if (notes.present) {
      map['notes'] = Variable<String>(notes.value);
    }
    if (createdBy.present) {
      map['created_by'] = Variable<String>(createdBy.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (serverUpdatedAt.present) {
      map['server_updated_at'] = Variable<DateTime>(serverUpdatedAt.value);
    }
    if (isDirty.present) {
      map['is_dirty'] = Variable<bool>(isDirty.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('DonorsCompanion(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('name: $name, ')
          ..write('phone: $phone, ')
          ..write('email: $email, ')
          ..write('address: $address, ')
          ..write('notes: $notes, ')
          ..write('createdBy: $createdBy, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('serverUpdatedAt: $serverUpdatedAt, ')
          ..write('isDirty: $isDirty, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $FundTypesTable extends FundTypes
    with TableInfo<$FundTypesTable, FundType> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FundTypesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _institutionIdMeta =
      const VerificationMeta('institutionId');
  @override
  late final GeneratedColumn<String> institutionId = GeneratedColumn<String>(
      'institution_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _codeMeta = const VerificationMeta('code');
  @override
  late final GeneratedColumn<String> code = GeneratedColumn<String>(
      'code', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameUrMeta = const VerificationMeta('nameUr');
  @override
  late final GeneratedColumn<String> nameUr = GeneratedColumn<String>(
      'name_ur', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameEnMeta = const VerificationMeta('nameEn');
  @override
  late final GeneratedColumn<String> nameEn = GeneratedColumn<String>(
      'name_en', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  @override
  late final GeneratedColumnWithTypeConverter<FundCategory, String> category =
      GeneratedColumn<String>('category', aliasedName, false,
              type: DriftSqlType.string, requiredDuringInsert: true)
          .withConverter<FundCategory>($FundTypesTable.$convertercategory);
  static const VerificationMeta _isRestrictedMeta =
      const VerificationMeta('isRestricted');
  @override
  late final GeneratedColumn<bool> isRestricted = GeneratedColumn<bool>(
      'is_restricted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints: GeneratedColumn.constraintIsAlways(
          'CHECK ("is_restricted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _isActiveMeta =
      const VerificationMeta('isActive');
  @override
  late final GeneratedColumn<bool> isActive = GeneratedColumn<bool>(
      'is_active', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_active" IN (0, 1))'),
      defaultValue: const Constant(true));
  static const VerificationMeta _openingBalancePaisaMeta =
      const VerificationMeta('openingBalancePaisa');
  @override
  late final GeneratedColumn<int> openingBalancePaisa = GeneratedColumn<int>(
      'opening_balance_paisa', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _sortOrderMeta =
      const VerificationMeta('sortOrder');
  @override
  late final GeneratedColumn<int> sortOrder = GeneratedColumn<int>(
      'sort_order', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _serverUpdatedAtMeta =
      const VerificationMeta('serverUpdatedAt');
  @override
  late final GeneratedColumn<DateTime> serverUpdatedAt =
      GeneratedColumn<DateTime>('server_updated_at', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _isDirtyMeta =
      const VerificationMeta('isDirty');
  @override
  late final GeneratedColumn<bool> isDirty = GeneratedColumn<bool>(
      'is_dirty', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_dirty" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        id,
        institutionId,
        code,
        nameUr,
        nameEn,
        category,
        isRestricted,
        isActive,
        openingBalancePaisa,
        sortOrder,
        serverUpdatedAt,
        isDirty
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fund_types';
  @override
  VerificationContext validateIntegrity(Insertable<FundType> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('institution_id')) {
      context.handle(
          _institutionIdMeta,
          institutionId.isAcceptableOrUnknown(
              data['institution_id']!, _institutionIdMeta));
    } else if (isInserting) {
      context.missing(_institutionIdMeta);
    }
    if (data.containsKey('code')) {
      context.handle(
          _codeMeta, code.isAcceptableOrUnknown(data['code']!, _codeMeta));
    } else if (isInserting) {
      context.missing(_codeMeta);
    }
    if (data.containsKey('name_ur')) {
      context.handle(_nameUrMeta,
          nameUr.isAcceptableOrUnknown(data['name_ur']!, _nameUrMeta));
    } else if (isInserting) {
      context.missing(_nameUrMeta);
    }
    if (data.containsKey('name_en')) {
      context.handle(_nameEnMeta,
          nameEn.isAcceptableOrUnknown(data['name_en']!, _nameEnMeta));
    } else if (isInserting) {
      context.missing(_nameEnMeta);
    }
    if (data.containsKey('is_restricted')) {
      context.handle(
          _isRestrictedMeta,
          isRestricted.isAcceptableOrUnknown(
              data['is_restricted']!, _isRestrictedMeta));
    }
    if (data.containsKey('is_active')) {
      context.handle(_isActiveMeta,
          isActive.isAcceptableOrUnknown(data['is_active']!, _isActiveMeta));
    }
    if (data.containsKey('opening_balance_paisa')) {
      context.handle(
          _openingBalancePaisaMeta,
          openingBalancePaisa.isAcceptableOrUnknown(
              data['opening_balance_paisa']!, _openingBalancePaisaMeta));
    }
    if (data.containsKey('sort_order')) {
      context.handle(_sortOrderMeta,
          sortOrder.isAcceptableOrUnknown(data['sort_order']!, _sortOrderMeta));
    }
    if (data.containsKey('server_updated_at')) {
      context.handle(
          _serverUpdatedAtMeta,
          serverUpdatedAt.isAcceptableOrUnknown(
              data['server_updated_at']!, _serverUpdatedAtMeta));
    }
    if (data.containsKey('is_dirty')) {
      context.handle(_isDirtyMeta,
          isDirty.isAcceptableOrUnknown(data['is_dirty']!, _isDirtyMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FundType map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FundType(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      institutionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}institution_id'])!,
      code: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}code'])!,
      nameUr: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name_ur'])!,
      nameEn: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name_en'])!,
      category: $FundTypesTable.$convertercategory.fromSql(attachedDatabase
          .typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}category'])!),
      isRestricted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_restricted'])!,
      isActive: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_active'])!,
      openingBalancePaisa: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}opening_balance_paisa'])!,
      sortOrder: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}sort_order'])!,
      serverUpdatedAt: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}server_updated_at']),
      isDirty: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_dirty'])!,
    );
  }

  @override
  $FundTypesTable createAlias(String alias) {
    return $FundTypesTable(attachedDatabase, alias);
  }

  static JsonTypeConverter2<FundCategory, String, String> $convertercategory =
      const EnumNameConverter<FundCategory>(FundCategory.values);
}

class FundType extends DataClass implements Insertable<FundType> {
  final String id;
  final String institutionId;
  final String code;
  final String nameUr;
  final String nameEn;
  final FundCategory category;
  final bool isRestricted;
  final bool isActive;
  final int openingBalancePaisa;
  final int sortOrder;
  final DateTime? serverUpdatedAt;
  final bool isDirty;
  const FundType(
      {required this.id,
      required this.institutionId,
      required this.code,
      required this.nameUr,
      required this.nameEn,
      required this.category,
      required this.isRestricted,
      required this.isActive,
      required this.openingBalancePaisa,
      required this.sortOrder,
      this.serverUpdatedAt,
      required this.isDirty});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['institution_id'] = Variable<String>(institutionId);
    map['code'] = Variable<String>(code);
    map['name_ur'] = Variable<String>(nameUr);
    map['name_en'] = Variable<String>(nameEn);
    {
      map['category'] =
          Variable<String>($FundTypesTable.$convertercategory.toSql(category));
    }
    map['is_restricted'] = Variable<bool>(isRestricted);
    map['is_active'] = Variable<bool>(isActive);
    map['opening_balance_paisa'] = Variable<int>(openingBalancePaisa);
    map['sort_order'] = Variable<int>(sortOrder);
    if (!nullToAbsent || serverUpdatedAt != null) {
      map['server_updated_at'] = Variable<DateTime>(serverUpdatedAt);
    }
    map['is_dirty'] = Variable<bool>(isDirty);
    return map;
  }

  FundTypesCompanion toCompanion(bool nullToAbsent) {
    return FundTypesCompanion(
      id: Value(id),
      institutionId: Value(institutionId),
      code: Value(code),
      nameUr: Value(nameUr),
      nameEn: Value(nameEn),
      category: Value(category),
      isRestricted: Value(isRestricted),
      isActive: Value(isActive),
      openingBalancePaisa: Value(openingBalancePaisa),
      sortOrder: Value(sortOrder),
      serverUpdatedAt: serverUpdatedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(serverUpdatedAt),
      isDirty: Value(isDirty),
    );
  }

  factory FundType.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FundType(
      id: serializer.fromJson<String>(json['id']),
      institutionId: serializer.fromJson<String>(json['institutionId']),
      code: serializer.fromJson<String>(json['code']),
      nameUr: serializer.fromJson<String>(json['nameUr']),
      nameEn: serializer.fromJson<String>(json['nameEn']),
      category: $FundTypesTable.$convertercategory
          .fromJson(serializer.fromJson<String>(json['category'])),
      isRestricted: serializer.fromJson<bool>(json['isRestricted']),
      isActive: serializer.fromJson<bool>(json['isActive']),
      openingBalancePaisa:
          serializer.fromJson<int>(json['openingBalancePaisa']),
      sortOrder: serializer.fromJson<int>(json['sortOrder']),
      serverUpdatedAt: serializer.fromJson<DateTime?>(json['serverUpdatedAt']),
      isDirty: serializer.fromJson<bool>(json['isDirty']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'institutionId': serializer.toJson<String>(institutionId),
      'code': serializer.toJson<String>(code),
      'nameUr': serializer.toJson<String>(nameUr),
      'nameEn': serializer.toJson<String>(nameEn),
      'category': serializer
          .toJson<String>($FundTypesTable.$convertercategory.toJson(category)),
      'isRestricted': serializer.toJson<bool>(isRestricted),
      'isActive': serializer.toJson<bool>(isActive),
      'openingBalancePaisa': serializer.toJson<int>(openingBalancePaisa),
      'sortOrder': serializer.toJson<int>(sortOrder),
      'serverUpdatedAt': serializer.toJson<DateTime?>(serverUpdatedAt),
      'isDirty': serializer.toJson<bool>(isDirty),
    };
  }

  FundType copyWith(
          {String? id,
          String? institutionId,
          String? code,
          String? nameUr,
          String? nameEn,
          FundCategory? category,
          bool? isRestricted,
          bool? isActive,
          int? openingBalancePaisa,
          int? sortOrder,
          Value<DateTime?> serverUpdatedAt = const Value.absent(),
          bool? isDirty}) =>
      FundType(
        id: id ?? this.id,
        institutionId: institutionId ?? this.institutionId,
        code: code ?? this.code,
        nameUr: nameUr ?? this.nameUr,
        nameEn: nameEn ?? this.nameEn,
        category: category ?? this.category,
        isRestricted: isRestricted ?? this.isRestricted,
        isActive: isActive ?? this.isActive,
        openingBalancePaisa: openingBalancePaisa ?? this.openingBalancePaisa,
        sortOrder: sortOrder ?? this.sortOrder,
        serverUpdatedAt: serverUpdatedAt.present
            ? serverUpdatedAt.value
            : this.serverUpdatedAt,
        isDirty: isDirty ?? this.isDirty,
      );
  FundType copyWithCompanion(FundTypesCompanion data) {
    return FundType(
      id: data.id.present ? data.id.value : this.id,
      institutionId: data.institutionId.present
          ? data.institutionId.value
          : this.institutionId,
      code: data.code.present ? data.code.value : this.code,
      nameUr: data.nameUr.present ? data.nameUr.value : this.nameUr,
      nameEn: data.nameEn.present ? data.nameEn.value : this.nameEn,
      category: data.category.present ? data.category.value : this.category,
      isRestricted: data.isRestricted.present
          ? data.isRestricted.value
          : this.isRestricted,
      isActive: data.isActive.present ? data.isActive.value : this.isActive,
      openingBalancePaisa: data.openingBalancePaisa.present
          ? data.openingBalancePaisa.value
          : this.openingBalancePaisa,
      sortOrder: data.sortOrder.present ? data.sortOrder.value : this.sortOrder,
      serverUpdatedAt: data.serverUpdatedAt.present
          ? data.serverUpdatedAt.value
          : this.serverUpdatedAt,
      isDirty: data.isDirty.present ? data.isDirty.value : this.isDirty,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FundType(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('code: $code, ')
          ..write('nameUr: $nameUr, ')
          ..write('nameEn: $nameEn, ')
          ..write('category: $category, ')
          ..write('isRestricted: $isRestricted, ')
          ..write('isActive: $isActive, ')
          ..write('openingBalancePaisa: $openingBalancePaisa, ')
          ..write('sortOrder: $sortOrder, ')
          ..write('serverUpdatedAt: $serverUpdatedAt, ')
          ..write('isDirty: $isDirty')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      institutionId,
      code,
      nameUr,
      nameEn,
      category,
      isRestricted,
      isActive,
      openingBalancePaisa,
      sortOrder,
      serverUpdatedAt,
      isDirty);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FundType &&
          other.id == this.id &&
          other.institutionId == this.institutionId &&
          other.code == this.code &&
          other.nameUr == this.nameUr &&
          other.nameEn == this.nameEn &&
          other.category == this.category &&
          other.isRestricted == this.isRestricted &&
          other.isActive == this.isActive &&
          other.openingBalancePaisa == this.openingBalancePaisa &&
          other.sortOrder == this.sortOrder &&
          other.serverUpdatedAt == this.serverUpdatedAt &&
          other.isDirty == this.isDirty);
}

class FundTypesCompanion extends UpdateCompanion<FundType> {
  final Value<String> id;
  final Value<String> institutionId;
  final Value<String> code;
  final Value<String> nameUr;
  final Value<String> nameEn;
  final Value<FundCategory> category;
  final Value<bool> isRestricted;
  final Value<bool> isActive;
  final Value<int> openingBalancePaisa;
  final Value<int> sortOrder;
  final Value<DateTime?> serverUpdatedAt;
  final Value<bool> isDirty;
  final Value<int> rowid;
  const FundTypesCompanion({
    this.id = const Value.absent(),
    this.institutionId = const Value.absent(),
    this.code = const Value.absent(),
    this.nameUr = const Value.absent(),
    this.nameEn = const Value.absent(),
    this.category = const Value.absent(),
    this.isRestricted = const Value.absent(),
    this.isActive = const Value.absent(),
    this.openingBalancePaisa = const Value.absent(),
    this.sortOrder = const Value.absent(),
    this.serverUpdatedAt = const Value.absent(),
    this.isDirty = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  FundTypesCompanion.insert({
    required String id,
    required String institutionId,
    required String code,
    required String nameUr,
    required String nameEn,
    required FundCategory category,
    this.isRestricted = const Value.absent(),
    this.isActive = const Value.absent(),
    this.openingBalancePaisa = const Value.absent(),
    this.sortOrder = const Value.absent(),
    this.serverUpdatedAt = const Value.absent(),
    this.isDirty = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        institutionId = Value(institutionId),
        code = Value(code),
        nameUr = Value(nameUr),
        nameEn = Value(nameEn),
        category = Value(category);
  static Insertable<FundType> custom({
    Expression<String>? id,
    Expression<String>? institutionId,
    Expression<String>? code,
    Expression<String>? nameUr,
    Expression<String>? nameEn,
    Expression<String>? category,
    Expression<bool>? isRestricted,
    Expression<bool>? isActive,
    Expression<int>? openingBalancePaisa,
    Expression<int>? sortOrder,
    Expression<DateTime>? serverUpdatedAt,
    Expression<bool>? isDirty,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (institutionId != null) 'institution_id': institutionId,
      if (code != null) 'code': code,
      if (nameUr != null) 'name_ur': nameUr,
      if (nameEn != null) 'name_en': nameEn,
      if (category != null) 'category': category,
      if (isRestricted != null) 'is_restricted': isRestricted,
      if (isActive != null) 'is_active': isActive,
      if (openingBalancePaisa != null)
        'opening_balance_paisa': openingBalancePaisa,
      if (sortOrder != null) 'sort_order': sortOrder,
      if (serverUpdatedAt != null) 'server_updated_at': serverUpdatedAt,
      if (isDirty != null) 'is_dirty': isDirty,
      if (rowid != null) 'rowid': rowid,
    });
  }

  FundTypesCompanion copyWith(
      {Value<String>? id,
      Value<String>? institutionId,
      Value<String>? code,
      Value<String>? nameUr,
      Value<String>? nameEn,
      Value<FundCategory>? category,
      Value<bool>? isRestricted,
      Value<bool>? isActive,
      Value<int>? openingBalancePaisa,
      Value<int>? sortOrder,
      Value<DateTime?>? serverUpdatedAt,
      Value<bool>? isDirty,
      Value<int>? rowid}) {
    return FundTypesCompanion(
      id: id ?? this.id,
      institutionId: institutionId ?? this.institutionId,
      code: code ?? this.code,
      nameUr: nameUr ?? this.nameUr,
      nameEn: nameEn ?? this.nameEn,
      category: category ?? this.category,
      isRestricted: isRestricted ?? this.isRestricted,
      isActive: isActive ?? this.isActive,
      openingBalancePaisa: openingBalancePaisa ?? this.openingBalancePaisa,
      sortOrder: sortOrder ?? this.sortOrder,
      serverUpdatedAt: serverUpdatedAt ?? this.serverUpdatedAt,
      isDirty: isDirty ?? this.isDirty,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (institutionId.present) {
      map['institution_id'] = Variable<String>(institutionId.value);
    }
    if (code.present) {
      map['code'] = Variable<String>(code.value);
    }
    if (nameUr.present) {
      map['name_ur'] = Variable<String>(nameUr.value);
    }
    if (nameEn.present) {
      map['name_en'] = Variable<String>(nameEn.value);
    }
    if (category.present) {
      map['category'] = Variable<String>(
          $FundTypesTable.$convertercategory.toSql(category.value));
    }
    if (isRestricted.present) {
      map['is_restricted'] = Variable<bool>(isRestricted.value);
    }
    if (isActive.present) {
      map['is_active'] = Variable<bool>(isActive.value);
    }
    if (openingBalancePaisa.present) {
      map['opening_balance_paisa'] = Variable<int>(openingBalancePaisa.value);
    }
    if (sortOrder.present) {
      map['sort_order'] = Variable<int>(sortOrder.value);
    }
    if (serverUpdatedAt.present) {
      map['server_updated_at'] = Variable<DateTime>(serverUpdatedAt.value);
    }
    if (isDirty.present) {
      map['is_dirty'] = Variable<bool>(isDirty.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FundTypesCompanion(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('code: $code, ')
          ..write('nameUr: $nameUr, ')
          ..write('nameEn: $nameEn, ')
          ..write('category: $category, ')
          ..write('isRestricted: $isRestricted, ')
          ..write('isActive: $isActive, ')
          ..write('openingBalancePaisa: $openingBalancePaisa, ')
          ..write('sortOrder: $sortOrder, ')
          ..write('serverUpdatedAt: $serverUpdatedAt, ')
          ..write('isDirty: $isDirty, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $PurposesTable extends Purposes with TableInfo<$PurposesTable, Purpose> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PurposesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _institutionIdMeta =
      const VerificationMeta('institutionId');
  @override
  late final GeneratedColumn<String> institutionId = GeneratedColumn<String>(
      'institution_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameUrMeta = const VerificationMeta('nameUr');
  @override
  late final GeneratedColumn<String> nameUr = GeneratedColumn<String>(
      'name_ur', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameEnMeta = const VerificationMeta('nameEn');
  @override
  late final GeneratedColumn<String> nameEn = GeneratedColumn<String>(
      'name_en', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _descriptionMeta =
      const VerificationMeta('description');
  @override
  late final GeneratedColumn<String> description = GeneratedColumn<String>(
      'description', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _isActiveMeta =
      const VerificationMeta('isActive');
  @override
  late final GeneratedColumn<bool> isActive = GeneratedColumn<bool>(
      'is_active', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_active" IN (0, 1))'),
      defaultValue: const Constant(true));
  static const VerificationMeta _serverUpdatedAtMeta =
      const VerificationMeta('serverUpdatedAt');
  @override
  late final GeneratedColumn<DateTime> serverUpdatedAt =
      GeneratedColumn<DateTime>('server_updated_at', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _isDirtyMeta =
      const VerificationMeta('isDirty');
  @override
  late final GeneratedColumn<bool> isDirty = GeneratedColumn<bool>(
      'is_dirty', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_dirty" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        id,
        institutionId,
        nameUr,
        nameEn,
        description,
        isActive,
        serverUpdatedAt,
        isDirty
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'purposes';
  @override
  VerificationContext validateIntegrity(Insertable<Purpose> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('institution_id')) {
      context.handle(
          _institutionIdMeta,
          institutionId.isAcceptableOrUnknown(
              data['institution_id']!, _institutionIdMeta));
    } else if (isInserting) {
      context.missing(_institutionIdMeta);
    }
    if (data.containsKey('name_ur')) {
      context.handle(_nameUrMeta,
          nameUr.isAcceptableOrUnknown(data['name_ur']!, _nameUrMeta));
    } else if (isInserting) {
      context.missing(_nameUrMeta);
    }
    if (data.containsKey('name_en')) {
      context.handle(_nameEnMeta,
          nameEn.isAcceptableOrUnknown(data['name_en']!, _nameEnMeta));
    } else if (isInserting) {
      context.missing(_nameEnMeta);
    }
    if (data.containsKey('description')) {
      context.handle(
          _descriptionMeta,
          description.isAcceptableOrUnknown(
              data['description']!, _descriptionMeta));
    }
    if (data.containsKey('is_active')) {
      context.handle(_isActiveMeta,
          isActive.isAcceptableOrUnknown(data['is_active']!, _isActiveMeta));
    }
    if (data.containsKey('server_updated_at')) {
      context.handle(
          _serverUpdatedAtMeta,
          serverUpdatedAt.isAcceptableOrUnknown(
              data['server_updated_at']!, _serverUpdatedAtMeta));
    }
    if (data.containsKey('is_dirty')) {
      context.handle(_isDirtyMeta,
          isDirty.isAcceptableOrUnknown(data['is_dirty']!, _isDirtyMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Purpose map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Purpose(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      institutionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}institution_id'])!,
      nameUr: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name_ur'])!,
      nameEn: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name_en'])!,
      description: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}description']),
      isActive: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_active'])!,
      serverUpdatedAt: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}server_updated_at']),
      isDirty: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_dirty'])!,
    );
  }

  @override
  $PurposesTable createAlias(String alias) {
    return $PurposesTable(attachedDatabase, alias);
  }
}

class Purpose extends DataClass implements Insertable<Purpose> {
  final String id;
  final String institutionId;
  final String nameUr;
  final String nameEn;
  final String? description;
  final bool isActive;
  final DateTime? serverUpdatedAt;
  final bool isDirty;
  const Purpose(
      {required this.id,
      required this.institutionId,
      required this.nameUr,
      required this.nameEn,
      this.description,
      required this.isActive,
      this.serverUpdatedAt,
      required this.isDirty});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['institution_id'] = Variable<String>(institutionId);
    map['name_ur'] = Variable<String>(nameUr);
    map['name_en'] = Variable<String>(nameEn);
    if (!nullToAbsent || description != null) {
      map['description'] = Variable<String>(description);
    }
    map['is_active'] = Variable<bool>(isActive);
    if (!nullToAbsent || serverUpdatedAt != null) {
      map['server_updated_at'] = Variable<DateTime>(serverUpdatedAt);
    }
    map['is_dirty'] = Variable<bool>(isDirty);
    return map;
  }

  PurposesCompanion toCompanion(bool nullToAbsent) {
    return PurposesCompanion(
      id: Value(id),
      institutionId: Value(institutionId),
      nameUr: Value(nameUr),
      nameEn: Value(nameEn),
      description: description == null && nullToAbsent
          ? const Value.absent()
          : Value(description),
      isActive: Value(isActive),
      serverUpdatedAt: serverUpdatedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(serverUpdatedAt),
      isDirty: Value(isDirty),
    );
  }

  factory Purpose.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Purpose(
      id: serializer.fromJson<String>(json['id']),
      institutionId: serializer.fromJson<String>(json['institutionId']),
      nameUr: serializer.fromJson<String>(json['nameUr']),
      nameEn: serializer.fromJson<String>(json['nameEn']),
      description: serializer.fromJson<String?>(json['description']),
      isActive: serializer.fromJson<bool>(json['isActive']),
      serverUpdatedAt: serializer.fromJson<DateTime?>(json['serverUpdatedAt']),
      isDirty: serializer.fromJson<bool>(json['isDirty']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'institutionId': serializer.toJson<String>(institutionId),
      'nameUr': serializer.toJson<String>(nameUr),
      'nameEn': serializer.toJson<String>(nameEn),
      'description': serializer.toJson<String?>(description),
      'isActive': serializer.toJson<bool>(isActive),
      'serverUpdatedAt': serializer.toJson<DateTime?>(serverUpdatedAt),
      'isDirty': serializer.toJson<bool>(isDirty),
    };
  }

  Purpose copyWith(
          {String? id,
          String? institutionId,
          String? nameUr,
          String? nameEn,
          Value<String?> description = const Value.absent(),
          bool? isActive,
          Value<DateTime?> serverUpdatedAt = const Value.absent(),
          bool? isDirty}) =>
      Purpose(
        id: id ?? this.id,
        institutionId: institutionId ?? this.institutionId,
        nameUr: nameUr ?? this.nameUr,
        nameEn: nameEn ?? this.nameEn,
        description: description.present ? description.value : this.description,
        isActive: isActive ?? this.isActive,
        serverUpdatedAt: serverUpdatedAt.present
            ? serverUpdatedAt.value
            : this.serverUpdatedAt,
        isDirty: isDirty ?? this.isDirty,
      );
  Purpose copyWithCompanion(PurposesCompanion data) {
    return Purpose(
      id: data.id.present ? data.id.value : this.id,
      institutionId: data.institutionId.present
          ? data.institutionId.value
          : this.institutionId,
      nameUr: data.nameUr.present ? data.nameUr.value : this.nameUr,
      nameEn: data.nameEn.present ? data.nameEn.value : this.nameEn,
      description:
          data.description.present ? data.description.value : this.description,
      isActive: data.isActive.present ? data.isActive.value : this.isActive,
      serverUpdatedAt: data.serverUpdatedAt.present
          ? data.serverUpdatedAt.value
          : this.serverUpdatedAt,
      isDirty: data.isDirty.present ? data.isDirty.value : this.isDirty,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Purpose(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('nameUr: $nameUr, ')
          ..write('nameEn: $nameEn, ')
          ..write('description: $description, ')
          ..write('isActive: $isActive, ')
          ..write('serverUpdatedAt: $serverUpdatedAt, ')
          ..write('isDirty: $isDirty')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, institutionId, nameUr, nameEn,
      description, isActive, serverUpdatedAt, isDirty);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Purpose &&
          other.id == this.id &&
          other.institutionId == this.institutionId &&
          other.nameUr == this.nameUr &&
          other.nameEn == this.nameEn &&
          other.description == this.description &&
          other.isActive == this.isActive &&
          other.serverUpdatedAt == this.serverUpdatedAt &&
          other.isDirty == this.isDirty);
}

class PurposesCompanion extends UpdateCompanion<Purpose> {
  final Value<String> id;
  final Value<String> institutionId;
  final Value<String> nameUr;
  final Value<String> nameEn;
  final Value<String?> description;
  final Value<bool> isActive;
  final Value<DateTime?> serverUpdatedAt;
  final Value<bool> isDirty;
  final Value<int> rowid;
  const PurposesCompanion({
    this.id = const Value.absent(),
    this.institutionId = const Value.absent(),
    this.nameUr = const Value.absent(),
    this.nameEn = const Value.absent(),
    this.description = const Value.absent(),
    this.isActive = const Value.absent(),
    this.serverUpdatedAt = const Value.absent(),
    this.isDirty = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  PurposesCompanion.insert({
    required String id,
    required String institutionId,
    required String nameUr,
    required String nameEn,
    this.description = const Value.absent(),
    this.isActive = const Value.absent(),
    this.serverUpdatedAt = const Value.absent(),
    this.isDirty = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        institutionId = Value(institutionId),
        nameUr = Value(nameUr),
        nameEn = Value(nameEn);
  static Insertable<Purpose> custom({
    Expression<String>? id,
    Expression<String>? institutionId,
    Expression<String>? nameUr,
    Expression<String>? nameEn,
    Expression<String>? description,
    Expression<bool>? isActive,
    Expression<DateTime>? serverUpdatedAt,
    Expression<bool>? isDirty,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (institutionId != null) 'institution_id': institutionId,
      if (nameUr != null) 'name_ur': nameUr,
      if (nameEn != null) 'name_en': nameEn,
      if (description != null) 'description': description,
      if (isActive != null) 'is_active': isActive,
      if (serverUpdatedAt != null) 'server_updated_at': serverUpdatedAt,
      if (isDirty != null) 'is_dirty': isDirty,
      if (rowid != null) 'rowid': rowid,
    });
  }

  PurposesCompanion copyWith(
      {Value<String>? id,
      Value<String>? institutionId,
      Value<String>? nameUr,
      Value<String>? nameEn,
      Value<String?>? description,
      Value<bool>? isActive,
      Value<DateTime?>? serverUpdatedAt,
      Value<bool>? isDirty,
      Value<int>? rowid}) {
    return PurposesCompanion(
      id: id ?? this.id,
      institutionId: institutionId ?? this.institutionId,
      nameUr: nameUr ?? this.nameUr,
      nameEn: nameEn ?? this.nameEn,
      description: description ?? this.description,
      isActive: isActive ?? this.isActive,
      serverUpdatedAt: serverUpdatedAt ?? this.serverUpdatedAt,
      isDirty: isDirty ?? this.isDirty,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (institutionId.present) {
      map['institution_id'] = Variable<String>(institutionId.value);
    }
    if (nameUr.present) {
      map['name_ur'] = Variable<String>(nameUr.value);
    }
    if (nameEn.present) {
      map['name_en'] = Variable<String>(nameEn.value);
    }
    if (description.present) {
      map['description'] = Variable<String>(description.value);
    }
    if (isActive.present) {
      map['is_active'] = Variable<bool>(isActive.value);
    }
    if (serverUpdatedAt.present) {
      map['server_updated_at'] = Variable<DateTime>(serverUpdatedAt.value);
    }
    if (isDirty.present) {
      map['is_dirty'] = Variable<bool>(isDirty.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PurposesCompanion(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('nameUr: $nameUr, ')
          ..write('nameEn: $nameEn, ')
          ..write('description: $description, ')
          ..write('isActive: $isActive, ')
          ..write('serverUpdatedAt: $serverUpdatedAt, ')
          ..write('isDirty: $isDirty, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $BankAccountsTable extends BankAccounts
    with TableInfo<$BankAccountsTable, BankAccount> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BankAccountsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _institutionIdMeta =
      const VerificationMeta('institutionId');
  @override
  late final GeneratedColumn<String> institutionId = GeneratedColumn<String>(
      'institution_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  @override
  late final GeneratedColumnWithTypeConverter<AccountType, String> type =
      GeneratedColumn<String>('type', aliasedName, false,
              type: DriftSqlType.string, requiredDuringInsert: true)
          .withConverter<AccountType>($BankAccountsTable.$convertertype);
  static const VerificationMeta _titleMeta = const VerificationMeta('title');
  @override
  late final GeneratedColumn<String> title = GeneratedColumn<String>(
      'title', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _bankNameMeta =
      const VerificationMeta('bankName');
  @override
  late final GeneratedColumn<String> bankName = GeneratedColumn<String>(
      'bank_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _accountNoMaskedMeta =
      const VerificationMeta('accountNoMasked');
  @override
  late final GeneratedColumn<String> accountNoMasked = GeneratedColumn<String>(
      'account_no_masked', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _openingBalancePaisaMeta =
      const VerificationMeta('openingBalancePaisa');
  @override
  late final GeneratedColumn<int> openingBalancePaisa = GeneratedColumn<int>(
      'opening_balance_paisa', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _isActiveMeta =
      const VerificationMeta('isActive');
  @override
  late final GeneratedColumn<bool> isActive = GeneratedColumn<bool>(
      'is_active', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_active" IN (0, 1))'),
      defaultValue: const Constant(true));
  static const VerificationMeta _serverUpdatedAtMeta =
      const VerificationMeta('serverUpdatedAt');
  @override
  late final GeneratedColumn<DateTime> serverUpdatedAt =
      GeneratedColumn<DateTime>('server_updated_at', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _isDirtyMeta =
      const VerificationMeta('isDirty');
  @override
  late final GeneratedColumn<bool> isDirty = GeneratedColumn<bool>(
      'is_dirty', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_dirty" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        id,
        institutionId,
        type,
        title,
        bankName,
        accountNoMasked,
        openingBalancePaisa,
        isActive,
        serverUpdatedAt,
        isDirty
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'bank_accounts';
  @override
  VerificationContext validateIntegrity(Insertable<BankAccount> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('institution_id')) {
      context.handle(
          _institutionIdMeta,
          institutionId.isAcceptableOrUnknown(
              data['institution_id']!, _institutionIdMeta));
    } else if (isInserting) {
      context.missing(_institutionIdMeta);
    }
    if (data.containsKey('title')) {
      context.handle(
          _titleMeta, title.isAcceptableOrUnknown(data['title']!, _titleMeta));
    } else if (isInserting) {
      context.missing(_titleMeta);
    }
    if (data.containsKey('bank_name')) {
      context.handle(_bankNameMeta,
          bankName.isAcceptableOrUnknown(data['bank_name']!, _bankNameMeta));
    }
    if (data.containsKey('account_no_masked')) {
      context.handle(
          _accountNoMaskedMeta,
          accountNoMasked.isAcceptableOrUnknown(
              data['account_no_masked']!, _accountNoMaskedMeta));
    }
    if (data.containsKey('opening_balance_paisa')) {
      context.handle(
          _openingBalancePaisaMeta,
          openingBalancePaisa.isAcceptableOrUnknown(
              data['opening_balance_paisa']!, _openingBalancePaisaMeta));
    }
    if (data.containsKey('is_active')) {
      context.handle(_isActiveMeta,
          isActive.isAcceptableOrUnknown(data['is_active']!, _isActiveMeta));
    }
    if (data.containsKey('server_updated_at')) {
      context.handle(
          _serverUpdatedAtMeta,
          serverUpdatedAt.isAcceptableOrUnknown(
              data['server_updated_at']!, _serverUpdatedAtMeta));
    }
    if (data.containsKey('is_dirty')) {
      context.handle(_isDirtyMeta,
          isDirty.isAcceptableOrUnknown(data['is_dirty']!, _isDirtyMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  BankAccount map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return BankAccount(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      institutionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}institution_id'])!,
      type: $BankAccountsTable.$convertertype.fromSql(attachedDatabase
          .typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}type'])!),
      title: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}title'])!,
      bankName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bank_name']),
      accountNoMasked: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}account_no_masked']),
      openingBalancePaisa: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}opening_balance_paisa'])!,
      isActive: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_active'])!,
      serverUpdatedAt: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}server_updated_at']),
      isDirty: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_dirty'])!,
    );
  }

  @override
  $BankAccountsTable createAlias(String alias) {
    return $BankAccountsTable(attachedDatabase, alias);
  }

  static JsonTypeConverter2<AccountType, String, String> $convertertype =
      const EnumNameConverter<AccountType>(AccountType.values);
}

class BankAccount extends DataClass implements Insertable<BankAccount> {
  final String id;
  final String institutionId;
  final AccountType type;
  final String title;
  final String? bankName;
  final String? accountNoMasked;
  final int openingBalancePaisa;
  final bool isActive;
  final DateTime? serverUpdatedAt;
  final bool isDirty;
  const BankAccount(
      {required this.id,
      required this.institutionId,
      required this.type,
      required this.title,
      this.bankName,
      this.accountNoMasked,
      required this.openingBalancePaisa,
      required this.isActive,
      this.serverUpdatedAt,
      required this.isDirty});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['institution_id'] = Variable<String>(institutionId);
    {
      map['type'] =
          Variable<String>($BankAccountsTable.$convertertype.toSql(type));
    }
    map['title'] = Variable<String>(title);
    if (!nullToAbsent || bankName != null) {
      map['bank_name'] = Variable<String>(bankName);
    }
    if (!nullToAbsent || accountNoMasked != null) {
      map['account_no_masked'] = Variable<String>(accountNoMasked);
    }
    map['opening_balance_paisa'] = Variable<int>(openingBalancePaisa);
    map['is_active'] = Variable<bool>(isActive);
    if (!nullToAbsent || serverUpdatedAt != null) {
      map['server_updated_at'] = Variable<DateTime>(serverUpdatedAt);
    }
    map['is_dirty'] = Variable<bool>(isDirty);
    return map;
  }

  BankAccountsCompanion toCompanion(bool nullToAbsent) {
    return BankAccountsCompanion(
      id: Value(id),
      institutionId: Value(institutionId),
      type: Value(type),
      title: Value(title),
      bankName: bankName == null && nullToAbsent
          ? const Value.absent()
          : Value(bankName),
      accountNoMasked: accountNoMasked == null && nullToAbsent
          ? const Value.absent()
          : Value(accountNoMasked),
      openingBalancePaisa: Value(openingBalancePaisa),
      isActive: Value(isActive),
      serverUpdatedAt: serverUpdatedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(serverUpdatedAt),
      isDirty: Value(isDirty),
    );
  }

  factory BankAccount.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return BankAccount(
      id: serializer.fromJson<String>(json['id']),
      institutionId: serializer.fromJson<String>(json['institutionId']),
      type: $BankAccountsTable.$convertertype
          .fromJson(serializer.fromJson<String>(json['type'])),
      title: serializer.fromJson<String>(json['title']),
      bankName: serializer.fromJson<String?>(json['bankName']),
      accountNoMasked: serializer.fromJson<String?>(json['accountNoMasked']),
      openingBalancePaisa:
          serializer.fromJson<int>(json['openingBalancePaisa']),
      isActive: serializer.fromJson<bool>(json['isActive']),
      serverUpdatedAt: serializer.fromJson<DateTime?>(json['serverUpdatedAt']),
      isDirty: serializer.fromJson<bool>(json['isDirty']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'institutionId': serializer.toJson<String>(institutionId),
      'type': serializer
          .toJson<String>($BankAccountsTable.$convertertype.toJson(type)),
      'title': serializer.toJson<String>(title),
      'bankName': serializer.toJson<String?>(bankName),
      'accountNoMasked': serializer.toJson<String?>(accountNoMasked),
      'openingBalancePaisa': serializer.toJson<int>(openingBalancePaisa),
      'isActive': serializer.toJson<bool>(isActive),
      'serverUpdatedAt': serializer.toJson<DateTime?>(serverUpdatedAt),
      'isDirty': serializer.toJson<bool>(isDirty),
    };
  }

  BankAccount copyWith(
          {String? id,
          String? institutionId,
          AccountType? type,
          String? title,
          Value<String?> bankName = const Value.absent(),
          Value<String?> accountNoMasked = const Value.absent(),
          int? openingBalancePaisa,
          bool? isActive,
          Value<DateTime?> serverUpdatedAt = const Value.absent(),
          bool? isDirty}) =>
      BankAccount(
        id: id ?? this.id,
        institutionId: institutionId ?? this.institutionId,
        type: type ?? this.type,
        title: title ?? this.title,
        bankName: bankName.present ? bankName.value : this.bankName,
        accountNoMasked: accountNoMasked.present
            ? accountNoMasked.value
            : this.accountNoMasked,
        openingBalancePaisa: openingBalancePaisa ?? this.openingBalancePaisa,
        isActive: isActive ?? this.isActive,
        serverUpdatedAt: serverUpdatedAt.present
            ? serverUpdatedAt.value
            : this.serverUpdatedAt,
        isDirty: isDirty ?? this.isDirty,
      );
  BankAccount copyWithCompanion(BankAccountsCompanion data) {
    return BankAccount(
      id: data.id.present ? data.id.value : this.id,
      institutionId: data.institutionId.present
          ? data.institutionId.value
          : this.institutionId,
      type: data.type.present ? data.type.value : this.type,
      title: data.title.present ? data.title.value : this.title,
      bankName: data.bankName.present ? data.bankName.value : this.bankName,
      accountNoMasked: data.accountNoMasked.present
          ? data.accountNoMasked.value
          : this.accountNoMasked,
      openingBalancePaisa: data.openingBalancePaisa.present
          ? data.openingBalancePaisa.value
          : this.openingBalancePaisa,
      isActive: data.isActive.present ? data.isActive.value : this.isActive,
      serverUpdatedAt: data.serverUpdatedAt.present
          ? data.serverUpdatedAt.value
          : this.serverUpdatedAt,
      isDirty: data.isDirty.present ? data.isDirty.value : this.isDirty,
    );
  }

  @override
  String toString() {
    return (StringBuffer('BankAccount(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('type: $type, ')
          ..write('title: $title, ')
          ..write('bankName: $bankName, ')
          ..write('accountNoMasked: $accountNoMasked, ')
          ..write('openingBalancePaisa: $openingBalancePaisa, ')
          ..write('isActive: $isActive, ')
          ..write('serverUpdatedAt: $serverUpdatedAt, ')
          ..write('isDirty: $isDirty')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, institutionId, type, title, bankName,
      accountNoMasked, openingBalancePaisa, isActive, serverUpdatedAt, isDirty);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is BankAccount &&
          other.id == this.id &&
          other.institutionId == this.institutionId &&
          other.type == this.type &&
          other.title == this.title &&
          other.bankName == this.bankName &&
          other.accountNoMasked == this.accountNoMasked &&
          other.openingBalancePaisa == this.openingBalancePaisa &&
          other.isActive == this.isActive &&
          other.serverUpdatedAt == this.serverUpdatedAt &&
          other.isDirty == this.isDirty);
}

class BankAccountsCompanion extends UpdateCompanion<BankAccount> {
  final Value<String> id;
  final Value<String> institutionId;
  final Value<AccountType> type;
  final Value<String> title;
  final Value<String?> bankName;
  final Value<String?> accountNoMasked;
  final Value<int> openingBalancePaisa;
  final Value<bool> isActive;
  final Value<DateTime?> serverUpdatedAt;
  final Value<bool> isDirty;
  final Value<int> rowid;
  const BankAccountsCompanion({
    this.id = const Value.absent(),
    this.institutionId = const Value.absent(),
    this.type = const Value.absent(),
    this.title = const Value.absent(),
    this.bankName = const Value.absent(),
    this.accountNoMasked = const Value.absent(),
    this.openingBalancePaisa = const Value.absent(),
    this.isActive = const Value.absent(),
    this.serverUpdatedAt = const Value.absent(),
    this.isDirty = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  BankAccountsCompanion.insert({
    required String id,
    required String institutionId,
    required AccountType type,
    required String title,
    this.bankName = const Value.absent(),
    this.accountNoMasked = const Value.absent(),
    this.openingBalancePaisa = const Value.absent(),
    this.isActive = const Value.absent(),
    this.serverUpdatedAt = const Value.absent(),
    this.isDirty = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        institutionId = Value(institutionId),
        type = Value(type),
        title = Value(title);
  static Insertable<BankAccount> custom({
    Expression<String>? id,
    Expression<String>? institutionId,
    Expression<String>? type,
    Expression<String>? title,
    Expression<String>? bankName,
    Expression<String>? accountNoMasked,
    Expression<int>? openingBalancePaisa,
    Expression<bool>? isActive,
    Expression<DateTime>? serverUpdatedAt,
    Expression<bool>? isDirty,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (institutionId != null) 'institution_id': institutionId,
      if (type != null) 'type': type,
      if (title != null) 'title': title,
      if (bankName != null) 'bank_name': bankName,
      if (accountNoMasked != null) 'account_no_masked': accountNoMasked,
      if (openingBalancePaisa != null)
        'opening_balance_paisa': openingBalancePaisa,
      if (isActive != null) 'is_active': isActive,
      if (serverUpdatedAt != null) 'server_updated_at': serverUpdatedAt,
      if (isDirty != null) 'is_dirty': isDirty,
      if (rowid != null) 'rowid': rowid,
    });
  }

  BankAccountsCompanion copyWith(
      {Value<String>? id,
      Value<String>? institutionId,
      Value<AccountType>? type,
      Value<String>? title,
      Value<String?>? bankName,
      Value<String?>? accountNoMasked,
      Value<int>? openingBalancePaisa,
      Value<bool>? isActive,
      Value<DateTime?>? serverUpdatedAt,
      Value<bool>? isDirty,
      Value<int>? rowid}) {
    return BankAccountsCompanion(
      id: id ?? this.id,
      institutionId: institutionId ?? this.institutionId,
      type: type ?? this.type,
      title: title ?? this.title,
      bankName: bankName ?? this.bankName,
      accountNoMasked: accountNoMasked ?? this.accountNoMasked,
      openingBalancePaisa: openingBalancePaisa ?? this.openingBalancePaisa,
      isActive: isActive ?? this.isActive,
      serverUpdatedAt: serverUpdatedAt ?? this.serverUpdatedAt,
      isDirty: isDirty ?? this.isDirty,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (institutionId.present) {
      map['institution_id'] = Variable<String>(institutionId.value);
    }
    if (type.present) {
      map['type'] =
          Variable<String>($BankAccountsTable.$convertertype.toSql(type.value));
    }
    if (title.present) {
      map['title'] = Variable<String>(title.value);
    }
    if (bankName.present) {
      map['bank_name'] = Variable<String>(bankName.value);
    }
    if (accountNoMasked.present) {
      map['account_no_masked'] = Variable<String>(accountNoMasked.value);
    }
    if (openingBalancePaisa.present) {
      map['opening_balance_paisa'] = Variable<int>(openingBalancePaisa.value);
    }
    if (isActive.present) {
      map['is_active'] = Variable<bool>(isActive.value);
    }
    if (serverUpdatedAt.present) {
      map['server_updated_at'] = Variable<DateTime>(serverUpdatedAt.value);
    }
    if (isDirty.present) {
      map['is_dirty'] = Variable<bool>(isDirty.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BankAccountsCompanion(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('type: $type, ')
          ..write('title: $title, ')
          ..write('bankName: $bankName, ')
          ..write('accountNoMasked: $accountNoMasked, ')
          ..write('openingBalancePaisa: $openingBalancePaisa, ')
          ..write('isActive: $isActive, ')
          ..write('serverUpdatedAt: $serverUpdatedAt, ')
          ..write('isDirty: $isDirty, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $ReceiptsTable extends Receipts with TableInfo<$ReceiptsTable, Receipt> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ReceiptsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _institutionIdMeta =
      const VerificationMeta('institutionId');
  @override
  late final GeneratedColumn<String> institutionId = GeneratedColumn<String>(
      'institution_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _officialNumberMeta =
      const VerificationMeta('officialNumber');
  @override
  late final GeneratedColumn<String> officialNumber = GeneratedColumn<String>(
      'official_number', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultConstraints: GeneratedColumn.constraintIsAlways('UNIQUE'));
  static const VerificationMeta _localProvisionalLabelMeta =
      const VerificationMeta('localProvisionalLabel');
  @override
  late final GeneratedColumn<String> localProvisionalLabel =
      GeneratedColumn<String>('local_provisional_label', aliasedName, true,
          type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  late final GeneratedColumnWithTypeConverter<ReceiptStatus, String> status =
      GeneratedColumn<String>('status', aliasedName, false,
              type: DriftSqlType.string, requiredDuringInsert: true)
          .withConverter<ReceiptStatus>($ReceiptsTable.$converterstatus);
  @override
  late final GeneratedColumnWithTypeConverter<TxType, String> txType =
      GeneratedColumn<String>('tx_type', aliasedName, false,
              type: DriftSqlType.string, requiredDuringInsert: true)
          .withConverter<TxType>($ReceiptsTable.$convertertxType);
  static const VerificationMeta _donorIdMeta =
      const VerificationMeta('donorId');
  @override
  late final GeneratedColumn<String> donorId = GeneratedColumn<String>(
      'donor_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _donorNameSnapshotMeta =
      const VerificationMeta('donorNameSnapshot');
  @override
  late final GeneratedColumn<String> donorNameSnapshot =
      GeneratedColumn<String>('donor_name_snapshot', aliasedName, false,
          type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _isAnonymousMeta =
      const VerificationMeta('isAnonymous');
  @override
  late final GeneratedColumn<bool> isAnonymous = GeneratedColumn<bool>(
      'is_anonymous', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints: GeneratedColumn.constraintIsAlways(
          'CHECK ("is_anonymous" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _totalPaisaMeta =
      const VerificationMeta('totalPaisa');
  @override
  late final GeneratedColumn<int> totalPaisa = GeneratedColumn<int>(
      'total_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _receiptDateMeta =
      const VerificationMeta('receiptDate');
  @override
  late final GeneratedColumn<DateTime> receiptDate = GeneratedColumn<DateTime>(
      'receipt_date', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  @override
  late final GeneratedColumnWithTypeConverter<PaymentMethod, String>
      paymentMethod = GeneratedColumn<String>(
              'payment_method', aliasedName, false,
              type: DriftSqlType.string, requiredDuringInsert: true)
          .withConverter<PaymentMethod>($ReceiptsTable.$converterpaymentMethod);
  static const VerificationMeta _bankAccountIdMeta =
      const VerificationMeta('bankAccountId');
  @override
  late final GeneratedColumn<String> bankAccountId = GeneratedColumn<String>(
      'bank_account_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _referenceNoMeta =
      const VerificationMeta('referenceNo');
  @override
  late final GeneratedColumn<String> referenceNo = GeneratedColumn<String>(
      'reference_no', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _evidencePathMeta =
      const VerificationMeta('evidencePath');
  @override
  late final GeneratedColumn<String> evidencePath = GeneratedColumn<String>(
      'evidence_path', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _staffNotesMeta =
      const VerificationMeta('staffNotes');
  @override
  late final GeneratedColumn<String> staffNotes = GeneratedColumn<String>(
      'staff_notes', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _donorNoteMeta =
      const VerificationMeta('donorNote');
  @override
  late final GeneratedColumn<String> donorNote = GeneratedColumn<String>(
      'donor_note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdByMeta =
      const VerificationMeta('createdBy');
  @override
  late final GeneratedColumn<String> createdBy = GeneratedColumn<String>(
      'created_by', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _verifiedByMeta =
      const VerificationMeta('verifiedBy');
  @override
  late final GeneratedColumn<String> verifiedBy = GeneratedColumn<String>(
      'verified_by', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _verifiedAtMeta =
      const VerificationMeta('verifiedAt');
  @override
  late final GeneratedColumn<DateTime> verifiedAt = GeneratedColumn<DateTime>(
      'verified_at', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _voidReasonMeta =
      const VerificationMeta('voidReason');
  @override
  late final GeneratedColumn<String> voidReason = GeneratedColumn<String>(
      'void_reason', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _replacedByIdMeta =
      const VerificationMeta('replacedById');
  @override
  late final GeneratedColumn<String> replacedById = GeneratedColumn<String>(
      'replaced_by_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _reversesIdMeta =
      const VerificationMeta('reversesId');
  @override
  late final GeneratedColumn<String> reversesId = GeneratedColumn<String>(
      'reverses_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _idempotencyKeyMeta =
      const VerificationMeta('idempotencyKey');
  @override
  late final GeneratedColumn<String> idempotencyKey = GeneratedColumn<String>(
      'idempotency_key', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: true,
      defaultConstraints: GeneratedColumn.constraintIsAlways('UNIQUE'));
  static const VerificationMeta _serverAckMeta =
      const VerificationMeta('serverAck');
  @override
  late final GeneratedColumn<bool> serverAck = GeneratedColumn<bool>(
      'server_ack', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("server_ack" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _serverUpdatedAtMeta =
      const VerificationMeta('serverUpdatedAt');
  @override
  late final GeneratedColumn<DateTime> serverUpdatedAt =
      GeneratedColumn<DateTime>('server_updated_at', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _isDirtyMeta =
      const VerificationMeta('isDirty');
  @override
  late final GeneratedColumn<bool> isDirty = GeneratedColumn<bool>(
      'is_dirty', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_dirty" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        id,
        institutionId,
        officialNumber,
        localProvisionalLabel,
        status,
        txType,
        donorId,
        donorNameSnapshot,
        isAnonymous,
        totalPaisa,
        receiptDate,
        paymentMethod,
        bankAccountId,
        referenceNo,
        evidencePath,
        staffNotes,
        donorNote,
        createdBy,
        verifiedBy,
        verifiedAt,
        voidReason,
        replacedById,
        reversesId,
        idempotencyKey,
        serverAck,
        createdAt,
        updatedAt,
        serverUpdatedAt,
        isDirty
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'receipts';
  @override
  VerificationContext validateIntegrity(Insertable<Receipt> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('institution_id')) {
      context.handle(
          _institutionIdMeta,
          institutionId.isAcceptableOrUnknown(
              data['institution_id']!, _institutionIdMeta));
    } else if (isInserting) {
      context.missing(_institutionIdMeta);
    }
    if (data.containsKey('official_number')) {
      context.handle(
          _officialNumberMeta,
          officialNumber.isAcceptableOrUnknown(
              data['official_number']!, _officialNumberMeta));
    }
    if (data.containsKey('local_provisional_label')) {
      context.handle(
          _localProvisionalLabelMeta,
          localProvisionalLabel.isAcceptableOrUnknown(
              data['local_provisional_label']!, _localProvisionalLabelMeta));
    }
    if (data.containsKey('donor_id')) {
      context.handle(_donorIdMeta,
          donorId.isAcceptableOrUnknown(data['donor_id']!, _donorIdMeta));
    }
    if (data.containsKey('donor_name_snapshot')) {
      context.handle(
          _donorNameSnapshotMeta,
          donorNameSnapshot.isAcceptableOrUnknown(
              data['donor_name_snapshot']!, _donorNameSnapshotMeta));
    } else if (isInserting) {
      context.missing(_donorNameSnapshotMeta);
    }
    if (data.containsKey('is_anonymous')) {
      context.handle(
          _isAnonymousMeta,
          isAnonymous.isAcceptableOrUnknown(
              data['is_anonymous']!, _isAnonymousMeta));
    }
    if (data.containsKey('total_paisa')) {
      context.handle(
          _totalPaisaMeta,
          totalPaisa.isAcceptableOrUnknown(
              data['total_paisa']!, _totalPaisaMeta));
    } else if (isInserting) {
      context.missing(_totalPaisaMeta);
    }
    if (data.containsKey('receipt_date')) {
      context.handle(
          _receiptDateMeta,
          receiptDate.isAcceptableOrUnknown(
              data['receipt_date']!, _receiptDateMeta));
    } else if (isInserting) {
      context.missing(_receiptDateMeta);
    }
    if (data.containsKey('bank_account_id')) {
      context.handle(
          _bankAccountIdMeta,
          bankAccountId.isAcceptableOrUnknown(
              data['bank_account_id']!, _bankAccountIdMeta));
    }
    if (data.containsKey('reference_no')) {
      context.handle(
          _referenceNoMeta,
          referenceNo.isAcceptableOrUnknown(
              data['reference_no']!, _referenceNoMeta));
    }
    if (data.containsKey('evidence_path')) {
      context.handle(
          _evidencePathMeta,
          evidencePath.isAcceptableOrUnknown(
              data['evidence_path']!, _evidencePathMeta));
    }
    if (data.containsKey('staff_notes')) {
      context.handle(
          _staffNotesMeta,
          staffNotes.isAcceptableOrUnknown(
              data['staff_notes']!, _staffNotesMeta));
    }
    if (data.containsKey('donor_note')) {
      context.handle(_donorNoteMeta,
          donorNote.isAcceptableOrUnknown(data['donor_note']!, _donorNoteMeta));
    }
    if (data.containsKey('created_by')) {
      context.handle(_createdByMeta,
          createdBy.isAcceptableOrUnknown(data['created_by']!, _createdByMeta));
    }
    if (data.containsKey('verified_by')) {
      context.handle(
          _verifiedByMeta,
          verifiedBy.isAcceptableOrUnknown(
              data['verified_by']!, _verifiedByMeta));
    }
    if (data.containsKey('verified_at')) {
      context.handle(
          _verifiedAtMeta,
          verifiedAt.isAcceptableOrUnknown(
              data['verified_at']!, _verifiedAtMeta));
    }
    if (data.containsKey('void_reason')) {
      context.handle(
          _voidReasonMeta,
          voidReason.isAcceptableOrUnknown(
              data['void_reason']!, _voidReasonMeta));
    }
    if (data.containsKey('replaced_by_id')) {
      context.handle(
          _replacedByIdMeta,
          replacedById.isAcceptableOrUnknown(
              data['replaced_by_id']!, _replacedByIdMeta));
    }
    if (data.containsKey('reverses_id')) {
      context.handle(
          _reversesIdMeta,
          reversesId.isAcceptableOrUnknown(
              data['reverses_id']!, _reversesIdMeta));
    }
    if (data.containsKey('idempotency_key')) {
      context.handle(
          _idempotencyKeyMeta,
          idempotencyKey.isAcceptableOrUnknown(
              data['idempotency_key']!, _idempotencyKeyMeta));
    } else if (isInserting) {
      context.missing(_idempotencyKeyMeta);
    }
    if (data.containsKey('server_ack')) {
      context.handle(_serverAckMeta,
          serverAck.isAcceptableOrUnknown(data['server_ack']!, _serverAckMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    } else if (isInserting) {
      context.missing(_updatedAtMeta);
    }
    if (data.containsKey('server_updated_at')) {
      context.handle(
          _serverUpdatedAtMeta,
          serverUpdatedAt.isAcceptableOrUnknown(
              data['server_updated_at']!, _serverUpdatedAtMeta));
    }
    if (data.containsKey('is_dirty')) {
      context.handle(_isDirtyMeta,
          isDirty.isAcceptableOrUnknown(data['is_dirty']!, _isDirtyMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Receipt map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Receipt(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      institutionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}institution_id'])!,
      officialNumber: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}official_number']),
      localProvisionalLabel: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}local_provisional_label']),
      status: $ReceiptsTable.$converterstatus.fromSql(attachedDatabase
          .typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status'])!),
      txType: $ReceiptsTable.$convertertxType.fromSql(attachedDatabase
          .typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tx_type'])!),
      donorId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}donor_id']),
      donorNameSnapshot: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}donor_name_snapshot'])!,
      isAnonymous: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_anonymous'])!,
      totalPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}total_paisa'])!,
      receiptDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}receipt_date'])!,
      paymentMethod: $ReceiptsTable.$converterpaymentMethod.fromSql(
          attachedDatabase.typeMapping.read(
              DriftSqlType.string, data['${effectivePrefix}payment_method'])!),
      bankAccountId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bank_account_id']),
      referenceNo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}reference_no']),
      evidencePath: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}evidence_path']),
      staffNotes: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}staff_notes']),
      donorNote: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}donor_note']),
      createdBy: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_by']),
      verifiedBy: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}verified_by']),
      verifiedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}verified_at']),
      voidReason: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}void_reason']),
      replacedById: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}replaced_by_id']),
      reversesId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}reverses_id']),
      idempotencyKey: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}idempotency_key'])!,
      serverAck: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}server_ack'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
      serverUpdatedAt: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}server_updated_at']),
      isDirty: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_dirty'])!,
    );
  }

  @override
  $ReceiptsTable createAlias(String alias) {
    return $ReceiptsTable(attachedDatabase, alias);
  }

  static JsonTypeConverter2<ReceiptStatus, String, String> $converterstatus =
      const EnumNameConverter<ReceiptStatus>(ReceiptStatus.values);
  static JsonTypeConverter2<TxType, String, String> $convertertxType =
      const EnumNameConverter<TxType>(TxType.values);
  static JsonTypeConverter2<PaymentMethod, String, String>
      $converterpaymentMethod =
      const EnumNameConverter<PaymentMethod>(PaymentMethod.values);
}

class Receipt extends DataClass implements Insertable<Receipt> {
  final String id;
  final String institutionId;

  /// Assigned ONLY by the trusted server. NULL = provisional/offline.
  final String? officialNumber;
  final String? localProvisionalLabel;
  final ReceiptStatus status;
  final TxType txType;
  final String? donorId;
  final String donorNameSnapshot;
  final bool isAnonymous;
  final int totalPaisa;
  final DateTime receiptDate;
  final PaymentMethod paymentMethod;
  final String? bankAccountId;
  final String? referenceNo;
  final String? evidencePath;
  final String? staffNotes;
  final String? donorNote;
  final String? createdBy;
  final String? verifiedBy;
  final DateTime? verifiedAt;
  final String? voidReason;
  final String? replacedById;
  final String? reversesId;
  final String idempotencyKey;
  final bool serverAck;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? serverUpdatedAt;
  final bool isDirty;
  const Receipt(
      {required this.id,
      required this.institutionId,
      this.officialNumber,
      this.localProvisionalLabel,
      required this.status,
      required this.txType,
      this.donorId,
      required this.donorNameSnapshot,
      required this.isAnonymous,
      required this.totalPaisa,
      required this.receiptDate,
      required this.paymentMethod,
      this.bankAccountId,
      this.referenceNo,
      this.evidencePath,
      this.staffNotes,
      this.donorNote,
      this.createdBy,
      this.verifiedBy,
      this.verifiedAt,
      this.voidReason,
      this.replacedById,
      this.reversesId,
      required this.idempotencyKey,
      required this.serverAck,
      required this.createdAt,
      required this.updatedAt,
      this.serverUpdatedAt,
      required this.isDirty});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['institution_id'] = Variable<String>(institutionId);
    if (!nullToAbsent || officialNumber != null) {
      map['official_number'] = Variable<String>(officialNumber);
    }
    if (!nullToAbsent || localProvisionalLabel != null) {
      map['local_provisional_label'] = Variable<String>(localProvisionalLabel);
    }
    {
      map['status'] =
          Variable<String>($ReceiptsTable.$converterstatus.toSql(status));
    }
    {
      map['tx_type'] =
          Variable<String>($ReceiptsTable.$convertertxType.toSql(txType));
    }
    if (!nullToAbsent || donorId != null) {
      map['donor_id'] = Variable<String>(donorId);
    }
    map['donor_name_snapshot'] = Variable<String>(donorNameSnapshot);
    map['is_anonymous'] = Variable<bool>(isAnonymous);
    map['total_paisa'] = Variable<int>(totalPaisa);
    map['receipt_date'] = Variable<DateTime>(receiptDate);
    {
      map['payment_method'] = Variable<String>(
          $ReceiptsTable.$converterpaymentMethod.toSql(paymentMethod));
    }
    if (!nullToAbsent || bankAccountId != null) {
      map['bank_account_id'] = Variable<String>(bankAccountId);
    }
    if (!nullToAbsent || referenceNo != null) {
      map['reference_no'] = Variable<String>(referenceNo);
    }
    if (!nullToAbsent || evidencePath != null) {
      map['evidence_path'] = Variable<String>(evidencePath);
    }
    if (!nullToAbsent || staffNotes != null) {
      map['staff_notes'] = Variable<String>(staffNotes);
    }
    if (!nullToAbsent || donorNote != null) {
      map['donor_note'] = Variable<String>(donorNote);
    }
    if (!nullToAbsent || createdBy != null) {
      map['created_by'] = Variable<String>(createdBy);
    }
    if (!nullToAbsent || verifiedBy != null) {
      map['verified_by'] = Variable<String>(verifiedBy);
    }
    if (!nullToAbsent || verifiedAt != null) {
      map['verified_at'] = Variable<DateTime>(verifiedAt);
    }
    if (!nullToAbsent || voidReason != null) {
      map['void_reason'] = Variable<String>(voidReason);
    }
    if (!nullToAbsent || replacedById != null) {
      map['replaced_by_id'] = Variable<String>(replacedById);
    }
    if (!nullToAbsent || reversesId != null) {
      map['reverses_id'] = Variable<String>(reversesId);
    }
    map['idempotency_key'] = Variable<String>(idempotencyKey);
    map['server_ack'] = Variable<bool>(serverAck);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    if (!nullToAbsent || serverUpdatedAt != null) {
      map['server_updated_at'] = Variable<DateTime>(serverUpdatedAt);
    }
    map['is_dirty'] = Variable<bool>(isDirty);
    return map;
  }

  ReceiptsCompanion toCompanion(bool nullToAbsent) {
    return ReceiptsCompanion(
      id: Value(id),
      institutionId: Value(institutionId),
      officialNumber: officialNumber == null && nullToAbsent
          ? const Value.absent()
          : Value(officialNumber),
      localProvisionalLabel: localProvisionalLabel == null && nullToAbsent
          ? const Value.absent()
          : Value(localProvisionalLabel),
      status: Value(status),
      txType: Value(txType),
      donorId: donorId == null && nullToAbsent
          ? const Value.absent()
          : Value(donorId),
      donorNameSnapshot: Value(donorNameSnapshot),
      isAnonymous: Value(isAnonymous),
      totalPaisa: Value(totalPaisa),
      receiptDate: Value(receiptDate),
      paymentMethod: Value(paymentMethod),
      bankAccountId: bankAccountId == null && nullToAbsent
          ? const Value.absent()
          : Value(bankAccountId),
      referenceNo: referenceNo == null && nullToAbsent
          ? const Value.absent()
          : Value(referenceNo),
      evidencePath: evidencePath == null && nullToAbsent
          ? const Value.absent()
          : Value(evidencePath),
      staffNotes: staffNotes == null && nullToAbsent
          ? const Value.absent()
          : Value(staffNotes),
      donorNote: donorNote == null && nullToAbsent
          ? const Value.absent()
          : Value(donorNote),
      createdBy: createdBy == null && nullToAbsent
          ? const Value.absent()
          : Value(createdBy),
      verifiedBy: verifiedBy == null && nullToAbsent
          ? const Value.absent()
          : Value(verifiedBy),
      verifiedAt: verifiedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(verifiedAt),
      voidReason: voidReason == null && nullToAbsent
          ? const Value.absent()
          : Value(voidReason),
      replacedById: replacedById == null && nullToAbsent
          ? const Value.absent()
          : Value(replacedById),
      reversesId: reversesId == null && nullToAbsent
          ? const Value.absent()
          : Value(reversesId),
      idempotencyKey: Value(idempotencyKey),
      serverAck: Value(serverAck),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      serverUpdatedAt: serverUpdatedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(serverUpdatedAt),
      isDirty: Value(isDirty),
    );
  }

  factory Receipt.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Receipt(
      id: serializer.fromJson<String>(json['id']),
      institutionId: serializer.fromJson<String>(json['institutionId']),
      officialNumber: serializer.fromJson<String?>(json['officialNumber']),
      localProvisionalLabel:
          serializer.fromJson<String?>(json['localProvisionalLabel']),
      status: $ReceiptsTable.$converterstatus
          .fromJson(serializer.fromJson<String>(json['status'])),
      txType: $ReceiptsTable.$convertertxType
          .fromJson(serializer.fromJson<String>(json['txType'])),
      donorId: serializer.fromJson<String?>(json['donorId']),
      donorNameSnapshot: serializer.fromJson<String>(json['donorNameSnapshot']),
      isAnonymous: serializer.fromJson<bool>(json['isAnonymous']),
      totalPaisa: serializer.fromJson<int>(json['totalPaisa']),
      receiptDate: serializer.fromJson<DateTime>(json['receiptDate']),
      paymentMethod: $ReceiptsTable.$converterpaymentMethod
          .fromJson(serializer.fromJson<String>(json['paymentMethod'])),
      bankAccountId: serializer.fromJson<String?>(json['bankAccountId']),
      referenceNo: serializer.fromJson<String?>(json['referenceNo']),
      evidencePath: serializer.fromJson<String?>(json['evidencePath']),
      staffNotes: serializer.fromJson<String?>(json['staffNotes']),
      donorNote: serializer.fromJson<String?>(json['donorNote']),
      createdBy: serializer.fromJson<String?>(json['createdBy']),
      verifiedBy: serializer.fromJson<String?>(json['verifiedBy']),
      verifiedAt: serializer.fromJson<DateTime?>(json['verifiedAt']),
      voidReason: serializer.fromJson<String?>(json['voidReason']),
      replacedById: serializer.fromJson<String?>(json['replacedById']),
      reversesId: serializer.fromJson<String?>(json['reversesId']),
      idempotencyKey: serializer.fromJson<String>(json['idempotencyKey']),
      serverAck: serializer.fromJson<bool>(json['serverAck']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
      serverUpdatedAt: serializer.fromJson<DateTime?>(json['serverUpdatedAt']),
      isDirty: serializer.fromJson<bool>(json['isDirty']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'institutionId': serializer.toJson<String>(institutionId),
      'officialNumber': serializer.toJson<String?>(officialNumber),
      'localProvisionalLabel':
          serializer.toJson<String?>(localProvisionalLabel),
      'status': serializer
          .toJson<String>($ReceiptsTable.$converterstatus.toJson(status)),
      'txType': serializer
          .toJson<String>($ReceiptsTable.$convertertxType.toJson(txType)),
      'donorId': serializer.toJson<String?>(donorId),
      'donorNameSnapshot': serializer.toJson<String>(donorNameSnapshot),
      'isAnonymous': serializer.toJson<bool>(isAnonymous),
      'totalPaisa': serializer.toJson<int>(totalPaisa),
      'receiptDate': serializer.toJson<DateTime>(receiptDate),
      'paymentMethod': serializer.toJson<String>(
          $ReceiptsTable.$converterpaymentMethod.toJson(paymentMethod)),
      'bankAccountId': serializer.toJson<String?>(bankAccountId),
      'referenceNo': serializer.toJson<String?>(referenceNo),
      'evidencePath': serializer.toJson<String?>(evidencePath),
      'staffNotes': serializer.toJson<String?>(staffNotes),
      'donorNote': serializer.toJson<String?>(donorNote),
      'createdBy': serializer.toJson<String?>(createdBy),
      'verifiedBy': serializer.toJson<String?>(verifiedBy),
      'verifiedAt': serializer.toJson<DateTime?>(verifiedAt),
      'voidReason': serializer.toJson<String?>(voidReason),
      'replacedById': serializer.toJson<String?>(replacedById),
      'reversesId': serializer.toJson<String?>(reversesId),
      'idempotencyKey': serializer.toJson<String>(idempotencyKey),
      'serverAck': serializer.toJson<bool>(serverAck),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
      'serverUpdatedAt': serializer.toJson<DateTime?>(serverUpdatedAt),
      'isDirty': serializer.toJson<bool>(isDirty),
    };
  }

  Receipt copyWith(
          {String? id,
          String? institutionId,
          Value<String?> officialNumber = const Value.absent(),
          Value<String?> localProvisionalLabel = const Value.absent(),
          ReceiptStatus? status,
          TxType? txType,
          Value<String?> donorId = const Value.absent(),
          String? donorNameSnapshot,
          bool? isAnonymous,
          int? totalPaisa,
          DateTime? receiptDate,
          PaymentMethod? paymentMethod,
          Value<String?> bankAccountId = const Value.absent(),
          Value<String?> referenceNo = const Value.absent(),
          Value<String?> evidencePath = const Value.absent(),
          Value<String?> staffNotes = const Value.absent(),
          Value<String?> donorNote = const Value.absent(),
          Value<String?> createdBy = const Value.absent(),
          Value<String?> verifiedBy = const Value.absent(),
          Value<DateTime?> verifiedAt = const Value.absent(),
          Value<String?> voidReason = const Value.absent(),
          Value<String?> replacedById = const Value.absent(),
          Value<String?> reversesId = const Value.absent(),
          String? idempotencyKey,
          bool? serverAck,
          DateTime? createdAt,
          DateTime? updatedAt,
          Value<DateTime?> serverUpdatedAt = const Value.absent(),
          bool? isDirty}) =>
      Receipt(
        id: id ?? this.id,
        institutionId: institutionId ?? this.institutionId,
        officialNumber:
            officialNumber.present ? officialNumber.value : this.officialNumber,
        localProvisionalLabel: localProvisionalLabel.present
            ? localProvisionalLabel.value
            : this.localProvisionalLabel,
        status: status ?? this.status,
        txType: txType ?? this.txType,
        donorId: donorId.present ? donorId.value : this.donorId,
        donorNameSnapshot: donorNameSnapshot ?? this.donorNameSnapshot,
        isAnonymous: isAnonymous ?? this.isAnonymous,
        totalPaisa: totalPaisa ?? this.totalPaisa,
        receiptDate: receiptDate ?? this.receiptDate,
        paymentMethod: paymentMethod ?? this.paymentMethod,
        bankAccountId:
            bankAccountId.present ? bankAccountId.value : this.bankAccountId,
        referenceNo: referenceNo.present ? referenceNo.value : this.referenceNo,
        evidencePath:
            evidencePath.present ? evidencePath.value : this.evidencePath,
        staffNotes: staffNotes.present ? staffNotes.value : this.staffNotes,
        donorNote: donorNote.present ? donorNote.value : this.donorNote,
        createdBy: createdBy.present ? createdBy.value : this.createdBy,
        verifiedBy: verifiedBy.present ? verifiedBy.value : this.verifiedBy,
        verifiedAt: verifiedAt.present ? verifiedAt.value : this.verifiedAt,
        voidReason: voidReason.present ? voidReason.value : this.voidReason,
        replacedById:
            replacedById.present ? replacedById.value : this.replacedById,
        reversesId: reversesId.present ? reversesId.value : this.reversesId,
        idempotencyKey: idempotencyKey ?? this.idempotencyKey,
        serverAck: serverAck ?? this.serverAck,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        serverUpdatedAt: serverUpdatedAt.present
            ? serverUpdatedAt.value
            : this.serverUpdatedAt,
        isDirty: isDirty ?? this.isDirty,
      );
  Receipt copyWithCompanion(ReceiptsCompanion data) {
    return Receipt(
      id: data.id.present ? data.id.value : this.id,
      institutionId: data.institutionId.present
          ? data.institutionId.value
          : this.institutionId,
      officialNumber: data.officialNumber.present
          ? data.officialNumber.value
          : this.officialNumber,
      localProvisionalLabel: data.localProvisionalLabel.present
          ? data.localProvisionalLabel.value
          : this.localProvisionalLabel,
      status: data.status.present ? data.status.value : this.status,
      txType: data.txType.present ? data.txType.value : this.txType,
      donorId: data.donorId.present ? data.donorId.value : this.donorId,
      donorNameSnapshot: data.donorNameSnapshot.present
          ? data.donorNameSnapshot.value
          : this.donorNameSnapshot,
      isAnonymous:
          data.isAnonymous.present ? data.isAnonymous.value : this.isAnonymous,
      totalPaisa:
          data.totalPaisa.present ? data.totalPaisa.value : this.totalPaisa,
      receiptDate:
          data.receiptDate.present ? data.receiptDate.value : this.receiptDate,
      paymentMethod: data.paymentMethod.present
          ? data.paymentMethod.value
          : this.paymentMethod,
      bankAccountId: data.bankAccountId.present
          ? data.bankAccountId.value
          : this.bankAccountId,
      referenceNo:
          data.referenceNo.present ? data.referenceNo.value : this.referenceNo,
      evidencePath: data.evidencePath.present
          ? data.evidencePath.value
          : this.evidencePath,
      staffNotes:
          data.staffNotes.present ? data.staffNotes.value : this.staffNotes,
      donorNote: data.donorNote.present ? data.donorNote.value : this.donorNote,
      createdBy: data.createdBy.present ? data.createdBy.value : this.createdBy,
      verifiedBy:
          data.verifiedBy.present ? data.verifiedBy.value : this.verifiedBy,
      verifiedAt:
          data.verifiedAt.present ? data.verifiedAt.value : this.verifiedAt,
      voidReason:
          data.voidReason.present ? data.voidReason.value : this.voidReason,
      replacedById: data.replacedById.present
          ? data.replacedById.value
          : this.replacedById,
      reversesId:
          data.reversesId.present ? data.reversesId.value : this.reversesId,
      idempotencyKey: data.idempotencyKey.present
          ? data.idempotencyKey.value
          : this.idempotencyKey,
      serverAck: data.serverAck.present ? data.serverAck.value : this.serverAck,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      serverUpdatedAt: data.serverUpdatedAt.present
          ? data.serverUpdatedAt.value
          : this.serverUpdatedAt,
      isDirty: data.isDirty.present ? data.isDirty.value : this.isDirty,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Receipt(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('officialNumber: $officialNumber, ')
          ..write('localProvisionalLabel: $localProvisionalLabel, ')
          ..write('status: $status, ')
          ..write('txType: $txType, ')
          ..write('donorId: $donorId, ')
          ..write('donorNameSnapshot: $donorNameSnapshot, ')
          ..write('isAnonymous: $isAnonymous, ')
          ..write('totalPaisa: $totalPaisa, ')
          ..write('receiptDate: $receiptDate, ')
          ..write('paymentMethod: $paymentMethod, ')
          ..write('bankAccountId: $bankAccountId, ')
          ..write('referenceNo: $referenceNo, ')
          ..write('evidencePath: $evidencePath, ')
          ..write('staffNotes: $staffNotes, ')
          ..write('donorNote: $donorNote, ')
          ..write('createdBy: $createdBy, ')
          ..write('verifiedBy: $verifiedBy, ')
          ..write('verifiedAt: $verifiedAt, ')
          ..write('voidReason: $voidReason, ')
          ..write('replacedById: $replacedById, ')
          ..write('reversesId: $reversesId, ')
          ..write('idempotencyKey: $idempotencyKey, ')
          ..write('serverAck: $serverAck, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('serverUpdatedAt: $serverUpdatedAt, ')
          ..write('isDirty: $isDirty')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        institutionId,
        officialNumber,
        localProvisionalLabel,
        status,
        txType,
        donorId,
        donorNameSnapshot,
        isAnonymous,
        totalPaisa,
        receiptDate,
        paymentMethod,
        bankAccountId,
        referenceNo,
        evidencePath,
        staffNotes,
        donorNote,
        createdBy,
        verifiedBy,
        verifiedAt,
        voidReason,
        replacedById,
        reversesId,
        idempotencyKey,
        serverAck,
        createdAt,
        updatedAt,
        serverUpdatedAt,
        isDirty
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Receipt &&
          other.id == this.id &&
          other.institutionId == this.institutionId &&
          other.officialNumber == this.officialNumber &&
          other.localProvisionalLabel == this.localProvisionalLabel &&
          other.status == this.status &&
          other.txType == this.txType &&
          other.donorId == this.donorId &&
          other.donorNameSnapshot == this.donorNameSnapshot &&
          other.isAnonymous == this.isAnonymous &&
          other.totalPaisa == this.totalPaisa &&
          other.receiptDate == this.receiptDate &&
          other.paymentMethod == this.paymentMethod &&
          other.bankAccountId == this.bankAccountId &&
          other.referenceNo == this.referenceNo &&
          other.evidencePath == this.evidencePath &&
          other.staffNotes == this.staffNotes &&
          other.donorNote == this.donorNote &&
          other.createdBy == this.createdBy &&
          other.verifiedBy == this.verifiedBy &&
          other.verifiedAt == this.verifiedAt &&
          other.voidReason == this.voidReason &&
          other.replacedById == this.replacedById &&
          other.reversesId == this.reversesId &&
          other.idempotencyKey == this.idempotencyKey &&
          other.serverAck == this.serverAck &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.serverUpdatedAt == this.serverUpdatedAt &&
          other.isDirty == this.isDirty);
}

class ReceiptsCompanion extends UpdateCompanion<Receipt> {
  final Value<String> id;
  final Value<String> institutionId;
  final Value<String?> officialNumber;
  final Value<String?> localProvisionalLabel;
  final Value<ReceiptStatus> status;
  final Value<TxType> txType;
  final Value<String?> donorId;
  final Value<String> donorNameSnapshot;
  final Value<bool> isAnonymous;
  final Value<int> totalPaisa;
  final Value<DateTime> receiptDate;
  final Value<PaymentMethod> paymentMethod;
  final Value<String?> bankAccountId;
  final Value<String?> referenceNo;
  final Value<String?> evidencePath;
  final Value<String?> staffNotes;
  final Value<String?> donorNote;
  final Value<String?> createdBy;
  final Value<String?> verifiedBy;
  final Value<DateTime?> verifiedAt;
  final Value<String?> voidReason;
  final Value<String?> replacedById;
  final Value<String?> reversesId;
  final Value<String> idempotencyKey;
  final Value<bool> serverAck;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<DateTime?> serverUpdatedAt;
  final Value<bool> isDirty;
  final Value<int> rowid;
  const ReceiptsCompanion({
    this.id = const Value.absent(),
    this.institutionId = const Value.absent(),
    this.officialNumber = const Value.absent(),
    this.localProvisionalLabel = const Value.absent(),
    this.status = const Value.absent(),
    this.txType = const Value.absent(),
    this.donorId = const Value.absent(),
    this.donorNameSnapshot = const Value.absent(),
    this.isAnonymous = const Value.absent(),
    this.totalPaisa = const Value.absent(),
    this.receiptDate = const Value.absent(),
    this.paymentMethod = const Value.absent(),
    this.bankAccountId = const Value.absent(),
    this.referenceNo = const Value.absent(),
    this.evidencePath = const Value.absent(),
    this.staffNotes = const Value.absent(),
    this.donorNote = const Value.absent(),
    this.createdBy = const Value.absent(),
    this.verifiedBy = const Value.absent(),
    this.verifiedAt = const Value.absent(),
    this.voidReason = const Value.absent(),
    this.replacedById = const Value.absent(),
    this.reversesId = const Value.absent(),
    this.idempotencyKey = const Value.absent(),
    this.serverAck = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.serverUpdatedAt = const Value.absent(),
    this.isDirty = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ReceiptsCompanion.insert({
    required String id,
    required String institutionId,
    this.officialNumber = const Value.absent(),
    this.localProvisionalLabel = const Value.absent(),
    required ReceiptStatus status,
    required TxType txType,
    this.donorId = const Value.absent(),
    required String donorNameSnapshot,
    this.isAnonymous = const Value.absent(),
    required int totalPaisa,
    required DateTime receiptDate,
    required PaymentMethod paymentMethod,
    this.bankAccountId = const Value.absent(),
    this.referenceNo = const Value.absent(),
    this.evidencePath = const Value.absent(),
    this.staffNotes = const Value.absent(),
    this.donorNote = const Value.absent(),
    this.createdBy = const Value.absent(),
    this.verifiedBy = const Value.absent(),
    this.verifiedAt = const Value.absent(),
    this.voidReason = const Value.absent(),
    this.replacedById = const Value.absent(),
    this.reversesId = const Value.absent(),
    required String idempotencyKey,
    this.serverAck = const Value.absent(),
    required DateTime createdAt,
    required DateTime updatedAt,
    this.serverUpdatedAt = const Value.absent(),
    this.isDirty = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        institutionId = Value(institutionId),
        status = Value(status),
        txType = Value(txType),
        donorNameSnapshot = Value(donorNameSnapshot),
        totalPaisa = Value(totalPaisa),
        receiptDate = Value(receiptDate),
        paymentMethod = Value(paymentMethod),
        idempotencyKey = Value(idempotencyKey),
        createdAt = Value(createdAt),
        updatedAt = Value(updatedAt);
  static Insertable<Receipt> custom({
    Expression<String>? id,
    Expression<String>? institutionId,
    Expression<String>? officialNumber,
    Expression<String>? localProvisionalLabel,
    Expression<String>? status,
    Expression<String>? txType,
    Expression<String>? donorId,
    Expression<String>? donorNameSnapshot,
    Expression<bool>? isAnonymous,
    Expression<int>? totalPaisa,
    Expression<DateTime>? receiptDate,
    Expression<String>? paymentMethod,
    Expression<String>? bankAccountId,
    Expression<String>? referenceNo,
    Expression<String>? evidencePath,
    Expression<String>? staffNotes,
    Expression<String>? donorNote,
    Expression<String>? createdBy,
    Expression<String>? verifiedBy,
    Expression<DateTime>? verifiedAt,
    Expression<String>? voidReason,
    Expression<String>? replacedById,
    Expression<String>? reversesId,
    Expression<String>? idempotencyKey,
    Expression<bool>? serverAck,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<DateTime>? serverUpdatedAt,
    Expression<bool>? isDirty,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (institutionId != null) 'institution_id': institutionId,
      if (officialNumber != null) 'official_number': officialNumber,
      if (localProvisionalLabel != null)
        'local_provisional_label': localProvisionalLabel,
      if (status != null) 'status': status,
      if (txType != null) 'tx_type': txType,
      if (donorId != null) 'donor_id': donorId,
      if (donorNameSnapshot != null) 'donor_name_snapshot': donorNameSnapshot,
      if (isAnonymous != null) 'is_anonymous': isAnonymous,
      if (totalPaisa != null) 'total_paisa': totalPaisa,
      if (receiptDate != null) 'receipt_date': receiptDate,
      if (paymentMethod != null) 'payment_method': paymentMethod,
      if (bankAccountId != null) 'bank_account_id': bankAccountId,
      if (referenceNo != null) 'reference_no': referenceNo,
      if (evidencePath != null) 'evidence_path': evidencePath,
      if (staffNotes != null) 'staff_notes': staffNotes,
      if (donorNote != null) 'donor_note': donorNote,
      if (createdBy != null) 'created_by': createdBy,
      if (verifiedBy != null) 'verified_by': verifiedBy,
      if (verifiedAt != null) 'verified_at': verifiedAt,
      if (voidReason != null) 'void_reason': voidReason,
      if (replacedById != null) 'replaced_by_id': replacedById,
      if (reversesId != null) 'reverses_id': reversesId,
      if (idempotencyKey != null) 'idempotency_key': idempotencyKey,
      if (serverAck != null) 'server_ack': serverAck,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (serverUpdatedAt != null) 'server_updated_at': serverUpdatedAt,
      if (isDirty != null) 'is_dirty': isDirty,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ReceiptsCompanion copyWith(
      {Value<String>? id,
      Value<String>? institutionId,
      Value<String?>? officialNumber,
      Value<String?>? localProvisionalLabel,
      Value<ReceiptStatus>? status,
      Value<TxType>? txType,
      Value<String?>? donorId,
      Value<String>? donorNameSnapshot,
      Value<bool>? isAnonymous,
      Value<int>? totalPaisa,
      Value<DateTime>? receiptDate,
      Value<PaymentMethod>? paymentMethod,
      Value<String?>? bankAccountId,
      Value<String?>? referenceNo,
      Value<String?>? evidencePath,
      Value<String?>? staffNotes,
      Value<String?>? donorNote,
      Value<String?>? createdBy,
      Value<String?>? verifiedBy,
      Value<DateTime?>? verifiedAt,
      Value<String?>? voidReason,
      Value<String?>? replacedById,
      Value<String?>? reversesId,
      Value<String>? idempotencyKey,
      Value<bool>? serverAck,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<DateTime?>? serverUpdatedAt,
      Value<bool>? isDirty,
      Value<int>? rowid}) {
    return ReceiptsCompanion(
      id: id ?? this.id,
      institutionId: institutionId ?? this.institutionId,
      officialNumber: officialNumber ?? this.officialNumber,
      localProvisionalLabel:
          localProvisionalLabel ?? this.localProvisionalLabel,
      status: status ?? this.status,
      txType: txType ?? this.txType,
      donorId: donorId ?? this.donorId,
      donorNameSnapshot: donorNameSnapshot ?? this.donorNameSnapshot,
      isAnonymous: isAnonymous ?? this.isAnonymous,
      totalPaisa: totalPaisa ?? this.totalPaisa,
      receiptDate: receiptDate ?? this.receiptDate,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      bankAccountId: bankAccountId ?? this.bankAccountId,
      referenceNo: referenceNo ?? this.referenceNo,
      evidencePath: evidencePath ?? this.evidencePath,
      staffNotes: staffNotes ?? this.staffNotes,
      donorNote: donorNote ?? this.donorNote,
      createdBy: createdBy ?? this.createdBy,
      verifiedBy: verifiedBy ?? this.verifiedBy,
      verifiedAt: verifiedAt ?? this.verifiedAt,
      voidReason: voidReason ?? this.voidReason,
      replacedById: replacedById ?? this.replacedById,
      reversesId: reversesId ?? this.reversesId,
      idempotencyKey: idempotencyKey ?? this.idempotencyKey,
      serverAck: serverAck ?? this.serverAck,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      serverUpdatedAt: serverUpdatedAt ?? this.serverUpdatedAt,
      isDirty: isDirty ?? this.isDirty,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (institutionId.present) {
      map['institution_id'] = Variable<String>(institutionId.value);
    }
    if (officialNumber.present) {
      map['official_number'] = Variable<String>(officialNumber.value);
    }
    if (localProvisionalLabel.present) {
      map['local_provisional_label'] =
          Variable<String>(localProvisionalLabel.value);
    }
    if (status.present) {
      map['status'] =
          Variable<String>($ReceiptsTable.$converterstatus.toSql(status.value));
    }
    if (txType.present) {
      map['tx_type'] =
          Variable<String>($ReceiptsTable.$convertertxType.toSql(txType.value));
    }
    if (donorId.present) {
      map['donor_id'] = Variable<String>(donorId.value);
    }
    if (donorNameSnapshot.present) {
      map['donor_name_snapshot'] = Variable<String>(donorNameSnapshot.value);
    }
    if (isAnonymous.present) {
      map['is_anonymous'] = Variable<bool>(isAnonymous.value);
    }
    if (totalPaisa.present) {
      map['total_paisa'] = Variable<int>(totalPaisa.value);
    }
    if (receiptDate.present) {
      map['receipt_date'] = Variable<DateTime>(receiptDate.value);
    }
    if (paymentMethod.present) {
      map['payment_method'] = Variable<String>(
          $ReceiptsTable.$converterpaymentMethod.toSql(paymentMethod.value));
    }
    if (bankAccountId.present) {
      map['bank_account_id'] = Variable<String>(bankAccountId.value);
    }
    if (referenceNo.present) {
      map['reference_no'] = Variable<String>(referenceNo.value);
    }
    if (evidencePath.present) {
      map['evidence_path'] = Variable<String>(evidencePath.value);
    }
    if (staffNotes.present) {
      map['staff_notes'] = Variable<String>(staffNotes.value);
    }
    if (donorNote.present) {
      map['donor_note'] = Variable<String>(donorNote.value);
    }
    if (createdBy.present) {
      map['created_by'] = Variable<String>(createdBy.value);
    }
    if (verifiedBy.present) {
      map['verified_by'] = Variable<String>(verifiedBy.value);
    }
    if (verifiedAt.present) {
      map['verified_at'] = Variable<DateTime>(verifiedAt.value);
    }
    if (voidReason.present) {
      map['void_reason'] = Variable<String>(voidReason.value);
    }
    if (replacedById.present) {
      map['replaced_by_id'] = Variable<String>(replacedById.value);
    }
    if (reversesId.present) {
      map['reverses_id'] = Variable<String>(reversesId.value);
    }
    if (idempotencyKey.present) {
      map['idempotency_key'] = Variable<String>(idempotencyKey.value);
    }
    if (serverAck.present) {
      map['server_ack'] = Variable<bool>(serverAck.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (serverUpdatedAt.present) {
      map['server_updated_at'] = Variable<DateTime>(serverUpdatedAt.value);
    }
    if (isDirty.present) {
      map['is_dirty'] = Variable<bool>(isDirty.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ReceiptsCompanion(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('officialNumber: $officialNumber, ')
          ..write('localProvisionalLabel: $localProvisionalLabel, ')
          ..write('status: $status, ')
          ..write('txType: $txType, ')
          ..write('donorId: $donorId, ')
          ..write('donorNameSnapshot: $donorNameSnapshot, ')
          ..write('isAnonymous: $isAnonymous, ')
          ..write('totalPaisa: $totalPaisa, ')
          ..write('receiptDate: $receiptDate, ')
          ..write('paymentMethod: $paymentMethod, ')
          ..write('bankAccountId: $bankAccountId, ')
          ..write('referenceNo: $referenceNo, ')
          ..write('evidencePath: $evidencePath, ')
          ..write('staffNotes: $staffNotes, ')
          ..write('donorNote: $donorNote, ')
          ..write('createdBy: $createdBy, ')
          ..write('verifiedBy: $verifiedBy, ')
          ..write('verifiedAt: $verifiedAt, ')
          ..write('voidReason: $voidReason, ')
          ..write('replacedById: $replacedById, ')
          ..write('reversesId: $reversesId, ')
          ..write('idempotencyKey: $idempotencyKey, ')
          ..write('serverAck: $serverAck, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('serverUpdatedAt: $serverUpdatedAt, ')
          ..write('isDirty: $isDirty, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $ReceiptAllocationsTable extends ReceiptAllocations
    with TableInfo<$ReceiptAllocationsTable, ReceiptAllocation> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ReceiptAllocationsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _receiptIdMeta =
      const VerificationMeta('receiptId');
  @override
  late final GeneratedColumn<String> receiptId = GeneratedColumn<String>(
      'receipt_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _fundTypeIdMeta =
      const VerificationMeta('fundTypeId');
  @override
  late final GeneratedColumn<String> fundTypeId = GeneratedColumn<String>(
      'fund_type_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _purposeIdMeta =
      const VerificationMeta('purposeId');
  @override
  late final GeneratedColumn<String> purposeId = GeneratedColumn<String>(
      'purpose_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _amountPaisaMeta =
      const VerificationMeta('amountPaisa');
  @override
  late final GeneratedColumn<int> amountPaisa = GeneratedColumn<int>(
      'amount_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns =>
      [id, receiptId, fundTypeId, purposeId, amountPaisa];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'receipt_allocations';
  @override
  VerificationContext validateIntegrity(Insertable<ReceiptAllocation> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('receipt_id')) {
      context.handle(_receiptIdMeta,
          receiptId.isAcceptableOrUnknown(data['receipt_id']!, _receiptIdMeta));
    } else if (isInserting) {
      context.missing(_receiptIdMeta);
    }
    if (data.containsKey('fund_type_id')) {
      context.handle(
          _fundTypeIdMeta,
          fundTypeId.isAcceptableOrUnknown(
              data['fund_type_id']!, _fundTypeIdMeta));
    } else if (isInserting) {
      context.missing(_fundTypeIdMeta);
    }
    if (data.containsKey('purpose_id')) {
      context.handle(_purposeIdMeta,
          purposeId.isAcceptableOrUnknown(data['purpose_id']!, _purposeIdMeta));
    }
    if (data.containsKey('amount_paisa')) {
      context.handle(
          _amountPaisaMeta,
          amountPaisa.isAcceptableOrUnknown(
              data['amount_paisa']!, _amountPaisaMeta));
    } else if (isInserting) {
      context.missing(_amountPaisaMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ReceiptAllocation map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ReceiptAllocation(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      receiptId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}receipt_id'])!,
      fundTypeId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}fund_type_id'])!,
      purposeId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}purpose_id']),
      amountPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}amount_paisa'])!,
    );
  }

  @override
  $ReceiptAllocationsTable createAlias(String alias) {
    return $ReceiptAllocationsTable(attachedDatabase, alias);
  }
}

class ReceiptAllocation extends DataClass
    implements Insertable<ReceiptAllocation> {
  final String id;
  final String receiptId;
  final String fundTypeId;
  final String? purposeId;
  final int amountPaisa;
  const ReceiptAllocation(
      {required this.id,
      required this.receiptId,
      required this.fundTypeId,
      this.purposeId,
      required this.amountPaisa});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['receipt_id'] = Variable<String>(receiptId);
    map['fund_type_id'] = Variable<String>(fundTypeId);
    if (!nullToAbsent || purposeId != null) {
      map['purpose_id'] = Variable<String>(purposeId);
    }
    map['amount_paisa'] = Variable<int>(amountPaisa);
    return map;
  }

  ReceiptAllocationsCompanion toCompanion(bool nullToAbsent) {
    return ReceiptAllocationsCompanion(
      id: Value(id),
      receiptId: Value(receiptId),
      fundTypeId: Value(fundTypeId),
      purposeId: purposeId == null && nullToAbsent
          ? const Value.absent()
          : Value(purposeId),
      amountPaisa: Value(amountPaisa),
    );
  }

  factory ReceiptAllocation.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ReceiptAllocation(
      id: serializer.fromJson<String>(json['id']),
      receiptId: serializer.fromJson<String>(json['receiptId']),
      fundTypeId: serializer.fromJson<String>(json['fundTypeId']),
      purposeId: serializer.fromJson<String?>(json['purposeId']),
      amountPaisa: serializer.fromJson<int>(json['amountPaisa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'receiptId': serializer.toJson<String>(receiptId),
      'fundTypeId': serializer.toJson<String>(fundTypeId),
      'purposeId': serializer.toJson<String?>(purposeId),
      'amountPaisa': serializer.toJson<int>(amountPaisa),
    };
  }

  ReceiptAllocation copyWith(
          {String? id,
          String? receiptId,
          String? fundTypeId,
          Value<String?> purposeId = const Value.absent(),
          int? amountPaisa}) =>
      ReceiptAllocation(
        id: id ?? this.id,
        receiptId: receiptId ?? this.receiptId,
        fundTypeId: fundTypeId ?? this.fundTypeId,
        purposeId: purposeId.present ? purposeId.value : this.purposeId,
        amountPaisa: amountPaisa ?? this.amountPaisa,
      );
  ReceiptAllocation copyWithCompanion(ReceiptAllocationsCompanion data) {
    return ReceiptAllocation(
      id: data.id.present ? data.id.value : this.id,
      receiptId: data.receiptId.present ? data.receiptId.value : this.receiptId,
      fundTypeId:
          data.fundTypeId.present ? data.fundTypeId.value : this.fundTypeId,
      purposeId: data.purposeId.present ? data.purposeId.value : this.purposeId,
      amountPaisa:
          data.amountPaisa.present ? data.amountPaisa.value : this.amountPaisa,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ReceiptAllocation(')
          ..write('id: $id, ')
          ..write('receiptId: $receiptId, ')
          ..write('fundTypeId: $fundTypeId, ')
          ..write('purposeId: $purposeId, ')
          ..write('amountPaisa: $amountPaisa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, receiptId, fundTypeId, purposeId, amountPaisa);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ReceiptAllocation &&
          other.id == this.id &&
          other.receiptId == this.receiptId &&
          other.fundTypeId == this.fundTypeId &&
          other.purposeId == this.purposeId &&
          other.amountPaisa == this.amountPaisa);
}

class ReceiptAllocationsCompanion extends UpdateCompanion<ReceiptAllocation> {
  final Value<String> id;
  final Value<String> receiptId;
  final Value<String> fundTypeId;
  final Value<String?> purposeId;
  final Value<int> amountPaisa;
  final Value<int> rowid;
  const ReceiptAllocationsCompanion({
    this.id = const Value.absent(),
    this.receiptId = const Value.absent(),
    this.fundTypeId = const Value.absent(),
    this.purposeId = const Value.absent(),
    this.amountPaisa = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ReceiptAllocationsCompanion.insert({
    required String id,
    required String receiptId,
    required String fundTypeId,
    this.purposeId = const Value.absent(),
    required int amountPaisa,
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        receiptId = Value(receiptId),
        fundTypeId = Value(fundTypeId),
        amountPaisa = Value(amountPaisa);
  static Insertable<ReceiptAllocation> custom({
    Expression<String>? id,
    Expression<String>? receiptId,
    Expression<String>? fundTypeId,
    Expression<String>? purposeId,
    Expression<int>? amountPaisa,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (receiptId != null) 'receipt_id': receiptId,
      if (fundTypeId != null) 'fund_type_id': fundTypeId,
      if (purposeId != null) 'purpose_id': purposeId,
      if (amountPaisa != null) 'amount_paisa': amountPaisa,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ReceiptAllocationsCompanion copyWith(
      {Value<String>? id,
      Value<String>? receiptId,
      Value<String>? fundTypeId,
      Value<String?>? purposeId,
      Value<int>? amountPaisa,
      Value<int>? rowid}) {
    return ReceiptAllocationsCompanion(
      id: id ?? this.id,
      receiptId: receiptId ?? this.receiptId,
      fundTypeId: fundTypeId ?? this.fundTypeId,
      purposeId: purposeId ?? this.purposeId,
      amountPaisa: amountPaisa ?? this.amountPaisa,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (receiptId.present) {
      map['receipt_id'] = Variable<String>(receiptId.value);
    }
    if (fundTypeId.present) {
      map['fund_type_id'] = Variable<String>(fundTypeId.value);
    }
    if (purposeId.present) {
      map['purpose_id'] = Variable<String>(purposeId.value);
    }
    if (amountPaisa.present) {
      map['amount_paisa'] = Variable<int>(amountPaisa.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ReceiptAllocationsCompanion(')
          ..write('id: $id, ')
          ..write('receiptId: $receiptId, ')
          ..write('fundTypeId: $fundTypeId, ')
          ..write('purposeId: $purposeId, ')
          ..write('amountPaisa: $amountPaisa, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $PaymentVerificationsTable extends PaymentVerifications
    with TableInfo<$PaymentVerificationsTable, PaymentVerification> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PaymentVerificationsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _receiptIdMeta =
      const VerificationMeta('receiptId');
  @override
  late final GeneratedColumn<String> receiptId = GeneratedColumn<String>(
      'receipt_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _verifiedByMeta =
      const VerificationMeta('verifiedBy');
  @override
  late final GeneratedColumn<String> verifiedBy = GeneratedColumn<String>(
      'verified_by', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _verifiedAtMeta =
      const VerificationMeta('verifiedAt');
  @override
  late final GeneratedColumn<DateTime> verifiedAt = GeneratedColumn<DateTime>(
      'verified_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _evidenceSummaryMeta =
      const VerificationMeta('evidenceSummary');
  @override
  late final GeneratedColumn<String> evidenceSummary = GeneratedColumn<String>(
      'evidence_summary', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _noteMeta = const VerificationMeta('note');
  @override
  late final GeneratedColumn<String> note = GeneratedColumn<String>(
      'note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, receiptId, verifiedBy, verifiedAt, evidenceSummary, note];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'payment_verifications';
  @override
  VerificationContext validateIntegrity(
      Insertable<PaymentVerification> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('receipt_id')) {
      context.handle(_receiptIdMeta,
          receiptId.isAcceptableOrUnknown(data['receipt_id']!, _receiptIdMeta));
    } else if (isInserting) {
      context.missing(_receiptIdMeta);
    }
    if (data.containsKey('verified_by')) {
      context.handle(
          _verifiedByMeta,
          verifiedBy.isAcceptableOrUnknown(
              data['verified_by']!, _verifiedByMeta));
    } else if (isInserting) {
      context.missing(_verifiedByMeta);
    }
    if (data.containsKey('verified_at')) {
      context.handle(
          _verifiedAtMeta,
          verifiedAt.isAcceptableOrUnknown(
              data['verified_at']!, _verifiedAtMeta));
    } else if (isInserting) {
      context.missing(_verifiedAtMeta);
    }
    if (data.containsKey('evidence_summary')) {
      context.handle(
          _evidenceSummaryMeta,
          evidenceSummary.isAcceptableOrUnknown(
              data['evidence_summary']!, _evidenceSummaryMeta));
    } else if (isInserting) {
      context.missing(_evidenceSummaryMeta);
    }
    if (data.containsKey('note')) {
      context.handle(
          _noteMeta, note.isAcceptableOrUnknown(data['note']!, _noteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PaymentVerification map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PaymentVerification(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      receiptId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}receipt_id'])!,
      verifiedBy: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}verified_by'])!,
      verifiedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}verified_at'])!,
      evidenceSummary: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}evidence_summary'])!,
      note: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}note']),
    );
  }

  @override
  $PaymentVerificationsTable createAlias(String alias) {
    return $PaymentVerificationsTable(attachedDatabase, alias);
  }
}

class PaymentVerification extends DataClass
    implements Insertable<PaymentVerification> {
  final String id;
  final String receiptId;
  final String verifiedBy;
  final DateTime verifiedAt;
  final String evidenceSummary;
  final String? note;
  const PaymentVerification(
      {required this.id,
      required this.receiptId,
      required this.verifiedBy,
      required this.verifiedAt,
      required this.evidenceSummary,
      this.note});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['receipt_id'] = Variable<String>(receiptId);
    map['verified_by'] = Variable<String>(verifiedBy);
    map['verified_at'] = Variable<DateTime>(verifiedAt);
    map['evidence_summary'] = Variable<String>(evidenceSummary);
    if (!nullToAbsent || note != null) {
      map['note'] = Variable<String>(note);
    }
    return map;
  }

  PaymentVerificationsCompanion toCompanion(bool nullToAbsent) {
    return PaymentVerificationsCompanion(
      id: Value(id),
      receiptId: Value(receiptId),
      verifiedBy: Value(verifiedBy),
      verifiedAt: Value(verifiedAt),
      evidenceSummary: Value(evidenceSummary),
      note: note == null && nullToAbsent ? const Value.absent() : Value(note),
    );
  }

  factory PaymentVerification.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PaymentVerification(
      id: serializer.fromJson<String>(json['id']),
      receiptId: serializer.fromJson<String>(json['receiptId']),
      verifiedBy: serializer.fromJson<String>(json['verifiedBy']),
      verifiedAt: serializer.fromJson<DateTime>(json['verifiedAt']),
      evidenceSummary: serializer.fromJson<String>(json['evidenceSummary']),
      note: serializer.fromJson<String?>(json['note']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'receiptId': serializer.toJson<String>(receiptId),
      'verifiedBy': serializer.toJson<String>(verifiedBy),
      'verifiedAt': serializer.toJson<DateTime>(verifiedAt),
      'evidenceSummary': serializer.toJson<String>(evidenceSummary),
      'note': serializer.toJson<String?>(note),
    };
  }

  PaymentVerification copyWith(
          {String? id,
          String? receiptId,
          String? verifiedBy,
          DateTime? verifiedAt,
          String? evidenceSummary,
          Value<String?> note = const Value.absent()}) =>
      PaymentVerification(
        id: id ?? this.id,
        receiptId: receiptId ?? this.receiptId,
        verifiedBy: verifiedBy ?? this.verifiedBy,
        verifiedAt: verifiedAt ?? this.verifiedAt,
        evidenceSummary: evidenceSummary ?? this.evidenceSummary,
        note: note.present ? note.value : this.note,
      );
  PaymentVerification copyWithCompanion(PaymentVerificationsCompanion data) {
    return PaymentVerification(
      id: data.id.present ? data.id.value : this.id,
      receiptId: data.receiptId.present ? data.receiptId.value : this.receiptId,
      verifiedBy:
          data.verifiedBy.present ? data.verifiedBy.value : this.verifiedBy,
      verifiedAt:
          data.verifiedAt.present ? data.verifiedAt.value : this.verifiedAt,
      evidenceSummary: data.evidenceSummary.present
          ? data.evidenceSummary.value
          : this.evidenceSummary,
      note: data.note.present ? data.note.value : this.note,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PaymentVerification(')
          ..write('id: $id, ')
          ..write('receiptId: $receiptId, ')
          ..write('verifiedBy: $verifiedBy, ')
          ..write('verifiedAt: $verifiedAt, ')
          ..write('evidenceSummary: $evidenceSummary, ')
          ..write('note: $note')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, receiptId, verifiedBy, verifiedAt, evidenceSummary, note);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PaymentVerification &&
          other.id == this.id &&
          other.receiptId == this.receiptId &&
          other.verifiedBy == this.verifiedBy &&
          other.verifiedAt == this.verifiedAt &&
          other.evidenceSummary == this.evidenceSummary &&
          other.note == this.note);
}

class PaymentVerificationsCompanion
    extends UpdateCompanion<PaymentVerification> {
  final Value<String> id;
  final Value<String> receiptId;
  final Value<String> verifiedBy;
  final Value<DateTime> verifiedAt;
  final Value<String> evidenceSummary;
  final Value<String?> note;
  final Value<int> rowid;
  const PaymentVerificationsCompanion({
    this.id = const Value.absent(),
    this.receiptId = const Value.absent(),
    this.verifiedBy = const Value.absent(),
    this.verifiedAt = const Value.absent(),
    this.evidenceSummary = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  PaymentVerificationsCompanion.insert({
    required String id,
    required String receiptId,
    required String verifiedBy,
    required DateTime verifiedAt,
    required String evidenceSummary,
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        receiptId = Value(receiptId),
        verifiedBy = Value(verifiedBy),
        verifiedAt = Value(verifiedAt),
        evidenceSummary = Value(evidenceSummary);
  static Insertable<PaymentVerification> custom({
    Expression<String>? id,
    Expression<String>? receiptId,
    Expression<String>? verifiedBy,
    Expression<DateTime>? verifiedAt,
    Expression<String>? evidenceSummary,
    Expression<String>? note,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (receiptId != null) 'receipt_id': receiptId,
      if (verifiedBy != null) 'verified_by': verifiedBy,
      if (verifiedAt != null) 'verified_at': verifiedAt,
      if (evidenceSummary != null) 'evidence_summary': evidenceSummary,
      if (note != null) 'note': note,
      if (rowid != null) 'rowid': rowid,
    });
  }

  PaymentVerificationsCompanion copyWith(
      {Value<String>? id,
      Value<String>? receiptId,
      Value<String>? verifiedBy,
      Value<DateTime>? verifiedAt,
      Value<String>? evidenceSummary,
      Value<String?>? note,
      Value<int>? rowid}) {
    return PaymentVerificationsCompanion(
      id: id ?? this.id,
      receiptId: receiptId ?? this.receiptId,
      verifiedBy: verifiedBy ?? this.verifiedBy,
      verifiedAt: verifiedAt ?? this.verifiedAt,
      evidenceSummary: evidenceSummary ?? this.evidenceSummary,
      note: note ?? this.note,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (receiptId.present) {
      map['receipt_id'] = Variable<String>(receiptId.value);
    }
    if (verifiedBy.present) {
      map['verified_by'] = Variable<String>(verifiedBy.value);
    }
    if (verifiedAt.present) {
      map['verified_at'] = Variable<DateTime>(verifiedAt.value);
    }
    if (evidenceSummary.present) {
      map['evidence_summary'] = Variable<String>(evidenceSummary.value);
    }
    if (note.present) {
      map['note'] = Variable<String>(note.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PaymentVerificationsCompanion(')
          ..write('id: $id, ')
          ..write('receiptId: $receiptId, ')
          ..write('verifiedBy: $verifiedBy, ')
          ..write('verifiedAt: $verifiedAt, ')
          ..write('evidenceSummary: $evidenceSummary, ')
          ..write('note: $note, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $ReceiptSequencesTable extends ReceiptSequences
    with TableInfo<$ReceiptSequencesTable, ReceiptSequence> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ReceiptSequencesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _institutionIdMeta =
      const VerificationMeta('institutionId');
  @override
  late final GeneratedColumn<String> institutionId = GeneratedColumn<String>(
      'institution_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _prefixMeta = const VerificationMeta('prefix');
  @override
  late final GeneratedColumn<String> prefix = GeneratedColumn<String>(
      'prefix', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _yearMeta = const VerificationMeta('year');
  @override
  late final GeneratedColumn<int> year = GeneratedColumn<int>(
      'year', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _lastNumberMeta =
      const VerificationMeta('lastNumber');
  @override
  late final GeneratedColumn<int> lastNumber = GeneratedColumn<int>(
      'last_number', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns =>
      [id, institutionId, prefix, year, lastNumber, updatedAt];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'receipt_sequences';
  @override
  VerificationContext validateIntegrity(Insertable<ReceiptSequence> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('institution_id')) {
      context.handle(
          _institutionIdMeta,
          institutionId.isAcceptableOrUnknown(
              data['institution_id']!, _institutionIdMeta));
    } else if (isInserting) {
      context.missing(_institutionIdMeta);
    }
    if (data.containsKey('prefix')) {
      context.handle(_prefixMeta,
          prefix.isAcceptableOrUnknown(data['prefix']!, _prefixMeta));
    } else if (isInserting) {
      context.missing(_prefixMeta);
    }
    if (data.containsKey('year')) {
      context.handle(
          _yearMeta, year.isAcceptableOrUnknown(data['year']!, _yearMeta));
    } else if (isInserting) {
      context.missing(_yearMeta);
    }
    if (data.containsKey('last_number')) {
      context.handle(
          _lastNumberMeta,
          lastNumber.isAcceptableOrUnknown(
              data['last_number']!, _lastNumberMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    } else if (isInserting) {
      context.missing(_updatedAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ReceiptSequence map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ReceiptSequence(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      institutionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}institution_id'])!,
      prefix: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}prefix'])!,
      year: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}year'])!,
      lastNumber: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}last_number'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $ReceiptSequencesTable createAlias(String alias) {
    return $ReceiptSequencesTable(attachedDatabase, alias);
  }
}

class ReceiptSequence extends DataClass implements Insertable<ReceiptSequence> {
  final String id;
  final String institutionId;
  final String prefix;
  final int year;
  final int lastNumber;
  final DateTime updatedAt;
  const ReceiptSequence(
      {required this.id,
      required this.institutionId,
      required this.prefix,
      required this.year,
      required this.lastNumber,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['institution_id'] = Variable<String>(institutionId);
    map['prefix'] = Variable<String>(prefix);
    map['year'] = Variable<int>(year);
    map['last_number'] = Variable<int>(lastNumber);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  ReceiptSequencesCompanion toCompanion(bool nullToAbsent) {
    return ReceiptSequencesCompanion(
      id: Value(id),
      institutionId: Value(institutionId),
      prefix: Value(prefix),
      year: Value(year),
      lastNumber: Value(lastNumber),
      updatedAt: Value(updatedAt),
    );
  }

  factory ReceiptSequence.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ReceiptSequence(
      id: serializer.fromJson<String>(json['id']),
      institutionId: serializer.fromJson<String>(json['institutionId']),
      prefix: serializer.fromJson<String>(json['prefix']),
      year: serializer.fromJson<int>(json['year']),
      lastNumber: serializer.fromJson<int>(json['lastNumber']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'institutionId': serializer.toJson<String>(institutionId),
      'prefix': serializer.toJson<String>(prefix),
      'year': serializer.toJson<int>(year),
      'lastNumber': serializer.toJson<int>(lastNumber),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  ReceiptSequence copyWith(
          {String? id,
          String? institutionId,
          String? prefix,
          int? year,
          int? lastNumber,
          DateTime? updatedAt}) =>
      ReceiptSequence(
        id: id ?? this.id,
        institutionId: institutionId ?? this.institutionId,
        prefix: prefix ?? this.prefix,
        year: year ?? this.year,
        lastNumber: lastNumber ?? this.lastNumber,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  ReceiptSequence copyWithCompanion(ReceiptSequencesCompanion data) {
    return ReceiptSequence(
      id: data.id.present ? data.id.value : this.id,
      institutionId: data.institutionId.present
          ? data.institutionId.value
          : this.institutionId,
      prefix: data.prefix.present ? data.prefix.value : this.prefix,
      year: data.year.present ? data.year.value : this.year,
      lastNumber:
          data.lastNumber.present ? data.lastNumber.value : this.lastNumber,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ReceiptSequence(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('prefix: $prefix, ')
          ..write('year: $year, ')
          ..write('lastNumber: $lastNumber, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, institutionId, prefix, year, lastNumber, updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ReceiptSequence &&
          other.id == this.id &&
          other.institutionId == this.institutionId &&
          other.prefix == this.prefix &&
          other.year == this.year &&
          other.lastNumber == this.lastNumber &&
          other.updatedAt == this.updatedAt);
}

class ReceiptSequencesCompanion extends UpdateCompanion<ReceiptSequence> {
  final Value<String> id;
  final Value<String> institutionId;
  final Value<String> prefix;
  final Value<int> year;
  final Value<int> lastNumber;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const ReceiptSequencesCompanion({
    this.id = const Value.absent(),
    this.institutionId = const Value.absent(),
    this.prefix = const Value.absent(),
    this.year = const Value.absent(),
    this.lastNumber = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ReceiptSequencesCompanion.insert({
    required String id,
    required String institutionId,
    required String prefix,
    required int year,
    this.lastNumber = const Value.absent(),
    required DateTime updatedAt,
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        institutionId = Value(institutionId),
        prefix = Value(prefix),
        year = Value(year),
        updatedAt = Value(updatedAt);
  static Insertable<ReceiptSequence> custom({
    Expression<String>? id,
    Expression<String>? institutionId,
    Expression<String>? prefix,
    Expression<int>? year,
    Expression<int>? lastNumber,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (institutionId != null) 'institution_id': institutionId,
      if (prefix != null) 'prefix': prefix,
      if (year != null) 'year': year,
      if (lastNumber != null) 'last_number': lastNumber,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ReceiptSequencesCompanion copyWith(
      {Value<String>? id,
      Value<String>? institutionId,
      Value<String>? prefix,
      Value<int>? year,
      Value<int>? lastNumber,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return ReceiptSequencesCompanion(
      id: id ?? this.id,
      institutionId: institutionId ?? this.institutionId,
      prefix: prefix ?? this.prefix,
      year: year ?? this.year,
      lastNumber: lastNumber ?? this.lastNumber,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (institutionId.present) {
      map['institution_id'] = Variable<String>(institutionId.value);
    }
    if (prefix.present) {
      map['prefix'] = Variable<String>(prefix.value);
    }
    if (year.present) {
      map['year'] = Variable<int>(year.value);
    }
    if (lastNumber.present) {
      map['last_number'] = Variable<int>(lastNumber.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ReceiptSequencesCompanion(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('prefix: $prefix, ')
          ..write('year: $year, ')
          ..write('lastNumber: $lastNumber, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $ExpenseVouchersTable extends ExpenseVouchers
    with TableInfo<$ExpenseVouchersTable, ExpenseVoucher> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ExpenseVouchersTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _institutionIdMeta =
      const VerificationMeta('institutionId');
  @override
  late final GeneratedColumn<String> institutionId = GeneratedColumn<String>(
      'institution_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _voucherNumberMeta =
      const VerificationMeta('voucherNumber');
  @override
  late final GeneratedColumn<String> voucherNumber = GeneratedColumn<String>(
      'voucher_number', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _voucherDateMeta =
      const VerificationMeta('voucherDate');
  @override
  late final GeneratedColumn<DateTime> voucherDate = GeneratedColumn<DateTime>(
      'voucher_date', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _payeeMeta = const VerificationMeta('payee');
  @override
  late final GeneratedColumn<String> payee = GeneratedColumn<String>(
      'payee', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _descriptionMeta =
      const VerificationMeta('description');
  @override
  late final GeneratedColumn<String> description = GeneratedColumn<String>(
      'description', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _totalPaisaMeta =
      const VerificationMeta('totalPaisa');
  @override
  late final GeneratedColumn<int> totalPaisa = GeneratedColumn<int>(
      'total_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  @override
  late final GeneratedColumnWithTypeConverter<PaymentMethod, String>
      paymentMethod = GeneratedColumn<String>(
              'payment_method', aliasedName, false,
              type: DriftSqlType.string, requiredDuringInsert: true)
          .withConverter<PaymentMethod>(
              $ExpenseVouchersTable.$converterpaymentMethod);
  static const VerificationMeta _bankAccountIdMeta =
      const VerificationMeta('bankAccountId');
  @override
  late final GeneratedColumn<String> bankAccountId = GeneratedColumn<String>(
      'bank_account_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _attachmentPathMeta =
      const VerificationMeta('attachmentPath');
  @override
  late final GeneratedColumn<String> attachmentPath = GeneratedColumn<String>(
      'attachment_path', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  late final GeneratedColumnWithTypeConverter<ExpenseStatus, String> status =
      GeneratedColumn<String>('status', aliasedName, false,
              type: DriftSqlType.string, requiredDuringInsert: true)
          .withConverter<ExpenseStatus>($ExpenseVouchersTable.$converterstatus);
  static const VerificationMeta _createdByMeta =
      const VerificationMeta('createdBy');
  @override
  late final GeneratedColumn<String> createdBy = GeneratedColumn<String>(
      'created_by', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _approvedByMeta =
      const VerificationMeta('approvedBy');
  @override
  late final GeneratedColumn<String> approvedBy = GeneratedColumn<String>(
      'approved_by', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _approvedAtMeta =
      const VerificationMeta('approvedAt');
  @override
  late final GeneratedColumn<DateTime> approvedAt = GeneratedColumn<DateTime>(
      'approved_at', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _rejectionReasonMeta =
      const VerificationMeta('rejectionReason');
  @override
  late final GeneratedColumn<String> rejectionReason = GeneratedColumn<String>(
      'rejection_reason', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _idempotencyKeyMeta =
      const VerificationMeta('idempotencyKey');
  @override
  late final GeneratedColumn<String> idempotencyKey = GeneratedColumn<String>(
      'idempotency_key', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: true,
      defaultConstraints: GeneratedColumn.constraintIsAlways('UNIQUE'));
  static const VerificationMeta _serverAckMeta =
      const VerificationMeta('serverAck');
  @override
  late final GeneratedColumn<bool> serverAck = GeneratedColumn<bool>(
      'server_ack', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("server_ack" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _serverUpdatedAtMeta =
      const VerificationMeta('serverUpdatedAt');
  @override
  late final GeneratedColumn<DateTime> serverUpdatedAt =
      GeneratedColumn<DateTime>('server_updated_at', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _isDirtyMeta =
      const VerificationMeta('isDirty');
  @override
  late final GeneratedColumn<bool> isDirty = GeneratedColumn<bool>(
      'is_dirty', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_dirty" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        id,
        institutionId,
        voucherNumber,
        voucherDate,
        payee,
        description,
        totalPaisa,
        paymentMethod,
        bankAccountId,
        attachmentPath,
        status,
        createdBy,
        approvedBy,
        approvedAt,
        rejectionReason,
        idempotencyKey,
        serverAck,
        createdAt,
        updatedAt,
        serverUpdatedAt,
        isDirty
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'expense_vouchers';
  @override
  VerificationContext validateIntegrity(Insertable<ExpenseVoucher> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('institution_id')) {
      context.handle(
          _institutionIdMeta,
          institutionId.isAcceptableOrUnknown(
              data['institution_id']!, _institutionIdMeta));
    } else if (isInserting) {
      context.missing(_institutionIdMeta);
    }
    if (data.containsKey('voucher_number')) {
      context.handle(
          _voucherNumberMeta,
          voucherNumber.isAcceptableOrUnknown(
              data['voucher_number']!, _voucherNumberMeta));
    } else if (isInserting) {
      context.missing(_voucherNumberMeta);
    }
    if (data.containsKey('voucher_date')) {
      context.handle(
          _voucherDateMeta,
          voucherDate.isAcceptableOrUnknown(
              data['voucher_date']!, _voucherDateMeta));
    } else if (isInserting) {
      context.missing(_voucherDateMeta);
    }
    if (data.containsKey('payee')) {
      context.handle(
          _payeeMeta, payee.isAcceptableOrUnknown(data['payee']!, _payeeMeta));
    } else if (isInserting) {
      context.missing(_payeeMeta);
    }
    if (data.containsKey('description')) {
      context.handle(
          _descriptionMeta,
          description.isAcceptableOrUnknown(
              data['description']!, _descriptionMeta));
    } else if (isInserting) {
      context.missing(_descriptionMeta);
    }
    if (data.containsKey('total_paisa')) {
      context.handle(
          _totalPaisaMeta,
          totalPaisa.isAcceptableOrUnknown(
              data['total_paisa']!, _totalPaisaMeta));
    } else if (isInserting) {
      context.missing(_totalPaisaMeta);
    }
    if (data.containsKey('bank_account_id')) {
      context.handle(
          _bankAccountIdMeta,
          bankAccountId.isAcceptableOrUnknown(
              data['bank_account_id']!, _bankAccountIdMeta));
    }
    if (data.containsKey('attachment_path')) {
      context.handle(
          _attachmentPathMeta,
          attachmentPath.isAcceptableOrUnknown(
              data['attachment_path']!, _attachmentPathMeta));
    }
    if (data.containsKey('created_by')) {
      context.handle(_createdByMeta,
          createdBy.isAcceptableOrUnknown(data['created_by']!, _createdByMeta));
    }
    if (data.containsKey('approved_by')) {
      context.handle(
          _approvedByMeta,
          approvedBy.isAcceptableOrUnknown(
              data['approved_by']!, _approvedByMeta));
    }
    if (data.containsKey('approved_at')) {
      context.handle(
          _approvedAtMeta,
          approvedAt.isAcceptableOrUnknown(
              data['approved_at']!, _approvedAtMeta));
    }
    if (data.containsKey('rejection_reason')) {
      context.handle(
          _rejectionReasonMeta,
          rejectionReason.isAcceptableOrUnknown(
              data['rejection_reason']!, _rejectionReasonMeta));
    }
    if (data.containsKey('idempotency_key')) {
      context.handle(
          _idempotencyKeyMeta,
          idempotencyKey.isAcceptableOrUnknown(
              data['idempotency_key']!, _idempotencyKeyMeta));
    } else if (isInserting) {
      context.missing(_idempotencyKeyMeta);
    }
    if (data.containsKey('server_ack')) {
      context.handle(_serverAckMeta,
          serverAck.isAcceptableOrUnknown(data['server_ack']!, _serverAckMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    } else if (isInserting) {
      context.missing(_updatedAtMeta);
    }
    if (data.containsKey('server_updated_at')) {
      context.handle(
          _serverUpdatedAtMeta,
          serverUpdatedAt.isAcceptableOrUnknown(
              data['server_updated_at']!, _serverUpdatedAtMeta));
    }
    if (data.containsKey('is_dirty')) {
      context.handle(_isDirtyMeta,
          isDirty.isAcceptableOrUnknown(data['is_dirty']!, _isDirtyMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ExpenseVoucher map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ExpenseVoucher(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      institutionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}institution_id'])!,
      voucherNumber: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}voucher_number'])!,
      voucherDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}voucher_date'])!,
      payee: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}payee'])!,
      description: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}description'])!,
      totalPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}total_paisa'])!,
      paymentMethod: $ExpenseVouchersTable.$converterpaymentMethod.fromSql(
          attachedDatabase.typeMapping.read(
              DriftSqlType.string, data['${effectivePrefix}payment_method'])!),
      bankAccountId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bank_account_id']),
      attachmentPath: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}attachment_path']),
      status: $ExpenseVouchersTable.$converterstatus.fromSql(attachedDatabase
          .typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status'])!),
      createdBy: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_by']),
      approvedBy: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}approved_by']),
      approvedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}approved_at']),
      rejectionReason: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}rejection_reason']),
      idempotencyKey: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}idempotency_key'])!,
      serverAck: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}server_ack'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
      serverUpdatedAt: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}server_updated_at']),
      isDirty: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_dirty'])!,
    );
  }

  @override
  $ExpenseVouchersTable createAlias(String alias) {
    return $ExpenseVouchersTable(attachedDatabase, alias);
  }

  static JsonTypeConverter2<PaymentMethod, String, String>
      $converterpaymentMethod =
      const EnumNameConverter<PaymentMethod>(PaymentMethod.values);
  static JsonTypeConverter2<ExpenseStatus, String, String> $converterstatus =
      const EnumNameConverter<ExpenseStatus>(ExpenseStatus.values);
}

class ExpenseVoucher extends DataClass implements Insertable<ExpenseVoucher> {
  final String id;
  final String institutionId;
  final String voucherNumber;
  final DateTime voucherDate;
  final String payee;
  final String description;
  final int totalPaisa;
  final PaymentMethod paymentMethod;
  final String? bankAccountId;
  final String? attachmentPath;
  final ExpenseStatus status;
  final String? createdBy;
  final String? approvedBy;
  final DateTime? approvedAt;
  final String? rejectionReason;
  final String idempotencyKey;
  final bool serverAck;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? serverUpdatedAt;
  final bool isDirty;
  const ExpenseVoucher(
      {required this.id,
      required this.institutionId,
      required this.voucherNumber,
      required this.voucherDate,
      required this.payee,
      required this.description,
      required this.totalPaisa,
      required this.paymentMethod,
      this.bankAccountId,
      this.attachmentPath,
      required this.status,
      this.createdBy,
      this.approvedBy,
      this.approvedAt,
      this.rejectionReason,
      required this.idempotencyKey,
      required this.serverAck,
      required this.createdAt,
      required this.updatedAt,
      this.serverUpdatedAt,
      required this.isDirty});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['institution_id'] = Variable<String>(institutionId);
    map['voucher_number'] = Variable<String>(voucherNumber);
    map['voucher_date'] = Variable<DateTime>(voucherDate);
    map['payee'] = Variable<String>(payee);
    map['description'] = Variable<String>(description);
    map['total_paisa'] = Variable<int>(totalPaisa);
    {
      map['payment_method'] = Variable<String>(
          $ExpenseVouchersTable.$converterpaymentMethod.toSql(paymentMethod));
    }
    if (!nullToAbsent || bankAccountId != null) {
      map['bank_account_id'] = Variable<String>(bankAccountId);
    }
    if (!nullToAbsent || attachmentPath != null) {
      map['attachment_path'] = Variable<String>(attachmentPath);
    }
    {
      map['status'] = Variable<String>(
          $ExpenseVouchersTable.$converterstatus.toSql(status));
    }
    if (!nullToAbsent || createdBy != null) {
      map['created_by'] = Variable<String>(createdBy);
    }
    if (!nullToAbsent || approvedBy != null) {
      map['approved_by'] = Variable<String>(approvedBy);
    }
    if (!nullToAbsent || approvedAt != null) {
      map['approved_at'] = Variable<DateTime>(approvedAt);
    }
    if (!nullToAbsent || rejectionReason != null) {
      map['rejection_reason'] = Variable<String>(rejectionReason);
    }
    map['idempotency_key'] = Variable<String>(idempotencyKey);
    map['server_ack'] = Variable<bool>(serverAck);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    if (!nullToAbsent || serverUpdatedAt != null) {
      map['server_updated_at'] = Variable<DateTime>(serverUpdatedAt);
    }
    map['is_dirty'] = Variable<bool>(isDirty);
    return map;
  }

  ExpenseVouchersCompanion toCompanion(bool nullToAbsent) {
    return ExpenseVouchersCompanion(
      id: Value(id),
      institutionId: Value(institutionId),
      voucherNumber: Value(voucherNumber),
      voucherDate: Value(voucherDate),
      payee: Value(payee),
      description: Value(description),
      totalPaisa: Value(totalPaisa),
      paymentMethod: Value(paymentMethod),
      bankAccountId: bankAccountId == null && nullToAbsent
          ? const Value.absent()
          : Value(bankAccountId),
      attachmentPath: attachmentPath == null && nullToAbsent
          ? const Value.absent()
          : Value(attachmentPath),
      status: Value(status),
      createdBy: createdBy == null && nullToAbsent
          ? const Value.absent()
          : Value(createdBy),
      approvedBy: approvedBy == null && nullToAbsent
          ? const Value.absent()
          : Value(approvedBy),
      approvedAt: approvedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(approvedAt),
      rejectionReason: rejectionReason == null && nullToAbsent
          ? const Value.absent()
          : Value(rejectionReason),
      idempotencyKey: Value(idempotencyKey),
      serverAck: Value(serverAck),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      serverUpdatedAt: serverUpdatedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(serverUpdatedAt),
      isDirty: Value(isDirty),
    );
  }

  factory ExpenseVoucher.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ExpenseVoucher(
      id: serializer.fromJson<String>(json['id']),
      institutionId: serializer.fromJson<String>(json['institutionId']),
      voucherNumber: serializer.fromJson<String>(json['voucherNumber']),
      voucherDate: serializer.fromJson<DateTime>(json['voucherDate']),
      payee: serializer.fromJson<String>(json['payee']),
      description: serializer.fromJson<String>(json['description']),
      totalPaisa: serializer.fromJson<int>(json['totalPaisa']),
      paymentMethod: $ExpenseVouchersTable.$converterpaymentMethod
          .fromJson(serializer.fromJson<String>(json['paymentMethod'])),
      bankAccountId: serializer.fromJson<String?>(json['bankAccountId']),
      attachmentPath: serializer.fromJson<String?>(json['attachmentPath']),
      status: $ExpenseVouchersTable.$converterstatus
          .fromJson(serializer.fromJson<String>(json['status'])),
      createdBy: serializer.fromJson<String?>(json['createdBy']),
      approvedBy: serializer.fromJson<String?>(json['approvedBy']),
      approvedAt: serializer.fromJson<DateTime?>(json['approvedAt']),
      rejectionReason: serializer.fromJson<String?>(json['rejectionReason']),
      idempotencyKey: serializer.fromJson<String>(json['idempotencyKey']),
      serverAck: serializer.fromJson<bool>(json['serverAck']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
      serverUpdatedAt: serializer.fromJson<DateTime?>(json['serverUpdatedAt']),
      isDirty: serializer.fromJson<bool>(json['isDirty']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'institutionId': serializer.toJson<String>(institutionId),
      'voucherNumber': serializer.toJson<String>(voucherNumber),
      'voucherDate': serializer.toJson<DateTime>(voucherDate),
      'payee': serializer.toJson<String>(payee),
      'description': serializer.toJson<String>(description),
      'totalPaisa': serializer.toJson<int>(totalPaisa),
      'paymentMethod': serializer.toJson<String>(
          $ExpenseVouchersTable.$converterpaymentMethod.toJson(paymentMethod)),
      'bankAccountId': serializer.toJson<String?>(bankAccountId),
      'attachmentPath': serializer.toJson<String?>(attachmentPath),
      'status': serializer.toJson<String>(
          $ExpenseVouchersTable.$converterstatus.toJson(status)),
      'createdBy': serializer.toJson<String?>(createdBy),
      'approvedBy': serializer.toJson<String?>(approvedBy),
      'approvedAt': serializer.toJson<DateTime?>(approvedAt),
      'rejectionReason': serializer.toJson<String?>(rejectionReason),
      'idempotencyKey': serializer.toJson<String>(idempotencyKey),
      'serverAck': serializer.toJson<bool>(serverAck),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
      'serverUpdatedAt': serializer.toJson<DateTime?>(serverUpdatedAt),
      'isDirty': serializer.toJson<bool>(isDirty),
    };
  }

  ExpenseVoucher copyWith(
          {String? id,
          String? institutionId,
          String? voucherNumber,
          DateTime? voucherDate,
          String? payee,
          String? description,
          int? totalPaisa,
          PaymentMethod? paymentMethod,
          Value<String?> bankAccountId = const Value.absent(),
          Value<String?> attachmentPath = const Value.absent(),
          ExpenseStatus? status,
          Value<String?> createdBy = const Value.absent(),
          Value<String?> approvedBy = const Value.absent(),
          Value<DateTime?> approvedAt = const Value.absent(),
          Value<String?> rejectionReason = const Value.absent(),
          String? idempotencyKey,
          bool? serverAck,
          DateTime? createdAt,
          DateTime? updatedAt,
          Value<DateTime?> serverUpdatedAt = const Value.absent(),
          bool? isDirty}) =>
      ExpenseVoucher(
        id: id ?? this.id,
        institutionId: institutionId ?? this.institutionId,
        voucherNumber: voucherNumber ?? this.voucherNumber,
        voucherDate: voucherDate ?? this.voucherDate,
        payee: payee ?? this.payee,
        description: description ?? this.description,
        totalPaisa: totalPaisa ?? this.totalPaisa,
        paymentMethod: paymentMethod ?? this.paymentMethod,
        bankAccountId:
            bankAccountId.present ? bankAccountId.value : this.bankAccountId,
        attachmentPath:
            attachmentPath.present ? attachmentPath.value : this.attachmentPath,
        status: status ?? this.status,
        createdBy: createdBy.present ? createdBy.value : this.createdBy,
        approvedBy: approvedBy.present ? approvedBy.value : this.approvedBy,
        approvedAt: approvedAt.present ? approvedAt.value : this.approvedAt,
        rejectionReason: rejectionReason.present
            ? rejectionReason.value
            : this.rejectionReason,
        idempotencyKey: idempotencyKey ?? this.idempotencyKey,
        serverAck: serverAck ?? this.serverAck,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        serverUpdatedAt: serverUpdatedAt.present
            ? serverUpdatedAt.value
            : this.serverUpdatedAt,
        isDirty: isDirty ?? this.isDirty,
      );
  ExpenseVoucher copyWithCompanion(ExpenseVouchersCompanion data) {
    return ExpenseVoucher(
      id: data.id.present ? data.id.value : this.id,
      institutionId: data.institutionId.present
          ? data.institutionId.value
          : this.institutionId,
      voucherNumber: data.voucherNumber.present
          ? data.voucherNumber.value
          : this.voucherNumber,
      voucherDate:
          data.voucherDate.present ? data.voucherDate.value : this.voucherDate,
      payee: data.payee.present ? data.payee.value : this.payee,
      description:
          data.description.present ? data.description.value : this.description,
      totalPaisa:
          data.totalPaisa.present ? data.totalPaisa.value : this.totalPaisa,
      paymentMethod: data.paymentMethod.present
          ? data.paymentMethod.value
          : this.paymentMethod,
      bankAccountId: data.bankAccountId.present
          ? data.bankAccountId.value
          : this.bankAccountId,
      attachmentPath: data.attachmentPath.present
          ? data.attachmentPath.value
          : this.attachmentPath,
      status: data.status.present ? data.status.value : this.status,
      createdBy: data.createdBy.present ? data.createdBy.value : this.createdBy,
      approvedBy:
          data.approvedBy.present ? data.approvedBy.value : this.approvedBy,
      approvedAt:
          data.approvedAt.present ? data.approvedAt.value : this.approvedAt,
      rejectionReason: data.rejectionReason.present
          ? data.rejectionReason.value
          : this.rejectionReason,
      idempotencyKey: data.idempotencyKey.present
          ? data.idempotencyKey.value
          : this.idempotencyKey,
      serverAck: data.serverAck.present ? data.serverAck.value : this.serverAck,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      serverUpdatedAt: data.serverUpdatedAt.present
          ? data.serverUpdatedAt.value
          : this.serverUpdatedAt,
      isDirty: data.isDirty.present ? data.isDirty.value : this.isDirty,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ExpenseVoucher(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('voucherNumber: $voucherNumber, ')
          ..write('voucherDate: $voucherDate, ')
          ..write('payee: $payee, ')
          ..write('description: $description, ')
          ..write('totalPaisa: $totalPaisa, ')
          ..write('paymentMethod: $paymentMethod, ')
          ..write('bankAccountId: $bankAccountId, ')
          ..write('attachmentPath: $attachmentPath, ')
          ..write('status: $status, ')
          ..write('createdBy: $createdBy, ')
          ..write('approvedBy: $approvedBy, ')
          ..write('approvedAt: $approvedAt, ')
          ..write('rejectionReason: $rejectionReason, ')
          ..write('idempotencyKey: $idempotencyKey, ')
          ..write('serverAck: $serverAck, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('serverUpdatedAt: $serverUpdatedAt, ')
          ..write('isDirty: $isDirty')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        institutionId,
        voucherNumber,
        voucherDate,
        payee,
        description,
        totalPaisa,
        paymentMethod,
        bankAccountId,
        attachmentPath,
        status,
        createdBy,
        approvedBy,
        approvedAt,
        rejectionReason,
        idempotencyKey,
        serverAck,
        createdAt,
        updatedAt,
        serverUpdatedAt,
        isDirty
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ExpenseVoucher &&
          other.id == this.id &&
          other.institutionId == this.institutionId &&
          other.voucherNumber == this.voucherNumber &&
          other.voucherDate == this.voucherDate &&
          other.payee == this.payee &&
          other.description == this.description &&
          other.totalPaisa == this.totalPaisa &&
          other.paymentMethod == this.paymentMethod &&
          other.bankAccountId == this.bankAccountId &&
          other.attachmentPath == this.attachmentPath &&
          other.status == this.status &&
          other.createdBy == this.createdBy &&
          other.approvedBy == this.approvedBy &&
          other.approvedAt == this.approvedAt &&
          other.rejectionReason == this.rejectionReason &&
          other.idempotencyKey == this.idempotencyKey &&
          other.serverAck == this.serverAck &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.serverUpdatedAt == this.serverUpdatedAt &&
          other.isDirty == this.isDirty);
}

class ExpenseVouchersCompanion extends UpdateCompanion<ExpenseVoucher> {
  final Value<String> id;
  final Value<String> institutionId;
  final Value<String> voucherNumber;
  final Value<DateTime> voucherDate;
  final Value<String> payee;
  final Value<String> description;
  final Value<int> totalPaisa;
  final Value<PaymentMethod> paymentMethod;
  final Value<String?> bankAccountId;
  final Value<String?> attachmentPath;
  final Value<ExpenseStatus> status;
  final Value<String?> createdBy;
  final Value<String?> approvedBy;
  final Value<DateTime?> approvedAt;
  final Value<String?> rejectionReason;
  final Value<String> idempotencyKey;
  final Value<bool> serverAck;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<DateTime?> serverUpdatedAt;
  final Value<bool> isDirty;
  final Value<int> rowid;
  const ExpenseVouchersCompanion({
    this.id = const Value.absent(),
    this.institutionId = const Value.absent(),
    this.voucherNumber = const Value.absent(),
    this.voucherDate = const Value.absent(),
    this.payee = const Value.absent(),
    this.description = const Value.absent(),
    this.totalPaisa = const Value.absent(),
    this.paymentMethod = const Value.absent(),
    this.bankAccountId = const Value.absent(),
    this.attachmentPath = const Value.absent(),
    this.status = const Value.absent(),
    this.createdBy = const Value.absent(),
    this.approvedBy = const Value.absent(),
    this.approvedAt = const Value.absent(),
    this.rejectionReason = const Value.absent(),
    this.idempotencyKey = const Value.absent(),
    this.serverAck = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.serverUpdatedAt = const Value.absent(),
    this.isDirty = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ExpenseVouchersCompanion.insert({
    required String id,
    required String institutionId,
    required String voucherNumber,
    required DateTime voucherDate,
    required String payee,
    required String description,
    required int totalPaisa,
    required PaymentMethod paymentMethod,
    this.bankAccountId = const Value.absent(),
    this.attachmentPath = const Value.absent(),
    required ExpenseStatus status,
    this.createdBy = const Value.absent(),
    this.approvedBy = const Value.absent(),
    this.approvedAt = const Value.absent(),
    this.rejectionReason = const Value.absent(),
    required String idempotencyKey,
    this.serverAck = const Value.absent(),
    required DateTime createdAt,
    required DateTime updatedAt,
    this.serverUpdatedAt = const Value.absent(),
    this.isDirty = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        institutionId = Value(institutionId),
        voucherNumber = Value(voucherNumber),
        voucherDate = Value(voucherDate),
        payee = Value(payee),
        description = Value(description),
        totalPaisa = Value(totalPaisa),
        paymentMethod = Value(paymentMethod),
        status = Value(status),
        idempotencyKey = Value(idempotencyKey),
        createdAt = Value(createdAt),
        updatedAt = Value(updatedAt);
  static Insertable<ExpenseVoucher> custom({
    Expression<String>? id,
    Expression<String>? institutionId,
    Expression<String>? voucherNumber,
    Expression<DateTime>? voucherDate,
    Expression<String>? payee,
    Expression<String>? description,
    Expression<int>? totalPaisa,
    Expression<String>? paymentMethod,
    Expression<String>? bankAccountId,
    Expression<String>? attachmentPath,
    Expression<String>? status,
    Expression<String>? createdBy,
    Expression<String>? approvedBy,
    Expression<DateTime>? approvedAt,
    Expression<String>? rejectionReason,
    Expression<String>? idempotencyKey,
    Expression<bool>? serverAck,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<DateTime>? serverUpdatedAt,
    Expression<bool>? isDirty,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (institutionId != null) 'institution_id': institutionId,
      if (voucherNumber != null) 'voucher_number': voucherNumber,
      if (voucherDate != null) 'voucher_date': voucherDate,
      if (payee != null) 'payee': payee,
      if (description != null) 'description': description,
      if (totalPaisa != null) 'total_paisa': totalPaisa,
      if (paymentMethod != null) 'payment_method': paymentMethod,
      if (bankAccountId != null) 'bank_account_id': bankAccountId,
      if (attachmentPath != null) 'attachment_path': attachmentPath,
      if (status != null) 'status': status,
      if (createdBy != null) 'created_by': createdBy,
      if (approvedBy != null) 'approved_by': approvedBy,
      if (approvedAt != null) 'approved_at': approvedAt,
      if (rejectionReason != null) 'rejection_reason': rejectionReason,
      if (idempotencyKey != null) 'idempotency_key': idempotencyKey,
      if (serverAck != null) 'server_ack': serverAck,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (serverUpdatedAt != null) 'server_updated_at': serverUpdatedAt,
      if (isDirty != null) 'is_dirty': isDirty,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ExpenseVouchersCompanion copyWith(
      {Value<String>? id,
      Value<String>? institutionId,
      Value<String>? voucherNumber,
      Value<DateTime>? voucherDate,
      Value<String>? payee,
      Value<String>? description,
      Value<int>? totalPaisa,
      Value<PaymentMethod>? paymentMethod,
      Value<String?>? bankAccountId,
      Value<String?>? attachmentPath,
      Value<ExpenseStatus>? status,
      Value<String?>? createdBy,
      Value<String?>? approvedBy,
      Value<DateTime?>? approvedAt,
      Value<String?>? rejectionReason,
      Value<String>? idempotencyKey,
      Value<bool>? serverAck,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<DateTime?>? serverUpdatedAt,
      Value<bool>? isDirty,
      Value<int>? rowid}) {
    return ExpenseVouchersCompanion(
      id: id ?? this.id,
      institutionId: institutionId ?? this.institutionId,
      voucherNumber: voucherNumber ?? this.voucherNumber,
      voucherDate: voucherDate ?? this.voucherDate,
      payee: payee ?? this.payee,
      description: description ?? this.description,
      totalPaisa: totalPaisa ?? this.totalPaisa,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      bankAccountId: bankAccountId ?? this.bankAccountId,
      attachmentPath: attachmentPath ?? this.attachmentPath,
      status: status ?? this.status,
      createdBy: createdBy ?? this.createdBy,
      approvedBy: approvedBy ?? this.approvedBy,
      approvedAt: approvedAt ?? this.approvedAt,
      rejectionReason: rejectionReason ?? this.rejectionReason,
      idempotencyKey: idempotencyKey ?? this.idempotencyKey,
      serverAck: serverAck ?? this.serverAck,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      serverUpdatedAt: serverUpdatedAt ?? this.serverUpdatedAt,
      isDirty: isDirty ?? this.isDirty,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (institutionId.present) {
      map['institution_id'] = Variable<String>(institutionId.value);
    }
    if (voucherNumber.present) {
      map['voucher_number'] = Variable<String>(voucherNumber.value);
    }
    if (voucherDate.present) {
      map['voucher_date'] = Variable<DateTime>(voucherDate.value);
    }
    if (payee.present) {
      map['payee'] = Variable<String>(payee.value);
    }
    if (description.present) {
      map['description'] = Variable<String>(description.value);
    }
    if (totalPaisa.present) {
      map['total_paisa'] = Variable<int>(totalPaisa.value);
    }
    if (paymentMethod.present) {
      map['payment_method'] = Variable<String>($ExpenseVouchersTable
          .$converterpaymentMethod
          .toSql(paymentMethod.value));
    }
    if (bankAccountId.present) {
      map['bank_account_id'] = Variable<String>(bankAccountId.value);
    }
    if (attachmentPath.present) {
      map['attachment_path'] = Variable<String>(attachmentPath.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(
          $ExpenseVouchersTable.$converterstatus.toSql(status.value));
    }
    if (createdBy.present) {
      map['created_by'] = Variable<String>(createdBy.value);
    }
    if (approvedBy.present) {
      map['approved_by'] = Variable<String>(approvedBy.value);
    }
    if (approvedAt.present) {
      map['approved_at'] = Variable<DateTime>(approvedAt.value);
    }
    if (rejectionReason.present) {
      map['rejection_reason'] = Variable<String>(rejectionReason.value);
    }
    if (idempotencyKey.present) {
      map['idempotency_key'] = Variable<String>(idempotencyKey.value);
    }
    if (serverAck.present) {
      map['server_ack'] = Variable<bool>(serverAck.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (serverUpdatedAt.present) {
      map['server_updated_at'] = Variable<DateTime>(serverUpdatedAt.value);
    }
    if (isDirty.present) {
      map['is_dirty'] = Variable<bool>(isDirty.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ExpenseVouchersCompanion(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('voucherNumber: $voucherNumber, ')
          ..write('voucherDate: $voucherDate, ')
          ..write('payee: $payee, ')
          ..write('description: $description, ')
          ..write('totalPaisa: $totalPaisa, ')
          ..write('paymentMethod: $paymentMethod, ')
          ..write('bankAccountId: $bankAccountId, ')
          ..write('attachmentPath: $attachmentPath, ')
          ..write('status: $status, ')
          ..write('createdBy: $createdBy, ')
          ..write('approvedBy: $approvedBy, ')
          ..write('approvedAt: $approvedAt, ')
          ..write('rejectionReason: $rejectionReason, ')
          ..write('idempotencyKey: $idempotencyKey, ')
          ..write('serverAck: $serverAck, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('serverUpdatedAt: $serverUpdatedAt, ')
          ..write('isDirty: $isDirty, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $ExpenseAllocationsTable extends ExpenseAllocations
    with TableInfo<$ExpenseAllocationsTable, ExpenseAllocation> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ExpenseAllocationsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _voucherIdMeta =
      const VerificationMeta('voucherId');
  @override
  late final GeneratedColumn<String> voucherId = GeneratedColumn<String>(
      'voucher_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _fundTypeIdMeta =
      const VerificationMeta('fundTypeId');
  @override
  late final GeneratedColumn<String> fundTypeId = GeneratedColumn<String>(
      'fund_type_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _purposeIdMeta =
      const VerificationMeta('purposeId');
  @override
  late final GeneratedColumn<String> purposeId = GeneratedColumn<String>(
      'purpose_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _amountPaisaMeta =
      const VerificationMeta('amountPaisa');
  @override
  late final GeneratedColumn<int> amountPaisa = GeneratedColumn<int>(
      'amount_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns =>
      [id, voucherId, fundTypeId, purposeId, amountPaisa];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'expense_allocations';
  @override
  VerificationContext validateIntegrity(Insertable<ExpenseAllocation> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('voucher_id')) {
      context.handle(_voucherIdMeta,
          voucherId.isAcceptableOrUnknown(data['voucher_id']!, _voucherIdMeta));
    } else if (isInserting) {
      context.missing(_voucherIdMeta);
    }
    if (data.containsKey('fund_type_id')) {
      context.handle(
          _fundTypeIdMeta,
          fundTypeId.isAcceptableOrUnknown(
              data['fund_type_id']!, _fundTypeIdMeta));
    } else if (isInserting) {
      context.missing(_fundTypeIdMeta);
    }
    if (data.containsKey('purpose_id')) {
      context.handle(_purposeIdMeta,
          purposeId.isAcceptableOrUnknown(data['purpose_id']!, _purposeIdMeta));
    }
    if (data.containsKey('amount_paisa')) {
      context.handle(
          _amountPaisaMeta,
          amountPaisa.isAcceptableOrUnknown(
              data['amount_paisa']!, _amountPaisaMeta));
    } else if (isInserting) {
      context.missing(_amountPaisaMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ExpenseAllocation map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ExpenseAllocation(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      voucherId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}voucher_id'])!,
      fundTypeId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}fund_type_id'])!,
      purposeId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}purpose_id']),
      amountPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}amount_paisa'])!,
    );
  }

  @override
  $ExpenseAllocationsTable createAlias(String alias) {
    return $ExpenseAllocationsTable(attachedDatabase, alias);
  }
}

class ExpenseAllocation extends DataClass
    implements Insertable<ExpenseAllocation> {
  final String id;
  final String voucherId;
  final String fundTypeId;
  final String? purposeId;
  final int amountPaisa;
  const ExpenseAllocation(
      {required this.id,
      required this.voucherId,
      required this.fundTypeId,
      this.purposeId,
      required this.amountPaisa});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['voucher_id'] = Variable<String>(voucherId);
    map['fund_type_id'] = Variable<String>(fundTypeId);
    if (!nullToAbsent || purposeId != null) {
      map['purpose_id'] = Variable<String>(purposeId);
    }
    map['amount_paisa'] = Variable<int>(amountPaisa);
    return map;
  }

  ExpenseAllocationsCompanion toCompanion(bool nullToAbsent) {
    return ExpenseAllocationsCompanion(
      id: Value(id),
      voucherId: Value(voucherId),
      fundTypeId: Value(fundTypeId),
      purposeId: purposeId == null && nullToAbsent
          ? const Value.absent()
          : Value(purposeId),
      amountPaisa: Value(amountPaisa),
    );
  }

  factory ExpenseAllocation.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ExpenseAllocation(
      id: serializer.fromJson<String>(json['id']),
      voucherId: serializer.fromJson<String>(json['voucherId']),
      fundTypeId: serializer.fromJson<String>(json['fundTypeId']),
      purposeId: serializer.fromJson<String?>(json['purposeId']),
      amountPaisa: serializer.fromJson<int>(json['amountPaisa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'voucherId': serializer.toJson<String>(voucherId),
      'fundTypeId': serializer.toJson<String>(fundTypeId),
      'purposeId': serializer.toJson<String?>(purposeId),
      'amountPaisa': serializer.toJson<int>(amountPaisa),
    };
  }

  ExpenseAllocation copyWith(
          {String? id,
          String? voucherId,
          String? fundTypeId,
          Value<String?> purposeId = const Value.absent(),
          int? amountPaisa}) =>
      ExpenseAllocation(
        id: id ?? this.id,
        voucherId: voucherId ?? this.voucherId,
        fundTypeId: fundTypeId ?? this.fundTypeId,
        purposeId: purposeId.present ? purposeId.value : this.purposeId,
        amountPaisa: amountPaisa ?? this.amountPaisa,
      );
  ExpenseAllocation copyWithCompanion(ExpenseAllocationsCompanion data) {
    return ExpenseAllocation(
      id: data.id.present ? data.id.value : this.id,
      voucherId: data.voucherId.present ? data.voucherId.value : this.voucherId,
      fundTypeId:
          data.fundTypeId.present ? data.fundTypeId.value : this.fundTypeId,
      purposeId: data.purposeId.present ? data.purposeId.value : this.purposeId,
      amountPaisa:
          data.amountPaisa.present ? data.amountPaisa.value : this.amountPaisa,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ExpenseAllocation(')
          ..write('id: $id, ')
          ..write('voucherId: $voucherId, ')
          ..write('fundTypeId: $fundTypeId, ')
          ..write('purposeId: $purposeId, ')
          ..write('amountPaisa: $amountPaisa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, voucherId, fundTypeId, purposeId, amountPaisa);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ExpenseAllocation &&
          other.id == this.id &&
          other.voucherId == this.voucherId &&
          other.fundTypeId == this.fundTypeId &&
          other.purposeId == this.purposeId &&
          other.amountPaisa == this.amountPaisa);
}

class ExpenseAllocationsCompanion extends UpdateCompanion<ExpenseAllocation> {
  final Value<String> id;
  final Value<String> voucherId;
  final Value<String> fundTypeId;
  final Value<String?> purposeId;
  final Value<int> amountPaisa;
  final Value<int> rowid;
  const ExpenseAllocationsCompanion({
    this.id = const Value.absent(),
    this.voucherId = const Value.absent(),
    this.fundTypeId = const Value.absent(),
    this.purposeId = const Value.absent(),
    this.amountPaisa = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ExpenseAllocationsCompanion.insert({
    required String id,
    required String voucherId,
    required String fundTypeId,
    this.purposeId = const Value.absent(),
    required int amountPaisa,
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        voucherId = Value(voucherId),
        fundTypeId = Value(fundTypeId),
        amountPaisa = Value(amountPaisa);
  static Insertable<ExpenseAllocation> custom({
    Expression<String>? id,
    Expression<String>? voucherId,
    Expression<String>? fundTypeId,
    Expression<String>? purposeId,
    Expression<int>? amountPaisa,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (voucherId != null) 'voucher_id': voucherId,
      if (fundTypeId != null) 'fund_type_id': fundTypeId,
      if (purposeId != null) 'purpose_id': purposeId,
      if (amountPaisa != null) 'amount_paisa': amountPaisa,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ExpenseAllocationsCompanion copyWith(
      {Value<String>? id,
      Value<String>? voucherId,
      Value<String>? fundTypeId,
      Value<String?>? purposeId,
      Value<int>? amountPaisa,
      Value<int>? rowid}) {
    return ExpenseAllocationsCompanion(
      id: id ?? this.id,
      voucherId: voucherId ?? this.voucherId,
      fundTypeId: fundTypeId ?? this.fundTypeId,
      purposeId: purposeId ?? this.purposeId,
      amountPaisa: amountPaisa ?? this.amountPaisa,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (voucherId.present) {
      map['voucher_id'] = Variable<String>(voucherId.value);
    }
    if (fundTypeId.present) {
      map['fund_type_id'] = Variable<String>(fundTypeId.value);
    }
    if (purposeId.present) {
      map['purpose_id'] = Variable<String>(purposeId.value);
    }
    if (amountPaisa.present) {
      map['amount_paisa'] = Variable<int>(amountPaisa.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ExpenseAllocationsCompanion(')
          ..write('id: $id, ')
          ..write('voucherId: $voucherId, ')
          ..write('fundTypeId: $fundTypeId, ')
          ..write('purposeId: $purposeId, ')
          ..write('amountPaisa: $amountPaisa, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $ApprovalsTable extends Approvals
    with TableInfo<$ApprovalsTable, Approval> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ApprovalsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _institutionIdMeta =
      const VerificationMeta('institutionId');
  @override
  late final GeneratedColumn<String> institutionId = GeneratedColumn<String>(
      'institution_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _entityTypeMeta =
      const VerificationMeta('entityType');
  @override
  late final GeneratedColumn<String> entityType = GeneratedColumn<String>(
      'entity_type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _entityIdMeta =
      const VerificationMeta('entityId');
  @override
  late final GeneratedColumn<String> entityId = GeneratedColumn<String>(
      'entity_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _actionMeta = const VerificationMeta('action');
  @override
  late final GeneratedColumn<String> action = GeneratedColumn<String>(
      'action', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  @override
  late final GeneratedColumnWithTypeConverter<ApprovalDecision, String>
      decision = GeneratedColumn<String>('decision', aliasedName, false,
              type: DriftSqlType.string, requiredDuringInsert: true)
          .withConverter<ApprovalDecision>($ApprovalsTable.$converterdecision);
  static const VerificationMeta _actorIdMeta =
      const VerificationMeta('actorId');
  @override
  late final GeneratedColumn<String> actorId = GeneratedColumn<String>(
      'actor_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _decidedAtMeta =
      const VerificationMeta('decidedAt');
  @override
  late final GeneratedColumn<DateTime> decidedAt = GeneratedColumn<DateTime>(
      'decided_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _reasonMeta = const VerificationMeta('reason');
  @override
  late final GeneratedColumn<String> reason = GeneratedColumn<String>(
      'reason', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        institutionId,
        entityType,
        entityId,
        action,
        decision,
        actorId,
        decidedAt,
        reason
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'approvals';
  @override
  VerificationContext validateIntegrity(Insertable<Approval> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('institution_id')) {
      context.handle(
          _institutionIdMeta,
          institutionId.isAcceptableOrUnknown(
              data['institution_id']!, _institutionIdMeta));
    } else if (isInserting) {
      context.missing(_institutionIdMeta);
    }
    if (data.containsKey('entity_type')) {
      context.handle(
          _entityTypeMeta,
          entityType.isAcceptableOrUnknown(
              data['entity_type']!, _entityTypeMeta));
    } else if (isInserting) {
      context.missing(_entityTypeMeta);
    }
    if (data.containsKey('entity_id')) {
      context.handle(_entityIdMeta,
          entityId.isAcceptableOrUnknown(data['entity_id']!, _entityIdMeta));
    } else if (isInserting) {
      context.missing(_entityIdMeta);
    }
    if (data.containsKey('action')) {
      context.handle(_actionMeta,
          action.isAcceptableOrUnknown(data['action']!, _actionMeta));
    } else if (isInserting) {
      context.missing(_actionMeta);
    }
    if (data.containsKey('actor_id')) {
      context.handle(_actorIdMeta,
          actorId.isAcceptableOrUnknown(data['actor_id']!, _actorIdMeta));
    } else if (isInserting) {
      context.missing(_actorIdMeta);
    }
    if (data.containsKey('decided_at')) {
      context.handle(_decidedAtMeta,
          decidedAt.isAcceptableOrUnknown(data['decided_at']!, _decidedAtMeta));
    } else if (isInserting) {
      context.missing(_decidedAtMeta);
    }
    if (data.containsKey('reason')) {
      context.handle(_reasonMeta,
          reason.isAcceptableOrUnknown(data['reason']!, _reasonMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Approval map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Approval(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      institutionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}institution_id'])!,
      entityType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_type'])!,
      entityId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_id'])!,
      action: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}action'])!,
      decision: $ApprovalsTable.$converterdecision.fromSql(attachedDatabase
          .typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}decision'])!),
      actorId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}actor_id'])!,
      decidedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}decided_at'])!,
      reason: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}reason']),
    );
  }

  @override
  $ApprovalsTable createAlias(String alias) {
    return $ApprovalsTable(attachedDatabase, alias);
  }

  static JsonTypeConverter2<ApprovalDecision, String, String>
      $converterdecision =
      const EnumNameConverter<ApprovalDecision>(ApprovalDecision.values);
}

class Approval extends DataClass implements Insertable<Approval> {
  final String id;
  final String institutionId;
  final String entityType;
  final String entityId;
  final String action;
  final ApprovalDecision decision;
  final String actorId;
  final DateTime decidedAt;
  final String? reason;
  const Approval(
      {required this.id,
      required this.institutionId,
      required this.entityType,
      required this.entityId,
      required this.action,
      required this.decision,
      required this.actorId,
      required this.decidedAt,
      this.reason});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['institution_id'] = Variable<String>(institutionId);
    map['entity_type'] = Variable<String>(entityType);
    map['entity_id'] = Variable<String>(entityId);
    map['action'] = Variable<String>(action);
    {
      map['decision'] =
          Variable<String>($ApprovalsTable.$converterdecision.toSql(decision));
    }
    map['actor_id'] = Variable<String>(actorId);
    map['decided_at'] = Variable<DateTime>(decidedAt);
    if (!nullToAbsent || reason != null) {
      map['reason'] = Variable<String>(reason);
    }
    return map;
  }

  ApprovalsCompanion toCompanion(bool nullToAbsent) {
    return ApprovalsCompanion(
      id: Value(id),
      institutionId: Value(institutionId),
      entityType: Value(entityType),
      entityId: Value(entityId),
      action: Value(action),
      decision: Value(decision),
      actorId: Value(actorId),
      decidedAt: Value(decidedAt),
      reason:
          reason == null && nullToAbsent ? const Value.absent() : Value(reason),
    );
  }

  factory Approval.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Approval(
      id: serializer.fromJson<String>(json['id']),
      institutionId: serializer.fromJson<String>(json['institutionId']),
      entityType: serializer.fromJson<String>(json['entityType']),
      entityId: serializer.fromJson<String>(json['entityId']),
      action: serializer.fromJson<String>(json['action']),
      decision: $ApprovalsTable.$converterdecision
          .fromJson(serializer.fromJson<String>(json['decision'])),
      actorId: serializer.fromJson<String>(json['actorId']),
      decidedAt: serializer.fromJson<DateTime>(json['decidedAt']),
      reason: serializer.fromJson<String?>(json['reason']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'institutionId': serializer.toJson<String>(institutionId),
      'entityType': serializer.toJson<String>(entityType),
      'entityId': serializer.toJson<String>(entityId),
      'action': serializer.toJson<String>(action),
      'decision': serializer
          .toJson<String>($ApprovalsTable.$converterdecision.toJson(decision)),
      'actorId': serializer.toJson<String>(actorId),
      'decidedAt': serializer.toJson<DateTime>(decidedAt),
      'reason': serializer.toJson<String?>(reason),
    };
  }

  Approval copyWith(
          {String? id,
          String? institutionId,
          String? entityType,
          String? entityId,
          String? action,
          ApprovalDecision? decision,
          String? actorId,
          DateTime? decidedAt,
          Value<String?> reason = const Value.absent()}) =>
      Approval(
        id: id ?? this.id,
        institutionId: institutionId ?? this.institutionId,
        entityType: entityType ?? this.entityType,
        entityId: entityId ?? this.entityId,
        action: action ?? this.action,
        decision: decision ?? this.decision,
        actorId: actorId ?? this.actorId,
        decidedAt: decidedAt ?? this.decidedAt,
        reason: reason.present ? reason.value : this.reason,
      );
  Approval copyWithCompanion(ApprovalsCompanion data) {
    return Approval(
      id: data.id.present ? data.id.value : this.id,
      institutionId: data.institutionId.present
          ? data.institutionId.value
          : this.institutionId,
      entityType:
          data.entityType.present ? data.entityType.value : this.entityType,
      entityId: data.entityId.present ? data.entityId.value : this.entityId,
      action: data.action.present ? data.action.value : this.action,
      decision: data.decision.present ? data.decision.value : this.decision,
      actorId: data.actorId.present ? data.actorId.value : this.actorId,
      decidedAt: data.decidedAt.present ? data.decidedAt.value : this.decidedAt,
      reason: data.reason.present ? data.reason.value : this.reason,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Approval(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('entityType: $entityType, ')
          ..write('entityId: $entityId, ')
          ..write('action: $action, ')
          ..write('decision: $decision, ')
          ..write('actorId: $actorId, ')
          ..write('decidedAt: $decidedAt, ')
          ..write('reason: $reason')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, institutionId, entityType, entityId,
      action, decision, actorId, decidedAt, reason);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Approval &&
          other.id == this.id &&
          other.institutionId == this.institutionId &&
          other.entityType == this.entityType &&
          other.entityId == this.entityId &&
          other.action == this.action &&
          other.decision == this.decision &&
          other.actorId == this.actorId &&
          other.decidedAt == this.decidedAt &&
          other.reason == this.reason);
}

class ApprovalsCompanion extends UpdateCompanion<Approval> {
  final Value<String> id;
  final Value<String> institutionId;
  final Value<String> entityType;
  final Value<String> entityId;
  final Value<String> action;
  final Value<ApprovalDecision> decision;
  final Value<String> actorId;
  final Value<DateTime> decidedAt;
  final Value<String?> reason;
  final Value<int> rowid;
  const ApprovalsCompanion({
    this.id = const Value.absent(),
    this.institutionId = const Value.absent(),
    this.entityType = const Value.absent(),
    this.entityId = const Value.absent(),
    this.action = const Value.absent(),
    this.decision = const Value.absent(),
    this.actorId = const Value.absent(),
    this.decidedAt = const Value.absent(),
    this.reason = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ApprovalsCompanion.insert({
    required String id,
    required String institutionId,
    required String entityType,
    required String entityId,
    required String action,
    required ApprovalDecision decision,
    required String actorId,
    required DateTime decidedAt,
    this.reason = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        institutionId = Value(institutionId),
        entityType = Value(entityType),
        entityId = Value(entityId),
        action = Value(action),
        decision = Value(decision),
        actorId = Value(actorId),
        decidedAt = Value(decidedAt);
  static Insertable<Approval> custom({
    Expression<String>? id,
    Expression<String>? institutionId,
    Expression<String>? entityType,
    Expression<String>? entityId,
    Expression<String>? action,
    Expression<String>? decision,
    Expression<String>? actorId,
    Expression<DateTime>? decidedAt,
    Expression<String>? reason,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (institutionId != null) 'institution_id': institutionId,
      if (entityType != null) 'entity_type': entityType,
      if (entityId != null) 'entity_id': entityId,
      if (action != null) 'action': action,
      if (decision != null) 'decision': decision,
      if (actorId != null) 'actor_id': actorId,
      if (decidedAt != null) 'decided_at': decidedAt,
      if (reason != null) 'reason': reason,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ApprovalsCompanion copyWith(
      {Value<String>? id,
      Value<String>? institutionId,
      Value<String>? entityType,
      Value<String>? entityId,
      Value<String>? action,
      Value<ApprovalDecision>? decision,
      Value<String>? actorId,
      Value<DateTime>? decidedAt,
      Value<String?>? reason,
      Value<int>? rowid}) {
    return ApprovalsCompanion(
      id: id ?? this.id,
      institutionId: institutionId ?? this.institutionId,
      entityType: entityType ?? this.entityType,
      entityId: entityId ?? this.entityId,
      action: action ?? this.action,
      decision: decision ?? this.decision,
      actorId: actorId ?? this.actorId,
      decidedAt: decidedAt ?? this.decidedAt,
      reason: reason ?? this.reason,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (institutionId.present) {
      map['institution_id'] = Variable<String>(institutionId.value);
    }
    if (entityType.present) {
      map['entity_type'] = Variable<String>(entityType.value);
    }
    if (entityId.present) {
      map['entity_id'] = Variable<String>(entityId.value);
    }
    if (action.present) {
      map['action'] = Variable<String>(action.value);
    }
    if (decision.present) {
      map['decision'] = Variable<String>(
          $ApprovalsTable.$converterdecision.toSql(decision.value));
    }
    if (actorId.present) {
      map['actor_id'] = Variable<String>(actorId.value);
    }
    if (decidedAt.present) {
      map['decided_at'] = Variable<DateTime>(decidedAt.value);
    }
    if (reason.present) {
      map['reason'] = Variable<String>(reason.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ApprovalsCompanion(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('entityType: $entityType, ')
          ..write('entityId: $entityId, ')
          ..write('action: $action, ')
          ..write('decision: $decision, ')
          ..write('actorId: $actorId, ')
          ..write('decidedAt: $decidedAt, ')
          ..write('reason: $reason, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $ReconciliationsTable extends Reconciliations
    with TableInfo<$ReconciliationsTable, Reconciliation> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ReconciliationsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _institutionIdMeta =
      const VerificationMeta('institutionId');
  @override
  late final GeneratedColumn<String> institutionId = GeneratedColumn<String>(
      'institution_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _bankAccountIdMeta =
      const VerificationMeta('bankAccountId');
  @override
  late final GeneratedColumn<String> bankAccountId = GeneratedColumn<String>(
      'bank_account_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _statementDateMeta =
      const VerificationMeta('statementDate');
  @override
  late final GeneratedColumn<DateTime> statementDate =
      GeneratedColumn<DateTime>('statement_date', aliasedName, false,
          type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _statementBalancePaisaMeta =
      const VerificationMeta('statementBalancePaisa');
  @override
  late final GeneratedColumn<int> statementBalancePaisa = GeneratedColumn<int>(
      'statement_balance_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _bookBalancePaisaMeta =
      const VerificationMeta('bookBalancePaisa');
  @override
  late final GeneratedColumn<int> bookBalancePaisa = GeneratedColumn<int>(
      'book_balance_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _differencePaisaMeta =
      const VerificationMeta('differencePaisa');
  @override
  late final GeneratedColumn<int> differencePaisa = GeneratedColumn<int>(
      'difference_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('open'));
  static const VerificationMeta _createdByMeta =
      const VerificationMeta('createdBy');
  @override
  late final GeneratedColumn<String> createdBy = GeneratedColumn<String>(
      'created_by', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _notesMeta = const VerificationMeta('notes');
  @override
  late final GeneratedColumn<String> notes = GeneratedColumn<String>(
      'notes', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        institutionId,
        bankAccountId,
        statementDate,
        statementBalancePaisa,
        bookBalancePaisa,
        differencePaisa,
        status,
        createdBy,
        notes,
        createdAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'reconciliations';
  @override
  VerificationContext validateIntegrity(Insertable<Reconciliation> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('institution_id')) {
      context.handle(
          _institutionIdMeta,
          institutionId.isAcceptableOrUnknown(
              data['institution_id']!, _institutionIdMeta));
    } else if (isInserting) {
      context.missing(_institutionIdMeta);
    }
    if (data.containsKey('bank_account_id')) {
      context.handle(
          _bankAccountIdMeta,
          bankAccountId.isAcceptableOrUnknown(
              data['bank_account_id']!, _bankAccountIdMeta));
    } else if (isInserting) {
      context.missing(_bankAccountIdMeta);
    }
    if (data.containsKey('statement_date')) {
      context.handle(
          _statementDateMeta,
          statementDate.isAcceptableOrUnknown(
              data['statement_date']!, _statementDateMeta));
    } else if (isInserting) {
      context.missing(_statementDateMeta);
    }
    if (data.containsKey('statement_balance_paisa')) {
      context.handle(
          _statementBalancePaisaMeta,
          statementBalancePaisa.isAcceptableOrUnknown(
              data['statement_balance_paisa']!, _statementBalancePaisaMeta));
    } else if (isInserting) {
      context.missing(_statementBalancePaisaMeta);
    }
    if (data.containsKey('book_balance_paisa')) {
      context.handle(
          _bookBalancePaisaMeta,
          bookBalancePaisa.isAcceptableOrUnknown(
              data['book_balance_paisa']!, _bookBalancePaisaMeta));
    } else if (isInserting) {
      context.missing(_bookBalancePaisaMeta);
    }
    if (data.containsKey('difference_paisa')) {
      context.handle(
          _differencePaisaMeta,
          differencePaisa.isAcceptableOrUnknown(
              data['difference_paisa']!, _differencePaisaMeta));
    } else if (isInserting) {
      context.missing(_differencePaisaMeta);
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('created_by')) {
      context.handle(_createdByMeta,
          createdBy.isAcceptableOrUnknown(data['created_by']!, _createdByMeta));
    }
    if (data.containsKey('notes')) {
      context.handle(
          _notesMeta, notes.isAcceptableOrUnknown(data['notes']!, _notesMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Reconciliation map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Reconciliation(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      institutionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}institution_id'])!,
      bankAccountId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}bank_account_id'])!,
      statementDate: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}statement_date'])!,
      statementBalancePaisa: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}statement_balance_paisa'])!,
      bookBalancePaisa: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}book_balance_paisa'])!,
      differencePaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}difference_paisa'])!,
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status'])!,
      createdBy: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_by']),
      notes: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}notes']),
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
    );
  }

  @override
  $ReconciliationsTable createAlias(String alias) {
    return $ReconciliationsTable(attachedDatabase, alias);
  }
}

class Reconciliation extends DataClass implements Insertable<Reconciliation> {
  final String id;
  final String institutionId;
  final String bankAccountId;
  final DateTime statementDate;
  final int statementBalancePaisa;
  final int bookBalancePaisa;
  final int differencePaisa;
  final String status;
  final String? createdBy;
  final String? notes;
  final DateTime createdAt;
  const Reconciliation(
      {required this.id,
      required this.institutionId,
      required this.bankAccountId,
      required this.statementDate,
      required this.statementBalancePaisa,
      required this.bookBalancePaisa,
      required this.differencePaisa,
      required this.status,
      this.createdBy,
      this.notes,
      required this.createdAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['institution_id'] = Variable<String>(institutionId);
    map['bank_account_id'] = Variable<String>(bankAccountId);
    map['statement_date'] = Variable<DateTime>(statementDate);
    map['statement_balance_paisa'] = Variable<int>(statementBalancePaisa);
    map['book_balance_paisa'] = Variable<int>(bookBalancePaisa);
    map['difference_paisa'] = Variable<int>(differencePaisa);
    map['status'] = Variable<String>(status);
    if (!nullToAbsent || createdBy != null) {
      map['created_by'] = Variable<String>(createdBy);
    }
    if (!nullToAbsent || notes != null) {
      map['notes'] = Variable<String>(notes);
    }
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  ReconciliationsCompanion toCompanion(bool nullToAbsent) {
    return ReconciliationsCompanion(
      id: Value(id),
      institutionId: Value(institutionId),
      bankAccountId: Value(bankAccountId),
      statementDate: Value(statementDate),
      statementBalancePaisa: Value(statementBalancePaisa),
      bookBalancePaisa: Value(bookBalancePaisa),
      differencePaisa: Value(differencePaisa),
      status: Value(status),
      createdBy: createdBy == null && nullToAbsent
          ? const Value.absent()
          : Value(createdBy),
      notes:
          notes == null && nullToAbsent ? const Value.absent() : Value(notes),
      createdAt: Value(createdAt),
    );
  }

  factory Reconciliation.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Reconciliation(
      id: serializer.fromJson<String>(json['id']),
      institutionId: serializer.fromJson<String>(json['institutionId']),
      bankAccountId: serializer.fromJson<String>(json['bankAccountId']),
      statementDate: serializer.fromJson<DateTime>(json['statementDate']),
      statementBalancePaisa:
          serializer.fromJson<int>(json['statementBalancePaisa']),
      bookBalancePaisa: serializer.fromJson<int>(json['bookBalancePaisa']),
      differencePaisa: serializer.fromJson<int>(json['differencePaisa']),
      status: serializer.fromJson<String>(json['status']),
      createdBy: serializer.fromJson<String?>(json['createdBy']),
      notes: serializer.fromJson<String?>(json['notes']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'institutionId': serializer.toJson<String>(institutionId),
      'bankAccountId': serializer.toJson<String>(bankAccountId),
      'statementDate': serializer.toJson<DateTime>(statementDate),
      'statementBalancePaisa': serializer.toJson<int>(statementBalancePaisa),
      'bookBalancePaisa': serializer.toJson<int>(bookBalancePaisa),
      'differencePaisa': serializer.toJson<int>(differencePaisa),
      'status': serializer.toJson<String>(status),
      'createdBy': serializer.toJson<String?>(createdBy),
      'notes': serializer.toJson<String?>(notes),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  Reconciliation copyWith(
          {String? id,
          String? institutionId,
          String? bankAccountId,
          DateTime? statementDate,
          int? statementBalancePaisa,
          int? bookBalancePaisa,
          int? differencePaisa,
          String? status,
          Value<String?> createdBy = const Value.absent(),
          Value<String?> notes = const Value.absent(),
          DateTime? createdAt}) =>
      Reconciliation(
        id: id ?? this.id,
        institutionId: institutionId ?? this.institutionId,
        bankAccountId: bankAccountId ?? this.bankAccountId,
        statementDate: statementDate ?? this.statementDate,
        statementBalancePaisa:
            statementBalancePaisa ?? this.statementBalancePaisa,
        bookBalancePaisa: bookBalancePaisa ?? this.bookBalancePaisa,
        differencePaisa: differencePaisa ?? this.differencePaisa,
        status: status ?? this.status,
        createdBy: createdBy.present ? createdBy.value : this.createdBy,
        notes: notes.present ? notes.value : this.notes,
        createdAt: createdAt ?? this.createdAt,
      );
  Reconciliation copyWithCompanion(ReconciliationsCompanion data) {
    return Reconciliation(
      id: data.id.present ? data.id.value : this.id,
      institutionId: data.institutionId.present
          ? data.institutionId.value
          : this.institutionId,
      bankAccountId: data.bankAccountId.present
          ? data.bankAccountId.value
          : this.bankAccountId,
      statementDate: data.statementDate.present
          ? data.statementDate.value
          : this.statementDate,
      statementBalancePaisa: data.statementBalancePaisa.present
          ? data.statementBalancePaisa.value
          : this.statementBalancePaisa,
      bookBalancePaisa: data.bookBalancePaisa.present
          ? data.bookBalancePaisa.value
          : this.bookBalancePaisa,
      differencePaisa: data.differencePaisa.present
          ? data.differencePaisa.value
          : this.differencePaisa,
      status: data.status.present ? data.status.value : this.status,
      createdBy: data.createdBy.present ? data.createdBy.value : this.createdBy,
      notes: data.notes.present ? data.notes.value : this.notes,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Reconciliation(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('bankAccountId: $bankAccountId, ')
          ..write('statementDate: $statementDate, ')
          ..write('statementBalancePaisa: $statementBalancePaisa, ')
          ..write('bookBalancePaisa: $bookBalancePaisa, ')
          ..write('differencePaisa: $differencePaisa, ')
          ..write('status: $status, ')
          ..write('createdBy: $createdBy, ')
          ..write('notes: $notes, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      institutionId,
      bankAccountId,
      statementDate,
      statementBalancePaisa,
      bookBalancePaisa,
      differencePaisa,
      status,
      createdBy,
      notes,
      createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Reconciliation &&
          other.id == this.id &&
          other.institutionId == this.institutionId &&
          other.bankAccountId == this.bankAccountId &&
          other.statementDate == this.statementDate &&
          other.statementBalancePaisa == this.statementBalancePaisa &&
          other.bookBalancePaisa == this.bookBalancePaisa &&
          other.differencePaisa == this.differencePaisa &&
          other.status == this.status &&
          other.createdBy == this.createdBy &&
          other.notes == this.notes &&
          other.createdAt == this.createdAt);
}

class ReconciliationsCompanion extends UpdateCompanion<Reconciliation> {
  final Value<String> id;
  final Value<String> institutionId;
  final Value<String> bankAccountId;
  final Value<DateTime> statementDate;
  final Value<int> statementBalancePaisa;
  final Value<int> bookBalancePaisa;
  final Value<int> differencePaisa;
  final Value<String> status;
  final Value<String?> createdBy;
  final Value<String?> notes;
  final Value<DateTime> createdAt;
  final Value<int> rowid;
  const ReconciliationsCompanion({
    this.id = const Value.absent(),
    this.institutionId = const Value.absent(),
    this.bankAccountId = const Value.absent(),
    this.statementDate = const Value.absent(),
    this.statementBalancePaisa = const Value.absent(),
    this.bookBalancePaisa = const Value.absent(),
    this.differencePaisa = const Value.absent(),
    this.status = const Value.absent(),
    this.createdBy = const Value.absent(),
    this.notes = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ReconciliationsCompanion.insert({
    required String id,
    required String institutionId,
    required String bankAccountId,
    required DateTime statementDate,
    required int statementBalancePaisa,
    required int bookBalancePaisa,
    required int differencePaisa,
    this.status = const Value.absent(),
    this.createdBy = const Value.absent(),
    this.notes = const Value.absent(),
    required DateTime createdAt,
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        institutionId = Value(institutionId),
        bankAccountId = Value(bankAccountId),
        statementDate = Value(statementDate),
        statementBalancePaisa = Value(statementBalancePaisa),
        bookBalancePaisa = Value(bookBalancePaisa),
        differencePaisa = Value(differencePaisa),
        createdAt = Value(createdAt);
  static Insertable<Reconciliation> custom({
    Expression<String>? id,
    Expression<String>? institutionId,
    Expression<String>? bankAccountId,
    Expression<DateTime>? statementDate,
    Expression<int>? statementBalancePaisa,
    Expression<int>? bookBalancePaisa,
    Expression<int>? differencePaisa,
    Expression<String>? status,
    Expression<String>? createdBy,
    Expression<String>? notes,
    Expression<DateTime>? createdAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (institutionId != null) 'institution_id': institutionId,
      if (bankAccountId != null) 'bank_account_id': bankAccountId,
      if (statementDate != null) 'statement_date': statementDate,
      if (statementBalancePaisa != null)
        'statement_balance_paisa': statementBalancePaisa,
      if (bookBalancePaisa != null) 'book_balance_paisa': bookBalancePaisa,
      if (differencePaisa != null) 'difference_paisa': differencePaisa,
      if (status != null) 'status': status,
      if (createdBy != null) 'created_by': createdBy,
      if (notes != null) 'notes': notes,
      if (createdAt != null) 'created_at': createdAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ReconciliationsCompanion copyWith(
      {Value<String>? id,
      Value<String>? institutionId,
      Value<String>? bankAccountId,
      Value<DateTime>? statementDate,
      Value<int>? statementBalancePaisa,
      Value<int>? bookBalancePaisa,
      Value<int>? differencePaisa,
      Value<String>? status,
      Value<String?>? createdBy,
      Value<String?>? notes,
      Value<DateTime>? createdAt,
      Value<int>? rowid}) {
    return ReconciliationsCompanion(
      id: id ?? this.id,
      institutionId: institutionId ?? this.institutionId,
      bankAccountId: bankAccountId ?? this.bankAccountId,
      statementDate: statementDate ?? this.statementDate,
      statementBalancePaisa:
          statementBalancePaisa ?? this.statementBalancePaisa,
      bookBalancePaisa: bookBalancePaisa ?? this.bookBalancePaisa,
      differencePaisa: differencePaisa ?? this.differencePaisa,
      status: status ?? this.status,
      createdBy: createdBy ?? this.createdBy,
      notes: notes ?? this.notes,
      createdAt: createdAt ?? this.createdAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (institutionId.present) {
      map['institution_id'] = Variable<String>(institutionId.value);
    }
    if (bankAccountId.present) {
      map['bank_account_id'] = Variable<String>(bankAccountId.value);
    }
    if (statementDate.present) {
      map['statement_date'] = Variable<DateTime>(statementDate.value);
    }
    if (statementBalancePaisa.present) {
      map['statement_balance_paisa'] =
          Variable<int>(statementBalancePaisa.value);
    }
    if (bookBalancePaisa.present) {
      map['book_balance_paisa'] = Variable<int>(bookBalancePaisa.value);
    }
    if (differencePaisa.present) {
      map['difference_paisa'] = Variable<int>(differencePaisa.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (createdBy.present) {
      map['created_by'] = Variable<String>(createdBy.value);
    }
    if (notes.present) {
      map['notes'] = Variable<String>(notes.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ReconciliationsCompanion(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('bankAccountId: $bankAccountId, ')
          ..write('statementDate: $statementDate, ')
          ..write('statementBalancePaisa: $statementBalancePaisa, ')
          ..write('bookBalancePaisa: $bookBalancePaisa, ')
          ..write('differencePaisa: $differencePaisa, ')
          ..write('status: $status, ')
          ..write('createdBy: $createdBy, ')
          ..write('notes: $notes, ')
          ..write('createdAt: $createdAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $EvidenceFilesTable extends EvidenceFiles
    with TableInfo<$EvidenceFilesTable, EvidenceFile> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EvidenceFilesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _institutionIdMeta =
      const VerificationMeta('institutionId');
  @override
  late final GeneratedColumn<String> institutionId = GeneratedColumn<String>(
      'institution_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _entityTypeMeta =
      const VerificationMeta('entityType');
  @override
  late final GeneratedColumn<String> entityType = GeneratedColumn<String>(
      'entity_type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _entityIdMeta =
      const VerificationMeta('entityId');
  @override
  late final GeneratedColumn<String> entityId = GeneratedColumn<String>(
      'entity_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _localPathMeta =
      const VerificationMeta('localPath');
  @override
  late final GeneratedColumn<String> localPath = GeneratedColumn<String>(
      'local_path', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _remotePathMeta =
      const VerificationMeta('remotePath');
  @override
  late final GeneratedColumn<String> remotePath = GeneratedColumn<String>(
      'remote_path', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _mimeMeta = const VerificationMeta('mime');
  @override
  late final GeneratedColumn<String> mime = GeneratedColumn<String>(
      'mime', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _sizeBytesMeta =
      const VerificationMeta('sizeBytes');
  @override
  late final GeneratedColumn<int> sizeBytes = GeneratedColumn<int>(
      'size_bytes', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _sha256Meta = const VerificationMeta('sha256');
  @override
  late final GeneratedColumn<String> sha256 = GeneratedColumn<String>(
      'sha256', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        institutionId,
        entityType,
        entityId,
        localPath,
        remotePath,
        mime,
        sizeBytes,
        sha256,
        createdAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'evidence_files';
  @override
  VerificationContext validateIntegrity(Insertable<EvidenceFile> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('institution_id')) {
      context.handle(
          _institutionIdMeta,
          institutionId.isAcceptableOrUnknown(
              data['institution_id']!, _institutionIdMeta));
    } else if (isInserting) {
      context.missing(_institutionIdMeta);
    }
    if (data.containsKey('entity_type')) {
      context.handle(
          _entityTypeMeta,
          entityType.isAcceptableOrUnknown(
              data['entity_type']!, _entityTypeMeta));
    } else if (isInserting) {
      context.missing(_entityTypeMeta);
    }
    if (data.containsKey('entity_id')) {
      context.handle(_entityIdMeta,
          entityId.isAcceptableOrUnknown(data['entity_id']!, _entityIdMeta));
    } else if (isInserting) {
      context.missing(_entityIdMeta);
    }
    if (data.containsKey('local_path')) {
      context.handle(_localPathMeta,
          localPath.isAcceptableOrUnknown(data['local_path']!, _localPathMeta));
    }
    if (data.containsKey('remote_path')) {
      context.handle(
          _remotePathMeta,
          remotePath.isAcceptableOrUnknown(
              data['remote_path']!, _remotePathMeta));
    }
    if (data.containsKey('mime')) {
      context.handle(
          _mimeMeta, mime.isAcceptableOrUnknown(data['mime']!, _mimeMeta));
    } else if (isInserting) {
      context.missing(_mimeMeta);
    }
    if (data.containsKey('size_bytes')) {
      context.handle(_sizeBytesMeta,
          sizeBytes.isAcceptableOrUnknown(data['size_bytes']!, _sizeBytesMeta));
    } else if (isInserting) {
      context.missing(_sizeBytesMeta);
    }
    if (data.containsKey('sha256')) {
      context.handle(_sha256Meta,
          sha256.isAcceptableOrUnknown(data['sha256']!, _sha256Meta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EvidenceFile map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EvidenceFile(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      institutionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}institution_id'])!,
      entityType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_type'])!,
      entityId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_id'])!,
      localPath: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}local_path']),
      remotePath: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}remote_path']),
      mime: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}mime'])!,
      sizeBytes: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}size_bytes'])!,
      sha256: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sha256']),
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
    );
  }

  @override
  $EvidenceFilesTable createAlias(String alias) {
    return $EvidenceFilesTable(attachedDatabase, alias);
  }
}

class EvidenceFile extends DataClass implements Insertable<EvidenceFile> {
  final String id;
  final String institutionId;
  final String entityType;
  final String entityId;
  final String? localPath;
  final String? remotePath;
  final String mime;
  final int sizeBytes;
  final String? sha256;
  final DateTime createdAt;
  const EvidenceFile(
      {required this.id,
      required this.institutionId,
      required this.entityType,
      required this.entityId,
      this.localPath,
      this.remotePath,
      required this.mime,
      required this.sizeBytes,
      this.sha256,
      required this.createdAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['institution_id'] = Variable<String>(institutionId);
    map['entity_type'] = Variable<String>(entityType);
    map['entity_id'] = Variable<String>(entityId);
    if (!nullToAbsent || localPath != null) {
      map['local_path'] = Variable<String>(localPath);
    }
    if (!nullToAbsent || remotePath != null) {
      map['remote_path'] = Variable<String>(remotePath);
    }
    map['mime'] = Variable<String>(mime);
    map['size_bytes'] = Variable<int>(sizeBytes);
    if (!nullToAbsent || sha256 != null) {
      map['sha256'] = Variable<String>(sha256);
    }
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  EvidenceFilesCompanion toCompanion(bool nullToAbsent) {
    return EvidenceFilesCompanion(
      id: Value(id),
      institutionId: Value(institutionId),
      entityType: Value(entityType),
      entityId: Value(entityId),
      localPath: localPath == null && nullToAbsent
          ? const Value.absent()
          : Value(localPath),
      remotePath: remotePath == null && nullToAbsent
          ? const Value.absent()
          : Value(remotePath),
      mime: Value(mime),
      sizeBytes: Value(sizeBytes),
      sha256:
          sha256 == null && nullToAbsent ? const Value.absent() : Value(sha256),
      createdAt: Value(createdAt),
    );
  }

  factory EvidenceFile.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EvidenceFile(
      id: serializer.fromJson<String>(json['id']),
      institutionId: serializer.fromJson<String>(json['institutionId']),
      entityType: serializer.fromJson<String>(json['entityType']),
      entityId: serializer.fromJson<String>(json['entityId']),
      localPath: serializer.fromJson<String?>(json['localPath']),
      remotePath: serializer.fromJson<String?>(json['remotePath']),
      mime: serializer.fromJson<String>(json['mime']),
      sizeBytes: serializer.fromJson<int>(json['sizeBytes']),
      sha256: serializer.fromJson<String?>(json['sha256']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'institutionId': serializer.toJson<String>(institutionId),
      'entityType': serializer.toJson<String>(entityType),
      'entityId': serializer.toJson<String>(entityId),
      'localPath': serializer.toJson<String?>(localPath),
      'remotePath': serializer.toJson<String?>(remotePath),
      'mime': serializer.toJson<String>(mime),
      'sizeBytes': serializer.toJson<int>(sizeBytes),
      'sha256': serializer.toJson<String?>(sha256),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  EvidenceFile copyWith(
          {String? id,
          String? institutionId,
          String? entityType,
          String? entityId,
          Value<String?> localPath = const Value.absent(),
          Value<String?> remotePath = const Value.absent(),
          String? mime,
          int? sizeBytes,
          Value<String?> sha256 = const Value.absent(),
          DateTime? createdAt}) =>
      EvidenceFile(
        id: id ?? this.id,
        institutionId: institutionId ?? this.institutionId,
        entityType: entityType ?? this.entityType,
        entityId: entityId ?? this.entityId,
        localPath: localPath.present ? localPath.value : this.localPath,
        remotePath: remotePath.present ? remotePath.value : this.remotePath,
        mime: mime ?? this.mime,
        sizeBytes: sizeBytes ?? this.sizeBytes,
        sha256: sha256.present ? sha256.value : this.sha256,
        createdAt: createdAt ?? this.createdAt,
      );
  EvidenceFile copyWithCompanion(EvidenceFilesCompanion data) {
    return EvidenceFile(
      id: data.id.present ? data.id.value : this.id,
      institutionId: data.institutionId.present
          ? data.institutionId.value
          : this.institutionId,
      entityType:
          data.entityType.present ? data.entityType.value : this.entityType,
      entityId: data.entityId.present ? data.entityId.value : this.entityId,
      localPath: data.localPath.present ? data.localPath.value : this.localPath,
      remotePath:
          data.remotePath.present ? data.remotePath.value : this.remotePath,
      mime: data.mime.present ? data.mime.value : this.mime,
      sizeBytes: data.sizeBytes.present ? data.sizeBytes.value : this.sizeBytes,
      sha256: data.sha256.present ? data.sha256.value : this.sha256,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('EvidenceFile(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('entityType: $entityType, ')
          ..write('entityId: $entityId, ')
          ..write('localPath: $localPath, ')
          ..write('remotePath: $remotePath, ')
          ..write('mime: $mime, ')
          ..write('sizeBytes: $sizeBytes, ')
          ..write('sha256: $sha256, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, institutionId, entityType, entityId,
      localPath, remotePath, mime, sizeBytes, sha256, createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EvidenceFile &&
          other.id == this.id &&
          other.institutionId == this.institutionId &&
          other.entityType == this.entityType &&
          other.entityId == this.entityId &&
          other.localPath == this.localPath &&
          other.remotePath == this.remotePath &&
          other.mime == this.mime &&
          other.sizeBytes == this.sizeBytes &&
          other.sha256 == this.sha256 &&
          other.createdAt == this.createdAt);
}

class EvidenceFilesCompanion extends UpdateCompanion<EvidenceFile> {
  final Value<String> id;
  final Value<String> institutionId;
  final Value<String> entityType;
  final Value<String> entityId;
  final Value<String?> localPath;
  final Value<String?> remotePath;
  final Value<String> mime;
  final Value<int> sizeBytes;
  final Value<String?> sha256;
  final Value<DateTime> createdAt;
  final Value<int> rowid;
  const EvidenceFilesCompanion({
    this.id = const Value.absent(),
    this.institutionId = const Value.absent(),
    this.entityType = const Value.absent(),
    this.entityId = const Value.absent(),
    this.localPath = const Value.absent(),
    this.remotePath = const Value.absent(),
    this.mime = const Value.absent(),
    this.sizeBytes = const Value.absent(),
    this.sha256 = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  EvidenceFilesCompanion.insert({
    required String id,
    required String institutionId,
    required String entityType,
    required String entityId,
    this.localPath = const Value.absent(),
    this.remotePath = const Value.absent(),
    required String mime,
    required int sizeBytes,
    this.sha256 = const Value.absent(),
    required DateTime createdAt,
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        institutionId = Value(institutionId),
        entityType = Value(entityType),
        entityId = Value(entityId),
        mime = Value(mime),
        sizeBytes = Value(sizeBytes),
        createdAt = Value(createdAt);
  static Insertable<EvidenceFile> custom({
    Expression<String>? id,
    Expression<String>? institutionId,
    Expression<String>? entityType,
    Expression<String>? entityId,
    Expression<String>? localPath,
    Expression<String>? remotePath,
    Expression<String>? mime,
    Expression<int>? sizeBytes,
    Expression<String>? sha256,
    Expression<DateTime>? createdAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (institutionId != null) 'institution_id': institutionId,
      if (entityType != null) 'entity_type': entityType,
      if (entityId != null) 'entity_id': entityId,
      if (localPath != null) 'local_path': localPath,
      if (remotePath != null) 'remote_path': remotePath,
      if (mime != null) 'mime': mime,
      if (sizeBytes != null) 'size_bytes': sizeBytes,
      if (sha256 != null) 'sha256': sha256,
      if (createdAt != null) 'created_at': createdAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  EvidenceFilesCompanion copyWith(
      {Value<String>? id,
      Value<String>? institutionId,
      Value<String>? entityType,
      Value<String>? entityId,
      Value<String?>? localPath,
      Value<String?>? remotePath,
      Value<String>? mime,
      Value<int>? sizeBytes,
      Value<String?>? sha256,
      Value<DateTime>? createdAt,
      Value<int>? rowid}) {
    return EvidenceFilesCompanion(
      id: id ?? this.id,
      institutionId: institutionId ?? this.institutionId,
      entityType: entityType ?? this.entityType,
      entityId: entityId ?? this.entityId,
      localPath: localPath ?? this.localPath,
      remotePath: remotePath ?? this.remotePath,
      mime: mime ?? this.mime,
      sizeBytes: sizeBytes ?? this.sizeBytes,
      sha256: sha256 ?? this.sha256,
      createdAt: createdAt ?? this.createdAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (institutionId.present) {
      map['institution_id'] = Variable<String>(institutionId.value);
    }
    if (entityType.present) {
      map['entity_type'] = Variable<String>(entityType.value);
    }
    if (entityId.present) {
      map['entity_id'] = Variable<String>(entityId.value);
    }
    if (localPath.present) {
      map['local_path'] = Variable<String>(localPath.value);
    }
    if (remotePath.present) {
      map['remote_path'] = Variable<String>(remotePath.value);
    }
    if (mime.present) {
      map['mime'] = Variable<String>(mime.value);
    }
    if (sizeBytes.present) {
      map['size_bytes'] = Variable<int>(sizeBytes.value);
    }
    if (sha256.present) {
      map['sha256'] = Variable<String>(sha256.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EvidenceFilesCompanion(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('entityType: $entityType, ')
          ..write('entityId: $entityId, ')
          ..write('localPath: $localPath, ')
          ..write('remotePath: $remotePath, ')
          ..write('mime: $mime, ')
          ..write('sizeBytes: $sizeBytes, ')
          ..write('sha256: $sha256, ')
          ..write('createdAt: $createdAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $AuditEventsTable extends AuditEvents
    with TableInfo<$AuditEventsTable, AuditEvent> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AuditEventsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _institutionIdMeta =
      const VerificationMeta('institutionId');
  @override
  late final GeneratedColumn<String> institutionId = GeneratedColumn<String>(
      'institution_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _sequenceMeta =
      const VerificationMeta('sequence');
  @override
  late final GeneratedColumn<int> sequence = GeneratedColumn<int>(
      'sequence', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _entityTypeMeta =
      const VerificationMeta('entityType');
  @override
  late final GeneratedColumn<String> entityType = GeneratedColumn<String>(
      'entity_type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _entityIdMeta =
      const VerificationMeta('entityId');
  @override
  late final GeneratedColumn<String> entityId = GeneratedColumn<String>(
      'entity_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _actionMeta = const VerificationMeta('action');
  @override
  late final GeneratedColumn<String> action = GeneratedColumn<String>(
      'action', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _actorIdMeta =
      const VerificationMeta('actorId');
  @override
  late final GeneratedColumn<String> actorId = GeneratedColumn<String>(
      'actor_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _occurredAtMeta =
      const VerificationMeta('occurredAt');
  @override
  late final GeneratedColumn<DateTime> occurredAt = GeneratedColumn<DateTime>(
      'occurred_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _reasonMeta = const VerificationMeta('reason');
  @override
  late final GeneratedColumn<String> reason = GeneratedColumn<String>(
      'reason', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _beforeJsonMeta =
      const VerificationMeta('beforeJson');
  @override
  late final GeneratedColumn<String> beforeJson = GeneratedColumn<String>(
      'before_json', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _afterJsonMeta =
      const VerificationMeta('afterJson');
  @override
  late final GeneratedColumn<String> afterJson = GeneratedColumn<String>(
      'after_json', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _prevHashMeta =
      const VerificationMeta('prevHash');
  @override
  late final GeneratedColumn<String> prevHash = GeneratedColumn<String>(
      'prev_hash', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _hashMeta = const VerificationMeta('hash');
  @override
  late final GeneratedColumn<String> hash = GeneratedColumn<String>(
      'hash', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        institutionId,
        sequence,
        entityType,
        entityId,
        action,
        actorId,
        occurredAt,
        reason,
        beforeJson,
        afterJson,
        prevHash,
        hash
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'audit_events';
  @override
  VerificationContext validateIntegrity(Insertable<AuditEvent> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('institution_id')) {
      context.handle(
          _institutionIdMeta,
          institutionId.isAcceptableOrUnknown(
              data['institution_id']!, _institutionIdMeta));
    } else if (isInserting) {
      context.missing(_institutionIdMeta);
    }
    if (data.containsKey('sequence')) {
      context.handle(_sequenceMeta,
          sequence.isAcceptableOrUnknown(data['sequence']!, _sequenceMeta));
    } else if (isInserting) {
      context.missing(_sequenceMeta);
    }
    if (data.containsKey('entity_type')) {
      context.handle(
          _entityTypeMeta,
          entityType.isAcceptableOrUnknown(
              data['entity_type']!, _entityTypeMeta));
    } else if (isInserting) {
      context.missing(_entityTypeMeta);
    }
    if (data.containsKey('entity_id')) {
      context.handle(_entityIdMeta,
          entityId.isAcceptableOrUnknown(data['entity_id']!, _entityIdMeta));
    } else if (isInserting) {
      context.missing(_entityIdMeta);
    }
    if (data.containsKey('action')) {
      context.handle(_actionMeta,
          action.isAcceptableOrUnknown(data['action']!, _actionMeta));
    } else if (isInserting) {
      context.missing(_actionMeta);
    }
    if (data.containsKey('actor_id')) {
      context.handle(_actorIdMeta,
          actorId.isAcceptableOrUnknown(data['actor_id']!, _actorIdMeta));
    } else if (isInserting) {
      context.missing(_actorIdMeta);
    }
    if (data.containsKey('occurred_at')) {
      context.handle(
          _occurredAtMeta,
          occurredAt.isAcceptableOrUnknown(
              data['occurred_at']!, _occurredAtMeta));
    } else if (isInserting) {
      context.missing(_occurredAtMeta);
    }
    if (data.containsKey('reason')) {
      context.handle(_reasonMeta,
          reason.isAcceptableOrUnknown(data['reason']!, _reasonMeta));
    }
    if (data.containsKey('before_json')) {
      context.handle(
          _beforeJsonMeta,
          beforeJson.isAcceptableOrUnknown(
              data['before_json']!, _beforeJsonMeta));
    }
    if (data.containsKey('after_json')) {
      context.handle(_afterJsonMeta,
          afterJson.isAcceptableOrUnknown(data['after_json']!, _afterJsonMeta));
    }
    if (data.containsKey('prev_hash')) {
      context.handle(_prevHashMeta,
          prevHash.isAcceptableOrUnknown(data['prev_hash']!, _prevHashMeta));
    } else if (isInserting) {
      context.missing(_prevHashMeta);
    }
    if (data.containsKey('hash')) {
      context.handle(
          _hashMeta, hash.isAcceptableOrUnknown(data['hash']!, _hashMeta));
    } else if (isInserting) {
      context.missing(_hashMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  List<Set<GeneratedColumn>> get uniqueKeys => [
        {institutionId, sequence},
      ];
  @override
  AuditEvent map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return AuditEvent(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      institutionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}institution_id'])!,
      sequence: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}sequence'])!,
      entityType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_type'])!,
      entityId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_id'])!,
      action: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}action'])!,
      actorId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}actor_id'])!,
      occurredAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}occurred_at'])!,
      reason: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}reason']),
      beforeJson: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}before_json']),
      afterJson: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}after_json']),
      prevHash: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}prev_hash'])!,
      hash: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hash'])!,
    );
  }

  @override
  $AuditEventsTable createAlias(String alias) {
    return $AuditEventsTable(attachedDatabase, alias);
  }
}

class AuditEvent extends DataClass implements Insertable<AuditEvent> {
  final String id;
  final String institutionId;
  final int sequence;
  final String entityType;
  final String entityId;
  final String action;
  final String actorId;
  final DateTime occurredAt;
  final String? reason;
  final String? beforeJson;
  final String? afterJson;
  final String prevHash;
  final String hash;
  const AuditEvent(
      {required this.id,
      required this.institutionId,
      required this.sequence,
      required this.entityType,
      required this.entityId,
      required this.action,
      required this.actorId,
      required this.occurredAt,
      this.reason,
      this.beforeJson,
      this.afterJson,
      required this.prevHash,
      required this.hash});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['institution_id'] = Variable<String>(institutionId);
    map['sequence'] = Variable<int>(sequence);
    map['entity_type'] = Variable<String>(entityType);
    map['entity_id'] = Variable<String>(entityId);
    map['action'] = Variable<String>(action);
    map['actor_id'] = Variable<String>(actorId);
    map['occurred_at'] = Variable<DateTime>(occurredAt);
    if (!nullToAbsent || reason != null) {
      map['reason'] = Variable<String>(reason);
    }
    if (!nullToAbsent || beforeJson != null) {
      map['before_json'] = Variable<String>(beforeJson);
    }
    if (!nullToAbsent || afterJson != null) {
      map['after_json'] = Variable<String>(afterJson);
    }
    map['prev_hash'] = Variable<String>(prevHash);
    map['hash'] = Variable<String>(hash);
    return map;
  }

  AuditEventsCompanion toCompanion(bool nullToAbsent) {
    return AuditEventsCompanion(
      id: Value(id),
      institutionId: Value(institutionId),
      sequence: Value(sequence),
      entityType: Value(entityType),
      entityId: Value(entityId),
      action: Value(action),
      actorId: Value(actorId),
      occurredAt: Value(occurredAt),
      reason:
          reason == null && nullToAbsent ? const Value.absent() : Value(reason),
      beforeJson: beforeJson == null && nullToAbsent
          ? const Value.absent()
          : Value(beforeJson),
      afterJson: afterJson == null && nullToAbsent
          ? const Value.absent()
          : Value(afterJson),
      prevHash: Value(prevHash),
      hash: Value(hash),
    );
  }

  factory AuditEvent.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return AuditEvent(
      id: serializer.fromJson<String>(json['id']),
      institutionId: serializer.fromJson<String>(json['institutionId']),
      sequence: serializer.fromJson<int>(json['sequence']),
      entityType: serializer.fromJson<String>(json['entityType']),
      entityId: serializer.fromJson<String>(json['entityId']),
      action: serializer.fromJson<String>(json['action']),
      actorId: serializer.fromJson<String>(json['actorId']),
      occurredAt: serializer.fromJson<DateTime>(json['occurredAt']),
      reason: serializer.fromJson<String?>(json['reason']),
      beforeJson: serializer.fromJson<String?>(json['beforeJson']),
      afterJson: serializer.fromJson<String?>(json['afterJson']),
      prevHash: serializer.fromJson<String>(json['prevHash']),
      hash: serializer.fromJson<String>(json['hash']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'institutionId': serializer.toJson<String>(institutionId),
      'sequence': serializer.toJson<int>(sequence),
      'entityType': serializer.toJson<String>(entityType),
      'entityId': serializer.toJson<String>(entityId),
      'action': serializer.toJson<String>(action),
      'actorId': serializer.toJson<String>(actorId),
      'occurredAt': serializer.toJson<DateTime>(occurredAt),
      'reason': serializer.toJson<String?>(reason),
      'beforeJson': serializer.toJson<String?>(beforeJson),
      'afterJson': serializer.toJson<String?>(afterJson),
      'prevHash': serializer.toJson<String>(prevHash),
      'hash': serializer.toJson<String>(hash),
    };
  }

  AuditEvent copyWith(
          {String? id,
          String? institutionId,
          int? sequence,
          String? entityType,
          String? entityId,
          String? action,
          String? actorId,
          DateTime? occurredAt,
          Value<String?> reason = const Value.absent(),
          Value<String?> beforeJson = const Value.absent(),
          Value<String?> afterJson = const Value.absent(),
          String? prevHash,
          String? hash}) =>
      AuditEvent(
        id: id ?? this.id,
        institutionId: institutionId ?? this.institutionId,
        sequence: sequence ?? this.sequence,
        entityType: entityType ?? this.entityType,
        entityId: entityId ?? this.entityId,
        action: action ?? this.action,
        actorId: actorId ?? this.actorId,
        occurredAt: occurredAt ?? this.occurredAt,
        reason: reason.present ? reason.value : this.reason,
        beforeJson: beforeJson.present ? beforeJson.value : this.beforeJson,
        afterJson: afterJson.present ? afterJson.value : this.afterJson,
        prevHash: prevHash ?? this.prevHash,
        hash: hash ?? this.hash,
      );
  AuditEvent copyWithCompanion(AuditEventsCompanion data) {
    return AuditEvent(
      id: data.id.present ? data.id.value : this.id,
      institutionId: data.institutionId.present
          ? data.institutionId.value
          : this.institutionId,
      sequence: data.sequence.present ? data.sequence.value : this.sequence,
      entityType:
          data.entityType.present ? data.entityType.value : this.entityType,
      entityId: data.entityId.present ? data.entityId.value : this.entityId,
      action: data.action.present ? data.action.value : this.action,
      actorId: data.actorId.present ? data.actorId.value : this.actorId,
      occurredAt:
          data.occurredAt.present ? data.occurredAt.value : this.occurredAt,
      reason: data.reason.present ? data.reason.value : this.reason,
      beforeJson:
          data.beforeJson.present ? data.beforeJson.value : this.beforeJson,
      afterJson: data.afterJson.present ? data.afterJson.value : this.afterJson,
      prevHash: data.prevHash.present ? data.prevHash.value : this.prevHash,
      hash: data.hash.present ? data.hash.value : this.hash,
    );
  }

  @override
  String toString() {
    return (StringBuffer('AuditEvent(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('sequence: $sequence, ')
          ..write('entityType: $entityType, ')
          ..write('entityId: $entityId, ')
          ..write('action: $action, ')
          ..write('actorId: $actorId, ')
          ..write('occurredAt: $occurredAt, ')
          ..write('reason: $reason, ')
          ..write('beforeJson: $beforeJson, ')
          ..write('afterJson: $afterJson, ')
          ..write('prevHash: $prevHash, ')
          ..write('hash: $hash')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      institutionId,
      sequence,
      entityType,
      entityId,
      action,
      actorId,
      occurredAt,
      reason,
      beforeJson,
      afterJson,
      prevHash,
      hash);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is AuditEvent &&
          other.id == this.id &&
          other.institutionId == this.institutionId &&
          other.sequence == this.sequence &&
          other.entityType == this.entityType &&
          other.entityId == this.entityId &&
          other.action == this.action &&
          other.actorId == this.actorId &&
          other.occurredAt == this.occurredAt &&
          other.reason == this.reason &&
          other.beforeJson == this.beforeJson &&
          other.afterJson == this.afterJson &&
          other.prevHash == this.prevHash &&
          other.hash == this.hash);
}

class AuditEventsCompanion extends UpdateCompanion<AuditEvent> {
  final Value<String> id;
  final Value<String> institutionId;
  final Value<int> sequence;
  final Value<String> entityType;
  final Value<String> entityId;
  final Value<String> action;
  final Value<String> actorId;
  final Value<DateTime> occurredAt;
  final Value<String?> reason;
  final Value<String?> beforeJson;
  final Value<String?> afterJson;
  final Value<String> prevHash;
  final Value<String> hash;
  final Value<int> rowid;
  const AuditEventsCompanion({
    this.id = const Value.absent(),
    this.institutionId = const Value.absent(),
    this.sequence = const Value.absent(),
    this.entityType = const Value.absent(),
    this.entityId = const Value.absent(),
    this.action = const Value.absent(),
    this.actorId = const Value.absent(),
    this.occurredAt = const Value.absent(),
    this.reason = const Value.absent(),
    this.beforeJson = const Value.absent(),
    this.afterJson = const Value.absent(),
    this.prevHash = const Value.absent(),
    this.hash = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  AuditEventsCompanion.insert({
    required String id,
    required String institutionId,
    required int sequence,
    required String entityType,
    required String entityId,
    required String action,
    required String actorId,
    required DateTime occurredAt,
    this.reason = const Value.absent(),
    this.beforeJson = const Value.absent(),
    this.afterJson = const Value.absent(),
    required String prevHash,
    required String hash,
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        institutionId = Value(institutionId),
        sequence = Value(sequence),
        entityType = Value(entityType),
        entityId = Value(entityId),
        action = Value(action),
        actorId = Value(actorId),
        occurredAt = Value(occurredAt),
        prevHash = Value(prevHash),
        hash = Value(hash);
  static Insertable<AuditEvent> custom({
    Expression<String>? id,
    Expression<String>? institutionId,
    Expression<int>? sequence,
    Expression<String>? entityType,
    Expression<String>? entityId,
    Expression<String>? action,
    Expression<String>? actorId,
    Expression<DateTime>? occurredAt,
    Expression<String>? reason,
    Expression<String>? beforeJson,
    Expression<String>? afterJson,
    Expression<String>? prevHash,
    Expression<String>? hash,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (institutionId != null) 'institution_id': institutionId,
      if (sequence != null) 'sequence': sequence,
      if (entityType != null) 'entity_type': entityType,
      if (entityId != null) 'entity_id': entityId,
      if (action != null) 'action': action,
      if (actorId != null) 'actor_id': actorId,
      if (occurredAt != null) 'occurred_at': occurredAt,
      if (reason != null) 'reason': reason,
      if (beforeJson != null) 'before_json': beforeJson,
      if (afterJson != null) 'after_json': afterJson,
      if (prevHash != null) 'prev_hash': prevHash,
      if (hash != null) 'hash': hash,
      if (rowid != null) 'rowid': rowid,
    });
  }

  AuditEventsCompanion copyWith(
      {Value<String>? id,
      Value<String>? institutionId,
      Value<int>? sequence,
      Value<String>? entityType,
      Value<String>? entityId,
      Value<String>? action,
      Value<String>? actorId,
      Value<DateTime>? occurredAt,
      Value<String?>? reason,
      Value<String?>? beforeJson,
      Value<String?>? afterJson,
      Value<String>? prevHash,
      Value<String>? hash,
      Value<int>? rowid}) {
    return AuditEventsCompanion(
      id: id ?? this.id,
      institutionId: institutionId ?? this.institutionId,
      sequence: sequence ?? this.sequence,
      entityType: entityType ?? this.entityType,
      entityId: entityId ?? this.entityId,
      action: action ?? this.action,
      actorId: actorId ?? this.actorId,
      occurredAt: occurredAt ?? this.occurredAt,
      reason: reason ?? this.reason,
      beforeJson: beforeJson ?? this.beforeJson,
      afterJson: afterJson ?? this.afterJson,
      prevHash: prevHash ?? this.prevHash,
      hash: hash ?? this.hash,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (institutionId.present) {
      map['institution_id'] = Variable<String>(institutionId.value);
    }
    if (sequence.present) {
      map['sequence'] = Variable<int>(sequence.value);
    }
    if (entityType.present) {
      map['entity_type'] = Variable<String>(entityType.value);
    }
    if (entityId.present) {
      map['entity_id'] = Variable<String>(entityId.value);
    }
    if (action.present) {
      map['action'] = Variable<String>(action.value);
    }
    if (actorId.present) {
      map['actor_id'] = Variable<String>(actorId.value);
    }
    if (occurredAt.present) {
      map['occurred_at'] = Variable<DateTime>(occurredAt.value);
    }
    if (reason.present) {
      map['reason'] = Variable<String>(reason.value);
    }
    if (beforeJson.present) {
      map['before_json'] = Variable<String>(beforeJson.value);
    }
    if (afterJson.present) {
      map['after_json'] = Variable<String>(afterJson.value);
    }
    if (prevHash.present) {
      map['prev_hash'] = Variable<String>(prevHash.value);
    }
    if (hash.present) {
      map['hash'] = Variable<String>(hash.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AuditEventsCompanion(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('sequence: $sequence, ')
          ..write('entityType: $entityType, ')
          ..write('entityId: $entityId, ')
          ..write('action: $action, ')
          ..write('actorId: $actorId, ')
          ..write('occurredAt: $occurredAt, ')
          ..write('reason: $reason, ')
          ..write('beforeJson: $beforeJson, ')
          ..write('afterJson: $afterJson, ')
          ..write('prevHash: $prevHash, ')
          ..write('hash: $hash, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $DevicesTable extends Devices with TableInfo<$DevicesTable, Device> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $DevicesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _institutionIdMeta =
      const VerificationMeta('institutionId');
  @override
  late final GeneratedColumn<String> institutionId = GeneratedColumn<String>(
      'institution_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _deviceNameMeta =
      const VerificationMeta('deviceName');
  @override
  late final GeneratedColumn<String> deviceName = GeneratedColumn<String>(
      'device_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _platformMeta =
      const VerificationMeta('platform');
  @override
  late final GeneratedColumn<String> platform = GeneratedColumn<String>(
      'platform', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _appVersionMeta =
      const VerificationMeta('appVersion');
  @override
  late final GeneratedColumn<String> appVersion = GeneratedColumn<String>(
      'app_version', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _registeredByMeta =
      const VerificationMeta('registeredBy');
  @override
  late final GeneratedColumn<String> registeredBy = GeneratedColumn<String>(
      'registered_by', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _registeredAtMeta =
      const VerificationMeta('registeredAt');
  @override
  late final GeneratedColumn<DateTime> registeredAt = GeneratedColumn<DateTime>(
      'registered_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _isActiveMeta =
      const VerificationMeta('isActive');
  @override
  late final GeneratedColumn<bool> isActive = GeneratedColumn<bool>(
      'is_active', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_active" IN (0, 1))'),
      defaultValue: const Constant(true));
  static const VerificationMeta _rangeStartMeta =
      const VerificationMeta('rangeStart');
  @override
  late final GeneratedColumn<int> rangeStart = GeneratedColumn<int>(
      'range_start', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _rangeEndMeta =
      const VerificationMeta('rangeEnd');
  @override
  late final GeneratedColumn<int> rangeEnd = GeneratedColumn<int>(
      'range_end', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        institutionId,
        deviceName,
        platform,
        appVersion,
        registeredBy,
        registeredAt,
        isActive,
        rangeStart,
        rangeEnd
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'devices';
  @override
  VerificationContext validateIntegrity(Insertable<Device> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('institution_id')) {
      context.handle(
          _institutionIdMeta,
          institutionId.isAcceptableOrUnknown(
              data['institution_id']!, _institutionIdMeta));
    } else if (isInserting) {
      context.missing(_institutionIdMeta);
    }
    if (data.containsKey('device_name')) {
      context.handle(
          _deviceNameMeta,
          deviceName.isAcceptableOrUnknown(
              data['device_name']!, _deviceNameMeta));
    } else if (isInserting) {
      context.missing(_deviceNameMeta);
    }
    if (data.containsKey('platform')) {
      context.handle(_platformMeta,
          platform.isAcceptableOrUnknown(data['platform']!, _platformMeta));
    } else if (isInserting) {
      context.missing(_platformMeta);
    }
    if (data.containsKey('app_version')) {
      context.handle(
          _appVersionMeta,
          appVersion.isAcceptableOrUnknown(
              data['app_version']!, _appVersionMeta));
    } else if (isInserting) {
      context.missing(_appVersionMeta);
    }
    if (data.containsKey('registered_by')) {
      context.handle(
          _registeredByMeta,
          registeredBy.isAcceptableOrUnknown(
              data['registered_by']!, _registeredByMeta));
    }
    if (data.containsKey('registered_at')) {
      context.handle(
          _registeredAtMeta,
          registeredAt.isAcceptableOrUnknown(
              data['registered_at']!, _registeredAtMeta));
    } else if (isInserting) {
      context.missing(_registeredAtMeta);
    }
    if (data.containsKey('is_active')) {
      context.handle(_isActiveMeta,
          isActive.isAcceptableOrUnknown(data['is_active']!, _isActiveMeta));
    }
    if (data.containsKey('range_start')) {
      context.handle(
          _rangeStartMeta,
          rangeStart.isAcceptableOrUnknown(
              data['range_start']!, _rangeStartMeta));
    }
    if (data.containsKey('range_end')) {
      context.handle(_rangeEndMeta,
          rangeEnd.isAcceptableOrUnknown(data['range_end']!, _rangeEndMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Device map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Device(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      institutionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}institution_id'])!,
      deviceName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}device_name'])!,
      platform: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}platform'])!,
      appVersion: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_version'])!,
      registeredBy: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}registered_by']),
      registeredAt: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}registered_at'])!,
      isActive: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_active'])!,
      rangeStart: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}range_start']),
      rangeEnd: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}range_end']),
    );
  }

  @override
  $DevicesTable createAlias(String alias) {
    return $DevicesTable(attachedDatabase, alias);
  }
}

class Device extends DataClass implements Insertable<Device> {
  final String id;
  final String institutionId;
  final String deviceName;
  final String platform;
  final String appVersion;
  final String? registeredBy;
  final DateTime registeredAt;
  final bool isActive;
  final int? rangeStart;
  final int? rangeEnd;
  const Device(
      {required this.id,
      required this.institutionId,
      required this.deviceName,
      required this.platform,
      required this.appVersion,
      this.registeredBy,
      required this.registeredAt,
      required this.isActive,
      this.rangeStart,
      this.rangeEnd});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['institution_id'] = Variable<String>(institutionId);
    map['device_name'] = Variable<String>(deviceName);
    map['platform'] = Variable<String>(platform);
    map['app_version'] = Variable<String>(appVersion);
    if (!nullToAbsent || registeredBy != null) {
      map['registered_by'] = Variable<String>(registeredBy);
    }
    map['registered_at'] = Variable<DateTime>(registeredAt);
    map['is_active'] = Variable<bool>(isActive);
    if (!nullToAbsent || rangeStart != null) {
      map['range_start'] = Variable<int>(rangeStart);
    }
    if (!nullToAbsent || rangeEnd != null) {
      map['range_end'] = Variable<int>(rangeEnd);
    }
    return map;
  }

  DevicesCompanion toCompanion(bool nullToAbsent) {
    return DevicesCompanion(
      id: Value(id),
      institutionId: Value(institutionId),
      deviceName: Value(deviceName),
      platform: Value(platform),
      appVersion: Value(appVersion),
      registeredBy: registeredBy == null && nullToAbsent
          ? const Value.absent()
          : Value(registeredBy),
      registeredAt: Value(registeredAt),
      isActive: Value(isActive),
      rangeStart: rangeStart == null && nullToAbsent
          ? const Value.absent()
          : Value(rangeStart),
      rangeEnd: rangeEnd == null && nullToAbsent
          ? const Value.absent()
          : Value(rangeEnd),
    );
  }

  factory Device.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Device(
      id: serializer.fromJson<String>(json['id']),
      institutionId: serializer.fromJson<String>(json['institutionId']),
      deviceName: serializer.fromJson<String>(json['deviceName']),
      platform: serializer.fromJson<String>(json['platform']),
      appVersion: serializer.fromJson<String>(json['appVersion']),
      registeredBy: serializer.fromJson<String?>(json['registeredBy']),
      registeredAt: serializer.fromJson<DateTime>(json['registeredAt']),
      isActive: serializer.fromJson<bool>(json['isActive']),
      rangeStart: serializer.fromJson<int?>(json['rangeStart']),
      rangeEnd: serializer.fromJson<int?>(json['rangeEnd']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'institutionId': serializer.toJson<String>(institutionId),
      'deviceName': serializer.toJson<String>(deviceName),
      'platform': serializer.toJson<String>(platform),
      'appVersion': serializer.toJson<String>(appVersion),
      'registeredBy': serializer.toJson<String?>(registeredBy),
      'registeredAt': serializer.toJson<DateTime>(registeredAt),
      'isActive': serializer.toJson<bool>(isActive),
      'rangeStart': serializer.toJson<int?>(rangeStart),
      'rangeEnd': serializer.toJson<int?>(rangeEnd),
    };
  }

  Device copyWith(
          {String? id,
          String? institutionId,
          String? deviceName,
          String? platform,
          String? appVersion,
          Value<String?> registeredBy = const Value.absent(),
          DateTime? registeredAt,
          bool? isActive,
          Value<int?> rangeStart = const Value.absent(),
          Value<int?> rangeEnd = const Value.absent()}) =>
      Device(
        id: id ?? this.id,
        institutionId: institutionId ?? this.institutionId,
        deviceName: deviceName ?? this.deviceName,
        platform: platform ?? this.platform,
        appVersion: appVersion ?? this.appVersion,
        registeredBy:
            registeredBy.present ? registeredBy.value : this.registeredBy,
        registeredAt: registeredAt ?? this.registeredAt,
        isActive: isActive ?? this.isActive,
        rangeStart: rangeStart.present ? rangeStart.value : this.rangeStart,
        rangeEnd: rangeEnd.present ? rangeEnd.value : this.rangeEnd,
      );
  Device copyWithCompanion(DevicesCompanion data) {
    return Device(
      id: data.id.present ? data.id.value : this.id,
      institutionId: data.institutionId.present
          ? data.institutionId.value
          : this.institutionId,
      deviceName:
          data.deviceName.present ? data.deviceName.value : this.deviceName,
      platform: data.platform.present ? data.platform.value : this.platform,
      appVersion:
          data.appVersion.present ? data.appVersion.value : this.appVersion,
      registeredBy: data.registeredBy.present
          ? data.registeredBy.value
          : this.registeredBy,
      registeredAt: data.registeredAt.present
          ? data.registeredAt.value
          : this.registeredAt,
      isActive: data.isActive.present ? data.isActive.value : this.isActive,
      rangeStart:
          data.rangeStart.present ? data.rangeStart.value : this.rangeStart,
      rangeEnd: data.rangeEnd.present ? data.rangeEnd.value : this.rangeEnd,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Device(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('deviceName: $deviceName, ')
          ..write('platform: $platform, ')
          ..write('appVersion: $appVersion, ')
          ..write('registeredBy: $registeredBy, ')
          ..write('registeredAt: $registeredAt, ')
          ..write('isActive: $isActive, ')
          ..write('rangeStart: $rangeStart, ')
          ..write('rangeEnd: $rangeEnd')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, institutionId, deviceName, platform,
      appVersion, registeredBy, registeredAt, isActive, rangeStart, rangeEnd);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Device &&
          other.id == this.id &&
          other.institutionId == this.institutionId &&
          other.deviceName == this.deviceName &&
          other.platform == this.platform &&
          other.appVersion == this.appVersion &&
          other.registeredBy == this.registeredBy &&
          other.registeredAt == this.registeredAt &&
          other.isActive == this.isActive &&
          other.rangeStart == this.rangeStart &&
          other.rangeEnd == this.rangeEnd);
}

class DevicesCompanion extends UpdateCompanion<Device> {
  final Value<String> id;
  final Value<String> institutionId;
  final Value<String> deviceName;
  final Value<String> platform;
  final Value<String> appVersion;
  final Value<String?> registeredBy;
  final Value<DateTime> registeredAt;
  final Value<bool> isActive;
  final Value<int?> rangeStart;
  final Value<int?> rangeEnd;
  final Value<int> rowid;
  const DevicesCompanion({
    this.id = const Value.absent(),
    this.institutionId = const Value.absent(),
    this.deviceName = const Value.absent(),
    this.platform = const Value.absent(),
    this.appVersion = const Value.absent(),
    this.registeredBy = const Value.absent(),
    this.registeredAt = const Value.absent(),
    this.isActive = const Value.absent(),
    this.rangeStart = const Value.absent(),
    this.rangeEnd = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  DevicesCompanion.insert({
    required String id,
    required String institutionId,
    required String deviceName,
    required String platform,
    required String appVersion,
    this.registeredBy = const Value.absent(),
    required DateTime registeredAt,
    this.isActive = const Value.absent(),
    this.rangeStart = const Value.absent(),
    this.rangeEnd = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        institutionId = Value(institutionId),
        deviceName = Value(deviceName),
        platform = Value(platform),
        appVersion = Value(appVersion),
        registeredAt = Value(registeredAt);
  static Insertable<Device> custom({
    Expression<String>? id,
    Expression<String>? institutionId,
    Expression<String>? deviceName,
    Expression<String>? platform,
    Expression<String>? appVersion,
    Expression<String>? registeredBy,
    Expression<DateTime>? registeredAt,
    Expression<bool>? isActive,
    Expression<int>? rangeStart,
    Expression<int>? rangeEnd,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (institutionId != null) 'institution_id': institutionId,
      if (deviceName != null) 'device_name': deviceName,
      if (platform != null) 'platform': platform,
      if (appVersion != null) 'app_version': appVersion,
      if (registeredBy != null) 'registered_by': registeredBy,
      if (registeredAt != null) 'registered_at': registeredAt,
      if (isActive != null) 'is_active': isActive,
      if (rangeStart != null) 'range_start': rangeStart,
      if (rangeEnd != null) 'range_end': rangeEnd,
      if (rowid != null) 'rowid': rowid,
    });
  }

  DevicesCompanion copyWith(
      {Value<String>? id,
      Value<String>? institutionId,
      Value<String>? deviceName,
      Value<String>? platform,
      Value<String>? appVersion,
      Value<String?>? registeredBy,
      Value<DateTime>? registeredAt,
      Value<bool>? isActive,
      Value<int?>? rangeStart,
      Value<int?>? rangeEnd,
      Value<int>? rowid}) {
    return DevicesCompanion(
      id: id ?? this.id,
      institutionId: institutionId ?? this.institutionId,
      deviceName: deviceName ?? this.deviceName,
      platform: platform ?? this.platform,
      appVersion: appVersion ?? this.appVersion,
      registeredBy: registeredBy ?? this.registeredBy,
      registeredAt: registeredAt ?? this.registeredAt,
      isActive: isActive ?? this.isActive,
      rangeStart: rangeStart ?? this.rangeStart,
      rangeEnd: rangeEnd ?? this.rangeEnd,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (institutionId.present) {
      map['institution_id'] = Variable<String>(institutionId.value);
    }
    if (deviceName.present) {
      map['device_name'] = Variable<String>(deviceName.value);
    }
    if (platform.present) {
      map['platform'] = Variable<String>(platform.value);
    }
    if (appVersion.present) {
      map['app_version'] = Variable<String>(appVersion.value);
    }
    if (registeredBy.present) {
      map['registered_by'] = Variable<String>(registeredBy.value);
    }
    if (registeredAt.present) {
      map['registered_at'] = Variable<DateTime>(registeredAt.value);
    }
    if (isActive.present) {
      map['is_active'] = Variable<bool>(isActive.value);
    }
    if (rangeStart.present) {
      map['range_start'] = Variable<int>(rangeStart.value);
    }
    if (rangeEnd.present) {
      map['range_end'] = Variable<int>(rangeEnd.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('DevicesCompanion(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('deviceName: $deviceName, ')
          ..write('platform: $platform, ')
          ..write('appVersion: $appVersion, ')
          ..write('registeredBy: $registeredBy, ')
          ..write('registeredAt: $registeredAt, ')
          ..write('isActive: $isActive, ')
          ..write('rangeStart: $rangeStart, ')
          ..write('rangeEnd: $rangeEnd, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $SyncOutboxTable extends SyncOutbox
    with TableInfo<$SyncOutboxTable, SyncOutboxData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SyncOutboxTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _institutionIdMeta =
      const VerificationMeta('institutionId');
  @override
  late final GeneratedColumn<String> institutionId = GeneratedColumn<String>(
      'institution_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _entityTypeMeta =
      const VerificationMeta('entityType');
  @override
  late final GeneratedColumn<String> entityType = GeneratedColumn<String>(
      'entity_type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _entityIdMeta =
      const VerificationMeta('entityId');
  @override
  late final GeneratedColumn<String> entityId = GeneratedColumn<String>(
      'entity_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  @override
  late final GeneratedColumnWithTypeConverter<OutboxOperation, String>
      operation = GeneratedColumn<String>('operation', aliasedName, false,
              type: DriftSqlType.string, requiredDuringInsert: true)
          .withConverter<OutboxOperation>($SyncOutboxTable.$converteroperation);
  static const VerificationMeta _payloadJsonMeta =
      const VerificationMeta('payloadJson');
  @override
  late final GeneratedColumn<String> payloadJson = GeneratedColumn<String>(
      'payload_json', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _idempotencyKeyMeta =
      const VerificationMeta('idempotencyKey');
  @override
  late final GeneratedColumn<String> idempotencyKey = GeneratedColumn<String>(
      'idempotency_key', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: true,
      defaultConstraints: GeneratedColumn.constraintIsAlways('UNIQUE'));
  static const VerificationMeta _attemptsMeta =
      const VerificationMeta('attempts');
  @override
  late final GeneratedColumn<int> attempts = GeneratedColumn<int>(
      'attempts', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _nextRetryAtMeta =
      const VerificationMeta('nextRetryAt');
  @override
  late final GeneratedColumn<DateTime> nextRetryAt = GeneratedColumn<DateTime>(
      'next_retry_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  @override
  late final GeneratedColumnWithTypeConverter<SyncStatus, String> status =
      GeneratedColumn<String>('status', aliasedName, false,
              type: DriftSqlType.string, requiredDuringInsert: true)
          .withConverter<SyncStatus>($SyncOutboxTable.$converterstatus);
  static const VerificationMeta _lastErrorMeta =
      const VerificationMeta('lastError');
  @override
  late final GeneratedColumn<String> lastError = GeneratedColumn<String>(
      'last_error', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        institutionId,
        entityType,
        entityId,
        operation,
        payloadJson,
        idempotencyKey,
        attempts,
        nextRetryAt,
        status,
        lastError,
        createdAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'sync_outbox';
  @override
  VerificationContext validateIntegrity(Insertable<SyncOutboxData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('institution_id')) {
      context.handle(
          _institutionIdMeta,
          institutionId.isAcceptableOrUnknown(
              data['institution_id']!, _institutionIdMeta));
    } else if (isInserting) {
      context.missing(_institutionIdMeta);
    }
    if (data.containsKey('entity_type')) {
      context.handle(
          _entityTypeMeta,
          entityType.isAcceptableOrUnknown(
              data['entity_type']!, _entityTypeMeta));
    } else if (isInserting) {
      context.missing(_entityTypeMeta);
    }
    if (data.containsKey('entity_id')) {
      context.handle(_entityIdMeta,
          entityId.isAcceptableOrUnknown(data['entity_id']!, _entityIdMeta));
    } else if (isInserting) {
      context.missing(_entityIdMeta);
    }
    if (data.containsKey('payload_json')) {
      context.handle(
          _payloadJsonMeta,
          payloadJson.isAcceptableOrUnknown(
              data['payload_json']!, _payloadJsonMeta));
    } else if (isInserting) {
      context.missing(_payloadJsonMeta);
    }
    if (data.containsKey('idempotency_key')) {
      context.handle(
          _idempotencyKeyMeta,
          idempotencyKey.isAcceptableOrUnknown(
              data['idempotency_key']!, _idempotencyKeyMeta));
    } else if (isInserting) {
      context.missing(_idempotencyKeyMeta);
    }
    if (data.containsKey('attempts')) {
      context.handle(_attemptsMeta,
          attempts.isAcceptableOrUnknown(data['attempts']!, _attemptsMeta));
    }
    if (data.containsKey('next_retry_at')) {
      context.handle(
          _nextRetryAtMeta,
          nextRetryAt.isAcceptableOrUnknown(
              data['next_retry_at']!, _nextRetryAtMeta));
    } else if (isInserting) {
      context.missing(_nextRetryAtMeta);
    }
    if (data.containsKey('last_error')) {
      context.handle(_lastErrorMeta,
          lastError.isAcceptableOrUnknown(data['last_error']!, _lastErrorMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  SyncOutboxData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SyncOutboxData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      institutionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}institution_id'])!,
      entityType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_type'])!,
      entityId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_id'])!,
      operation: $SyncOutboxTable.$converteroperation.fromSql(attachedDatabase
          .typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}operation'])!),
      payloadJson: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}payload_json'])!,
      idempotencyKey: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}idempotency_key'])!,
      attempts: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}attempts'])!,
      nextRetryAt: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}next_retry_at'])!,
      status: $SyncOutboxTable.$converterstatus.fromSql(attachedDatabase
          .typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status'])!),
      lastError: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}last_error']),
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
    );
  }

  @override
  $SyncOutboxTable createAlias(String alias) {
    return $SyncOutboxTable(attachedDatabase, alias);
  }

  static JsonTypeConverter2<OutboxOperation, String, String>
      $converteroperation =
      const EnumNameConverter<OutboxOperation>(OutboxOperation.values);
  static JsonTypeConverter2<SyncStatus, String, String> $converterstatus =
      const EnumNameConverter<SyncStatus>(SyncStatus.values);
}

class SyncOutboxData extends DataClass implements Insertable<SyncOutboxData> {
  final String id;
  final String institutionId;
  final String entityType;
  final String entityId;
  final OutboxOperation operation;
  final String payloadJson;
  final String idempotencyKey;
  final int attempts;
  final DateTime nextRetryAt;
  final SyncStatus status;
  final String? lastError;
  final DateTime createdAt;
  const SyncOutboxData(
      {required this.id,
      required this.institutionId,
      required this.entityType,
      required this.entityId,
      required this.operation,
      required this.payloadJson,
      required this.idempotencyKey,
      required this.attempts,
      required this.nextRetryAt,
      required this.status,
      this.lastError,
      required this.createdAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['institution_id'] = Variable<String>(institutionId);
    map['entity_type'] = Variable<String>(entityType);
    map['entity_id'] = Variable<String>(entityId);
    {
      map['operation'] = Variable<String>(
          $SyncOutboxTable.$converteroperation.toSql(operation));
    }
    map['payload_json'] = Variable<String>(payloadJson);
    map['idempotency_key'] = Variable<String>(idempotencyKey);
    map['attempts'] = Variable<int>(attempts);
    map['next_retry_at'] = Variable<DateTime>(nextRetryAt);
    {
      map['status'] =
          Variable<String>($SyncOutboxTable.$converterstatus.toSql(status));
    }
    if (!nullToAbsent || lastError != null) {
      map['last_error'] = Variable<String>(lastError);
    }
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  SyncOutboxCompanion toCompanion(bool nullToAbsent) {
    return SyncOutboxCompanion(
      id: Value(id),
      institutionId: Value(institutionId),
      entityType: Value(entityType),
      entityId: Value(entityId),
      operation: Value(operation),
      payloadJson: Value(payloadJson),
      idempotencyKey: Value(idempotencyKey),
      attempts: Value(attempts),
      nextRetryAt: Value(nextRetryAt),
      status: Value(status),
      lastError: lastError == null && nullToAbsent
          ? const Value.absent()
          : Value(lastError),
      createdAt: Value(createdAt),
    );
  }

  factory SyncOutboxData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SyncOutboxData(
      id: serializer.fromJson<String>(json['id']),
      institutionId: serializer.fromJson<String>(json['institutionId']),
      entityType: serializer.fromJson<String>(json['entityType']),
      entityId: serializer.fromJson<String>(json['entityId']),
      operation: $SyncOutboxTable.$converteroperation
          .fromJson(serializer.fromJson<String>(json['operation'])),
      payloadJson: serializer.fromJson<String>(json['payloadJson']),
      idempotencyKey: serializer.fromJson<String>(json['idempotencyKey']),
      attempts: serializer.fromJson<int>(json['attempts']),
      nextRetryAt: serializer.fromJson<DateTime>(json['nextRetryAt']),
      status: $SyncOutboxTable.$converterstatus
          .fromJson(serializer.fromJson<String>(json['status'])),
      lastError: serializer.fromJson<String?>(json['lastError']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'institutionId': serializer.toJson<String>(institutionId),
      'entityType': serializer.toJson<String>(entityType),
      'entityId': serializer.toJson<String>(entityId),
      'operation': serializer.toJson<String>(
          $SyncOutboxTable.$converteroperation.toJson(operation)),
      'payloadJson': serializer.toJson<String>(payloadJson),
      'idempotencyKey': serializer.toJson<String>(idempotencyKey),
      'attempts': serializer.toJson<int>(attempts),
      'nextRetryAt': serializer.toJson<DateTime>(nextRetryAt),
      'status': serializer
          .toJson<String>($SyncOutboxTable.$converterstatus.toJson(status)),
      'lastError': serializer.toJson<String?>(lastError),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  SyncOutboxData copyWith(
          {String? id,
          String? institutionId,
          String? entityType,
          String? entityId,
          OutboxOperation? operation,
          String? payloadJson,
          String? idempotencyKey,
          int? attempts,
          DateTime? nextRetryAt,
          SyncStatus? status,
          Value<String?> lastError = const Value.absent(),
          DateTime? createdAt}) =>
      SyncOutboxData(
        id: id ?? this.id,
        institutionId: institutionId ?? this.institutionId,
        entityType: entityType ?? this.entityType,
        entityId: entityId ?? this.entityId,
        operation: operation ?? this.operation,
        payloadJson: payloadJson ?? this.payloadJson,
        idempotencyKey: idempotencyKey ?? this.idempotencyKey,
        attempts: attempts ?? this.attempts,
        nextRetryAt: nextRetryAt ?? this.nextRetryAt,
        status: status ?? this.status,
        lastError: lastError.present ? lastError.value : this.lastError,
        createdAt: createdAt ?? this.createdAt,
      );
  SyncOutboxData copyWithCompanion(SyncOutboxCompanion data) {
    return SyncOutboxData(
      id: data.id.present ? data.id.value : this.id,
      institutionId: data.institutionId.present
          ? data.institutionId.value
          : this.institutionId,
      entityType:
          data.entityType.present ? data.entityType.value : this.entityType,
      entityId: data.entityId.present ? data.entityId.value : this.entityId,
      operation: data.operation.present ? data.operation.value : this.operation,
      payloadJson:
          data.payloadJson.present ? data.payloadJson.value : this.payloadJson,
      idempotencyKey: data.idempotencyKey.present
          ? data.idempotencyKey.value
          : this.idempotencyKey,
      attempts: data.attempts.present ? data.attempts.value : this.attempts,
      nextRetryAt:
          data.nextRetryAt.present ? data.nextRetryAt.value : this.nextRetryAt,
      status: data.status.present ? data.status.value : this.status,
      lastError: data.lastError.present ? data.lastError.value : this.lastError,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SyncOutboxData(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('entityType: $entityType, ')
          ..write('entityId: $entityId, ')
          ..write('operation: $operation, ')
          ..write('payloadJson: $payloadJson, ')
          ..write('idempotencyKey: $idempotencyKey, ')
          ..write('attempts: $attempts, ')
          ..write('nextRetryAt: $nextRetryAt, ')
          ..write('status: $status, ')
          ..write('lastError: $lastError, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      institutionId,
      entityType,
      entityId,
      operation,
      payloadJson,
      idempotencyKey,
      attempts,
      nextRetryAt,
      status,
      lastError,
      createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SyncOutboxData &&
          other.id == this.id &&
          other.institutionId == this.institutionId &&
          other.entityType == this.entityType &&
          other.entityId == this.entityId &&
          other.operation == this.operation &&
          other.payloadJson == this.payloadJson &&
          other.idempotencyKey == this.idempotencyKey &&
          other.attempts == this.attempts &&
          other.nextRetryAt == this.nextRetryAt &&
          other.status == this.status &&
          other.lastError == this.lastError &&
          other.createdAt == this.createdAt);
}

class SyncOutboxCompanion extends UpdateCompanion<SyncOutboxData> {
  final Value<String> id;
  final Value<String> institutionId;
  final Value<String> entityType;
  final Value<String> entityId;
  final Value<OutboxOperation> operation;
  final Value<String> payloadJson;
  final Value<String> idempotencyKey;
  final Value<int> attempts;
  final Value<DateTime> nextRetryAt;
  final Value<SyncStatus> status;
  final Value<String?> lastError;
  final Value<DateTime> createdAt;
  final Value<int> rowid;
  const SyncOutboxCompanion({
    this.id = const Value.absent(),
    this.institutionId = const Value.absent(),
    this.entityType = const Value.absent(),
    this.entityId = const Value.absent(),
    this.operation = const Value.absent(),
    this.payloadJson = const Value.absent(),
    this.idempotencyKey = const Value.absent(),
    this.attempts = const Value.absent(),
    this.nextRetryAt = const Value.absent(),
    this.status = const Value.absent(),
    this.lastError = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  SyncOutboxCompanion.insert({
    required String id,
    required String institutionId,
    required String entityType,
    required String entityId,
    required OutboxOperation operation,
    required String payloadJson,
    required String idempotencyKey,
    this.attempts = const Value.absent(),
    required DateTime nextRetryAt,
    required SyncStatus status,
    this.lastError = const Value.absent(),
    required DateTime createdAt,
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        institutionId = Value(institutionId),
        entityType = Value(entityType),
        entityId = Value(entityId),
        operation = Value(operation),
        payloadJson = Value(payloadJson),
        idempotencyKey = Value(idempotencyKey),
        nextRetryAt = Value(nextRetryAt),
        status = Value(status),
        createdAt = Value(createdAt);
  static Insertable<SyncOutboxData> custom({
    Expression<String>? id,
    Expression<String>? institutionId,
    Expression<String>? entityType,
    Expression<String>? entityId,
    Expression<String>? operation,
    Expression<String>? payloadJson,
    Expression<String>? idempotencyKey,
    Expression<int>? attempts,
    Expression<DateTime>? nextRetryAt,
    Expression<String>? status,
    Expression<String>? lastError,
    Expression<DateTime>? createdAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (institutionId != null) 'institution_id': institutionId,
      if (entityType != null) 'entity_type': entityType,
      if (entityId != null) 'entity_id': entityId,
      if (operation != null) 'operation': operation,
      if (payloadJson != null) 'payload_json': payloadJson,
      if (idempotencyKey != null) 'idempotency_key': idempotencyKey,
      if (attempts != null) 'attempts': attempts,
      if (nextRetryAt != null) 'next_retry_at': nextRetryAt,
      if (status != null) 'status': status,
      if (lastError != null) 'last_error': lastError,
      if (createdAt != null) 'created_at': createdAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  SyncOutboxCompanion copyWith(
      {Value<String>? id,
      Value<String>? institutionId,
      Value<String>? entityType,
      Value<String>? entityId,
      Value<OutboxOperation>? operation,
      Value<String>? payloadJson,
      Value<String>? idempotencyKey,
      Value<int>? attempts,
      Value<DateTime>? nextRetryAt,
      Value<SyncStatus>? status,
      Value<String?>? lastError,
      Value<DateTime>? createdAt,
      Value<int>? rowid}) {
    return SyncOutboxCompanion(
      id: id ?? this.id,
      institutionId: institutionId ?? this.institutionId,
      entityType: entityType ?? this.entityType,
      entityId: entityId ?? this.entityId,
      operation: operation ?? this.operation,
      payloadJson: payloadJson ?? this.payloadJson,
      idempotencyKey: idempotencyKey ?? this.idempotencyKey,
      attempts: attempts ?? this.attempts,
      nextRetryAt: nextRetryAt ?? this.nextRetryAt,
      status: status ?? this.status,
      lastError: lastError ?? this.lastError,
      createdAt: createdAt ?? this.createdAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (institutionId.present) {
      map['institution_id'] = Variable<String>(institutionId.value);
    }
    if (entityType.present) {
      map['entity_type'] = Variable<String>(entityType.value);
    }
    if (entityId.present) {
      map['entity_id'] = Variable<String>(entityId.value);
    }
    if (operation.present) {
      map['operation'] = Variable<String>(
          $SyncOutboxTable.$converteroperation.toSql(operation.value));
    }
    if (payloadJson.present) {
      map['payload_json'] = Variable<String>(payloadJson.value);
    }
    if (idempotencyKey.present) {
      map['idempotency_key'] = Variable<String>(idempotencyKey.value);
    }
    if (attempts.present) {
      map['attempts'] = Variable<int>(attempts.value);
    }
    if (nextRetryAt.present) {
      map['next_retry_at'] = Variable<DateTime>(nextRetryAt.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(
          $SyncOutboxTable.$converterstatus.toSql(status.value));
    }
    if (lastError.present) {
      map['last_error'] = Variable<String>(lastError.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SyncOutboxCompanion(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('entityType: $entityType, ')
          ..write('entityId: $entityId, ')
          ..write('operation: $operation, ')
          ..write('payloadJson: $payloadJson, ')
          ..write('idempotencyKey: $idempotencyKey, ')
          ..write('attempts: $attempts, ')
          ..write('nextRetryAt: $nextRetryAt, ')
          ..write('status: $status, ')
          ..write('lastError: $lastError, ')
          ..write('createdAt: $createdAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $SyncConflictsTable extends SyncConflicts
    with TableInfo<$SyncConflictsTable, SyncConflict> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SyncConflictsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _institutionIdMeta =
      const VerificationMeta('institutionId');
  @override
  late final GeneratedColumn<String> institutionId = GeneratedColumn<String>(
      'institution_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _entityTypeMeta =
      const VerificationMeta('entityType');
  @override
  late final GeneratedColumn<String> entityType = GeneratedColumn<String>(
      'entity_type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _entityIdMeta =
      const VerificationMeta('entityId');
  @override
  late final GeneratedColumn<String> entityId = GeneratedColumn<String>(
      'entity_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _localJsonMeta =
      const VerificationMeta('localJson');
  @override
  late final GeneratedColumn<String> localJson = GeneratedColumn<String>(
      'local_json', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _remoteJsonMeta =
      const VerificationMeta('remoteJson');
  @override
  late final GeneratedColumn<String> remoteJson = GeneratedColumn<String>(
      'remote_json', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _detectedAtMeta =
      const VerificationMeta('detectedAt');
  @override
  late final GeneratedColumn<DateTime> detectedAt = GeneratedColumn<DateTime>(
      'detected_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('open'));
  static const VerificationMeta _resolvedByMeta =
      const VerificationMeta('resolvedBy');
  @override
  late final GeneratedColumn<String> resolvedBy = GeneratedColumn<String>(
      'resolved_by', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _resolvedAtMeta =
      const VerificationMeta('resolvedAt');
  @override
  late final GeneratedColumn<DateTime> resolvedAt = GeneratedColumn<DateTime>(
      'resolved_at', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _resolutionNoteMeta =
      const VerificationMeta('resolutionNote');
  @override
  late final GeneratedColumn<String> resolutionNote = GeneratedColumn<String>(
      'resolution_note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        institutionId,
        entityType,
        entityId,
        localJson,
        remoteJson,
        detectedAt,
        status,
        resolvedBy,
        resolvedAt,
        resolutionNote
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'sync_conflicts';
  @override
  VerificationContext validateIntegrity(Insertable<SyncConflict> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('institution_id')) {
      context.handle(
          _institutionIdMeta,
          institutionId.isAcceptableOrUnknown(
              data['institution_id']!, _institutionIdMeta));
    } else if (isInserting) {
      context.missing(_institutionIdMeta);
    }
    if (data.containsKey('entity_type')) {
      context.handle(
          _entityTypeMeta,
          entityType.isAcceptableOrUnknown(
              data['entity_type']!, _entityTypeMeta));
    } else if (isInserting) {
      context.missing(_entityTypeMeta);
    }
    if (data.containsKey('entity_id')) {
      context.handle(_entityIdMeta,
          entityId.isAcceptableOrUnknown(data['entity_id']!, _entityIdMeta));
    } else if (isInserting) {
      context.missing(_entityIdMeta);
    }
    if (data.containsKey('local_json')) {
      context.handle(_localJsonMeta,
          localJson.isAcceptableOrUnknown(data['local_json']!, _localJsonMeta));
    } else if (isInserting) {
      context.missing(_localJsonMeta);
    }
    if (data.containsKey('remote_json')) {
      context.handle(
          _remoteJsonMeta,
          remoteJson.isAcceptableOrUnknown(
              data['remote_json']!, _remoteJsonMeta));
    } else if (isInserting) {
      context.missing(_remoteJsonMeta);
    }
    if (data.containsKey('detected_at')) {
      context.handle(
          _detectedAtMeta,
          detectedAt.isAcceptableOrUnknown(
              data['detected_at']!, _detectedAtMeta));
    } else if (isInserting) {
      context.missing(_detectedAtMeta);
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('resolved_by')) {
      context.handle(
          _resolvedByMeta,
          resolvedBy.isAcceptableOrUnknown(
              data['resolved_by']!, _resolvedByMeta));
    }
    if (data.containsKey('resolved_at')) {
      context.handle(
          _resolvedAtMeta,
          resolvedAt.isAcceptableOrUnknown(
              data['resolved_at']!, _resolvedAtMeta));
    }
    if (data.containsKey('resolution_note')) {
      context.handle(
          _resolutionNoteMeta,
          resolutionNote.isAcceptableOrUnknown(
              data['resolution_note']!, _resolutionNoteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  SyncConflict map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SyncConflict(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      institutionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}institution_id'])!,
      entityType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_type'])!,
      entityId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_id'])!,
      localJson: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}local_json'])!,
      remoteJson: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}remote_json'])!,
      detectedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}detected_at'])!,
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status'])!,
      resolvedBy: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}resolved_by']),
      resolvedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}resolved_at']),
      resolutionNote: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}resolution_note']),
    );
  }

  @override
  $SyncConflictsTable createAlias(String alias) {
    return $SyncConflictsTable(attachedDatabase, alias);
  }
}

class SyncConflict extends DataClass implements Insertable<SyncConflict> {
  final String id;
  final String institutionId;
  final String entityType;
  final String entityId;
  final String localJson;
  final String remoteJson;
  final DateTime detectedAt;
  final String status;
  final String? resolvedBy;
  final DateTime? resolvedAt;
  final String? resolutionNote;
  const SyncConflict(
      {required this.id,
      required this.institutionId,
      required this.entityType,
      required this.entityId,
      required this.localJson,
      required this.remoteJson,
      required this.detectedAt,
      required this.status,
      this.resolvedBy,
      this.resolvedAt,
      this.resolutionNote});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['institution_id'] = Variable<String>(institutionId);
    map['entity_type'] = Variable<String>(entityType);
    map['entity_id'] = Variable<String>(entityId);
    map['local_json'] = Variable<String>(localJson);
    map['remote_json'] = Variable<String>(remoteJson);
    map['detected_at'] = Variable<DateTime>(detectedAt);
    map['status'] = Variable<String>(status);
    if (!nullToAbsent || resolvedBy != null) {
      map['resolved_by'] = Variable<String>(resolvedBy);
    }
    if (!nullToAbsent || resolvedAt != null) {
      map['resolved_at'] = Variable<DateTime>(resolvedAt);
    }
    if (!nullToAbsent || resolutionNote != null) {
      map['resolution_note'] = Variable<String>(resolutionNote);
    }
    return map;
  }

  SyncConflictsCompanion toCompanion(bool nullToAbsent) {
    return SyncConflictsCompanion(
      id: Value(id),
      institutionId: Value(institutionId),
      entityType: Value(entityType),
      entityId: Value(entityId),
      localJson: Value(localJson),
      remoteJson: Value(remoteJson),
      detectedAt: Value(detectedAt),
      status: Value(status),
      resolvedBy: resolvedBy == null && nullToAbsent
          ? const Value.absent()
          : Value(resolvedBy),
      resolvedAt: resolvedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(resolvedAt),
      resolutionNote: resolutionNote == null && nullToAbsent
          ? const Value.absent()
          : Value(resolutionNote),
    );
  }

  factory SyncConflict.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SyncConflict(
      id: serializer.fromJson<String>(json['id']),
      institutionId: serializer.fromJson<String>(json['institutionId']),
      entityType: serializer.fromJson<String>(json['entityType']),
      entityId: serializer.fromJson<String>(json['entityId']),
      localJson: serializer.fromJson<String>(json['localJson']),
      remoteJson: serializer.fromJson<String>(json['remoteJson']),
      detectedAt: serializer.fromJson<DateTime>(json['detectedAt']),
      status: serializer.fromJson<String>(json['status']),
      resolvedBy: serializer.fromJson<String?>(json['resolvedBy']),
      resolvedAt: serializer.fromJson<DateTime?>(json['resolvedAt']),
      resolutionNote: serializer.fromJson<String?>(json['resolutionNote']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'institutionId': serializer.toJson<String>(institutionId),
      'entityType': serializer.toJson<String>(entityType),
      'entityId': serializer.toJson<String>(entityId),
      'localJson': serializer.toJson<String>(localJson),
      'remoteJson': serializer.toJson<String>(remoteJson),
      'detectedAt': serializer.toJson<DateTime>(detectedAt),
      'status': serializer.toJson<String>(status),
      'resolvedBy': serializer.toJson<String?>(resolvedBy),
      'resolvedAt': serializer.toJson<DateTime?>(resolvedAt),
      'resolutionNote': serializer.toJson<String?>(resolutionNote),
    };
  }

  SyncConflict copyWith(
          {String? id,
          String? institutionId,
          String? entityType,
          String? entityId,
          String? localJson,
          String? remoteJson,
          DateTime? detectedAt,
          String? status,
          Value<String?> resolvedBy = const Value.absent(),
          Value<DateTime?> resolvedAt = const Value.absent(),
          Value<String?> resolutionNote = const Value.absent()}) =>
      SyncConflict(
        id: id ?? this.id,
        institutionId: institutionId ?? this.institutionId,
        entityType: entityType ?? this.entityType,
        entityId: entityId ?? this.entityId,
        localJson: localJson ?? this.localJson,
        remoteJson: remoteJson ?? this.remoteJson,
        detectedAt: detectedAt ?? this.detectedAt,
        status: status ?? this.status,
        resolvedBy: resolvedBy.present ? resolvedBy.value : this.resolvedBy,
        resolvedAt: resolvedAt.present ? resolvedAt.value : this.resolvedAt,
        resolutionNote:
            resolutionNote.present ? resolutionNote.value : this.resolutionNote,
      );
  SyncConflict copyWithCompanion(SyncConflictsCompanion data) {
    return SyncConflict(
      id: data.id.present ? data.id.value : this.id,
      institutionId: data.institutionId.present
          ? data.institutionId.value
          : this.institutionId,
      entityType:
          data.entityType.present ? data.entityType.value : this.entityType,
      entityId: data.entityId.present ? data.entityId.value : this.entityId,
      localJson: data.localJson.present ? data.localJson.value : this.localJson,
      remoteJson:
          data.remoteJson.present ? data.remoteJson.value : this.remoteJson,
      detectedAt:
          data.detectedAt.present ? data.detectedAt.value : this.detectedAt,
      status: data.status.present ? data.status.value : this.status,
      resolvedBy:
          data.resolvedBy.present ? data.resolvedBy.value : this.resolvedBy,
      resolvedAt:
          data.resolvedAt.present ? data.resolvedAt.value : this.resolvedAt,
      resolutionNote: data.resolutionNote.present
          ? data.resolutionNote.value
          : this.resolutionNote,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SyncConflict(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('entityType: $entityType, ')
          ..write('entityId: $entityId, ')
          ..write('localJson: $localJson, ')
          ..write('remoteJson: $remoteJson, ')
          ..write('detectedAt: $detectedAt, ')
          ..write('status: $status, ')
          ..write('resolvedBy: $resolvedBy, ')
          ..write('resolvedAt: $resolvedAt, ')
          ..write('resolutionNote: $resolutionNote')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      institutionId,
      entityType,
      entityId,
      localJson,
      remoteJson,
      detectedAt,
      status,
      resolvedBy,
      resolvedAt,
      resolutionNote);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SyncConflict &&
          other.id == this.id &&
          other.institutionId == this.institutionId &&
          other.entityType == this.entityType &&
          other.entityId == this.entityId &&
          other.localJson == this.localJson &&
          other.remoteJson == this.remoteJson &&
          other.detectedAt == this.detectedAt &&
          other.status == this.status &&
          other.resolvedBy == this.resolvedBy &&
          other.resolvedAt == this.resolvedAt &&
          other.resolutionNote == this.resolutionNote);
}

class SyncConflictsCompanion extends UpdateCompanion<SyncConflict> {
  final Value<String> id;
  final Value<String> institutionId;
  final Value<String> entityType;
  final Value<String> entityId;
  final Value<String> localJson;
  final Value<String> remoteJson;
  final Value<DateTime> detectedAt;
  final Value<String> status;
  final Value<String?> resolvedBy;
  final Value<DateTime?> resolvedAt;
  final Value<String?> resolutionNote;
  final Value<int> rowid;
  const SyncConflictsCompanion({
    this.id = const Value.absent(),
    this.institutionId = const Value.absent(),
    this.entityType = const Value.absent(),
    this.entityId = const Value.absent(),
    this.localJson = const Value.absent(),
    this.remoteJson = const Value.absent(),
    this.detectedAt = const Value.absent(),
    this.status = const Value.absent(),
    this.resolvedBy = const Value.absent(),
    this.resolvedAt = const Value.absent(),
    this.resolutionNote = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  SyncConflictsCompanion.insert({
    required String id,
    required String institutionId,
    required String entityType,
    required String entityId,
    required String localJson,
    required String remoteJson,
    required DateTime detectedAt,
    this.status = const Value.absent(),
    this.resolvedBy = const Value.absent(),
    this.resolvedAt = const Value.absent(),
    this.resolutionNote = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        institutionId = Value(institutionId),
        entityType = Value(entityType),
        entityId = Value(entityId),
        localJson = Value(localJson),
        remoteJson = Value(remoteJson),
        detectedAt = Value(detectedAt);
  static Insertable<SyncConflict> custom({
    Expression<String>? id,
    Expression<String>? institutionId,
    Expression<String>? entityType,
    Expression<String>? entityId,
    Expression<String>? localJson,
    Expression<String>? remoteJson,
    Expression<DateTime>? detectedAt,
    Expression<String>? status,
    Expression<String>? resolvedBy,
    Expression<DateTime>? resolvedAt,
    Expression<String>? resolutionNote,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (institutionId != null) 'institution_id': institutionId,
      if (entityType != null) 'entity_type': entityType,
      if (entityId != null) 'entity_id': entityId,
      if (localJson != null) 'local_json': localJson,
      if (remoteJson != null) 'remote_json': remoteJson,
      if (detectedAt != null) 'detected_at': detectedAt,
      if (status != null) 'status': status,
      if (resolvedBy != null) 'resolved_by': resolvedBy,
      if (resolvedAt != null) 'resolved_at': resolvedAt,
      if (resolutionNote != null) 'resolution_note': resolutionNote,
      if (rowid != null) 'rowid': rowid,
    });
  }

  SyncConflictsCompanion copyWith(
      {Value<String>? id,
      Value<String>? institutionId,
      Value<String>? entityType,
      Value<String>? entityId,
      Value<String>? localJson,
      Value<String>? remoteJson,
      Value<DateTime>? detectedAt,
      Value<String>? status,
      Value<String?>? resolvedBy,
      Value<DateTime?>? resolvedAt,
      Value<String?>? resolutionNote,
      Value<int>? rowid}) {
    return SyncConflictsCompanion(
      id: id ?? this.id,
      institutionId: institutionId ?? this.institutionId,
      entityType: entityType ?? this.entityType,
      entityId: entityId ?? this.entityId,
      localJson: localJson ?? this.localJson,
      remoteJson: remoteJson ?? this.remoteJson,
      detectedAt: detectedAt ?? this.detectedAt,
      status: status ?? this.status,
      resolvedBy: resolvedBy ?? this.resolvedBy,
      resolvedAt: resolvedAt ?? this.resolvedAt,
      resolutionNote: resolutionNote ?? this.resolutionNote,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (institutionId.present) {
      map['institution_id'] = Variable<String>(institutionId.value);
    }
    if (entityType.present) {
      map['entity_type'] = Variable<String>(entityType.value);
    }
    if (entityId.present) {
      map['entity_id'] = Variable<String>(entityId.value);
    }
    if (localJson.present) {
      map['local_json'] = Variable<String>(localJson.value);
    }
    if (remoteJson.present) {
      map['remote_json'] = Variable<String>(remoteJson.value);
    }
    if (detectedAt.present) {
      map['detected_at'] = Variable<DateTime>(detectedAt.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (resolvedBy.present) {
      map['resolved_by'] = Variable<String>(resolvedBy.value);
    }
    if (resolvedAt.present) {
      map['resolved_at'] = Variable<DateTime>(resolvedAt.value);
    }
    if (resolutionNote.present) {
      map['resolution_note'] = Variable<String>(resolutionNote.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SyncConflictsCompanion(')
          ..write('id: $id, ')
          ..write('institutionId: $institutionId, ')
          ..write('entityType: $entityType, ')
          ..write('entityId: $entityId, ')
          ..write('localJson: $localJson, ')
          ..write('remoteJson: $remoteJson, ')
          ..write('detectedAt: $detectedAt, ')
          ..write('status: $status, ')
          ..write('resolvedBy: $resolvedBy, ')
          ..write('resolvedAt: $resolvedAt, ')
          ..write('resolutionNote: $resolutionNote, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $InstitutionsTable institutions = $InstitutionsTable(this);
  late final $UserProfilesTable userProfiles = $UserProfilesTable(this);
  late final $DonorsTable donors = $DonorsTable(this);
  late final $FundTypesTable fundTypes = $FundTypesTable(this);
  late final $PurposesTable purposes = $PurposesTable(this);
  late final $BankAccountsTable bankAccounts = $BankAccountsTable(this);
  late final $ReceiptsTable receipts = $ReceiptsTable(this);
  late final $ReceiptAllocationsTable receiptAllocations =
      $ReceiptAllocationsTable(this);
  late final $PaymentVerificationsTable paymentVerifications =
      $PaymentVerificationsTable(this);
  late final $ReceiptSequencesTable receiptSequences =
      $ReceiptSequencesTable(this);
  late final $ExpenseVouchersTable expenseVouchers =
      $ExpenseVouchersTable(this);
  late final $ExpenseAllocationsTable expenseAllocations =
      $ExpenseAllocationsTable(this);
  late final $ApprovalsTable approvals = $ApprovalsTable(this);
  late final $ReconciliationsTable reconciliations =
      $ReconciliationsTable(this);
  late final $EvidenceFilesTable evidenceFiles = $EvidenceFilesTable(this);
  late final $AuditEventsTable auditEvents = $AuditEventsTable(this);
  late final $DevicesTable devices = $DevicesTable(this);
  late final $SyncOutboxTable syncOutbox = $SyncOutboxTable(this);
  late final $SyncConflictsTable syncConflicts = $SyncConflictsTable(this);
  late final Index idxDonorsInstitutionName = Index(
      'idx_donors_institution_name',
      'CREATE INDEX idx_donors_institution_name ON donors (institution_id, name)');
  late final Index idxReceiptsInstitutionDate = Index(
      'idx_receipts_institution_date',
      'CREATE INDEX idx_receipts_institution_date ON receipts (institution_id, receipt_date)');
  late final Index idxReceiptsStatus = Index('idx_receipts_status',
      'CREATE INDEX idx_receipts_status ON receipts (institution_id, status)');
  late final Index idxReceiptsIdempotency = Index('idx_receipts_idempotency',
      'CREATE INDEX idx_receipts_idempotency ON receipts (idempotency_key)');
  late final Index idxExpensesInstitutionDate = Index(
      'idx_expenses_institution_date',
      'CREATE INDEX idx_expenses_institution_date ON expense_vouchers (institution_id, voucher_date)');
  late final Index idxApprovalsEntity = Index('idx_approvals_entity',
      'CREATE INDEX idx_approvals_entity ON approvals (entity_type, entity_id)');
  late final Index idxAuditEntity = Index('idx_audit_entity',
      'CREATE INDEX idx_audit_entity ON audit_events (institution_id, entity_type, entity_id)');
  late final Index idxAuditTime = Index('idx_audit_time',
      'CREATE INDEX idx_audit_time ON audit_events (institution_id, occurred_at)');
  late final Index idxOutboxStatus = Index('idx_outbox_status',
      'CREATE INDEX idx_outbox_status ON sync_outbox (status, next_retry_at)');
  late final Index idxConflictsStatus = Index('idx_conflicts_status',
      'CREATE INDEX idx_conflicts_status ON sync_conflicts (status)');
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        institutions,
        userProfiles,
        donors,
        fundTypes,
        purposes,
        bankAccounts,
        receipts,
        receiptAllocations,
        paymentVerifications,
        receiptSequences,
        expenseVouchers,
        expenseAllocations,
        approvals,
        reconciliations,
        evidenceFiles,
        auditEvents,
        devices,
        syncOutbox,
        syncConflicts,
        idxDonorsInstitutionName,
        idxReceiptsInstitutionDate,
        idxReceiptsStatus,
        idxReceiptsIdempotency,
        idxExpensesInstitutionDate,
        idxApprovalsEntity,
        idxAuditEntity,
        idxAuditTime,
        idxOutboxStatus,
        idxConflictsStatus
      ];
}

typedef $$InstitutionsTableCreateCompanionBuilder = InstitutionsCompanion
    Function({
  required String id,
  required String nameUr,
  required String nameEn,
  Value<String?> logoPath,
  Value<String?> address,
  Value<String?> phone,
  Value<String?> email,
  Value<String?> registrationNo,
  Value<String?> ntn,
  Value<int> fyStartMonth,
  Value<int> fyStartDay,
  Value<String> receiptPrefix,
  Value<String> numberingFormat,
  Value<String> receiptLanguage,
  Value<String> printFormat,
  Value<String> acceptedMethodsJson,
  Value<String?> signatoriesJson,
  Value<int> dualApprovalThresholdPaisa,
  Value<bool> autoSync,
  Value<bool> isDemo,
  required DateTime createdAt,
  required DateTime updatedAt,
  Value<DateTime?> serverUpdatedAt,
  Value<bool> isDirty,
  Value<int> rowid,
});
typedef $$InstitutionsTableUpdateCompanionBuilder = InstitutionsCompanion
    Function({
  Value<String> id,
  Value<String> nameUr,
  Value<String> nameEn,
  Value<String?> logoPath,
  Value<String?> address,
  Value<String?> phone,
  Value<String?> email,
  Value<String?> registrationNo,
  Value<String?> ntn,
  Value<int> fyStartMonth,
  Value<int> fyStartDay,
  Value<String> receiptPrefix,
  Value<String> numberingFormat,
  Value<String> receiptLanguage,
  Value<String> printFormat,
  Value<String> acceptedMethodsJson,
  Value<String?> signatoriesJson,
  Value<int> dualApprovalThresholdPaisa,
  Value<bool> autoSync,
  Value<bool> isDemo,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<DateTime?> serverUpdatedAt,
  Value<bool> isDirty,
  Value<int> rowid,
});

class $$InstitutionsTableFilterComposer
    extends Composer<_$AppDatabase, $InstitutionsTable> {
  $$InstitutionsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get nameUr => $composableBuilder(
      column: $table.nameUr, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get nameEn => $composableBuilder(
      column: $table.nameEn, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get logoPath => $composableBuilder(
      column: $table.logoPath, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get address => $composableBuilder(
      column: $table.address, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get phone => $composableBuilder(
      column: $table.phone, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get email => $composableBuilder(
      column: $table.email, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get registrationNo => $composableBuilder(
      column: $table.registrationNo,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get ntn => $composableBuilder(
      column: $table.ntn, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get fyStartMonth => $composableBuilder(
      column: $table.fyStartMonth, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get fyStartDay => $composableBuilder(
      column: $table.fyStartDay, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get receiptPrefix => $composableBuilder(
      column: $table.receiptPrefix, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get numberingFormat => $composableBuilder(
      column: $table.numberingFormat,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get receiptLanguage => $composableBuilder(
      column: $table.receiptLanguage,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get printFormat => $composableBuilder(
      column: $table.printFormat, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get acceptedMethodsJson => $composableBuilder(
      column: $table.acceptedMethodsJson,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get signatoriesJson => $composableBuilder(
      column: $table.signatoriesJson,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get dualApprovalThresholdPaisa => $composableBuilder(
      column: $table.dualApprovalThresholdPaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get autoSync => $composableBuilder(
      column: $table.autoSync, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isDemo => $composableBuilder(
      column: $table.isDemo, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isDirty => $composableBuilder(
      column: $table.isDirty, builder: (column) => ColumnFilters(column));
}

class $$InstitutionsTableOrderingComposer
    extends Composer<_$AppDatabase, $InstitutionsTable> {
  $$InstitutionsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get nameUr => $composableBuilder(
      column: $table.nameUr, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get nameEn => $composableBuilder(
      column: $table.nameEn, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get logoPath => $composableBuilder(
      column: $table.logoPath, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get address => $composableBuilder(
      column: $table.address, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get phone => $composableBuilder(
      column: $table.phone, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get email => $composableBuilder(
      column: $table.email, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get registrationNo => $composableBuilder(
      column: $table.registrationNo,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get ntn => $composableBuilder(
      column: $table.ntn, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get fyStartMonth => $composableBuilder(
      column: $table.fyStartMonth,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get fyStartDay => $composableBuilder(
      column: $table.fyStartDay, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get receiptPrefix => $composableBuilder(
      column: $table.receiptPrefix,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get numberingFormat => $composableBuilder(
      column: $table.numberingFormat,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get receiptLanguage => $composableBuilder(
      column: $table.receiptLanguage,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get printFormat => $composableBuilder(
      column: $table.printFormat, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get acceptedMethodsJson => $composableBuilder(
      column: $table.acceptedMethodsJson,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get signatoriesJson => $composableBuilder(
      column: $table.signatoriesJson,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get dualApprovalThresholdPaisa => $composableBuilder(
      column: $table.dualApprovalThresholdPaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get autoSync => $composableBuilder(
      column: $table.autoSync, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isDemo => $composableBuilder(
      column: $table.isDemo, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isDirty => $composableBuilder(
      column: $table.isDirty, builder: (column) => ColumnOrderings(column));
}

class $$InstitutionsTableAnnotationComposer
    extends Composer<_$AppDatabase, $InstitutionsTable> {
  $$InstitutionsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get nameUr =>
      $composableBuilder(column: $table.nameUr, builder: (column) => column);

  GeneratedColumn<String> get nameEn =>
      $composableBuilder(column: $table.nameEn, builder: (column) => column);

  GeneratedColumn<String> get logoPath =>
      $composableBuilder(column: $table.logoPath, builder: (column) => column);

  GeneratedColumn<String> get address =>
      $composableBuilder(column: $table.address, builder: (column) => column);

  GeneratedColumn<String> get phone =>
      $composableBuilder(column: $table.phone, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<String> get registrationNo => $composableBuilder(
      column: $table.registrationNo, builder: (column) => column);

  GeneratedColumn<String> get ntn =>
      $composableBuilder(column: $table.ntn, builder: (column) => column);

  GeneratedColumn<int> get fyStartMonth => $composableBuilder(
      column: $table.fyStartMonth, builder: (column) => column);

  GeneratedColumn<int> get fyStartDay => $composableBuilder(
      column: $table.fyStartDay, builder: (column) => column);

  GeneratedColumn<String> get receiptPrefix => $composableBuilder(
      column: $table.receiptPrefix, builder: (column) => column);

  GeneratedColumn<String> get numberingFormat => $composableBuilder(
      column: $table.numberingFormat, builder: (column) => column);

  GeneratedColumn<String> get receiptLanguage => $composableBuilder(
      column: $table.receiptLanguage, builder: (column) => column);

  GeneratedColumn<String> get printFormat => $composableBuilder(
      column: $table.printFormat, builder: (column) => column);

  GeneratedColumn<String> get acceptedMethodsJson => $composableBuilder(
      column: $table.acceptedMethodsJson, builder: (column) => column);

  GeneratedColumn<String> get signatoriesJson => $composableBuilder(
      column: $table.signatoriesJson, builder: (column) => column);

  GeneratedColumn<int> get dualApprovalThresholdPaisa => $composableBuilder(
      column: $table.dualApprovalThresholdPaisa, builder: (column) => column);

  GeneratedColumn<bool> get autoSync =>
      $composableBuilder(column: $table.autoSync, builder: (column) => column);

  GeneratedColumn<bool> get isDemo =>
      $composableBuilder(column: $table.isDemo, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt, builder: (column) => column);

  GeneratedColumn<bool> get isDirty =>
      $composableBuilder(column: $table.isDirty, builder: (column) => column);
}

class $$InstitutionsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $InstitutionsTable,
    Institution,
    $$InstitutionsTableFilterComposer,
    $$InstitutionsTableOrderingComposer,
    $$InstitutionsTableAnnotationComposer,
    $$InstitutionsTableCreateCompanionBuilder,
    $$InstitutionsTableUpdateCompanionBuilder,
    (
      Institution,
      BaseReferences<_$AppDatabase, $InstitutionsTable, Institution>
    ),
    Institution,
    PrefetchHooks Function()> {
  $$InstitutionsTableTableManager(_$AppDatabase db, $InstitutionsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$InstitutionsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$InstitutionsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$InstitutionsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> nameUr = const Value.absent(),
            Value<String> nameEn = const Value.absent(),
            Value<String?> logoPath = const Value.absent(),
            Value<String?> address = const Value.absent(),
            Value<String?> phone = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> registrationNo = const Value.absent(),
            Value<String?> ntn = const Value.absent(),
            Value<int> fyStartMonth = const Value.absent(),
            Value<int> fyStartDay = const Value.absent(),
            Value<String> receiptPrefix = const Value.absent(),
            Value<String> numberingFormat = const Value.absent(),
            Value<String> receiptLanguage = const Value.absent(),
            Value<String> printFormat = const Value.absent(),
            Value<String> acceptedMethodsJson = const Value.absent(),
            Value<String?> signatoriesJson = const Value.absent(),
            Value<int> dualApprovalThresholdPaisa = const Value.absent(),
            Value<bool> autoSync = const Value.absent(),
            Value<bool> isDemo = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<DateTime?> serverUpdatedAt = const Value.absent(),
            Value<bool> isDirty = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              InstitutionsCompanion(
            id: id,
            nameUr: nameUr,
            nameEn: nameEn,
            logoPath: logoPath,
            address: address,
            phone: phone,
            email: email,
            registrationNo: registrationNo,
            ntn: ntn,
            fyStartMonth: fyStartMonth,
            fyStartDay: fyStartDay,
            receiptPrefix: receiptPrefix,
            numberingFormat: numberingFormat,
            receiptLanguage: receiptLanguage,
            printFormat: printFormat,
            acceptedMethodsJson: acceptedMethodsJson,
            signatoriesJson: signatoriesJson,
            dualApprovalThresholdPaisa: dualApprovalThresholdPaisa,
            autoSync: autoSync,
            isDemo: isDemo,
            createdAt: createdAt,
            updatedAt: updatedAt,
            serverUpdatedAt: serverUpdatedAt,
            isDirty: isDirty,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String nameUr,
            required String nameEn,
            Value<String?> logoPath = const Value.absent(),
            Value<String?> address = const Value.absent(),
            Value<String?> phone = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> registrationNo = const Value.absent(),
            Value<String?> ntn = const Value.absent(),
            Value<int> fyStartMonth = const Value.absent(),
            Value<int> fyStartDay = const Value.absent(),
            Value<String> receiptPrefix = const Value.absent(),
            Value<String> numberingFormat = const Value.absent(),
            Value<String> receiptLanguage = const Value.absent(),
            Value<String> printFormat = const Value.absent(),
            Value<String> acceptedMethodsJson = const Value.absent(),
            Value<String?> signatoriesJson = const Value.absent(),
            Value<int> dualApprovalThresholdPaisa = const Value.absent(),
            Value<bool> autoSync = const Value.absent(),
            Value<bool> isDemo = const Value.absent(),
            required DateTime createdAt,
            required DateTime updatedAt,
            Value<DateTime?> serverUpdatedAt = const Value.absent(),
            Value<bool> isDirty = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              InstitutionsCompanion.insert(
            id: id,
            nameUr: nameUr,
            nameEn: nameEn,
            logoPath: logoPath,
            address: address,
            phone: phone,
            email: email,
            registrationNo: registrationNo,
            ntn: ntn,
            fyStartMonth: fyStartMonth,
            fyStartDay: fyStartDay,
            receiptPrefix: receiptPrefix,
            numberingFormat: numberingFormat,
            receiptLanguage: receiptLanguage,
            printFormat: printFormat,
            acceptedMethodsJson: acceptedMethodsJson,
            signatoriesJson: signatoriesJson,
            dualApprovalThresholdPaisa: dualApprovalThresholdPaisa,
            autoSync: autoSync,
            isDemo: isDemo,
            createdAt: createdAt,
            updatedAt: updatedAt,
            serverUpdatedAt: serverUpdatedAt,
            isDirty: isDirty,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$InstitutionsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $InstitutionsTable,
    Institution,
    $$InstitutionsTableFilterComposer,
    $$InstitutionsTableOrderingComposer,
    $$InstitutionsTableAnnotationComposer,
    $$InstitutionsTableCreateCompanionBuilder,
    $$InstitutionsTableUpdateCompanionBuilder,
    (
      Institution,
      BaseReferences<_$AppDatabase, $InstitutionsTable, Institution>
    ),
    Institution,
    PrefetchHooks Function()>;
typedef $$UserProfilesTableCreateCompanionBuilder = UserProfilesCompanion
    Function({
  required String id,
  required String institutionId,
  required String displayName,
  required String email,
  required UserRole role,
  Value<String?> pinHash,
  Value<bool> isActive,
  required DateTime createdAt,
  Value<DateTime?> serverUpdatedAt,
  Value<bool> isDirty,
  Value<int> rowid,
});
typedef $$UserProfilesTableUpdateCompanionBuilder = UserProfilesCompanion
    Function({
  Value<String> id,
  Value<String> institutionId,
  Value<String> displayName,
  Value<String> email,
  Value<UserRole> role,
  Value<String?> pinHash,
  Value<bool> isActive,
  Value<DateTime> createdAt,
  Value<DateTime?> serverUpdatedAt,
  Value<bool> isDirty,
  Value<int> rowid,
});

class $$UserProfilesTableFilterComposer
    extends Composer<_$AppDatabase, $UserProfilesTable> {
  $$UserProfilesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get displayName => $composableBuilder(
      column: $table.displayName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get email => $composableBuilder(
      column: $table.email, builder: (column) => ColumnFilters(column));

  ColumnWithTypeConverterFilters<UserRole, UserRole, String> get role =>
      $composableBuilder(
          column: $table.role,
          builder: (column) => ColumnWithTypeConverterFilters(column));

  ColumnFilters<String> get pinHash => $composableBuilder(
      column: $table.pinHash, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isDirty => $composableBuilder(
      column: $table.isDirty, builder: (column) => ColumnFilters(column));
}

class $$UserProfilesTableOrderingComposer
    extends Composer<_$AppDatabase, $UserProfilesTable> {
  $$UserProfilesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get institutionId => $composableBuilder(
      column: $table.institutionId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get displayName => $composableBuilder(
      column: $table.displayName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get email => $composableBuilder(
      column: $table.email, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get role => $composableBuilder(
      column: $table.role, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get pinHash => $composableBuilder(
      column: $table.pinHash, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isDirty => $composableBuilder(
      column: $table.isDirty, builder: (column) => ColumnOrderings(column));
}

class $$UserProfilesTableAnnotationComposer
    extends Composer<_$AppDatabase, $UserProfilesTable> {
  $$UserProfilesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => column);

  GeneratedColumn<String> get displayName => $composableBuilder(
      column: $table.displayName, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumnWithTypeConverter<UserRole, String> get role =>
      $composableBuilder(column: $table.role, builder: (column) => column);

  GeneratedColumn<String> get pinHash =>
      $composableBuilder(column: $table.pinHash, builder: (column) => column);

  GeneratedColumn<bool> get isActive =>
      $composableBuilder(column: $table.isActive, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt, builder: (column) => column);

  GeneratedColumn<bool> get isDirty =>
      $composableBuilder(column: $table.isDirty, builder: (column) => column);
}

class $$UserProfilesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $UserProfilesTable,
    UserProfile,
    $$UserProfilesTableFilterComposer,
    $$UserProfilesTableOrderingComposer,
    $$UserProfilesTableAnnotationComposer,
    $$UserProfilesTableCreateCompanionBuilder,
    $$UserProfilesTableUpdateCompanionBuilder,
    (
      UserProfile,
      BaseReferences<_$AppDatabase, $UserProfilesTable, UserProfile>
    ),
    UserProfile,
    PrefetchHooks Function()> {
  $$UserProfilesTableTableManager(_$AppDatabase db, $UserProfilesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$UserProfilesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$UserProfilesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$UserProfilesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> institutionId = const Value.absent(),
            Value<String> displayName = const Value.absent(),
            Value<String> email = const Value.absent(),
            Value<UserRole> role = const Value.absent(),
            Value<String?> pinHash = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime?> serverUpdatedAt = const Value.absent(),
            Value<bool> isDirty = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              UserProfilesCompanion(
            id: id,
            institutionId: institutionId,
            displayName: displayName,
            email: email,
            role: role,
            pinHash: pinHash,
            isActive: isActive,
            createdAt: createdAt,
            serverUpdatedAt: serverUpdatedAt,
            isDirty: isDirty,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String institutionId,
            required String displayName,
            required String email,
            required UserRole role,
            Value<String?> pinHash = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            required DateTime createdAt,
            Value<DateTime?> serverUpdatedAt = const Value.absent(),
            Value<bool> isDirty = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              UserProfilesCompanion.insert(
            id: id,
            institutionId: institutionId,
            displayName: displayName,
            email: email,
            role: role,
            pinHash: pinHash,
            isActive: isActive,
            createdAt: createdAt,
            serverUpdatedAt: serverUpdatedAt,
            isDirty: isDirty,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$UserProfilesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $UserProfilesTable,
    UserProfile,
    $$UserProfilesTableFilterComposer,
    $$UserProfilesTableOrderingComposer,
    $$UserProfilesTableAnnotationComposer,
    $$UserProfilesTableCreateCompanionBuilder,
    $$UserProfilesTableUpdateCompanionBuilder,
    (
      UserProfile,
      BaseReferences<_$AppDatabase, $UserProfilesTable, UserProfile>
    ),
    UserProfile,
    PrefetchHooks Function()>;
typedef $$DonorsTableCreateCompanionBuilder = DonorsCompanion Function({
  required String id,
  required String institutionId,
  required String name,
  Value<String?> phone,
  Value<String?> email,
  Value<String?> address,
  Value<String?> notes,
  Value<String?> createdBy,
  required DateTime createdAt,
  required DateTime updatedAt,
  Value<DateTime?> serverUpdatedAt,
  Value<bool> isDirty,
  Value<int> rowid,
});
typedef $$DonorsTableUpdateCompanionBuilder = DonorsCompanion Function({
  Value<String> id,
  Value<String> institutionId,
  Value<String> name,
  Value<String?> phone,
  Value<String?> email,
  Value<String?> address,
  Value<String?> notes,
  Value<String?> createdBy,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<DateTime?> serverUpdatedAt,
  Value<bool> isDirty,
  Value<int> rowid,
});

class $$DonorsTableFilterComposer
    extends Composer<_$AppDatabase, $DonorsTable> {
  $$DonorsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get phone => $composableBuilder(
      column: $table.phone, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get email => $composableBuilder(
      column: $table.email, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get address => $composableBuilder(
      column: $table.address, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get notes => $composableBuilder(
      column: $table.notes, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get createdBy => $composableBuilder(
      column: $table.createdBy, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isDirty => $composableBuilder(
      column: $table.isDirty, builder: (column) => ColumnFilters(column));
}

class $$DonorsTableOrderingComposer
    extends Composer<_$AppDatabase, $DonorsTable> {
  $$DonorsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get institutionId => $composableBuilder(
      column: $table.institutionId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get phone => $composableBuilder(
      column: $table.phone, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get email => $composableBuilder(
      column: $table.email, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get address => $composableBuilder(
      column: $table.address, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get notes => $composableBuilder(
      column: $table.notes, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get createdBy => $composableBuilder(
      column: $table.createdBy, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isDirty => $composableBuilder(
      column: $table.isDirty, builder: (column) => ColumnOrderings(column));
}

class $$DonorsTableAnnotationComposer
    extends Composer<_$AppDatabase, $DonorsTable> {
  $$DonorsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<String> get phone =>
      $composableBuilder(column: $table.phone, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<String> get address =>
      $composableBuilder(column: $table.address, builder: (column) => column);

  GeneratedColumn<String> get notes =>
      $composableBuilder(column: $table.notes, builder: (column) => column);

  GeneratedColumn<String> get createdBy =>
      $composableBuilder(column: $table.createdBy, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt, builder: (column) => column);

  GeneratedColumn<bool> get isDirty =>
      $composableBuilder(column: $table.isDirty, builder: (column) => column);
}

class $$DonorsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $DonorsTable,
    Donor,
    $$DonorsTableFilterComposer,
    $$DonorsTableOrderingComposer,
    $$DonorsTableAnnotationComposer,
    $$DonorsTableCreateCompanionBuilder,
    $$DonorsTableUpdateCompanionBuilder,
    (Donor, BaseReferences<_$AppDatabase, $DonorsTable, Donor>),
    Donor,
    PrefetchHooks Function()> {
  $$DonorsTableTableManager(_$AppDatabase db, $DonorsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$DonorsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$DonorsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$DonorsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> institutionId = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<String?> phone = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> address = const Value.absent(),
            Value<String?> notes = const Value.absent(),
            Value<String?> createdBy = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<DateTime?> serverUpdatedAt = const Value.absent(),
            Value<bool> isDirty = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              DonorsCompanion(
            id: id,
            institutionId: institutionId,
            name: name,
            phone: phone,
            email: email,
            address: address,
            notes: notes,
            createdBy: createdBy,
            createdAt: createdAt,
            updatedAt: updatedAt,
            serverUpdatedAt: serverUpdatedAt,
            isDirty: isDirty,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String institutionId,
            required String name,
            Value<String?> phone = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> address = const Value.absent(),
            Value<String?> notes = const Value.absent(),
            Value<String?> createdBy = const Value.absent(),
            required DateTime createdAt,
            required DateTime updatedAt,
            Value<DateTime?> serverUpdatedAt = const Value.absent(),
            Value<bool> isDirty = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              DonorsCompanion.insert(
            id: id,
            institutionId: institutionId,
            name: name,
            phone: phone,
            email: email,
            address: address,
            notes: notes,
            createdBy: createdBy,
            createdAt: createdAt,
            updatedAt: updatedAt,
            serverUpdatedAt: serverUpdatedAt,
            isDirty: isDirty,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$DonorsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $DonorsTable,
    Donor,
    $$DonorsTableFilterComposer,
    $$DonorsTableOrderingComposer,
    $$DonorsTableAnnotationComposer,
    $$DonorsTableCreateCompanionBuilder,
    $$DonorsTableUpdateCompanionBuilder,
    (Donor, BaseReferences<_$AppDatabase, $DonorsTable, Donor>),
    Donor,
    PrefetchHooks Function()>;
typedef $$FundTypesTableCreateCompanionBuilder = FundTypesCompanion Function({
  required String id,
  required String institutionId,
  required String code,
  required String nameUr,
  required String nameEn,
  required FundCategory category,
  Value<bool> isRestricted,
  Value<bool> isActive,
  Value<int> openingBalancePaisa,
  Value<int> sortOrder,
  Value<DateTime?> serverUpdatedAt,
  Value<bool> isDirty,
  Value<int> rowid,
});
typedef $$FundTypesTableUpdateCompanionBuilder = FundTypesCompanion Function({
  Value<String> id,
  Value<String> institutionId,
  Value<String> code,
  Value<String> nameUr,
  Value<String> nameEn,
  Value<FundCategory> category,
  Value<bool> isRestricted,
  Value<bool> isActive,
  Value<int> openingBalancePaisa,
  Value<int> sortOrder,
  Value<DateTime?> serverUpdatedAt,
  Value<bool> isDirty,
  Value<int> rowid,
});

class $$FundTypesTableFilterComposer
    extends Composer<_$AppDatabase, $FundTypesTable> {
  $$FundTypesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get code => $composableBuilder(
      column: $table.code, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get nameUr => $composableBuilder(
      column: $table.nameUr, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get nameEn => $composableBuilder(
      column: $table.nameEn, builder: (column) => ColumnFilters(column));

  ColumnWithTypeConverterFilters<FundCategory, FundCategory, String>
      get category => $composableBuilder(
          column: $table.category,
          builder: (column) => ColumnWithTypeConverterFilters(column));

  ColumnFilters<bool> get isRestricted => $composableBuilder(
      column: $table.isRestricted, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get openingBalancePaisa => $composableBuilder(
      column: $table.openingBalancePaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get sortOrder => $composableBuilder(
      column: $table.sortOrder, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isDirty => $composableBuilder(
      column: $table.isDirty, builder: (column) => ColumnFilters(column));
}

class $$FundTypesTableOrderingComposer
    extends Composer<_$AppDatabase, $FundTypesTable> {
  $$FundTypesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get institutionId => $composableBuilder(
      column: $table.institutionId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get code => $composableBuilder(
      column: $table.code, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get nameUr => $composableBuilder(
      column: $table.nameUr, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get nameEn => $composableBuilder(
      column: $table.nameEn, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get category => $composableBuilder(
      column: $table.category, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isRestricted => $composableBuilder(
      column: $table.isRestricted,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get openingBalancePaisa => $composableBuilder(
      column: $table.openingBalancePaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get sortOrder => $composableBuilder(
      column: $table.sortOrder, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isDirty => $composableBuilder(
      column: $table.isDirty, builder: (column) => ColumnOrderings(column));
}

class $$FundTypesTableAnnotationComposer
    extends Composer<_$AppDatabase, $FundTypesTable> {
  $$FundTypesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => column);

  GeneratedColumn<String> get code =>
      $composableBuilder(column: $table.code, builder: (column) => column);

  GeneratedColumn<String> get nameUr =>
      $composableBuilder(column: $table.nameUr, builder: (column) => column);

  GeneratedColumn<String> get nameEn =>
      $composableBuilder(column: $table.nameEn, builder: (column) => column);

  GeneratedColumnWithTypeConverter<FundCategory, String> get category =>
      $composableBuilder(column: $table.category, builder: (column) => column);

  GeneratedColumn<bool> get isRestricted => $composableBuilder(
      column: $table.isRestricted, builder: (column) => column);

  GeneratedColumn<bool> get isActive =>
      $composableBuilder(column: $table.isActive, builder: (column) => column);

  GeneratedColumn<int> get openingBalancePaisa => $composableBuilder(
      column: $table.openingBalancePaisa, builder: (column) => column);

  GeneratedColumn<int> get sortOrder =>
      $composableBuilder(column: $table.sortOrder, builder: (column) => column);

  GeneratedColumn<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt, builder: (column) => column);

  GeneratedColumn<bool> get isDirty =>
      $composableBuilder(column: $table.isDirty, builder: (column) => column);
}

class $$FundTypesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FundTypesTable,
    FundType,
    $$FundTypesTableFilterComposer,
    $$FundTypesTableOrderingComposer,
    $$FundTypesTableAnnotationComposer,
    $$FundTypesTableCreateCompanionBuilder,
    $$FundTypesTableUpdateCompanionBuilder,
    (FundType, BaseReferences<_$AppDatabase, $FundTypesTable, FundType>),
    FundType,
    PrefetchHooks Function()> {
  $$FundTypesTableTableManager(_$AppDatabase db, $FundTypesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$FundTypesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$FundTypesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$FundTypesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> institutionId = const Value.absent(),
            Value<String> code = const Value.absent(),
            Value<String> nameUr = const Value.absent(),
            Value<String> nameEn = const Value.absent(),
            Value<FundCategory> category = const Value.absent(),
            Value<bool> isRestricted = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            Value<int> openingBalancePaisa = const Value.absent(),
            Value<int> sortOrder = const Value.absent(),
            Value<DateTime?> serverUpdatedAt = const Value.absent(),
            Value<bool> isDirty = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              FundTypesCompanion(
            id: id,
            institutionId: institutionId,
            code: code,
            nameUr: nameUr,
            nameEn: nameEn,
            category: category,
            isRestricted: isRestricted,
            isActive: isActive,
            openingBalancePaisa: openingBalancePaisa,
            sortOrder: sortOrder,
            serverUpdatedAt: serverUpdatedAt,
            isDirty: isDirty,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String institutionId,
            required String code,
            required String nameUr,
            required String nameEn,
            required FundCategory category,
            Value<bool> isRestricted = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            Value<int> openingBalancePaisa = const Value.absent(),
            Value<int> sortOrder = const Value.absent(),
            Value<DateTime?> serverUpdatedAt = const Value.absent(),
            Value<bool> isDirty = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              FundTypesCompanion.insert(
            id: id,
            institutionId: institutionId,
            code: code,
            nameUr: nameUr,
            nameEn: nameEn,
            category: category,
            isRestricted: isRestricted,
            isActive: isActive,
            openingBalancePaisa: openingBalancePaisa,
            sortOrder: sortOrder,
            serverUpdatedAt: serverUpdatedAt,
            isDirty: isDirty,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$FundTypesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $FundTypesTable,
    FundType,
    $$FundTypesTableFilterComposer,
    $$FundTypesTableOrderingComposer,
    $$FundTypesTableAnnotationComposer,
    $$FundTypesTableCreateCompanionBuilder,
    $$FundTypesTableUpdateCompanionBuilder,
    (FundType, BaseReferences<_$AppDatabase, $FundTypesTable, FundType>),
    FundType,
    PrefetchHooks Function()>;
typedef $$PurposesTableCreateCompanionBuilder = PurposesCompanion Function({
  required String id,
  required String institutionId,
  required String nameUr,
  required String nameEn,
  Value<String?> description,
  Value<bool> isActive,
  Value<DateTime?> serverUpdatedAt,
  Value<bool> isDirty,
  Value<int> rowid,
});
typedef $$PurposesTableUpdateCompanionBuilder = PurposesCompanion Function({
  Value<String> id,
  Value<String> institutionId,
  Value<String> nameUr,
  Value<String> nameEn,
  Value<String?> description,
  Value<bool> isActive,
  Value<DateTime?> serverUpdatedAt,
  Value<bool> isDirty,
  Value<int> rowid,
});

class $$PurposesTableFilterComposer
    extends Composer<_$AppDatabase, $PurposesTable> {
  $$PurposesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get nameUr => $composableBuilder(
      column: $table.nameUr, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get nameEn => $composableBuilder(
      column: $table.nameEn, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get description => $composableBuilder(
      column: $table.description, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isDirty => $composableBuilder(
      column: $table.isDirty, builder: (column) => ColumnFilters(column));
}

class $$PurposesTableOrderingComposer
    extends Composer<_$AppDatabase, $PurposesTable> {
  $$PurposesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get institutionId => $composableBuilder(
      column: $table.institutionId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get nameUr => $composableBuilder(
      column: $table.nameUr, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get nameEn => $composableBuilder(
      column: $table.nameEn, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get description => $composableBuilder(
      column: $table.description, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isDirty => $composableBuilder(
      column: $table.isDirty, builder: (column) => ColumnOrderings(column));
}

class $$PurposesTableAnnotationComposer
    extends Composer<_$AppDatabase, $PurposesTable> {
  $$PurposesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => column);

  GeneratedColumn<String> get nameUr =>
      $composableBuilder(column: $table.nameUr, builder: (column) => column);

  GeneratedColumn<String> get nameEn =>
      $composableBuilder(column: $table.nameEn, builder: (column) => column);

  GeneratedColumn<String> get description => $composableBuilder(
      column: $table.description, builder: (column) => column);

  GeneratedColumn<bool> get isActive =>
      $composableBuilder(column: $table.isActive, builder: (column) => column);

  GeneratedColumn<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt, builder: (column) => column);

  GeneratedColumn<bool> get isDirty =>
      $composableBuilder(column: $table.isDirty, builder: (column) => column);
}

class $$PurposesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PurposesTable,
    Purpose,
    $$PurposesTableFilterComposer,
    $$PurposesTableOrderingComposer,
    $$PurposesTableAnnotationComposer,
    $$PurposesTableCreateCompanionBuilder,
    $$PurposesTableUpdateCompanionBuilder,
    (Purpose, BaseReferences<_$AppDatabase, $PurposesTable, Purpose>),
    Purpose,
    PrefetchHooks Function()> {
  $$PurposesTableTableManager(_$AppDatabase db, $PurposesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$PurposesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$PurposesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$PurposesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> institutionId = const Value.absent(),
            Value<String> nameUr = const Value.absent(),
            Value<String> nameEn = const Value.absent(),
            Value<String?> description = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            Value<DateTime?> serverUpdatedAt = const Value.absent(),
            Value<bool> isDirty = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              PurposesCompanion(
            id: id,
            institutionId: institutionId,
            nameUr: nameUr,
            nameEn: nameEn,
            description: description,
            isActive: isActive,
            serverUpdatedAt: serverUpdatedAt,
            isDirty: isDirty,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String institutionId,
            required String nameUr,
            required String nameEn,
            Value<String?> description = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            Value<DateTime?> serverUpdatedAt = const Value.absent(),
            Value<bool> isDirty = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              PurposesCompanion.insert(
            id: id,
            institutionId: institutionId,
            nameUr: nameUr,
            nameEn: nameEn,
            description: description,
            isActive: isActive,
            serverUpdatedAt: serverUpdatedAt,
            isDirty: isDirty,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$PurposesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $PurposesTable,
    Purpose,
    $$PurposesTableFilterComposer,
    $$PurposesTableOrderingComposer,
    $$PurposesTableAnnotationComposer,
    $$PurposesTableCreateCompanionBuilder,
    $$PurposesTableUpdateCompanionBuilder,
    (Purpose, BaseReferences<_$AppDatabase, $PurposesTable, Purpose>),
    Purpose,
    PrefetchHooks Function()>;
typedef $$BankAccountsTableCreateCompanionBuilder = BankAccountsCompanion
    Function({
  required String id,
  required String institutionId,
  required AccountType type,
  required String title,
  Value<String?> bankName,
  Value<String?> accountNoMasked,
  Value<int> openingBalancePaisa,
  Value<bool> isActive,
  Value<DateTime?> serverUpdatedAt,
  Value<bool> isDirty,
  Value<int> rowid,
});
typedef $$BankAccountsTableUpdateCompanionBuilder = BankAccountsCompanion
    Function({
  Value<String> id,
  Value<String> institutionId,
  Value<AccountType> type,
  Value<String> title,
  Value<String?> bankName,
  Value<String?> accountNoMasked,
  Value<int> openingBalancePaisa,
  Value<bool> isActive,
  Value<DateTime?> serverUpdatedAt,
  Value<bool> isDirty,
  Value<int> rowid,
});

class $$BankAccountsTableFilterComposer
    extends Composer<_$AppDatabase, $BankAccountsTable> {
  $$BankAccountsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => ColumnFilters(column));

  ColumnWithTypeConverterFilters<AccountType, AccountType, String> get type =>
      $composableBuilder(
          column: $table.type,
          builder: (column) => ColumnWithTypeConverterFilters(column));

  ColumnFilters<String> get title => $composableBuilder(
      column: $table.title, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get bankName => $composableBuilder(
      column: $table.bankName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get accountNoMasked => $composableBuilder(
      column: $table.accountNoMasked,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get openingBalancePaisa => $composableBuilder(
      column: $table.openingBalancePaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isDirty => $composableBuilder(
      column: $table.isDirty, builder: (column) => ColumnFilters(column));
}

class $$BankAccountsTableOrderingComposer
    extends Composer<_$AppDatabase, $BankAccountsTable> {
  $$BankAccountsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get institutionId => $composableBuilder(
      column: $table.institutionId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get title => $composableBuilder(
      column: $table.title, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get bankName => $composableBuilder(
      column: $table.bankName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get accountNoMasked => $composableBuilder(
      column: $table.accountNoMasked,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get openingBalancePaisa => $composableBuilder(
      column: $table.openingBalancePaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isDirty => $composableBuilder(
      column: $table.isDirty, builder: (column) => ColumnOrderings(column));
}

class $$BankAccountsTableAnnotationComposer
    extends Composer<_$AppDatabase, $BankAccountsTable> {
  $$BankAccountsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => column);

  GeneratedColumnWithTypeConverter<AccountType, String> get type =>
      $composableBuilder(column: $table.type, builder: (column) => column);

  GeneratedColumn<String> get title =>
      $composableBuilder(column: $table.title, builder: (column) => column);

  GeneratedColumn<String> get bankName =>
      $composableBuilder(column: $table.bankName, builder: (column) => column);

  GeneratedColumn<String> get accountNoMasked => $composableBuilder(
      column: $table.accountNoMasked, builder: (column) => column);

  GeneratedColumn<int> get openingBalancePaisa => $composableBuilder(
      column: $table.openingBalancePaisa, builder: (column) => column);

  GeneratedColumn<bool> get isActive =>
      $composableBuilder(column: $table.isActive, builder: (column) => column);

  GeneratedColumn<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt, builder: (column) => column);

  GeneratedColumn<bool> get isDirty =>
      $composableBuilder(column: $table.isDirty, builder: (column) => column);
}

class $$BankAccountsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $BankAccountsTable,
    BankAccount,
    $$BankAccountsTableFilterComposer,
    $$BankAccountsTableOrderingComposer,
    $$BankAccountsTableAnnotationComposer,
    $$BankAccountsTableCreateCompanionBuilder,
    $$BankAccountsTableUpdateCompanionBuilder,
    (
      BankAccount,
      BaseReferences<_$AppDatabase, $BankAccountsTable, BankAccount>
    ),
    BankAccount,
    PrefetchHooks Function()> {
  $$BankAccountsTableTableManager(_$AppDatabase db, $BankAccountsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$BankAccountsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$BankAccountsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$BankAccountsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> institutionId = const Value.absent(),
            Value<AccountType> type = const Value.absent(),
            Value<String> title = const Value.absent(),
            Value<String?> bankName = const Value.absent(),
            Value<String?> accountNoMasked = const Value.absent(),
            Value<int> openingBalancePaisa = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            Value<DateTime?> serverUpdatedAt = const Value.absent(),
            Value<bool> isDirty = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              BankAccountsCompanion(
            id: id,
            institutionId: institutionId,
            type: type,
            title: title,
            bankName: bankName,
            accountNoMasked: accountNoMasked,
            openingBalancePaisa: openingBalancePaisa,
            isActive: isActive,
            serverUpdatedAt: serverUpdatedAt,
            isDirty: isDirty,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String institutionId,
            required AccountType type,
            required String title,
            Value<String?> bankName = const Value.absent(),
            Value<String?> accountNoMasked = const Value.absent(),
            Value<int> openingBalancePaisa = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            Value<DateTime?> serverUpdatedAt = const Value.absent(),
            Value<bool> isDirty = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              BankAccountsCompanion.insert(
            id: id,
            institutionId: institutionId,
            type: type,
            title: title,
            bankName: bankName,
            accountNoMasked: accountNoMasked,
            openingBalancePaisa: openingBalancePaisa,
            isActive: isActive,
            serverUpdatedAt: serverUpdatedAt,
            isDirty: isDirty,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$BankAccountsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $BankAccountsTable,
    BankAccount,
    $$BankAccountsTableFilterComposer,
    $$BankAccountsTableOrderingComposer,
    $$BankAccountsTableAnnotationComposer,
    $$BankAccountsTableCreateCompanionBuilder,
    $$BankAccountsTableUpdateCompanionBuilder,
    (
      BankAccount,
      BaseReferences<_$AppDatabase, $BankAccountsTable, BankAccount>
    ),
    BankAccount,
    PrefetchHooks Function()>;
typedef $$ReceiptsTableCreateCompanionBuilder = ReceiptsCompanion Function({
  required String id,
  required String institutionId,
  Value<String?> officialNumber,
  Value<String?> localProvisionalLabel,
  required ReceiptStatus status,
  required TxType txType,
  Value<String?> donorId,
  required String donorNameSnapshot,
  Value<bool> isAnonymous,
  required int totalPaisa,
  required DateTime receiptDate,
  required PaymentMethod paymentMethod,
  Value<String?> bankAccountId,
  Value<String?> referenceNo,
  Value<String?> evidencePath,
  Value<String?> staffNotes,
  Value<String?> donorNote,
  Value<String?> createdBy,
  Value<String?> verifiedBy,
  Value<DateTime?> verifiedAt,
  Value<String?> voidReason,
  Value<String?> replacedById,
  Value<String?> reversesId,
  required String idempotencyKey,
  Value<bool> serverAck,
  required DateTime createdAt,
  required DateTime updatedAt,
  Value<DateTime?> serverUpdatedAt,
  Value<bool> isDirty,
  Value<int> rowid,
});
typedef $$ReceiptsTableUpdateCompanionBuilder = ReceiptsCompanion Function({
  Value<String> id,
  Value<String> institutionId,
  Value<String?> officialNumber,
  Value<String?> localProvisionalLabel,
  Value<ReceiptStatus> status,
  Value<TxType> txType,
  Value<String?> donorId,
  Value<String> donorNameSnapshot,
  Value<bool> isAnonymous,
  Value<int> totalPaisa,
  Value<DateTime> receiptDate,
  Value<PaymentMethod> paymentMethod,
  Value<String?> bankAccountId,
  Value<String?> referenceNo,
  Value<String?> evidencePath,
  Value<String?> staffNotes,
  Value<String?> donorNote,
  Value<String?> createdBy,
  Value<String?> verifiedBy,
  Value<DateTime?> verifiedAt,
  Value<String?> voidReason,
  Value<String?> replacedById,
  Value<String?> reversesId,
  Value<String> idempotencyKey,
  Value<bool> serverAck,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<DateTime?> serverUpdatedAt,
  Value<bool> isDirty,
  Value<int> rowid,
});

class $$ReceiptsTableFilterComposer
    extends Composer<_$AppDatabase, $ReceiptsTable> {
  $$ReceiptsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get officialNumber => $composableBuilder(
      column: $table.officialNumber,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get localProvisionalLabel => $composableBuilder(
      column: $table.localProvisionalLabel,
      builder: (column) => ColumnFilters(column));

  ColumnWithTypeConverterFilters<ReceiptStatus, ReceiptStatus, String>
      get status => $composableBuilder(
          column: $table.status,
          builder: (column) => ColumnWithTypeConverterFilters(column));

  ColumnWithTypeConverterFilters<TxType, TxType, String> get txType =>
      $composableBuilder(
          column: $table.txType,
          builder: (column) => ColumnWithTypeConverterFilters(column));

  ColumnFilters<String> get donorId => $composableBuilder(
      column: $table.donorId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get donorNameSnapshot => $composableBuilder(
      column: $table.donorNameSnapshot,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isAnonymous => $composableBuilder(
      column: $table.isAnonymous, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get totalPaisa => $composableBuilder(
      column: $table.totalPaisa, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get receiptDate => $composableBuilder(
      column: $table.receiptDate, builder: (column) => ColumnFilters(column));

  ColumnWithTypeConverterFilters<PaymentMethod, PaymentMethod, String>
      get paymentMethod => $composableBuilder(
          column: $table.paymentMethod,
          builder: (column) => ColumnWithTypeConverterFilters(column));

  ColumnFilters<String> get bankAccountId => $composableBuilder(
      column: $table.bankAccountId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get referenceNo => $composableBuilder(
      column: $table.referenceNo, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get evidencePath => $composableBuilder(
      column: $table.evidencePath, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get staffNotes => $composableBuilder(
      column: $table.staffNotes, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get donorNote => $composableBuilder(
      column: $table.donorNote, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get createdBy => $composableBuilder(
      column: $table.createdBy, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get verifiedBy => $composableBuilder(
      column: $table.verifiedBy, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get verifiedAt => $composableBuilder(
      column: $table.verifiedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get voidReason => $composableBuilder(
      column: $table.voidReason, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get replacedById => $composableBuilder(
      column: $table.replacedById, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get reversesId => $composableBuilder(
      column: $table.reversesId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get idempotencyKey => $composableBuilder(
      column: $table.idempotencyKey,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get serverAck => $composableBuilder(
      column: $table.serverAck, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isDirty => $composableBuilder(
      column: $table.isDirty, builder: (column) => ColumnFilters(column));
}

class $$ReceiptsTableOrderingComposer
    extends Composer<_$AppDatabase, $ReceiptsTable> {
  $$ReceiptsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get institutionId => $composableBuilder(
      column: $table.institutionId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get officialNumber => $composableBuilder(
      column: $table.officialNumber,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get localProvisionalLabel => $composableBuilder(
      column: $table.localProvisionalLabel,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get txType => $composableBuilder(
      column: $table.txType, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get donorId => $composableBuilder(
      column: $table.donorId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get donorNameSnapshot => $composableBuilder(
      column: $table.donorNameSnapshot,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isAnonymous => $composableBuilder(
      column: $table.isAnonymous, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get totalPaisa => $composableBuilder(
      column: $table.totalPaisa, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get receiptDate => $composableBuilder(
      column: $table.receiptDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get paymentMethod => $composableBuilder(
      column: $table.paymentMethod,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get bankAccountId => $composableBuilder(
      column: $table.bankAccountId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get referenceNo => $composableBuilder(
      column: $table.referenceNo, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get evidencePath => $composableBuilder(
      column: $table.evidencePath,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get staffNotes => $composableBuilder(
      column: $table.staffNotes, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get donorNote => $composableBuilder(
      column: $table.donorNote, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get createdBy => $composableBuilder(
      column: $table.createdBy, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get verifiedBy => $composableBuilder(
      column: $table.verifiedBy, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get verifiedAt => $composableBuilder(
      column: $table.verifiedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get voidReason => $composableBuilder(
      column: $table.voidReason, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get replacedById => $composableBuilder(
      column: $table.replacedById,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get reversesId => $composableBuilder(
      column: $table.reversesId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get idempotencyKey => $composableBuilder(
      column: $table.idempotencyKey,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get serverAck => $composableBuilder(
      column: $table.serverAck, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isDirty => $composableBuilder(
      column: $table.isDirty, builder: (column) => ColumnOrderings(column));
}

class $$ReceiptsTableAnnotationComposer
    extends Composer<_$AppDatabase, $ReceiptsTable> {
  $$ReceiptsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => column);

  GeneratedColumn<String> get officialNumber => $composableBuilder(
      column: $table.officialNumber, builder: (column) => column);

  GeneratedColumn<String> get localProvisionalLabel => $composableBuilder(
      column: $table.localProvisionalLabel, builder: (column) => column);

  GeneratedColumnWithTypeConverter<ReceiptStatus, String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumnWithTypeConverter<TxType, String> get txType =>
      $composableBuilder(column: $table.txType, builder: (column) => column);

  GeneratedColumn<String> get donorId =>
      $composableBuilder(column: $table.donorId, builder: (column) => column);

  GeneratedColumn<String> get donorNameSnapshot => $composableBuilder(
      column: $table.donorNameSnapshot, builder: (column) => column);

  GeneratedColumn<bool> get isAnonymous => $composableBuilder(
      column: $table.isAnonymous, builder: (column) => column);

  GeneratedColumn<int> get totalPaisa => $composableBuilder(
      column: $table.totalPaisa, builder: (column) => column);

  GeneratedColumn<DateTime> get receiptDate => $composableBuilder(
      column: $table.receiptDate, builder: (column) => column);

  GeneratedColumnWithTypeConverter<PaymentMethod, String> get paymentMethod =>
      $composableBuilder(
          column: $table.paymentMethod, builder: (column) => column);

  GeneratedColumn<String> get bankAccountId => $composableBuilder(
      column: $table.bankAccountId, builder: (column) => column);

  GeneratedColumn<String> get referenceNo => $composableBuilder(
      column: $table.referenceNo, builder: (column) => column);

  GeneratedColumn<String> get evidencePath => $composableBuilder(
      column: $table.evidencePath, builder: (column) => column);

  GeneratedColumn<String> get staffNotes => $composableBuilder(
      column: $table.staffNotes, builder: (column) => column);

  GeneratedColumn<String> get donorNote =>
      $composableBuilder(column: $table.donorNote, builder: (column) => column);

  GeneratedColumn<String> get createdBy =>
      $composableBuilder(column: $table.createdBy, builder: (column) => column);

  GeneratedColumn<String> get verifiedBy => $composableBuilder(
      column: $table.verifiedBy, builder: (column) => column);

  GeneratedColumn<DateTime> get verifiedAt => $composableBuilder(
      column: $table.verifiedAt, builder: (column) => column);

  GeneratedColumn<String> get voidReason => $composableBuilder(
      column: $table.voidReason, builder: (column) => column);

  GeneratedColumn<String> get replacedById => $composableBuilder(
      column: $table.replacedById, builder: (column) => column);

  GeneratedColumn<String> get reversesId => $composableBuilder(
      column: $table.reversesId, builder: (column) => column);

  GeneratedColumn<String> get idempotencyKey => $composableBuilder(
      column: $table.idempotencyKey, builder: (column) => column);

  GeneratedColumn<bool> get serverAck =>
      $composableBuilder(column: $table.serverAck, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt, builder: (column) => column);

  GeneratedColumn<bool> get isDirty =>
      $composableBuilder(column: $table.isDirty, builder: (column) => column);
}

class $$ReceiptsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ReceiptsTable,
    Receipt,
    $$ReceiptsTableFilterComposer,
    $$ReceiptsTableOrderingComposer,
    $$ReceiptsTableAnnotationComposer,
    $$ReceiptsTableCreateCompanionBuilder,
    $$ReceiptsTableUpdateCompanionBuilder,
    (Receipt, BaseReferences<_$AppDatabase, $ReceiptsTable, Receipt>),
    Receipt,
    PrefetchHooks Function()> {
  $$ReceiptsTableTableManager(_$AppDatabase db, $ReceiptsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ReceiptsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ReceiptsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ReceiptsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> institutionId = const Value.absent(),
            Value<String?> officialNumber = const Value.absent(),
            Value<String?> localProvisionalLabel = const Value.absent(),
            Value<ReceiptStatus> status = const Value.absent(),
            Value<TxType> txType = const Value.absent(),
            Value<String?> donorId = const Value.absent(),
            Value<String> donorNameSnapshot = const Value.absent(),
            Value<bool> isAnonymous = const Value.absent(),
            Value<int> totalPaisa = const Value.absent(),
            Value<DateTime> receiptDate = const Value.absent(),
            Value<PaymentMethod> paymentMethod = const Value.absent(),
            Value<String?> bankAccountId = const Value.absent(),
            Value<String?> referenceNo = const Value.absent(),
            Value<String?> evidencePath = const Value.absent(),
            Value<String?> staffNotes = const Value.absent(),
            Value<String?> donorNote = const Value.absent(),
            Value<String?> createdBy = const Value.absent(),
            Value<String?> verifiedBy = const Value.absent(),
            Value<DateTime?> verifiedAt = const Value.absent(),
            Value<String?> voidReason = const Value.absent(),
            Value<String?> replacedById = const Value.absent(),
            Value<String?> reversesId = const Value.absent(),
            Value<String> idempotencyKey = const Value.absent(),
            Value<bool> serverAck = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<DateTime?> serverUpdatedAt = const Value.absent(),
            Value<bool> isDirty = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ReceiptsCompanion(
            id: id,
            institutionId: institutionId,
            officialNumber: officialNumber,
            localProvisionalLabel: localProvisionalLabel,
            status: status,
            txType: txType,
            donorId: donorId,
            donorNameSnapshot: donorNameSnapshot,
            isAnonymous: isAnonymous,
            totalPaisa: totalPaisa,
            receiptDate: receiptDate,
            paymentMethod: paymentMethod,
            bankAccountId: bankAccountId,
            referenceNo: referenceNo,
            evidencePath: evidencePath,
            staffNotes: staffNotes,
            donorNote: donorNote,
            createdBy: createdBy,
            verifiedBy: verifiedBy,
            verifiedAt: verifiedAt,
            voidReason: voidReason,
            replacedById: replacedById,
            reversesId: reversesId,
            idempotencyKey: idempotencyKey,
            serverAck: serverAck,
            createdAt: createdAt,
            updatedAt: updatedAt,
            serverUpdatedAt: serverUpdatedAt,
            isDirty: isDirty,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String institutionId,
            Value<String?> officialNumber = const Value.absent(),
            Value<String?> localProvisionalLabel = const Value.absent(),
            required ReceiptStatus status,
            required TxType txType,
            Value<String?> donorId = const Value.absent(),
            required String donorNameSnapshot,
            Value<bool> isAnonymous = const Value.absent(),
            required int totalPaisa,
            required DateTime receiptDate,
            required PaymentMethod paymentMethod,
            Value<String?> bankAccountId = const Value.absent(),
            Value<String?> referenceNo = const Value.absent(),
            Value<String?> evidencePath = const Value.absent(),
            Value<String?> staffNotes = const Value.absent(),
            Value<String?> donorNote = const Value.absent(),
            Value<String?> createdBy = const Value.absent(),
            Value<String?> verifiedBy = const Value.absent(),
            Value<DateTime?> verifiedAt = const Value.absent(),
            Value<String?> voidReason = const Value.absent(),
            Value<String?> replacedById = const Value.absent(),
            Value<String?> reversesId = const Value.absent(),
            required String idempotencyKey,
            Value<bool> serverAck = const Value.absent(),
            required DateTime createdAt,
            required DateTime updatedAt,
            Value<DateTime?> serverUpdatedAt = const Value.absent(),
            Value<bool> isDirty = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ReceiptsCompanion.insert(
            id: id,
            institutionId: institutionId,
            officialNumber: officialNumber,
            localProvisionalLabel: localProvisionalLabel,
            status: status,
            txType: txType,
            donorId: donorId,
            donorNameSnapshot: donorNameSnapshot,
            isAnonymous: isAnonymous,
            totalPaisa: totalPaisa,
            receiptDate: receiptDate,
            paymentMethod: paymentMethod,
            bankAccountId: bankAccountId,
            referenceNo: referenceNo,
            evidencePath: evidencePath,
            staffNotes: staffNotes,
            donorNote: donorNote,
            createdBy: createdBy,
            verifiedBy: verifiedBy,
            verifiedAt: verifiedAt,
            voidReason: voidReason,
            replacedById: replacedById,
            reversesId: reversesId,
            idempotencyKey: idempotencyKey,
            serverAck: serverAck,
            createdAt: createdAt,
            updatedAt: updatedAt,
            serverUpdatedAt: serverUpdatedAt,
            isDirty: isDirty,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$ReceiptsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $ReceiptsTable,
    Receipt,
    $$ReceiptsTableFilterComposer,
    $$ReceiptsTableOrderingComposer,
    $$ReceiptsTableAnnotationComposer,
    $$ReceiptsTableCreateCompanionBuilder,
    $$ReceiptsTableUpdateCompanionBuilder,
    (Receipt, BaseReferences<_$AppDatabase, $ReceiptsTable, Receipt>),
    Receipt,
    PrefetchHooks Function()>;
typedef $$ReceiptAllocationsTableCreateCompanionBuilder
    = ReceiptAllocationsCompanion Function({
  required String id,
  required String receiptId,
  required String fundTypeId,
  Value<String?> purposeId,
  required int amountPaisa,
  Value<int> rowid,
});
typedef $$ReceiptAllocationsTableUpdateCompanionBuilder
    = ReceiptAllocationsCompanion Function({
  Value<String> id,
  Value<String> receiptId,
  Value<String> fundTypeId,
  Value<String?> purposeId,
  Value<int> amountPaisa,
  Value<int> rowid,
});

class $$ReceiptAllocationsTableFilterComposer
    extends Composer<_$AppDatabase, $ReceiptAllocationsTable> {
  $$ReceiptAllocationsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get receiptId => $composableBuilder(
      column: $table.receiptId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get fundTypeId => $composableBuilder(
      column: $table.fundTypeId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get purposeId => $composableBuilder(
      column: $table.purposeId, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => ColumnFilters(column));
}

class $$ReceiptAllocationsTableOrderingComposer
    extends Composer<_$AppDatabase, $ReceiptAllocationsTable> {
  $$ReceiptAllocationsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get receiptId => $composableBuilder(
      column: $table.receiptId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get fundTypeId => $composableBuilder(
      column: $table.fundTypeId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get purposeId => $composableBuilder(
      column: $table.purposeId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => ColumnOrderings(column));
}

class $$ReceiptAllocationsTableAnnotationComposer
    extends Composer<_$AppDatabase, $ReceiptAllocationsTable> {
  $$ReceiptAllocationsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get receiptId =>
      $composableBuilder(column: $table.receiptId, builder: (column) => column);

  GeneratedColumn<String> get fundTypeId => $composableBuilder(
      column: $table.fundTypeId, builder: (column) => column);

  GeneratedColumn<String> get purposeId =>
      $composableBuilder(column: $table.purposeId, builder: (column) => column);

  GeneratedColumn<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => column);
}

class $$ReceiptAllocationsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ReceiptAllocationsTable,
    ReceiptAllocation,
    $$ReceiptAllocationsTableFilterComposer,
    $$ReceiptAllocationsTableOrderingComposer,
    $$ReceiptAllocationsTableAnnotationComposer,
    $$ReceiptAllocationsTableCreateCompanionBuilder,
    $$ReceiptAllocationsTableUpdateCompanionBuilder,
    (
      ReceiptAllocation,
      BaseReferences<_$AppDatabase, $ReceiptAllocationsTable, ReceiptAllocation>
    ),
    ReceiptAllocation,
    PrefetchHooks Function()> {
  $$ReceiptAllocationsTableTableManager(
      _$AppDatabase db, $ReceiptAllocationsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ReceiptAllocationsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ReceiptAllocationsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ReceiptAllocationsTableAnnotationComposer(
                  $db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> receiptId = const Value.absent(),
            Value<String> fundTypeId = const Value.absent(),
            Value<String?> purposeId = const Value.absent(),
            Value<int> amountPaisa = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ReceiptAllocationsCompanion(
            id: id,
            receiptId: receiptId,
            fundTypeId: fundTypeId,
            purposeId: purposeId,
            amountPaisa: amountPaisa,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String receiptId,
            required String fundTypeId,
            Value<String?> purposeId = const Value.absent(),
            required int amountPaisa,
            Value<int> rowid = const Value.absent(),
          }) =>
              ReceiptAllocationsCompanion.insert(
            id: id,
            receiptId: receiptId,
            fundTypeId: fundTypeId,
            purposeId: purposeId,
            amountPaisa: amountPaisa,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$ReceiptAllocationsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $ReceiptAllocationsTable,
    ReceiptAllocation,
    $$ReceiptAllocationsTableFilterComposer,
    $$ReceiptAllocationsTableOrderingComposer,
    $$ReceiptAllocationsTableAnnotationComposer,
    $$ReceiptAllocationsTableCreateCompanionBuilder,
    $$ReceiptAllocationsTableUpdateCompanionBuilder,
    (
      ReceiptAllocation,
      BaseReferences<_$AppDatabase, $ReceiptAllocationsTable, ReceiptAllocation>
    ),
    ReceiptAllocation,
    PrefetchHooks Function()>;
typedef $$PaymentVerificationsTableCreateCompanionBuilder
    = PaymentVerificationsCompanion Function({
  required String id,
  required String receiptId,
  required String verifiedBy,
  required DateTime verifiedAt,
  required String evidenceSummary,
  Value<String?> note,
  Value<int> rowid,
});
typedef $$PaymentVerificationsTableUpdateCompanionBuilder
    = PaymentVerificationsCompanion Function({
  Value<String> id,
  Value<String> receiptId,
  Value<String> verifiedBy,
  Value<DateTime> verifiedAt,
  Value<String> evidenceSummary,
  Value<String?> note,
  Value<int> rowid,
});

class $$PaymentVerificationsTableFilterComposer
    extends Composer<_$AppDatabase, $PaymentVerificationsTable> {
  $$PaymentVerificationsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get receiptId => $composableBuilder(
      column: $table.receiptId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get verifiedBy => $composableBuilder(
      column: $table.verifiedBy, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get verifiedAt => $composableBuilder(
      column: $table.verifiedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get evidenceSummary => $composableBuilder(
      column: $table.evidenceSummary,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnFilters(column));
}

class $$PaymentVerificationsTableOrderingComposer
    extends Composer<_$AppDatabase, $PaymentVerificationsTable> {
  $$PaymentVerificationsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get receiptId => $composableBuilder(
      column: $table.receiptId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get verifiedBy => $composableBuilder(
      column: $table.verifiedBy, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get verifiedAt => $composableBuilder(
      column: $table.verifiedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get evidenceSummary => $composableBuilder(
      column: $table.evidenceSummary,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnOrderings(column));
}

class $$PaymentVerificationsTableAnnotationComposer
    extends Composer<_$AppDatabase, $PaymentVerificationsTable> {
  $$PaymentVerificationsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get receiptId =>
      $composableBuilder(column: $table.receiptId, builder: (column) => column);

  GeneratedColumn<String> get verifiedBy => $composableBuilder(
      column: $table.verifiedBy, builder: (column) => column);

  GeneratedColumn<DateTime> get verifiedAt => $composableBuilder(
      column: $table.verifiedAt, builder: (column) => column);

  GeneratedColumn<String> get evidenceSummary => $composableBuilder(
      column: $table.evidenceSummary, builder: (column) => column);

  GeneratedColumn<String> get note =>
      $composableBuilder(column: $table.note, builder: (column) => column);
}

class $$PaymentVerificationsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PaymentVerificationsTable,
    PaymentVerification,
    $$PaymentVerificationsTableFilterComposer,
    $$PaymentVerificationsTableOrderingComposer,
    $$PaymentVerificationsTableAnnotationComposer,
    $$PaymentVerificationsTableCreateCompanionBuilder,
    $$PaymentVerificationsTableUpdateCompanionBuilder,
    (
      PaymentVerification,
      BaseReferences<_$AppDatabase, $PaymentVerificationsTable,
          PaymentVerification>
    ),
    PaymentVerification,
    PrefetchHooks Function()> {
  $$PaymentVerificationsTableTableManager(
      _$AppDatabase db, $PaymentVerificationsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$PaymentVerificationsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$PaymentVerificationsTableOrderingComposer(
                  $db: db, $table: table),
          createComputedFieldComposer: () =>
              $$PaymentVerificationsTableAnnotationComposer(
                  $db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> receiptId = const Value.absent(),
            Value<String> verifiedBy = const Value.absent(),
            Value<DateTime> verifiedAt = const Value.absent(),
            Value<String> evidenceSummary = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              PaymentVerificationsCompanion(
            id: id,
            receiptId: receiptId,
            verifiedBy: verifiedBy,
            verifiedAt: verifiedAt,
            evidenceSummary: evidenceSummary,
            note: note,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String receiptId,
            required String verifiedBy,
            required DateTime verifiedAt,
            required String evidenceSummary,
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              PaymentVerificationsCompanion.insert(
            id: id,
            receiptId: receiptId,
            verifiedBy: verifiedBy,
            verifiedAt: verifiedAt,
            evidenceSummary: evidenceSummary,
            note: note,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$PaymentVerificationsTableProcessedTableManager
    = ProcessedTableManager<
        _$AppDatabase,
        $PaymentVerificationsTable,
        PaymentVerification,
        $$PaymentVerificationsTableFilterComposer,
        $$PaymentVerificationsTableOrderingComposer,
        $$PaymentVerificationsTableAnnotationComposer,
        $$PaymentVerificationsTableCreateCompanionBuilder,
        $$PaymentVerificationsTableUpdateCompanionBuilder,
        (
          PaymentVerification,
          BaseReferences<_$AppDatabase, $PaymentVerificationsTable,
              PaymentVerification>
        ),
        PaymentVerification,
        PrefetchHooks Function()>;
typedef $$ReceiptSequencesTableCreateCompanionBuilder
    = ReceiptSequencesCompanion Function({
  required String id,
  required String institutionId,
  required String prefix,
  required int year,
  Value<int> lastNumber,
  required DateTime updatedAt,
  Value<int> rowid,
});
typedef $$ReceiptSequencesTableUpdateCompanionBuilder
    = ReceiptSequencesCompanion Function({
  Value<String> id,
  Value<String> institutionId,
  Value<String> prefix,
  Value<int> year,
  Value<int> lastNumber,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$ReceiptSequencesTableFilterComposer
    extends Composer<_$AppDatabase, $ReceiptSequencesTable> {
  $$ReceiptSequencesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get prefix => $composableBuilder(
      column: $table.prefix, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get year => $composableBuilder(
      column: $table.year, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get lastNumber => $composableBuilder(
      column: $table.lastNumber, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$ReceiptSequencesTableOrderingComposer
    extends Composer<_$AppDatabase, $ReceiptSequencesTable> {
  $$ReceiptSequencesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get institutionId => $composableBuilder(
      column: $table.institutionId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get prefix => $composableBuilder(
      column: $table.prefix, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get year => $composableBuilder(
      column: $table.year, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get lastNumber => $composableBuilder(
      column: $table.lastNumber, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$ReceiptSequencesTableAnnotationComposer
    extends Composer<_$AppDatabase, $ReceiptSequencesTable> {
  $$ReceiptSequencesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => column);

  GeneratedColumn<String> get prefix =>
      $composableBuilder(column: $table.prefix, builder: (column) => column);

  GeneratedColumn<int> get year =>
      $composableBuilder(column: $table.year, builder: (column) => column);

  GeneratedColumn<int> get lastNumber => $composableBuilder(
      column: $table.lastNumber, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$ReceiptSequencesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ReceiptSequencesTable,
    ReceiptSequence,
    $$ReceiptSequencesTableFilterComposer,
    $$ReceiptSequencesTableOrderingComposer,
    $$ReceiptSequencesTableAnnotationComposer,
    $$ReceiptSequencesTableCreateCompanionBuilder,
    $$ReceiptSequencesTableUpdateCompanionBuilder,
    (
      ReceiptSequence,
      BaseReferences<_$AppDatabase, $ReceiptSequencesTable, ReceiptSequence>
    ),
    ReceiptSequence,
    PrefetchHooks Function()> {
  $$ReceiptSequencesTableTableManager(
      _$AppDatabase db, $ReceiptSequencesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ReceiptSequencesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ReceiptSequencesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ReceiptSequencesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> institutionId = const Value.absent(),
            Value<String> prefix = const Value.absent(),
            Value<int> year = const Value.absent(),
            Value<int> lastNumber = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ReceiptSequencesCompanion(
            id: id,
            institutionId: institutionId,
            prefix: prefix,
            year: year,
            lastNumber: lastNumber,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String institutionId,
            required String prefix,
            required int year,
            Value<int> lastNumber = const Value.absent(),
            required DateTime updatedAt,
            Value<int> rowid = const Value.absent(),
          }) =>
              ReceiptSequencesCompanion.insert(
            id: id,
            institutionId: institutionId,
            prefix: prefix,
            year: year,
            lastNumber: lastNumber,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$ReceiptSequencesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $ReceiptSequencesTable,
    ReceiptSequence,
    $$ReceiptSequencesTableFilterComposer,
    $$ReceiptSequencesTableOrderingComposer,
    $$ReceiptSequencesTableAnnotationComposer,
    $$ReceiptSequencesTableCreateCompanionBuilder,
    $$ReceiptSequencesTableUpdateCompanionBuilder,
    (
      ReceiptSequence,
      BaseReferences<_$AppDatabase, $ReceiptSequencesTable, ReceiptSequence>
    ),
    ReceiptSequence,
    PrefetchHooks Function()>;
typedef $$ExpenseVouchersTableCreateCompanionBuilder = ExpenseVouchersCompanion
    Function({
  required String id,
  required String institutionId,
  required String voucherNumber,
  required DateTime voucherDate,
  required String payee,
  required String description,
  required int totalPaisa,
  required PaymentMethod paymentMethod,
  Value<String?> bankAccountId,
  Value<String?> attachmentPath,
  required ExpenseStatus status,
  Value<String?> createdBy,
  Value<String?> approvedBy,
  Value<DateTime?> approvedAt,
  Value<String?> rejectionReason,
  required String idempotencyKey,
  Value<bool> serverAck,
  required DateTime createdAt,
  required DateTime updatedAt,
  Value<DateTime?> serverUpdatedAt,
  Value<bool> isDirty,
  Value<int> rowid,
});
typedef $$ExpenseVouchersTableUpdateCompanionBuilder = ExpenseVouchersCompanion
    Function({
  Value<String> id,
  Value<String> institutionId,
  Value<String> voucherNumber,
  Value<DateTime> voucherDate,
  Value<String> payee,
  Value<String> description,
  Value<int> totalPaisa,
  Value<PaymentMethod> paymentMethod,
  Value<String?> bankAccountId,
  Value<String?> attachmentPath,
  Value<ExpenseStatus> status,
  Value<String?> createdBy,
  Value<String?> approvedBy,
  Value<DateTime?> approvedAt,
  Value<String?> rejectionReason,
  Value<String> idempotencyKey,
  Value<bool> serverAck,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<DateTime?> serverUpdatedAt,
  Value<bool> isDirty,
  Value<int> rowid,
});

class $$ExpenseVouchersTableFilterComposer
    extends Composer<_$AppDatabase, $ExpenseVouchersTable> {
  $$ExpenseVouchersTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get voucherNumber => $composableBuilder(
      column: $table.voucherNumber, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get voucherDate => $composableBuilder(
      column: $table.voucherDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get payee => $composableBuilder(
      column: $table.payee, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get description => $composableBuilder(
      column: $table.description, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get totalPaisa => $composableBuilder(
      column: $table.totalPaisa, builder: (column) => ColumnFilters(column));

  ColumnWithTypeConverterFilters<PaymentMethod, PaymentMethod, String>
      get paymentMethod => $composableBuilder(
          column: $table.paymentMethod,
          builder: (column) => ColumnWithTypeConverterFilters(column));

  ColumnFilters<String> get bankAccountId => $composableBuilder(
      column: $table.bankAccountId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get attachmentPath => $composableBuilder(
      column: $table.attachmentPath,
      builder: (column) => ColumnFilters(column));

  ColumnWithTypeConverterFilters<ExpenseStatus, ExpenseStatus, String>
      get status => $composableBuilder(
          column: $table.status,
          builder: (column) => ColumnWithTypeConverterFilters(column));

  ColumnFilters<String> get createdBy => $composableBuilder(
      column: $table.createdBy, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get approvedBy => $composableBuilder(
      column: $table.approvedBy, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get approvedAt => $composableBuilder(
      column: $table.approvedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get rejectionReason => $composableBuilder(
      column: $table.rejectionReason,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get idempotencyKey => $composableBuilder(
      column: $table.idempotencyKey,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get serverAck => $composableBuilder(
      column: $table.serverAck, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isDirty => $composableBuilder(
      column: $table.isDirty, builder: (column) => ColumnFilters(column));
}

class $$ExpenseVouchersTableOrderingComposer
    extends Composer<_$AppDatabase, $ExpenseVouchersTable> {
  $$ExpenseVouchersTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get institutionId => $composableBuilder(
      column: $table.institutionId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get voucherNumber => $composableBuilder(
      column: $table.voucherNumber,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get voucherDate => $composableBuilder(
      column: $table.voucherDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get payee => $composableBuilder(
      column: $table.payee, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get description => $composableBuilder(
      column: $table.description, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get totalPaisa => $composableBuilder(
      column: $table.totalPaisa, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get paymentMethod => $composableBuilder(
      column: $table.paymentMethod,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get bankAccountId => $composableBuilder(
      column: $table.bankAccountId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get attachmentPath => $composableBuilder(
      column: $table.attachmentPath,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get createdBy => $composableBuilder(
      column: $table.createdBy, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get approvedBy => $composableBuilder(
      column: $table.approvedBy, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get approvedAt => $composableBuilder(
      column: $table.approvedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get rejectionReason => $composableBuilder(
      column: $table.rejectionReason,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get idempotencyKey => $composableBuilder(
      column: $table.idempotencyKey,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get serverAck => $composableBuilder(
      column: $table.serverAck, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isDirty => $composableBuilder(
      column: $table.isDirty, builder: (column) => ColumnOrderings(column));
}

class $$ExpenseVouchersTableAnnotationComposer
    extends Composer<_$AppDatabase, $ExpenseVouchersTable> {
  $$ExpenseVouchersTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => column);

  GeneratedColumn<String> get voucherNumber => $composableBuilder(
      column: $table.voucherNumber, builder: (column) => column);

  GeneratedColumn<DateTime> get voucherDate => $composableBuilder(
      column: $table.voucherDate, builder: (column) => column);

  GeneratedColumn<String> get payee =>
      $composableBuilder(column: $table.payee, builder: (column) => column);

  GeneratedColumn<String> get description => $composableBuilder(
      column: $table.description, builder: (column) => column);

  GeneratedColumn<int> get totalPaisa => $composableBuilder(
      column: $table.totalPaisa, builder: (column) => column);

  GeneratedColumnWithTypeConverter<PaymentMethod, String> get paymentMethod =>
      $composableBuilder(
          column: $table.paymentMethod, builder: (column) => column);

  GeneratedColumn<String> get bankAccountId => $composableBuilder(
      column: $table.bankAccountId, builder: (column) => column);

  GeneratedColumn<String> get attachmentPath => $composableBuilder(
      column: $table.attachmentPath, builder: (column) => column);

  GeneratedColumnWithTypeConverter<ExpenseStatus, String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<String> get createdBy =>
      $composableBuilder(column: $table.createdBy, builder: (column) => column);

  GeneratedColumn<String> get approvedBy => $composableBuilder(
      column: $table.approvedBy, builder: (column) => column);

  GeneratedColumn<DateTime> get approvedAt => $composableBuilder(
      column: $table.approvedAt, builder: (column) => column);

  GeneratedColumn<String> get rejectionReason => $composableBuilder(
      column: $table.rejectionReason, builder: (column) => column);

  GeneratedColumn<String> get idempotencyKey => $composableBuilder(
      column: $table.idempotencyKey, builder: (column) => column);

  GeneratedColumn<bool> get serverAck =>
      $composableBuilder(column: $table.serverAck, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<DateTime> get serverUpdatedAt => $composableBuilder(
      column: $table.serverUpdatedAt, builder: (column) => column);

  GeneratedColumn<bool> get isDirty =>
      $composableBuilder(column: $table.isDirty, builder: (column) => column);
}

class $$ExpenseVouchersTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ExpenseVouchersTable,
    ExpenseVoucher,
    $$ExpenseVouchersTableFilterComposer,
    $$ExpenseVouchersTableOrderingComposer,
    $$ExpenseVouchersTableAnnotationComposer,
    $$ExpenseVouchersTableCreateCompanionBuilder,
    $$ExpenseVouchersTableUpdateCompanionBuilder,
    (
      ExpenseVoucher,
      BaseReferences<_$AppDatabase, $ExpenseVouchersTable, ExpenseVoucher>
    ),
    ExpenseVoucher,
    PrefetchHooks Function()> {
  $$ExpenseVouchersTableTableManager(
      _$AppDatabase db, $ExpenseVouchersTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ExpenseVouchersTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ExpenseVouchersTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ExpenseVouchersTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> institutionId = const Value.absent(),
            Value<String> voucherNumber = const Value.absent(),
            Value<DateTime> voucherDate = const Value.absent(),
            Value<String> payee = const Value.absent(),
            Value<String> description = const Value.absent(),
            Value<int> totalPaisa = const Value.absent(),
            Value<PaymentMethod> paymentMethod = const Value.absent(),
            Value<String?> bankAccountId = const Value.absent(),
            Value<String?> attachmentPath = const Value.absent(),
            Value<ExpenseStatus> status = const Value.absent(),
            Value<String?> createdBy = const Value.absent(),
            Value<String?> approvedBy = const Value.absent(),
            Value<DateTime?> approvedAt = const Value.absent(),
            Value<String?> rejectionReason = const Value.absent(),
            Value<String> idempotencyKey = const Value.absent(),
            Value<bool> serverAck = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<DateTime?> serverUpdatedAt = const Value.absent(),
            Value<bool> isDirty = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ExpenseVouchersCompanion(
            id: id,
            institutionId: institutionId,
            voucherNumber: voucherNumber,
            voucherDate: voucherDate,
            payee: payee,
            description: description,
            totalPaisa: totalPaisa,
            paymentMethod: paymentMethod,
            bankAccountId: bankAccountId,
            attachmentPath: attachmentPath,
            status: status,
            createdBy: createdBy,
            approvedBy: approvedBy,
            approvedAt: approvedAt,
            rejectionReason: rejectionReason,
            idempotencyKey: idempotencyKey,
            serverAck: serverAck,
            createdAt: createdAt,
            updatedAt: updatedAt,
            serverUpdatedAt: serverUpdatedAt,
            isDirty: isDirty,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String institutionId,
            required String voucherNumber,
            required DateTime voucherDate,
            required String payee,
            required String description,
            required int totalPaisa,
            required PaymentMethod paymentMethod,
            Value<String?> bankAccountId = const Value.absent(),
            Value<String?> attachmentPath = const Value.absent(),
            required ExpenseStatus status,
            Value<String?> createdBy = const Value.absent(),
            Value<String?> approvedBy = const Value.absent(),
            Value<DateTime?> approvedAt = const Value.absent(),
            Value<String?> rejectionReason = const Value.absent(),
            required String idempotencyKey,
            Value<bool> serverAck = const Value.absent(),
            required DateTime createdAt,
            required DateTime updatedAt,
            Value<DateTime?> serverUpdatedAt = const Value.absent(),
            Value<bool> isDirty = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ExpenseVouchersCompanion.insert(
            id: id,
            institutionId: institutionId,
            voucherNumber: voucherNumber,
            voucherDate: voucherDate,
            payee: payee,
            description: description,
            totalPaisa: totalPaisa,
            paymentMethod: paymentMethod,
            bankAccountId: bankAccountId,
            attachmentPath: attachmentPath,
            status: status,
            createdBy: createdBy,
            approvedBy: approvedBy,
            approvedAt: approvedAt,
            rejectionReason: rejectionReason,
            idempotencyKey: idempotencyKey,
            serverAck: serverAck,
            createdAt: createdAt,
            updatedAt: updatedAt,
            serverUpdatedAt: serverUpdatedAt,
            isDirty: isDirty,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$ExpenseVouchersTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $ExpenseVouchersTable,
    ExpenseVoucher,
    $$ExpenseVouchersTableFilterComposer,
    $$ExpenseVouchersTableOrderingComposer,
    $$ExpenseVouchersTableAnnotationComposer,
    $$ExpenseVouchersTableCreateCompanionBuilder,
    $$ExpenseVouchersTableUpdateCompanionBuilder,
    (
      ExpenseVoucher,
      BaseReferences<_$AppDatabase, $ExpenseVouchersTable, ExpenseVoucher>
    ),
    ExpenseVoucher,
    PrefetchHooks Function()>;
typedef $$ExpenseAllocationsTableCreateCompanionBuilder
    = ExpenseAllocationsCompanion Function({
  required String id,
  required String voucherId,
  required String fundTypeId,
  Value<String?> purposeId,
  required int amountPaisa,
  Value<int> rowid,
});
typedef $$ExpenseAllocationsTableUpdateCompanionBuilder
    = ExpenseAllocationsCompanion Function({
  Value<String> id,
  Value<String> voucherId,
  Value<String> fundTypeId,
  Value<String?> purposeId,
  Value<int> amountPaisa,
  Value<int> rowid,
});

class $$ExpenseAllocationsTableFilterComposer
    extends Composer<_$AppDatabase, $ExpenseAllocationsTable> {
  $$ExpenseAllocationsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get voucherId => $composableBuilder(
      column: $table.voucherId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get fundTypeId => $composableBuilder(
      column: $table.fundTypeId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get purposeId => $composableBuilder(
      column: $table.purposeId, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => ColumnFilters(column));
}

class $$ExpenseAllocationsTableOrderingComposer
    extends Composer<_$AppDatabase, $ExpenseAllocationsTable> {
  $$ExpenseAllocationsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get voucherId => $composableBuilder(
      column: $table.voucherId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get fundTypeId => $composableBuilder(
      column: $table.fundTypeId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get purposeId => $composableBuilder(
      column: $table.purposeId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => ColumnOrderings(column));
}

class $$ExpenseAllocationsTableAnnotationComposer
    extends Composer<_$AppDatabase, $ExpenseAllocationsTable> {
  $$ExpenseAllocationsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get voucherId =>
      $composableBuilder(column: $table.voucherId, builder: (column) => column);

  GeneratedColumn<String> get fundTypeId => $composableBuilder(
      column: $table.fundTypeId, builder: (column) => column);

  GeneratedColumn<String> get purposeId =>
      $composableBuilder(column: $table.purposeId, builder: (column) => column);

  GeneratedColumn<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => column);
}

class $$ExpenseAllocationsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ExpenseAllocationsTable,
    ExpenseAllocation,
    $$ExpenseAllocationsTableFilterComposer,
    $$ExpenseAllocationsTableOrderingComposer,
    $$ExpenseAllocationsTableAnnotationComposer,
    $$ExpenseAllocationsTableCreateCompanionBuilder,
    $$ExpenseAllocationsTableUpdateCompanionBuilder,
    (
      ExpenseAllocation,
      BaseReferences<_$AppDatabase, $ExpenseAllocationsTable, ExpenseAllocation>
    ),
    ExpenseAllocation,
    PrefetchHooks Function()> {
  $$ExpenseAllocationsTableTableManager(
      _$AppDatabase db, $ExpenseAllocationsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ExpenseAllocationsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ExpenseAllocationsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ExpenseAllocationsTableAnnotationComposer(
                  $db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> voucherId = const Value.absent(),
            Value<String> fundTypeId = const Value.absent(),
            Value<String?> purposeId = const Value.absent(),
            Value<int> amountPaisa = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ExpenseAllocationsCompanion(
            id: id,
            voucherId: voucherId,
            fundTypeId: fundTypeId,
            purposeId: purposeId,
            amountPaisa: amountPaisa,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String voucherId,
            required String fundTypeId,
            Value<String?> purposeId = const Value.absent(),
            required int amountPaisa,
            Value<int> rowid = const Value.absent(),
          }) =>
              ExpenseAllocationsCompanion.insert(
            id: id,
            voucherId: voucherId,
            fundTypeId: fundTypeId,
            purposeId: purposeId,
            amountPaisa: amountPaisa,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$ExpenseAllocationsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $ExpenseAllocationsTable,
    ExpenseAllocation,
    $$ExpenseAllocationsTableFilterComposer,
    $$ExpenseAllocationsTableOrderingComposer,
    $$ExpenseAllocationsTableAnnotationComposer,
    $$ExpenseAllocationsTableCreateCompanionBuilder,
    $$ExpenseAllocationsTableUpdateCompanionBuilder,
    (
      ExpenseAllocation,
      BaseReferences<_$AppDatabase, $ExpenseAllocationsTable, ExpenseAllocation>
    ),
    ExpenseAllocation,
    PrefetchHooks Function()>;
typedef $$ApprovalsTableCreateCompanionBuilder = ApprovalsCompanion Function({
  required String id,
  required String institutionId,
  required String entityType,
  required String entityId,
  required String action,
  required ApprovalDecision decision,
  required String actorId,
  required DateTime decidedAt,
  Value<String?> reason,
  Value<int> rowid,
});
typedef $$ApprovalsTableUpdateCompanionBuilder = ApprovalsCompanion Function({
  Value<String> id,
  Value<String> institutionId,
  Value<String> entityType,
  Value<String> entityId,
  Value<String> action,
  Value<ApprovalDecision> decision,
  Value<String> actorId,
  Value<DateTime> decidedAt,
  Value<String?> reason,
  Value<int> rowid,
});

class $$ApprovalsTableFilterComposer
    extends Composer<_$AppDatabase, $ApprovalsTable> {
  $$ApprovalsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entityId => $composableBuilder(
      column: $table.entityId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get action => $composableBuilder(
      column: $table.action, builder: (column) => ColumnFilters(column));

  ColumnWithTypeConverterFilters<ApprovalDecision, ApprovalDecision, String>
      get decision => $composableBuilder(
          column: $table.decision,
          builder: (column) => ColumnWithTypeConverterFilters(column));

  ColumnFilters<String> get actorId => $composableBuilder(
      column: $table.actorId, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get decidedAt => $composableBuilder(
      column: $table.decidedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get reason => $composableBuilder(
      column: $table.reason, builder: (column) => ColumnFilters(column));
}

class $$ApprovalsTableOrderingComposer
    extends Composer<_$AppDatabase, $ApprovalsTable> {
  $$ApprovalsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get institutionId => $composableBuilder(
      column: $table.institutionId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entityId => $composableBuilder(
      column: $table.entityId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get action => $composableBuilder(
      column: $table.action, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get decision => $composableBuilder(
      column: $table.decision, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get actorId => $composableBuilder(
      column: $table.actorId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get decidedAt => $composableBuilder(
      column: $table.decidedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get reason => $composableBuilder(
      column: $table.reason, builder: (column) => ColumnOrderings(column));
}

class $$ApprovalsTableAnnotationComposer
    extends Composer<_$AppDatabase, $ApprovalsTable> {
  $$ApprovalsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => column);

  GeneratedColumn<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => column);

  GeneratedColumn<String> get entityId =>
      $composableBuilder(column: $table.entityId, builder: (column) => column);

  GeneratedColumn<String> get action =>
      $composableBuilder(column: $table.action, builder: (column) => column);

  GeneratedColumnWithTypeConverter<ApprovalDecision, String> get decision =>
      $composableBuilder(column: $table.decision, builder: (column) => column);

  GeneratedColumn<String> get actorId =>
      $composableBuilder(column: $table.actorId, builder: (column) => column);

  GeneratedColumn<DateTime> get decidedAt =>
      $composableBuilder(column: $table.decidedAt, builder: (column) => column);

  GeneratedColumn<String> get reason =>
      $composableBuilder(column: $table.reason, builder: (column) => column);
}

class $$ApprovalsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ApprovalsTable,
    Approval,
    $$ApprovalsTableFilterComposer,
    $$ApprovalsTableOrderingComposer,
    $$ApprovalsTableAnnotationComposer,
    $$ApprovalsTableCreateCompanionBuilder,
    $$ApprovalsTableUpdateCompanionBuilder,
    (Approval, BaseReferences<_$AppDatabase, $ApprovalsTable, Approval>),
    Approval,
    PrefetchHooks Function()> {
  $$ApprovalsTableTableManager(_$AppDatabase db, $ApprovalsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ApprovalsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ApprovalsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ApprovalsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> institutionId = const Value.absent(),
            Value<String> entityType = const Value.absent(),
            Value<String> entityId = const Value.absent(),
            Value<String> action = const Value.absent(),
            Value<ApprovalDecision> decision = const Value.absent(),
            Value<String> actorId = const Value.absent(),
            Value<DateTime> decidedAt = const Value.absent(),
            Value<String?> reason = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ApprovalsCompanion(
            id: id,
            institutionId: institutionId,
            entityType: entityType,
            entityId: entityId,
            action: action,
            decision: decision,
            actorId: actorId,
            decidedAt: decidedAt,
            reason: reason,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String institutionId,
            required String entityType,
            required String entityId,
            required String action,
            required ApprovalDecision decision,
            required String actorId,
            required DateTime decidedAt,
            Value<String?> reason = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ApprovalsCompanion.insert(
            id: id,
            institutionId: institutionId,
            entityType: entityType,
            entityId: entityId,
            action: action,
            decision: decision,
            actorId: actorId,
            decidedAt: decidedAt,
            reason: reason,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$ApprovalsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $ApprovalsTable,
    Approval,
    $$ApprovalsTableFilterComposer,
    $$ApprovalsTableOrderingComposer,
    $$ApprovalsTableAnnotationComposer,
    $$ApprovalsTableCreateCompanionBuilder,
    $$ApprovalsTableUpdateCompanionBuilder,
    (Approval, BaseReferences<_$AppDatabase, $ApprovalsTable, Approval>),
    Approval,
    PrefetchHooks Function()>;
typedef $$ReconciliationsTableCreateCompanionBuilder = ReconciliationsCompanion
    Function({
  required String id,
  required String institutionId,
  required String bankAccountId,
  required DateTime statementDate,
  required int statementBalancePaisa,
  required int bookBalancePaisa,
  required int differencePaisa,
  Value<String> status,
  Value<String?> createdBy,
  Value<String?> notes,
  required DateTime createdAt,
  Value<int> rowid,
});
typedef $$ReconciliationsTableUpdateCompanionBuilder = ReconciliationsCompanion
    Function({
  Value<String> id,
  Value<String> institutionId,
  Value<String> bankAccountId,
  Value<DateTime> statementDate,
  Value<int> statementBalancePaisa,
  Value<int> bookBalancePaisa,
  Value<int> differencePaisa,
  Value<String> status,
  Value<String?> createdBy,
  Value<String?> notes,
  Value<DateTime> createdAt,
  Value<int> rowid,
});

class $$ReconciliationsTableFilterComposer
    extends Composer<_$AppDatabase, $ReconciliationsTable> {
  $$ReconciliationsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get bankAccountId => $composableBuilder(
      column: $table.bankAccountId, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get statementDate => $composableBuilder(
      column: $table.statementDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get statementBalancePaisa => $composableBuilder(
      column: $table.statementBalancePaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get bookBalancePaisa => $composableBuilder(
      column: $table.bookBalancePaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get differencePaisa => $composableBuilder(
      column: $table.differencePaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get createdBy => $composableBuilder(
      column: $table.createdBy, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get notes => $composableBuilder(
      column: $table.notes, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));
}

class $$ReconciliationsTableOrderingComposer
    extends Composer<_$AppDatabase, $ReconciliationsTable> {
  $$ReconciliationsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get institutionId => $composableBuilder(
      column: $table.institutionId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get bankAccountId => $composableBuilder(
      column: $table.bankAccountId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get statementDate => $composableBuilder(
      column: $table.statementDate,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get statementBalancePaisa => $composableBuilder(
      column: $table.statementBalancePaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get bookBalancePaisa => $composableBuilder(
      column: $table.bookBalancePaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get differencePaisa => $composableBuilder(
      column: $table.differencePaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get createdBy => $composableBuilder(
      column: $table.createdBy, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get notes => $composableBuilder(
      column: $table.notes, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));
}

class $$ReconciliationsTableAnnotationComposer
    extends Composer<_$AppDatabase, $ReconciliationsTable> {
  $$ReconciliationsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => column);

  GeneratedColumn<String> get bankAccountId => $composableBuilder(
      column: $table.bankAccountId, builder: (column) => column);

  GeneratedColumn<DateTime> get statementDate => $composableBuilder(
      column: $table.statementDate, builder: (column) => column);

  GeneratedColumn<int> get statementBalancePaisa => $composableBuilder(
      column: $table.statementBalancePaisa, builder: (column) => column);

  GeneratedColumn<int> get bookBalancePaisa => $composableBuilder(
      column: $table.bookBalancePaisa, builder: (column) => column);

  GeneratedColumn<int> get differencePaisa => $composableBuilder(
      column: $table.differencePaisa, builder: (column) => column);

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<String> get createdBy =>
      $composableBuilder(column: $table.createdBy, builder: (column) => column);

  GeneratedColumn<String> get notes =>
      $composableBuilder(column: $table.notes, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);
}

class $$ReconciliationsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ReconciliationsTable,
    Reconciliation,
    $$ReconciliationsTableFilterComposer,
    $$ReconciliationsTableOrderingComposer,
    $$ReconciliationsTableAnnotationComposer,
    $$ReconciliationsTableCreateCompanionBuilder,
    $$ReconciliationsTableUpdateCompanionBuilder,
    (
      Reconciliation,
      BaseReferences<_$AppDatabase, $ReconciliationsTable, Reconciliation>
    ),
    Reconciliation,
    PrefetchHooks Function()> {
  $$ReconciliationsTableTableManager(
      _$AppDatabase db, $ReconciliationsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ReconciliationsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ReconciliationsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ReconciliationsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> institutionId = const Value.absent(),
            Value<String> bankAccountId = const Value.absent(),
            Value<DateTime> statementDate = const Value.absent(),
            Value<int> statementBalancePaisa = const Value.absent(),
            Value<int> bookBalancePaisa = const Value.absent(),
            Value<int> differencePaisa = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<String?> createdBy = const Value.absent(),
            Value<String?> notes = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ReconciliationsCompanion(
            id: id,
            institutionId: institutionId,
            bankAccountId: bankAccountId,
            statementDate: statementDate,
            statementBalancePaisa: statementBalancePaisa,
            bookBalancePaisa: bookBalancePaisa,
            differencePaisa: differencePaisa,
            status: status,
            createdBy: createdBy,
            notes: notes,
            createdAt: createdAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String institutionId,
            required String bankAccountId,
            required DateTime statementDate,
            required int statementBalancePaisa,
            required int bookBalancePaisa,
            required int differencePaisa,
            Value<String> status = const Value.absent(),
            Value<String?> createdBy = const Value.absent(),
            Value<String?> notes = const Value.absent(),
            required DateTime createdAt,
            Value<int> rowid = const Value.absent(),
          }) =>
              ReconciliationsCompanion.insert(
            id: id,
            institutionId: institutionId,
            bankAccountId: bankAccountId,
            statementDate: statementDate,
            statementBalancePaisa: statementBalancePaisa,
            bookBalancePaisa: bookBalancePaisa,
            differencePaisa: differencePaisa,
            status: status,
            createdBy: createdBy,
            notes: notes,
            createdAt: createdAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$ReconciliationsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $ReconciliationsTable,
    Reconciliation,
    $$ReconciliationsTableFilterComposer,
    $$ReconciliationsTableOrderingComposer,
    $$ReconciliationsTableAnnotationComposer,
    $$ReconciliationsTableCreateCompanionBuilder,
    $$ReconciliationsTableUpdateCompanionBuilder,
    (
      Reconciliation,
      BaseReferences<_$AppDatabase, $ReconciliationsTable, Reconciliation>
    ),
    Reconciliation,
    PrefetchHooks Function()>;
typedef $$EvidenceFilesTableCreateCompanionBuilder = EvidenceFilesCompanion
    Function({
  required String id,
  required String institutionId,
  required String entityType,
  required String entityId,
  Value<String?> localPath,
  Value<String?> remotePath,
  required String mime,
  required int sizeBytes,
  Value<String?> sha256,
  required DateTime createdAt,
  Value<int> rowid,
});
typedef $$EvidenceFilesTableUpdateCompanionBuilder = EvidenceFilesCompanion
    Function({
  Value<String> id,
  Value<String> institutionId,
  Value<String> entityType,
  Value<String> entityId,
  Value<String?> localPath,
  Value<String?> remotePath,
  Value<String> mime,
  Value<int> sizeBytes,
  Value<String?> sha256,
  Value<DateTime> createdAt,
  Value<int> rowid,
});

class $$EvidenceFilesTableFilterComposer
    extends Composer<_$AppDatabase, $EvidenceFilesTable> {
  $$EvidenceFilesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entityId => $composableBuilder(
      column: $table.entityId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get localPath => $composableBuilder(
      column: $table.localPath, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get remotePath => $composableBuilder(
      column: $table.remotePath, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get mime => $composableBuilder(
      column: $table.mime, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get sizeBytes => $composableBuilder(
      column: $table.sizeBytes, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get sha256 => $composableBuilder(
      column: $table.sha256, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));
}

class $$EvidenceFilesTableOrderingComposer
    extends Composer<_$AppDatabase, $EvidenceFilesTable> {
  $$EvidenceFilesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get institutionId => $composableBuilder(
      column: $table.institutionId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entityId => $composableBuilder(
      column: $table.entityId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get localPath => $composableBuilder(
      column: $table.localPath, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get remotePath => $composableBuilder(
      column: $table.remotePath, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get mime => $composableBuilder(
      column: $table.mime, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get sizeBytes => $composableBuilder(
      column: $table.sizeBytes, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get sha256 => $composableBuilder(
      column: $table.sha256, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));
}

class $$EvidenceFilesTableAnnotationComposer
    extends Composer<_$AppDatabase, $EvidenceFilesTable> {
  $$EvidenceFilesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => column);

  GeneratedColumn<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => column);

  GeneratedColumn<String> get entityId =>
      $composableBuilder(column: $table.entityId, builder: (column) => column);

  GeneratedColumn<String> get localPath =>
      $composableBuilder(column: $table.localPath, builder: (column) => column);

  GeneratedColumn<String> get remotePath => $composableBuilder(
      column: $table.remotePath, builder: (column) => column);

  GeneratedColumn<String> get mime =>
      $composableBuilder(column: $table.mime, builder: (column) => column);

  GeneratedColumn<int> get sizeBytes =>
      $composableBuilder(column: $table.sizeBytes, builder: (column) => column);

  GeneratedColumn<String> get sha256 =>
      $composableBuilder(column: $table.sha256, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);
}

class $$EvidenceFilesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $EvidenceFilesTable,
    EvidenceFile,
    $$EvidenceFilesTableFilterComposer,
    $$EvidenceFilesTableOrderingComposer,
    $$EvidenceFilesTableAnnotationComposer,
    $$EvidenceFilesTableCreateCompanionBuilder,
    $$EvidenceFilesTableUpdateCompanionBuilder,
    (
      EvidenceFile,
      BaseReferences<_$AppDatabase, $EvidenceFilesTable, EvidenceFile>
    ),
    EvidenceFile,
    PrefetchHooks Function()> {
  $$EvidenceFilesTableTableManager(_$AppDatabase db, $EvidenceFilesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$EvidenceFilesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$EvidenceFilesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$EvidenceFilesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> institutionId = const Value.absent(),
            Value<String> entityType = const Value.absent(),
            Value<String> entityId = const Value.absent(),
            Value<String?> localPath = const Value.absent(),
            Value<String?> remotePath = const Value.absent(),
            Value<String> mime = const Value.absent(),
            Value<int> sizeBytes = const Value.absent(),
            Value<String?> sha256 = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              EvidenceFilesCompanion(
            id: id,
            institutionId: institutionId,
            entityType: entityType,
            entityId: entityId,
            localPath: localPath,
            remotePath: remotePath,
            mime: mime,
            sizeBytes: sizeBytes,
            sha256: sha256,
            createdAt: createdAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String institutionId,
            required String entityType,
            required String entityId,
            Value<String?> localPath = const Value.absent(),
            Value<String?> remotePath = const Value.absent(),
            required String mime,
            required int sizeBytes,
            Value<String?> sha256 = const Value.absent(),
            required DateTime createdAt,
            Value<int> rowid = const Value.absent(),
          }) =>
              EvidenceFilesCompanion.insert(
            id: id,
            institutionId: institutionId,
            entityType: entityType,
            entityId: entityId,
            localPath: localPath,
            remotePath: remotePath,
            mime: mime,
            sizeBytes: sizeBytes,
            sha256: sha256,
            createdAt: createdAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$EvidenceFilesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $EvidenceFilesTable,
    EvidenceFile,
    $$EvidenceFilesTableFilterComposer,
    $$EvidenceFilesTableOrderingComposer,
    $$EvidenceFilesTableAnnotationComposer,
    $$EvidenceFilesTableCreateCompanionBuilder,
    $$EvidenceFilesTableUpdateCompanionBuilder,
    (
      EvidenceFile,
      BaseReferences<_$AppDatabase, $EvidenceFilesTable, EvidenceFile>
    ),
    EvidenceFile,
    PrefetchHooks Function()>;
typedef $$AuditEventsTableCreateCompanionBuilder = AuditEventsCompanion
    Function({
  required String id,
  required String institutionId,
  required int sequence,
  required String entityType,
  required String entityId,
  required String action,
  required String actorId,
  required DateTime occurredAt,
  Value<String?> reason,
  Value<String?> beforeJson,
  Value<String?> afterJson,
  required String prevHash,
  required String hash,
  Value<int> rowid,
});
typedef $$AuditEventsTableUpdateCompanionBuilder = AuditEventsCompanion
    Function({
  Value<String> id,
  Value<String> institutionId,
  Value<int> sequence,
  Value<String> entityType,
  Value<String> entityId,
  Value<String> action,
  Value<String> actorId,
  Value<DateTime> occurredAt,
  Value<String?> reason,
  Value<String?> beforeJson,
  Value<String?> afterJson,
  Value<String> prevHash,
  Value<String> hash,
  Value<int> rowid,
});

class $$AuditEventsTableFilterComposer
    extends Composer<_$AppDatabase, $AuditEventsTable> {
  $$AuditEventsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get sequence => $composableBuilder(
      column: $table.sequence, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entityId => $composableBuilder(
      column: $table.entityId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get action => $composableBuilder(
      column: $table.action, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get actorId => $composableBuilder(
      column: $table.actorId, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get occurredAt => $composableBuilder(
      column: $table.occurredAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get reason => $composableBuilder(
      column: $table.reason, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get beforeJson => $composableBuilder(
      column: $table.beforeJson, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get afterJson => $composableBuilder(
      column: $table.afterJson, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get prevHash => $composableBuilder(
      column: $table.prevHash, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get hash => $composableBuilder(
      column: $table.hash, builder: (column) => ColumnFilters(column));
}

class $$AuditEventsTableOrderingComposer
    extends Composer<_$AppDatabase, $AuditEventsTable> {
  $$AuditEventsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get institutionId => $composableBuilder(
      column: $table.institutionId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get sequence => $composableBuilder(
      column: $table.sequence, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entityId => $composableBuilder(
      column: $table.entityId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get action => $composableBuilder(
      column: $table.action, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get actorId => $composableBuilder(
      column: $table.actorId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get occurredAt => $composableBuilder(
      column: $table.occurredAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get reason => $composableBuilder(
      column: $table.reason, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get beforeJson => $composableBuilder(
      column: $table.beforeJson, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get afterJson => $composableBuilder(
      column: $table.afterJson, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get prevHash => $composableBuilder(
      column: $table.prevHash, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get hash => $composableBuilder(
      column: $table.hash, builder: (column) => ColumnOrderings(column));
}

class $$AuditEventsTableAnnotationComposer
    extends Composer<_$AppDatabase, $AuditEventsTable> {
  $$AuditEventsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => column);

  GeneratedColumn<int> get sequence =>
      $composableBuilder(column: $table.sequence, builder: (column) => column);

  GeneratedColumn<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => column);

  GeneratedColumn<String> get entityId =>
      $composableBuilder(column: $table.entityId, builder: (column) => column);

  GeneratedColumn<String> get action =>
      $composableBuilder(column: $table.action, builder: (column) => column);

  GeneratedColumn<String> get actorId =>
      $composableBuilder(column: $table.actorId, builder: (column) => column);

  GeneratedColumn<DateTime> get occurredAt => $composableBuilder(
      column: $table.occurredAt, builder: (column) => column);

  GeneratedColumn<String> get reason =>
      $composableBuilder(column: $table.reason, builder: (column) => column);

  GeneratedColumn<String> get beforeJson => $composableBuilder(
      column: $table.beforeJson, builder: (column) => column);

  GeneratedColumn<String> get afterJson =>
      $composableBuilder(column: $table.afterJson, builder: (column) => column);

  GeneratedColumn<String> get prevHash =>
      $composableBuilder(column: $table.prevHash, builder: (column) => column);

  GeneratedColumn<String> get hash =>
      $composableBuilder(column: $table.hash, builder: (column) => column);
}

class $$AuditEventsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $AuditEventsTable,
    AuditEvent,
    $$AuditEventsTableFilterComposer,
    $$AuditEventsTableOrderingComposer,
    $$AuditEventsTableAnnotationComposer,
    $$AuditEventsTableCreateCompanionBuilder,
    $$AuditEventsTableUpdateCompanionBuilder,
    (AuditEvent, BaseReferences<_$AppDatabase, $AuditEventsTable, AuditEvent>),
    AuditEvent,
    PrefetchHooks Function()> {
  $$AuditEventsTableTableManager(_$AppDatabase db, $AuditEventsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$AuditEventsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$AuditEventsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$AuditEventsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> institutionId = const Value.absent(),
            Value<int> sequence = const Value.absent(),
            Value<String> entityType = const Value.absent(),
            Value<String> entityId = const Value.absent(),
            Value<String> action = const Value.absent(),
            Value<String> actorId = const Value.absent(),
            Value<DateTime> occurredAt = const Value.absent(),
            Value<String?> reason = const Value.absent(),
            Value<String?> beforeJson = const Value.absent(),
            Value<String?> afterJson = const Value.absent(),
            Value<String> prevHash = const Value.absent(),
            Value<String> hash = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              AuditEventsCompanion(
            id: id,
            institutionId: institutionId,
            sequence: sequence,
            entityType: entityType,
            entityId: entityId,
            action: action,
            actorId: actorId,
            occurredAt: occurredAt,
            reason: reason,
            beforeJson: beforeJson,
            afterJson: afterJson,
            prevHash: prevHash,
            hash: hash,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String institutionId,
            required int sequence,
            required String entityType,
            required String entityId,
            required String action,
            required String actorId,
            required DateTime occurredAt,
            Value<String?> reason = const Value.absent(),
            Value<String?> beforeJson = const Value.absent(),
            Value<String?> afterJson = const Value.absent(),
            required String prevHash,
            required String hash,
            Value<int> rowid = const Value.absent(),
          }) =>
              AuditEventsCompanion.insert(
            id: id,
            institutionId: institutionId,
            sequence: sequence,
            entityType: entityType,
            entityId: entityId,
            action: action,
            actorId: actorId,
            occurredAt: occurredAt,
            reason: reason,
            beforeJson: beforeJson,
            afterJson: afterJson,
            prevHash: prevHash,
            hash: hash,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$AuditEventsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $AuditEventsTable,
    AuditEvent,
    $$AuditEventsTableFilterComposer,
    $$AuditEventsTableOrderingComposer,
    $$AuditEventsTableAnnotationComposer,
    $$AuditEventsTableCreateCompanionBuilder,
    $$AuditEventsTableUpdateCompanionBuilder,
    (AuditEvent, BaseReferences<_$AppDatabase, $AuditEventsTable, AuditEvent>),
    AuditEvent,
    PrefetchHooks Function()>;
typedef $$DevicesTableCreateCompanionBuilder = DevicesCompanion Function({
  required String id,
  required String institutionId,
  required String deviceName,
  required String platform,
  required String appVersion,
  Value<String?> registeredBy,
  required DateTime registeredAt,
  Value<bool> isActive,
  Value<int?> rangeStart,
  Value<int?> rangeEnd,
  Value<int> rowid,
});
typedef $$DevicesTableUpdateCompanionBuilder = DevicesCompanion Function({
  Value<String> id,
  Value<String> institutionId,
  Value<String> deviceName,
  Value<String> platform,
  Value<String> appVersion,
  Value<String?> registeredBy,
  Value<DateTime> registeredAt,
  Value<bool> isActive,
  Value<int?> rangeStart,
  Value<int?> rangeEnd,
  Value<int> rowid,
});

class $$DevicesTableFilterComposer
    extends Composer<_$AppDatabase, $DevicesTable> {
  $$DevicesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deviceName => $composableBuilder(
      column: $table.deviceName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get platform => $composableBuilder(
      column: $table.platform, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get appVersion => $composableBuilder(
      column: $table.appVersion, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get registeredBy => $composableBuilder(
      column: $table.registeredBy, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get registeredAt => $composableBuilder(
      column: $table.registeredAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get rangeStart => $composableBuilder(
      column: $table.rangeStart, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get rangeEnd => $composableBuilder(
      column: $table.rangeEnd, builder: (column) => ColumnFilters(column));
}

class $$DevicesTableOrderingComposer
    extends Composer<_$AppDatabase, $DevicesTable> {
  $$DevicesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get institutionId => $composableBuilder(
      column: $table.institutionId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deviceName => $composableBuilder(
      column: $table.deviceName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get platform => $composableBuilder(
      column: $table.platform, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get appVersion => $composableBuilder(
      column: $table.appVersion, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get registeredBy => $composableBuilder(
      column: $table.registeredBy,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get registeredAt => $composableBuilder(
      column: $table.registeredAt,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get rangeStart => $composableBuilder(
      column: $table.rangeStart, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get rangeEnd => $composableBuilder(
      column: $table.rangeEnd, builder: (column) => ColumnOrderings(column));
}

class $$DevicesTableAnnotationComposer
    extends Composer<_$AppDatabase, $DevicesTable> {
  $$DevicesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => column);

  GeneratedColumn<String> get deviceName => $composableBuilder(
      column: $table.deviceName, builder: (column) => column);

  GeneratedColumn<String> get platform =>
      $composableBuilder(column: $table.platform, builder: (column) => column);

  GeneratedColumn<String> get appVersion => $composableBuilder(
      column: $table.appVersion, builder: (column) => column);

  GeneratedColumn<String> get registeredBy => $composableBuilder(
      column: $table.registeredBy, builder: (column) => column);

  GeneratedColumn<DateTime> get registeredAt => $composableBuilder(
      column: $table.registeredAt, builder: (column) => column);

  GeneratedColumn<bool> get isActive =>
      $composableBuilder(column: $table.isActive, builder: (column) => column);

  GeneratedColumn<int> get rangeStart => $composableBuilder(
      column: $table.rangeStart, builder: (column) => column);

  GeneratedColumn<int> get rangeEnd =>
      $composableBuilder(column: $table.rangeEnd, builder: (column) => column);
}

class $$DevicesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $DevicesTable,
    Device,
    $$DevicesTableFilterComposer,
    $$DevicesTableOrderingComposer,
    $$DevicesTableAnnotationComposer,
    $$DevicesTableCreateCompanionBuilder,
    $$DevicesTableUpdateCompanionBuilder,
    (Device, BaseReferences<_$AppDatabase, $DevicesTable, Device>),
    Device,
    PrefetchHooks Function()> {
  $$DevicesTableTableManager(_$AppDatabase db, $DevicesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$DevicesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$DevicesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$DevicesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> institutionId = const Value.absent(),
            Value<String> deviceName = const Value.absent(),
            Value<String> platform = const Value.absent(),
            Value<String> appVersion = const Value.absent(),
            Value<String?> registeredBy = const Value.absent(),
            Value<DateTime> registeredAt = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            Value<int?> rangeStart = const Value.absent(),
            Value<int?> rangeEnd = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              DevicesCompanion(
            id: id,
            institutionId: institutionId,
            deviceName: deviceName,
            platform: platform,
            appVersion: appVersion,
            registeredBy: registeredBy,
            registeredAt: registeredAt,
            isActive: isActive,
            rangeStart: rangeStart,
            rangeEnd: rangeEnd,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String institutionId,
            required String deviceName,
            required String platform,
            required String appVersion,
            Value<String?> registeredBy = const Value.absent(),
            required DateTime registeredAt,
            Value<bool> isActive = const Value.absent(),
            Value<int?> rangeStart = const Value.absent(),
            Value<int?> rangeEnd = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              DevicesCompanion.insert(
            id: id,
            institutionId: institutionId,
            deviceName: deviceName,
            platform: platform,
            appVersion: appVersion,
            registeredBy: registeredBy,
            registeredAt: registeredAt,
            isActive: isActive,
            rangeStart: rangeStart,
            rangeEnd: rangeEnd,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$DevicesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $DevicesTable,
    Device,
    $$DevicesTableFilterComposer,
    $$DevicesTableOrderingComposer,
    $$DevicesTableAnnotationComposer,
    $$DevicesTableCreateCompanionBuilder,
    $$DevicesTableUpdateCompanionBuilder,
    (Device, BaseReferences<_$AppDatabase, $DevicesTable, Device>),
    Device,
    PrefetchHooks Function()>;
typedef $$SyncOutboxTableCreateCompanionBuilder = SyncOutboxCompanion Function({
  required String id,
  required String institutionId,
  required String entityType,
  required String entityId,
  required OutboxOperation operation,
  required String payloadJson,
  required String idempotencyKey,
  Value<int> attempts,
  required DateTime nextRetryAt,
  required SyncStatus status,
  Value<String?> lastError,
  required DateTime createdAt,
  Value<int> rowid,
});
typedef $$SyncOutboxTableUpdateCompanionBuilder = SyncOutboxCompanion Function({
  Value<String> id,
  Value<String> institutionId,
  Value<String> entityType,
  Value<String> entityId,
  Value<OutboxOperation> operation,
  Value<String> payloadJson,
  Value<String> idempotencyKey,
  Value<int> attempts,
  Value<DateTime> nextRetryAt,
  Value<SyncStatus> status,
  Value<String?> lastError,
  Value<DateTime> createdAt,
  Value<int> rowid,
});

class $$SyncOutboxTableFilterComposer
    extends Composer<_$AppDatabase, $SyncOutboxTable> {
  $$SyncOutboxTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entityId => $composableBuilder(
      column: $table.entityId, builder: (column) => ColumnFilters(column));

  ColumnWithTypeConverterFilters<OutboxOperation, OutboxOperation, String>
      get operation => $composableBuilder(
          column: $table.operation,
          builder: (column) => ColumnWithTypeConverterFilters(column));

  ColumnFilters<String> get payloadJson => $composableBuilder(
      column: $table.payloadJson, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get idempotencyKey => $composableBuilder(
      column: $table.idempotencyKey,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get attempts => $composableBuilder(
      column: $table.attempts, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get nextRetryAt => $composableBuilder(
      column: $table.nextRetryAt, builder: (column) => ColumnFilters(column));

  ColumnWithTypeConverterFilters<SyncStatus, SyncStatus, String> get status =>
      $composableBuilder(
          column: $table.status,
          builder: (column) => ColumnWithTypeConverterFilters(column));

  ColumnFilters<String> get lastError => $composableBuilder(
      column: $table.lastError, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));
}

class $$SyncOutboxTableOrderingComposer
    extends Composer<_$AppDatabase, $SyncOutboxTable> {
  $$SyncOutboxTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get institutionId => $composableBuilder(
      column: $table.institutionId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entityId => $composableBuilder(
      column: $table.entityId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get operation => $composableBuilder(
      column: $table.operation, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get payloadJson => $composableBuilder(
      column: $table.payloadJson, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get idempotencyKey => $composableBuilder(
      column: $table.idempotencyKey,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get attempts => $composableBuilder(
      column: $table.attempts, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get nextRetryAt => $composableBuilder(
      column: $table.nextRetryAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get lastError => $composableBuilder(
      column: $table.lastError, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));
}

class $$SyncOutboxTableAnnotationComposer
    extends Composer<_$AppDatabase, $SyncOutboxTable> {
  $$SyncOutboxTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => column);

  GeneratedColumn<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => column);

  GeneratedColumn<String> get entityId =>
      $composableBuilder(column: $table.entityId, builder: (column) => column);

  GeneratedColumnWithTypeConverter<OutboxOperation, String> get operation =>
      $composableBuilder(column: $table.operation, builder: (column) => column);

  GeneratedColumn<String> get payloadJson => $composableBuilder(
      column: $table.payloadJson, builder: (column) => column);

  GeneratedColumn<String> get idempotencyKey => $composableBuilder(
      column: $table.idempotencyKey, builder: (column) => column);

  GeneratedColumn<int> get attempts =>
      $composableBuilder(column: $table.attempts, builder: (column) => column);

  GeneratedColumn<DateTime> get nextRetryAt => $composableBuilder(
      column: $table.nextRetryAt, builder: (column) => column);

  GeneratedColumnWithTypeConverter<SyncStatus, String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<String> get lastError =>
      $composableBuilder(column: $table.lastError, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);
}

class $$SyncOutboxTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SyncOutboxTable,
    SyncOutboxData,
    $$SyncOutboxTableFilterComposer,
    $$SyncOutboxTableOrderingComposer,
    $$SyncOutboxTableAnnotationComposer,
    $$SyncOutboxTableCreateCompanionBuilder,
    $$SyncOutboxTableUpdateCompanionBuilder,
    (
      SyncOutboxData,
      BaseReferences<_$AppDatabase, $SyncOutboxTable, SyncOutboxData>
    ),
    SyncOutboxData,
    PrefetchHooks Function()> {
  $$SyncOutboxTableTableManager(_$AppDatabase db, $SyncOutboxTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SyncOutboxTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SyncOutboxTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SyncOutboxTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> institutionId = const Value.absent(),
            Value<String> entityType = const Value.absent(),
            Value<String> entityId = const Value.absent(),
            Value<OutboxOperation> operation = const Value.absent(),
            Value<String> payloadJson = const Value.absent(),
            Value<String> idempotencyKey = const Value.absent(),
            Value<int> attempts = const Value.absent(),
            Value<DateTime> nextRetryAt = const Value.absent(),
            Value<SyncStatus> status = const Value.absent(),
            Value<String?> lastError = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SyncOutboxCompanion(
            id: id,
            institutionId: institutionId,
            entityType: entityType,
            entityId: entityId,
            operation: operation,
            payloadJson: payloadJson,
            idempotencyKey: idempotencyKey,
            attempts: attempts,
            nextRetryAt: nextRetryAt,
            status: status,
            lastError: lastError,
            createdAt: createdAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String institutionId,
            required String entityType,
            required String entityId,
            required OutboxOperation operation,
            required String payloadJson,
            required String idempotencyKey,
            Value<int> attempts = const Value.absent(),
            required DateTime nextRetryAt,
            required SyncStatus status,
            Value<String?> lastError = const Value.absent(),
            required DateTime createdAt,
            Value<int> rowid = const Value.absent(),
          }) =>
              SyncOutboxCompanion.insert(
            id: id,
            institutionId: institutionId,
            entityType: entityType,
            entityId: entityId,
            operation: operation,
            payloadJson: payloadJson,
            idempotencyKey: idempotencyKey,
            attempts: attempts,
            nextRetryAt: nextRetryAt,
            status: status,
            lastError: lastError,
            createdAt: createdAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SyncOutboxTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SyncOutboxTable,
    SyncOutboxData,
    $$SyncOutboxTableFilterComposer,
    $$SyncOutboxTableOrderingComposer,
    $$SyncOutboxTableAnnotationComposer,
    $$SyncOutboxTableCreateCompanionBuilder,
    $$SyncOutboxTableUpdateCompanionBuilder,
    (
      SyncOutboxData,
      BaseReferences<_$AppDatabase, $SyncOutboxTable, SyncOutboxData>
    ),
    SyncOutboxData,
    PrefetchHooks Function()>;
typedef $$SyncConflictsTableCreateCompanionBuilder = SyncConflictsCompanion
    Function({
  required String id,
  required String institutionId,
  required String entityType,
  required String entityId,
  required String localJson,
  required String remoteJson,
  required DateTime detectedAt,
  Value<String> status,
  Value<String?> resolvedBy,
  Value<DateTime?> resolvedAt,
  Value<String?> resolutionNote,
  Value<int> rowid,
});
typedef $$SyncConflictsTableUpdateCompanionBuilder = SyncConflictsCompanion
    Function({
  Value<String> id,
  Value<String> institutionId,
  Value<String> entityType,
  Value<String> entityId,
  Value<String> localJson,
  Value<String> remoteJson,
  Value<DateTime> detectedAt,
  Value<String> status,
  Value<String?> resolvedBy,
  Value<DateTime?> resolvedAt,
  Value<String?> resolutionNote,
  Value<int> rowid,
});

class $$SyncConflictsTableFilterComposer
    extends Composer<_$AppDatabase, $SyncConflictsTable> {
  $$SyncConflictsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entityId => $composableBuilder(
      column: $table.entityId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get localJson => $composableBuilder(
      column: $table.localJson, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get remoteJson => $composableBuilder(
      column: $table.remoteJson, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get detectedAt => $composableBuilder(
      column: $table.detectedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get resolvedBy => $composableBuilder(
      column: $table.resolvedBy, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get resolvedAt => $composableBuilder(
      column: $table.resolvedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get resolutionNote => $composableBuilder(
      column: $table.resolutionNote,
      builder: (column) => ColumnFilters(column));
}

class $$SyncConflictsTableOrderingComposer
    extends Composer<_$AppDatabase, $SyncConflictsTable> {
  $$SyncConflictsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get institutionId => $composableBuilder(
      column: $table.institutionId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entityId => $composableBuilder(
      column: $table.entityId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get localJson => $composableBuilder(
      column: $table.localJson, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get remoteJson => $composableBuilder(
      column: $table.remoteJson, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get detectedAt => $composableBuilder(
      column: $table.detectedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get resolvedBy => $composableBuilder(
      column: $table.resolvedBy, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get resolvedAt => $composableBuilder(
      column: $table.resolvedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get resolutionNote => $composableBuilder(
      column: $table.resolutionNote,
      builder: (column) => ColumnOrderings(column));
}

class $$SyncConflictsTableAnnotationComposer
    extends Composer<_$AppDatabase, $SyncConflictsTable> {
  $$SyncConflictsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get institutionId => $composableBuilder(
      column: $table.institutionId, builder: (column) => column);

  GeneratedColumn<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => column);

  GeneratedColumn<String> get entityId =>
      $composableBuilder(column: $table.entityId, builder: (column) => column);

  GeneratedColumn<String> get localJson =>
      $composableBuilder(column: $table.localJson, builder: (column) => column);

  GeneratedColumn<String> get remoteJson => $composableBuilder(
      column: $table.remoteJson, builder: (column) => column);

  GeneratedColumn<DateTime> get detectedAt => $composableBuilder(
      column: $table.detectedAt, builder: (column) => column);

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<String> get resolvedBy => $composableBuilder(
      column: $table.resolvedBy, builder: (column) => column);

  GeneratedColumn<DateTime> get resolvedAt => $composableBuilder(
      column: $table.resolvedAt, builder: (column) => column);

  GeneratedColumn<String> get resolutionNote => $composableBuilder(
      column: $table.resolutionNote, builder: (column) => column);
}

class $$SyncConflictsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SyncConflictsTable,
    SyncConflict,
    $$SyncConflictsTableFilterComposer,
    $$SyncConflictsTableOrderingComposer,
    $$SyncConflictsTableAnnotationComposer,
    $$SyncConflictsTableCreateCompanionBuilder,
    $$SyncConflictsTableUpdateCompanionBuilder,
    (
      SyncConflict,
      BaseReferences<_$AppDatabase, $SyncConflictsTable, SyncConflict>
    ),
    SyncConflict,
    PrefetchHooks Function()> {
  $$SyncConflictsTableTableManager(_$AppDatabase db, $SyncConflictsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SyncConflictsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SyncConflictsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SyncConflictsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> institutionId = const Value.absent(),
            Value<String> entityType = const Value.absent(),
            Value<String> entityId = const Value.absent(),
            Value<String> localJson = const Value.absent(),
            Value<String> remoteJson = const Value.absent(),
            Value<DateTime> detectedAt = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<String?> resolvedBy = const Value.absent(),
            Value<DateTime?> resolvedAt = const Value.absent(),
            Value<String?> resolutionNote = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SyncConflictsCompanion(
            id: id,
            institutionId: institutionId,
            entityType: entityType,
            entityId: entityId,
            localJson: localJson,
            remoteJson: remoteJson,
            detectedAt: detectedAt,
            status: status,
            resolvedBy: resolvedBy,
            resolvedAt: resolvedAt,
            resolutionNote: resolutionNote,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String institutionId,
            required String entityType,
            required String entityId,
            required String localJson,
            required String remoteJson,
            required DateTime detectedAt,
            Value<String> status = const Value.absent(),
            Value<String?> resolvedBy = const Value.absent(),
            Value<DateTime?> resolvedAt = const Value.absent(),
            Value<String?> resolutionNote = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SyncConflictsCompanion.insert(
            id: id,
            institutionId: institutionId,
            entityType: entityType,
            entityId: entityId,
            localJson: localJson,
            remoteJson: remoteJson,
            detectedAt: detectedAt,
            status: status,
            resolvedBy: resolvedBy,
            resolvedAt: resolvedAt,
            resolutionNote: resolutionNote,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SyncConflictsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SyncConflictsTable,
    SyncConflict,
    $$SyncConflictsTableFilterComposer,
    $$SyncConflictsTableOrderingComposer,
    $$SyncConflictsTableAnnotationComposer,
    $$SyncConflictsTableCreateCompanionBuilder,
    $$SyncConflictsTableUpdateCompanionBuilder,
    (
      SyncConflict,
      BaseReferences<_$AppDatabase, $SyncConflictsTable, SyncConflict>
    ),
    SyncConflict,
    PrefetchHooks Function()>;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$InstitutionsTableTableManager get institutions =>
      $$InstitutionsTableTableManager(_db, _db.institutions);
  $$UserProfilesTableTableManager get userProfiles =>
      $$UserProfilesTableTableManager(_db, _db.userProfiles);
  $$DonorsTableTableManager get donors =>
      $$DonorsTableTableManager(_db, _db.donors);
  $$FundTypesTableTableManager get fundTypes =>
      $$FundTypesTableTableManager(_db, _db.fundTypes);
  $$PurposesTableTableManager get purposes =>
      $$PurposesTableTableManager(_db, _db.purposes);
  $$BankAccountsTableTableManager get bankAccounts =>
      $$BankAccountsTableTableManager(_db, _db.bankAccounts);
  $$ReceiptsTableTableManager get receipts =>
      $$ReceiptsTableTableManager(_db, _db.receipts);
  $$ReceiptAllocationsTableTableManager get receiptAllocations =>
      $$ReceiptAllocationsTableTableManager(_db, _db.receiptAllocations);
  $$PaymentVerificationsTableTableManager get paymentVerifications =>
      $$PaymentVerificationsTableTableManager(_db, _db.paymentVerifications);
  $$ReceiptSequencesTableTableManager get receiptSequences =>
      $$ReceiptSequencesTableTableManager(_db, _db.receiptSequences);
  $$ExpenseVouchersTableTableManager get expenseVouchers =>
      $$ExpenseVouchersTableTableManager(_db, _db.expenseVouchers);
  $$ExpenseAllocationsTableTableManager get expenseAllocations =>
      $$ExpenseAllocationsTableTableManager(_db, _db.expenseAllocations);
  $$ApprovalsTableTableManager get approvals =>
      $$ApprovalsTableTableManager(_db, _db.approvals);
  $$ReconciliationsTableTableManager get reconciliations =>
      $$ReconciliationsTableTableManager(_db, _db.reconciliations);
  $$EvidenceFilesTableTableManager get evidenceFiles =>
      $$EvidenceFilesTableTableManager(_db, _db.evidenceFiles);
  $$AuditEventsTableTableManager get auditEvents =>
      $$AuditEventsTableTableManager(_db, _db.auditEvents);
  $$DevicesTableTableManager get devices =>
      $$DevicesTableTableManager(_db, _db.devices);
  $$SyncOutboxTableTableManager get syncOutbox =>
      $$SyncOutboxTableTableManager(_db, _db.syncOutbox);
  $$SyncConflictsTableTableManager get syncConflicts =>
      $$SyncConflictsTableTableManager(_db, _db.syncConflicts);
}
