import 'package:drift/drift.dart';
import 'package:drift_flutter/drift_flutter.dart';
import '../../domain/entities/enums.dart';
import 'schema.dart';

part 'app_database.g.dart';

/// Local SQLite database. Schema version history:
/// - v1: initial schema (19 tables) — 2026-10-13
/// Future versions MUST add explicit `onUpgrade` steps below; never
/// recreate tables destructively (financial data must survive upgrades).
@DriftDatabase(
  tables: [
    Institutions,
    UserProfiles,
    Donors,
    FundTypes,
    Purposes,
    BankAccounts,
    Receipts,
    ReceiptAllocations,
    PaymentVerifications,
    ReceiptSequences,
    ExpenseVouchers,
    ExpenseAllocations,
    Approvals,
    Reconciliations,
    EvidenceFiles,
    AuditEvents,
    Devices,
    SyncOutbox,
    SyncConflicts,
  ],
)
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_openConnection());

  /// For tests: pass `NativeDatabase.memory()` (or a file executor).
  AppDatabase.forTesting(super.executor);

  @override
  int get schemaVersion => 2;

  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (m) async {
          await m.createAll();
        },
        onUpgrade: (m, from, to) async {
          // v2: offline PIN login — add pinHash to user_profiles.
          if (from < 2) {
            await m.addColumn(userProfiles, userProfiles.pinHash);
          }
        },
        beforeOpen: (details) async {
          // Financial integrity: enforce foreign keys on every connection.
          await customStatement('PRAGMA foreign_keys = ON');
        },
      );
}

LazyDatabase _openConnection() {
  return LazyDatabase(() async {
    return driftDatabase(name: 'madrasa_receipt_pro');
  });
}
