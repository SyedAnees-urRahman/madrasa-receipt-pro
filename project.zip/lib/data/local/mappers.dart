import 'package:drift/drift.dart';
import '../local/app_database.dart' as db;
import '../../domain/entities/entities.dart';
import '../../domain/entities/enums.dart';
import '../../domain/repositories/repositories.dart';

/// Drift row <-> domain entity conversions. Single place for the mapping
/// so repositories stay thin.
abstract final class Mappers {
  static Institution institution(db.Institution row) => Institution(
        id: row.id,
        nameUr: row.nameUr,
        nameEn: row.nameEn,
        logoPath: row.logoPath,
        address: row.address,
        phone: row.phone,
        email: row.email,
        registrationNo: row.registrationNo,
        ntn: row.ntn,
        fyStartMonth: row.fyStartMonth,
        fyStartDay: row.fyStartDay,
        receiptPrefix: row.receiptPrefix,
        numberingFormat: row.numberingFormat,
        receiptLanguage: row.receiptLanguage,
        printFormat: row.printFormat,
        acceptedMethods: _decodeMethods(row.acceptedMethodsJson),
        dualApprovalThresholdPaisa: row.dualApprovalThresholdPaisa,
        autoSync: row.autoSync,
        isDemo: row.isDemo,
        signatoriesJson: row.signatoriesJson,
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
      );

  static List<PaymentMethod> _decodeMethods(String json) {
    final out = <PaymentMethod>[];
    for (final part in json.replaceAll(RegExp(r'[\[\]"\s]'), '').split(',')) {
      for (final m in PaymentMethod.values) {
        if (m.name == part) out.add(m);
      }
    }
    return out.isEmpty ? [PaymentMethod.cash] : out;
  }

  static String encodeMethods(List<PaymentMethod> methods) =>
      '[${methods.map((m) => '"${m.name}"').join(',')}]';

  static UserProfile userProfile(db.UserProfile row) => UserProfile(
        id: row.id,
        institutionId: row.institutionId,
        displayName: row.displayName,
        email: row.email,
        role: row.role,
        isActive: row.isActive,
        createdAt: row.createdAt,
      );

  static Donor donor(db.Donor row) => Donor(
        id: row.id,
        institutionId: row.institutionId,
        name: row.name,
        phone: row.phone,
        email: row.email,
        address: row.address,
        notes: row.notes,
        createdBy: row.createdBy ?? '',
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
      );

  static FundType fund(db.FundType row) => FundType(
        id: row.id,
        institutionId: row.institutionId,
        code: row.code,
        nameUr: row.nameUr,
        nameEn: row.nameEn,
        category: row.category,
        isRestricted: row.isRestricted,
        isActive: row.isActive,
        openingBalancePaisa: row.openingBalancePaisa,
        sortOrder: row.sortOrder,
      );

  static Purpose purpose(db.Purpose row) => Purpose(
        id: row.id,
        institutionId: row.institutionId,
        nameUr: row.nameUr,
        nameEn: row.nameEn,
        description: row.description,
        isActive: row.isActive,
      );

  static BankAccount account(db.BankAccount row) => BankAccount(
        id: row.id,
        institutionId: row.institutionId,
        type: row.type,
        title: row.title,
        bankName: row.bankName,
        accountNoMasked: row.accountNoMasked,
        openingBalancePaisa: row.openingBalancePaisa,
        isActive: row.isActive,
      );

  static ReceiptAllocation receiptAllocation(db.ReceiptAllocation row) =>
      ReceiptAllocation(
        id: row.id,
        receiptId: row.receiptId,
        fundTypeId: row.fundTypeId,
        purposeId: row.purposeId,
        amountPaisa: row.amountPaisa,
      );

  static Receipt receipt(db.Receipt row, List<db.ReceiptAllocation> allocs) =>
      Receipt(
        id: row.id,
        institutionId: row.institutionId,
        officialNumber: row.officialNumber,
        localProvisionalLabel: row.localProvisionalLabel,
        status: row.status,
        txType: row.txType,
        donorId: row.donorId,
        donorNameSnapshot: row.donorNameSnapshot,
        isAnonymous: row.isAnonymous,
        totalPaisa: row.totalPaisa,
        receiptDate: row.receiptDate,
        paymentMethod: row.paymentMethod,
        bankAccountId: row.bankAccountId,
        referenceNo: row.referenceNo,
        evidencePath: row.evidencePath,
        staffNotes: row.staffNotes,
        donorNote: row.donorNote,
        createdBy: row.createdBy,
        verifiedBy: row.verifiedBy,
        verifiedAt: row.verifiedAt,
        voidReason: row.voidReason,
        replacedById: row.replacedById,
        reversesId: row.reversesId,
        idempotencyKey: row.idempotencyKey,
        serverAck: row.serverAck,
        allocations: allocs.map(receiptAllocation).toList(),
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
      );

  static PaymentVerification verification(db.PaymentVerification row) =>
      PaymentVerification(
        id: row.id,
        receiptId: row.receiptId,
        verifiedBy: row.verifiedBy,
        verifiedAt: row.verifiedAt,
        evidenceSummary: row.evidenceSummary,
        note: row.note,
      );

  static ExpenseAllocation expenseAllocation(db.ExpenseAllocation row) =>
      ExpenseAllocation(
        id: row.id,
        voucherId: row.voucherId,
        fundTypeId: row.fundTypeId,
        purposeId: row.purposeId,
        amountPaisa: row.amountPaisa,
      );

  static ExpenseVoucher expense(
          db.ExpenseVoucher row, List<db.ExpenseAllocation> allocs) =>
      ExpenseVoucher(
        id: row.id,
        institutionId: row.institutionId,
        voucherNumber: row.voucherNumber,
        voucherDate: row.voucherDate,
        payee: row.payee,
        description: row.description,
        totalPaisa: row.totalPaisa,
        paymentMethod: row.paymentMethod,
        bankAccountId: row.bankAccountId,
        attachmentPath: row.attachmentPath,
        status: row.status,
        createdBy: row.createdBy,
        approvedBy: row.approvedBy,
        approvedAt: row.approvedAt,
        rejectionReason: row.rejectionReason,
        idempotencyKey: row.idempotencyKey,
        allocations: allocs.map(expenseAllocation).toList(),
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
      );

  static AuditEvent auditEvent(db.AuditEvent row) => AuditEvent(
        id: row.id,
        institutionId: row.institutionId,
        sequence: row.sequence,
        entityType: row.entityType,
        entityId: row.entityId,
        action: row.action,
        actorId: row.actorId,
        occurredAt: row.occurredAt,
        reason: row.reason,
        beforeJson: row.beforeJson,
        afterJson: row.afterJson,
        prevHash: row.prevHash,
        hash: row.hash,
      );

  static SyncConflict syncConflict(db.SyncConflict row) => SyncConflict(
        id: row.id,
        entityType: row.entityType,
        entityId: row.entityId,
        localJson: row.localJson,
        remoteJson: row.remoteJson,
        detectedAt: row.detectedAt,
        status: row.status,
        resolvedBy: row.resolvedBy,
        resolvedAt: row.resolvedAt,
        resolutionNote: row.resolutionNote,
      );

  // ---------- companions from drafts ----------

  static db.ReceiptsCompanion receiptInsert({
    required String id,
    required String institutionId,
    required ReceiptDraft draft,
    required String donorNameSnapshot,
    required String idempotencyKey,
    required String localProvisionalLabel,
    required String? createdBy,
    required DateTime now,
  }) {
    return db.ReceiptsCompanion.insert(
      id: id,
      institutionId: institutionId,
      status: ReceiptStatus.draft,
      txType: draft.txType,
      donorId: Value(draft.donorId),
      donorNameSnapshot: donorNameSnapshot,
      isAnonymous: Value(draft.isAnonymous),
      totalPaisa: draft.totalPaisa,
      receiptDate: draft.receiptDate,
      paymentMethod: draft.paymentMethod,
      bankAccountId: Value(draft.bankAccountId),
      referenceNo: Value(draft.referenceNo),
      evidencePath: Value(draft.evidencePath),
      staffNotes: Value(draft.staffNotes),
      donorNote: Value(draft.donorNote),
      createdBy: Value(createdBy),
      idempotencyKey: idempotencyKey,
      localProvisionalLabel: Value(localProvisionalLabel),
      createdAt: now,
      updatedAt: now,
    );
  }

  static db.ReceiptAllocationsCompanion allocationInsert({
    required String id,
    required String receiptId,
    required AllocationDraft draft,
  }) =>
      db.ReceiptAllocationsCompanion.insert(
        id: id,
        receiptId: receiptId,
        fundTypeId: draft.fundTypeId,
        purposeId: Value(draft.purposeId),
        amountPaisa: draft.amountPaisa,
      );
}
