/// Abstract remote gateway. The sync engine talks ONLY to this interface,
/// so it is fully testable with a fake. The real implementation
/// ([SupabaseGateway]) lives in supabase_gateway.dart.
abstract class RemoteGateway {
  /// True when a request is likely to reach the server. Never used as
  /// proof that a request succeeded — only server ACKs prove that.
  Future<bool> get isOnline;

  /// Current server time (for watermarking). Falls back to local on error.
  Future<DateTime> serverTime();

  // ---------- push (all idempotent: server dedupes on idempotency_key) ---
  Future<PushResult> pushReceipt(Map<String, dynamic> payload);
  Future<PushResult> pushReceiptAllocations(
      String receiptId, List<Map<String, dynamic>> allocations);
  Future<PushResult> pushExpense(Map<String, dynamic> payload);
  Future<PushResult> pushDonor(Map<String, dynamic> payload);
  Future<PushResult> pushAuditEvent(Map<String, dynamic> payload);

  /// Atomically reserves the next official receipt number on the server
  /// (locked sequence). Returns the formatted number, e.g. MD-2026-000001.
  Future<String> issueOfficialNumber({
    required String institutionId,
    required String receiptId,
    required String idempotencyKey,
  });

  // ---------------- pull ------------------------------------------------
  /// Rows changed on the server since [since] for one table.
  Future<List<Map<String, dynamic>>> pullTable({
    required String table,
    required String institutionId,
    required DateTime since,
    int limit = 500,
  });

  Future<Map<String, DateTime>> pullWatermarks(String institutionId);
}

class PushResult {
  const PushResult({
    required this.acknowledged,
    this.serverUpdatedAt,
    this.extra = const {},
  });
  final bool acknowledged;
  final DateTime? serverUpdatedAt;
  final Map<String, dynamic> extra;
}

/// Thrown when the gateway cannot complete a request.
class GatewayException implements Exception {
  const GatewayException(this.message, {this.retryable = true});
  final String message;
  final bool retryable;
}
