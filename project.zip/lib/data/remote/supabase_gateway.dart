import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'remote_gateway.dart';

/// Real Supabase implementation of [RemoteGateway].
///
/// Security rules honored here:
/// - Only the anon key is bundled (via --dart-define). The service-role
///   key NEVER ships in the app.
/// - Official receipt numbers are issued by the `issue-receipt-number`
///   edge function (SECURITY DEFINER, locked sequence). Clients cannot
///   write `official_number` directly (RLS + trigger).
/// - Evidence uploads go to a PRIVATE storage bucket with short-lived
///   signed URLs.
class SupabaseGateway implements RemoteGateway {
  SupabaseGateway(this._client);
  final SupabaseClient _client;

  @override
  Future<bool> get isOnline async {
    final net = await Connectivity().checkConnectivity();
    if (net.contains(ConnectivityResult.none)) return false;
    try {
      await _client.rpc('ping').timeout(const Duration(seconds: 6));
      return true;
    } catch (_) {
      return false;
    }
  }

  @override
  Future<DateTime> serverTime() async {
    try {
      final res = await _client.rpc('server_time');
      return DateTime.parse(res as String);
    } catch (_) {
      return DateTime.now().toUtc();
    }
  }

  Never _wrap(Object e) {
    final msg = e.toString();
    // PostgrestException carries statusCode; 5xx/429/timeouts are retryable.
    final retryable = !(msg.contains('23505') /* unique violation */);
    throw GatewayException(msg, retryable: retryable);
  }

  @override
  Future<PushResult> pushReceipt(Map<String, dynamic> payload) async {
    try {
      final key = payload['idempotency_key'] as String;
      await _client.from('receipts').upsert(
        _stripNulls(payload),
        onConflict: 'idempotency_key',
      );
      final allocs = payload['allocations'] as List? ?? [];
      for (final a in allocs) {
        final m = Map<String, dynamic>.from(a as Map);
        m['receipt_id'] = payload['id'];
        await _client.from('receipt_allocations').upsert(
          _stripNulls(m),
          onConflict: 'id',
        );
      }
      // Ask the server whether it already issued a number for this receipt.
      final row = await _client
          .from('receipts')
          .select('official_number, updated_at')
          .eq('idempotency_key', key)
          .maybeSingle();
      return PushResult(
        acknowledged: true,
        serverUpdatedAt: row == null
            ? null
            : DateTime.tryParse(row['updated_at']?.toString() ?? ''),
        extra: {
          if (row?['official_number'] != null)
            'official_number': row!['official_number'],
        },
      );
    } catch (e) {
      _wrap(e);
    }
  }

  @override
  Future<PushResult> pushReceiptAllocations(
      String receiptId, List<Map<String, dynamic>> allocations) async {
    try {
      for (final a in allocations) {
        final m = Map<String, dynamic>.from(a);
        m['receipt_id'] = receiptId;
        await _client.from('receipt_allocations').upsert(
              _stripNulls(m),
              onConflict: 'id',
            );
      }
      return const PushResult(acknowledged: true);
    } catch (e) {
      _wrap(e);
    }
  }

  @override
  Future<PushResult> pushExpense(Map<String, dynamic> payload) async {
    try {
      await _client.from('expense_vouchers').upsert(
        _stripNulls(payload)..remove('allocations'),
        onConflict: 'idempotency_key',
      );
      final allocs = payload['allocations'] as List? ?? [];
      for (final a in allocs) {
        final m = Map<String, dynamic>.from(a as Map);
        m['voucher_id'] = payload['id'];
        await _client.from('expense_allocations').upsert(
              _stripNulls(m),
              onConflict: 'id',
            );
      }
      return const PushResult(acknowledged: true);
    } catch (e) {
      _wrap(e);
    }
  }

  @override
  Future<PushResult> pushDonor(Map<String, dynamic> payload) async {
    try {
      await _client.from('donors').upsert(
            _stripNulls(payload),
            onConflict: 'id',
          );
      return const PushResult(acknowledged: true);
    } catch (e) {
      _wrap(e);
    }
  }

  @override
  Future<PushResult> pushAuditEvent(Map<String, dynamic> payload) async {
    try {
      // Audit events are INSERT-only server-side as well.
      await _client.from('audit_events').insert(_stripNulls(payload));
      return const PushResult(acknowledged: true);
    } catch (e) {
      // Duplicate hash → already recorded; treat as acknowledged.
      if (e.toString().contains('23505')) {
        return const PushResult(acknowledged: true);
      }
      _wrap(e);
    }
  }

  @override
  Future<String> issueOfficialNumber({
    required String institutionId,
    required String receiptId,
    required String idempotencyKey,
  }) async {
    try {
      final res = await _client.rpc('issue_receipt_number', params: {
        'p_institution_id': institutionId,
        'p_receipt_id': receiptId,
        'p_idempotency_key': idempotencyKey,
      });
      final number = (res as Map<String, dynamic>)['official_number'] as String;
      return number;
    } catch (e) {
      _wrap(e);
    }
  }

  @override
  Future<List<Map<String, dynamic>>> pullTable({
    required String table,
    required String institutionId,
    required DateTime since,
    int limit = 500,
  }) async {
    try {
      final rows = await _client
          .from(table)
          .select()
          .eq('institution_id', institutionId)
          .gt('updated_at', since.toUtc().toIso8601String())
          .order('updated_at', ascending: true)
          .limit(limit);
      return (rows as List).cast<Map<String, dynamic>>();
    } catch (e) {
      _wrap(e);
    }
  }

  @override
  Future<Map<String, DateTime>> pullWatermarks(String institutionId) async {
    // Watermarks are maintained locally; server time anchors them.
    final now = await serverTime();
    return {'server_time': now};
  }

  /// Uploads evidence to the PRIVATE bucket; returns the storage path.
  /// URLs are minted short-lived and signed — never public.
  Future<String> uploadEvidence({
    required String institutionId,
    required String entityId,
    required String localPath,
    required String mime,
  }) async {
    final ext = localPath.split('.').last;
    final remotePath =
        '$institutionId/$entityId/${DateTime.now().millisecondsSinceEpoch}.$ext';
    await _client.storage.from('receipt-evidence').uploadBinary(
          remotePath,
          await File(localPath).readAsBytes(),
          fileOptions: FileOptions(contentType: mime, upsert: false),
        );
    return remotePath;
  }

  Future<String> signedEvidenceUrl(String remotePath) async {
    return _client.storage
        .from('receipt-evidence')
        .createSignedUrl(remotePath, 60 * 15); // 15 minutes
  }

  Map<String, dynamic> _stripNulls(Map<String, dynamic> m) {
    final out = Map<String, dynamic>.from(m);
    out.removeWhere((k, v) => v == null);
    return out;
  }
}
