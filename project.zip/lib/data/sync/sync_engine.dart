import 'dart:convert';
import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';
import '../local/app_database.dart' as db;
import '../remote/remote_gateway.dart';
import 'conflict_policy.dart';
import 'audit_logger.dart';
import '../../core/config/app_config.dart';
import '../../domain/entities/enums.dart';
import '../../domain/repositories/repositories.dart' show AuditDraft;

const _uuid = Uuid();

/// Reliable synchronization:
/// - durable outbox, stable UUIDs, idempotency keys
/// - bounded exponential backoff, per-record status
/// - no local pending data deleted before server ACK + local commit
/// - deterministic conflict policy (never silent last-write-wins on
///   confirmed financial records)
class SyncEngine {
  SyncEngine({
    required db.AppDatabase database,
    required RemoteGateway gateway,
    required AuditLogger audit,
    required SyncStateStore state,
  })  : _db = database,
        _gateway = gateway,
        _audit = audit,
        _state = state;

  final db.AppDatabase _db;
  final RemoteGateway _gateway;
  final AuditLogger _audit;
  final SyncStateStore _state;

  Future<SyncResult> runOnce({
    required String institutionId,
    required String actorId,
  }) async {
    final result = SyncResult();
    if (!await _gateway.isOnline) {
      result.offline = true;
      return result;
    }
    final now = await _gateway.serverTime().catchError((_) => DateTime.now());

    await _pushPhase(institutionId, now, result);
    await _numberingPhase(institutionId, actorId, now, result);
    await _pullPhase(institutionId, now, result);

    await _state.setLastSync(institutionId, now);
    result.lastSync = now;
    return result;
  }

  // ---------------- push ----------------

  Future<void> _pushPhase(
      String institutionId, DateTime now, SyncResult result) async {
    final pending = await (_db.select(_db.syncOutbox)
          ..where((t) =>
              t.institutionId.equals(institutionId) &
              t.status.isInValues([SyncStatus.pending, SyncStatus.failed]) &
              t.nextRetryAt.isSmallerOrEqualValue(now))
          ..orderBy([(t) => OrderingTerm(expression: t.createdAt)])
          ..limit(50))
        .get();

    for (final entry in pending) {
      await (_db.update(_db.syncOutbox)..where((t) => t.id.equals(entry.id)))
          .write(const db.SyncOutboxCompanion(status: Value(SyncStatus.inFlight)));
      try {
        final ack = await _dispatch(entry);
        await _applyAck(institutionId, entry, ack, now);
        await (_db.delete(_db.syncOutbox)..where((t) => t.id.equals(entry.id)))
            .go();
        result.pushed++;
      } on GatewayException catch (e) {
        await _scheduleRetry(entry, now, e);
        result.errors.add('${entry.entityType}/${entry.entityId}: ${e.message}');
      } catch (e) {
        await _scheduleRetry(
            entry, now, GatewayException(e.toString(), retryable: true));
        result.errors.add('${entry.entityType}/${entry.entityId}: $e');
      }
    }
  }

  Future<PushResult> _dispatch(db.SyncOutboxData entry) async {
    switch (entry.entityType) {
      case 'receipts':
        return _gateway.pushReceipt(await _receiptPayload(entry.entityId));
      case 'donors':
        final row = await (_db.select(_db.donors)
              ..where((t) => t.id.equals(entry.entityId)))
            .getSingle();
        return _gateway.pushDonor({
          'id': row.id,
          'institution_id': row.institutionId,
          'name': row.name,
          'phone': row.phone,
          'email': row.email,
          'address': row.address,
          'updated_at': row.updatedAt.toUtc().toIso8601String(),
        });
      case 'expense_vouchers':
        final row = await (_db.select(_db.expenseVouchers)
              ..where((t) => t.id.equals(entry.entityId)))
            .getSingle();
        final allocs = await (_db.select(_db.expenseAllocations)
              ..where((t) => t.voucherId.equals(entry.entityId)))
            .get();
        return _gateway.pushExpense({
          'id': row.id,
          'institution_id': row.institutionId,
          'voucher_number': row.voucherNumber,
          'voucher_date': row.voucherDate.toUtc().toIso8601String(),
          'payee': row.payee,
          'description': row.description,
          'total_paisa': row.totalPaisa,
          'payment_method': row.paymentMethod.name,
          'bank_account_id': row.bankAccountId,
          'status': row.status.name,
          'approved_by': row.approvedBy,
          'idempotency_key': row.idempotencyKey,
          'updated_at': row.updatedAt.toUtc().toIso8601String(),
          'allocations': [
            for (final a in allocs)
              {
                'id': a.id,
                'fund_type_id': a.fundTypeId,
                'purpose_id': a.purposeId,
                'amount_paisa': a.amountPaisa,
              },
          ],
        });
      case 'audit_events':
        final row = await (_db.select(_db.auditEvents)
              ..where((t) => t.id.equals(entry.entityId)))
            .getSingle();
        return _gateway.pushAuditEvent({
          'id': row.id,
          'institution_id': row.institutionId,
          'sequence': row.sequence,
          'entity_type': row.entityType,
          'entity_id': row.entityId,
          'action': row.action,
          'actor_id': row.actorId,
          'occurred_at': row.occurredAt.toUtc().toIso8601String(),
          'reason': row.reason,
          'before': row.beforeJson,
          'after': row.afterJson,
          'prev_hash': row.prevHash,
          'hash': row.hash,
        });
      default:
        throw GatewayException(
            'Unknown entity type ${entry.entityType}', retryable: false);
    }
  }

  Future<Map<String, dynamic>> _receiptPayload(String receiptId) async {
    final row = await (_db.select(_db.receipts)
          ..where((t) => t.id.equals(receiptId)))
        .getSingle();
    final allocs = await (_db.select(_db.receiptAllocations)
          ..where((t) => t.receiptId.equals(receiptId)))
        .get();
    return {
      'id': row.id,
      'institution_id': row.institutionId,
      'official_number': row.officialNumber,
      'local_provisional_label': row.localProvisionalLabel,
      'status': row.status.name,
      'tx_type': row.txType.name,
      'donor_id': row.donorId,
      'donor_name_snapshot': row.donorNameSnapshot,
      'is_anonymous': row.isAnonymous,
      'total_paisa': row.totalPaisa,
      'receipt_date': row.receiptDate.toUtc().toIso8601String(),
      'payment_method': row.paymentMethod.name,
      'bank_account_id': row.bankAccountId,
      'reference_no': row.referenceNo,
      'staff_notes': row.staffNotes,
      'donor_note': row.donorNote,
      'created_by': row.createdBy,
      'verified_by': row.verifiedBy,
      'verified_at': row.verifiedAt?.toUtc().toIso8601String(),
      'void_reason': row.voidReason,
      'reverses_id': row.reversesId,
      'idempotency_key': row.idempotencyKey,
      'updated_at': row.updatedAt.toUtc().toIso8601String(),
      'allocations': [
        for (final a in allocs)
          {
            'id': a.id,
            'fund_type_id': a.fundTypeId,
            'purpose_id': a.purposeId,
            'amount_paisa': a.amountPaisa,
          },
      ],
    };
  }

  Future<void> _applyAck(String institutionId, db.SyncOutboxData entry,
      PushResult ack, DateTime now) async {
    if (!ack.acknowledged) {
      throw const GatewayException('Server did not acknowledge', retryable: true);
    }
    final serverAt = ack.serverUpdatedAt ?? now;
    await _db.transaction(() async {
      switch (entry.entityType) {
        case 'receipts':
          await (_db.update(_db.receipts)
                ..where((t) => t.id.equals(entry.entityId)))
              .write(db.ReceiptsCompanion(
            serverAck: const Value(true),
            isDirty: const Value(false),
            serverUpdatedAt: Value(serverAt),
            officialNumber: ack.extra['official_number'] == null
                ? const Value.absent()
                : Value(ack.extra['official_number'] as String),
          ));
          if (ack.extra['official_number'] != null) {
            await _audit.log(
              institutionId: institutionId,
              draft: AuditDraft(
                entityType: 'receipt',
                entityId: entry.entityId,
                action: 'receipt.official_number_assigned',
                actorId: 'server',
                afterJson: jsonEncode(
                    {'official_number': ack.extra['official_number']}),
              ),
              now: now,
            );
          }
        case 'expense_vouchers':
          await (_db.update(_db.expenseVouchers)
                ..where((t) => t.id.equals(entry.entityId)))
              .write(db.ExpenseVouchersCompanion(
            serverUpdatedAt: Value(serverAt),
            isDirty: const Value(false),
          ));
        case 'donors':
          await (_db.update(_db.donors)
                ..where((t) => t.id.equals(entry.entityId)))
              .write(db.DonorsCompanion(
            serverUpdatedAt: Value(serverAt),
            isDirty: const Value(false),
          ));
      }
    });
  }

  Future<void> _scheduleRetry(
      db.SyncOutboxData entry, DateTime now, GatewayException e) async {
    final attempts = entry.attempts + 1;
    final backoff = AppConfig.syncBackoff;
    if (!e.retryable || attempts >= AppConfig.maxSyncAttempts) {
      await (_db.update(_db.syncOutbox)..where((t) => t.id.equals(entry.id)))
          .write(db.SyncOutboxCompanion(
        status: const Value(SyncStatus.failed),
        attempts: Value(attempts),
        lastError: Value(e.message),
      ));
      return;
    }
    final delay = backoff[attempts.clamp(1, backoff.length) - 1];
    await (_db.update(_db.syncOutbox)..where((t) => t.id.equals(entry.id)))
        .write(db.SyncOutboxCompanion(
      status: const Value(SyncStatus.pending),
      attempts: Value(attempts),
      nextRetryAt: Value(now.add(delay)),
      lastError: Value(e.message),
    ));
  }

  // ---------------- official numbering ----------------

  Future<void> _numberingPhase(String institutionId, String actorId,
      DateTime now, SyncResult result) async {
    final awaiting = await (_db.select(_db.receipts)
          ..where((t) =>
              t.institutionId.equals(institutionId) &
              t.status.equalsValue(ReceiptStatus.confirmed) &
              t.officialNumber.isNull() &
              t.serverAck.equals(true)))
        .get();
    for (final row in awaiting) {
      try {
        final number = await _gateway.issueOfficialNumber(
          institutionId: institutionId,
          receiptId: row.id,
          idempotencyKey: '${row.idempotencyKey}:number',
        );
        await _db.transaction(() async {
          await (_db.update(_db.receipts)..where((t) => t.id.equals(row.id)))
              .write(db.ReceiptsCompanion(
            officialNumber: Value(number),
            serverUpdatedAt: Value(now),
          ));
          await _audit.log(
            institutionId: institutionId,
            draft: AuditDraft(
              entityType: 'receipt',
              entityId: row.id,
              action: 'receipt.official_number_assigned',
              actorId: 'server',
              afterJson: jsonEncode({'official_number': number}),
            ),
            now: now,
          );
        });
        result.numbered++;
      } on GatewayException catch (e) {
        result.errors.add('numbering/${row.id}: ${e.message}');
      }
    }
  }

  // ---------------- pull ----------------

  static const _pullTables = [
    'institutions',
    'user_profiles',
    'donors',
    'fund_types',
    'purposes',
    'bank_accounts',
    'receipts',
    'expense_vouchers',
  ];

  Future<void> _pullPhase(
      String institutionId, DateTime now, SyncResult result) async {
    for (final table in _pullTables) {
      try {
        final since = await _state.watermark(institutionId, table);
        final rows = await _gateway.pullTable(
          table: table,
          institutionId: institutionId,
          since: since,
        );
        var maxAt = since;
        for (final remote in rows) {
          await _applyRemote(table, institutionId, remote, result);
          final updated = DateTime.tryParse(remote['updated_at']?.toString() ?? '');
          if (updated != null && updated.isAfter(maxAt)) maxAt = updated;
        }
        await _state.setWatermark(institutionId, table, maxAt);
        result.pulled += rows.length;
      } on GatewayException catch (e) {
        result.errors.add('pull/$table: ${e.message}');
      }
    }
  }

  Future<void> _applyRemote(String table, String institutionId,
      Map<String, dynamic> remote, SyncResult result) async {
    final id = remote['id'] as String;
    switch (table) {
      case 'receipts':
        await _applyRemoteReceipt(institutionId, id, remote, result);
      case 'donors':
        await _upsertSimple(
          table: table,
          institutionId: institutionId,
          id: id,
          remote: remote,
          result: result,
          find: () => (_db.select(_db.donors)..where((t) => t.id.equals(id)))
              .getSingleOrNull(),
          isDirty: (r) => (r as db.Donor).isDirty,
          isLocked: (_) => false,
          toMap: (r) => _donorMap(r as db.Donor),
          apply: (dirty) => _db.into(_db.donors).insertOnConflictUpdate(
                db.DonorsCompanion.insert(
                  id: id,
                  institutionId: institutionId,
                  name: remote['name'] as String,
                  phone: Value(remote['phone'] as String?),
                  email: Value(remote['email'] as String?),
                  address: Value(remote['address'] as String?),
                  createdAt: DateTime.parse(remote['created_at'] as String),
                  updatedAt: DateTime.parse(remote['updated_at'] as String),
                  serverUpdatedAt:
                      Value(DateTime.parse(remote['updated_at'] as String)),
                  isDirty: Value(dirty),
                ),
              ),
        );
      case 'fund_types':
        await _upsertSimple(
          table: table,
          institutionId: institutionId,
          id: id,
          remote: remote,
          result: result,
          find: () => (_db.select(_db.fundTypes)..where((t) => t.id.equals(id)))
              .getSingleOrNull(),
          isDirty: (r) => (r as db.FundType).isDirty,
          isLocked: (_) => false,
          toMap: (r) => _fundMap(r as db.FundType),
          apply: (dirty) => _db.into(_db.fundTypes).insertOnConflictUpdate(
                db.FundTypesCompanion.insert(
                  id: id,
                  institutionId: institutionId,
                  code: remote['code'] as String,
                  nameUr: remote['name_ur'] as String,
                  nameEn: remote['name_en'] as String,
                  category: FundCategory.values.byName(remote['category'] as String),
                  isRestricted: Value(remote['is_restricted'] as bool? ?? false),
                  isActive: Value(remote['is_active'] as bool? ?? true),
                  openingBalancePaisa:
                      Value(remote['opening_balance_paisa'] as int? ?? 0),
                  serverUpdatedAt:
                      Value(DateTime.parse(remote['updated_at'] as String)),
                  isDirty: Value(dirty),
                ),
              ),
        );
      default:
        break; // other tables: pull support added as needed
    }
  }

  Future<void> _upsertSimple({
    required String table,
    required String institutionId,
    required String id,
    required Map<String, dynamic> remote,
    required SyncResult result,
    required Future<Object?> Function() find,
    required bool Function(Object) isDirty,
    required bool Function(Object) isLocked,
    required Map<String, dynamic> Function(Object) toMap,
    required Future<void> Function(bool keepDirty) apply,
  }) async {
    final local = await find();
    if (local == null) {
      await apply(false);
      return;
    }
    if (!isDirty(local)) {
      await apply(false);
      return;
    }
    final decision = ConflictPolicy.decide(
      entityType: table,
      local: toMap(local),
      remote: remote,
      localIsFinanciallyLocked: isLocked(local),
    );
    switch (decision.kind) {
      case ConflictKind.keepRemote:
        await apply(false);
      case ConflictKind.merged:
        // Controlled merge of draft-safe fields; stays dirty for re-push.
        await _applyMerged(table, id, decision.merged);
      case ConflictKind.review:
        await _db.into(_db.syncConflicts).insert(
              db.SyncConflictsCompanion.insert(
                id: _uuid.v4(),
                institutionId: institutionId,
                entityType: table,
                entityId: id,
                localJson: decision.localJson,
                remoteJson: decision.remoteJson,
                detectedAt: DateTime.now(),
              ),
            );
        result.conflicts++;
    }
  }

  Future<void> _applyMerged(
      String table, String id, Map<String, dynamic> merged) async {
    // Draft-safe merged fields are written back; row stays dirty so the
    // merged state is pushed on the next run.
    if (table == 'donors') {
      await (_db.update(_db.donors)..where((t) => t.id.equals(id))).write(
        db.DonorsCompanion(
          phone: Value(merged['phone'] as String?),
          email: Value(merged['email'] as String?),
          address: Value(merged['address'] as String?),
          notes: Value(merged['notes'] as String?),
          updatedAt: Value(DateTime.now()),
          isDirty: const Value(true),
        ),
      );
    }
  }

  Future<void> _applyRemoteReceipt(String institutionId, String id,
      Map<String, dynamic> remote, SyncResult result) async {
    final local = await (_db.select(_db.receipts)..where((t) => t.id.equals(id)))
        .getSingleOrNull();
    if (local == null) {
      await _insertRemoteReceipt(institutionId, remote);
      return;
    }
    if (!local.isDirty) {
      await _overwriteReceipt(remote);
      return;
    }
    final decision = ConflictPolicy.decide(
      entityType: 'receipts',
      local: _receiptMap(local),
      remote: remote,
      localIsFinanciallyLocked:
          local.status == ReceiptStatus.confirmed || local.status == ReceiptStatus.reversed,
    );
    switch (decision.kind) {
      case ConflictKind.keepRemote:
        await _overwriteReceipt(remote);
      case ConflictKind.merged:
        await _applyMergedReceipt(id, decision.merged);
      case ConflictKind.review:
        await _db.into(_db.syncConflicts).insert(
              db.SyncConflictsCompanion.insert(
                id: _uuid.v4(),
                institutionId: institutionId,
                entityType: 'receipts',
                entityId: id,
                localJson: decision.localJson,
                remoteJson: decision.remoteJson,
                detectedAt: DateTime.now(),
              ),
            );
        result.conflicts++;
    }
  }

  Future<void> _insertRemoteReceipt(
      String institutionId, Map<String, dynamic> remote) async {
    final id = remote['id'] as String;
    await _db.into(_db.receipts).insertOnConflictUpdate(
          db.ReceiptsCompanion.insert(
            id: id,
            institutionId: institutionId,
            status: ReceiptStatus.values.byName(remote['status'] as String),
            txType: TxType.values.byName(remote['tx_type'] as String),
            donorId: Value(remote['donor_id'] as String?),
            donorNameSnapshot: remote['donor_name_snapshot'] as String? ?? '',
            isAnonymous: Value(remote['is_anonymous'] as bool? ?? false),
            totalPaisa: remote['total_paisa'] as int,
            receiptDate: DateTime.parse(remote['receipt_date'] as String),
            paymentMethod:
                PaymentMethod.values.byName(remote['payment_method'] as String),
            bankAccountId: Value(remote['bank_account_id'] as String?),
            referenceNo: Value(remote['reference_no'] as String?),
            staffNotes: Value(remote['staff_notes'] as String?),
            donorNote: Value(remote['donor_note'] as String?),
            createdBy: Value(remote['created_by'] as String?),
            verifiedBy: Value(remote['verified_by'] as String?),
            idempotencyKey: remote['idempotency_key'] as String? ?? _uuid.v4(),
            officialNumber: Value(remote['official_number'] as String?),
            localProvisionalLabel:
                Value(remote['local_provisional_label'] as String?),
            reversesId: Value(remote['reverses_id'] as String?),
            serverAck: const Value(true),
            serverUpdatedAt:
                Value(DateTime.parse(remote['updated_at'] as String)),
            createdAt: DateTime.parse(
                remote['created_at'] as String? ?? remote['updated_at'] as String),
            updatedAt: DateTime.parse(remote['updated_at'] as String),
          ),
        );
    final allocs = remote['allocations'] as List? ?? [];
    for (final a in allocs) {
      final m = a as Map<String, dynamic>;
      await _db.into(_db.receiptAllocations).insertOnConflictUpdate(
            db.ReceiptAllocationsCompanion.insert(
              id: m['id'] as String? ?? _uuid.v4(),
              receiptId: id,
              fundTypeId: m['fund_type_id'] as String,
              purposeId: Value(m['purpose_id'] as String?),
              amountPaisa: m['amount_paisa'] as int,
            ),
          );
    }
  }

  Future<void> _overwriteReceipt(Map<String, dynamic> remote) async {
    final id = remote['id'] as String;
    await (_db.update(_db.receipts)..where((t) => t.id.equals(id))).write(
      db.ReceiptsCompanion(
        status: Value(ReceiptStatus.values.byName(remote['status'] as String)),
        officialNumber: Value(remote['official_number'] as String?),
        verifiedBy: Value(remote['verified_by'] as String?),
        staffNotes: Value(remote['staff_notes'] as String?),
        donorNote: Value(remote['donor_note'] as String?),
        referenceNo: Value(remote['reference_no'] as String?),
        serverUpdatedAt: Value(DateTime.parse(remote['updated_at'] as String)),
        updatedAt: Value(DateTime.parse(remote['updated_at'] as String)),
        isDirty: const Value(false),
        serverAck: const Value(true),
      ),
    );
  }

  Future<void> _applyMergedReceipt(String id, Map<String, dynamic> merged) async {
    await (_db.update(_db.receipts)..where((t) => t.id.equals(id))).write(
      db.ReceiptsCompanion(
        staffNotes: Value(merged['staff_notes'] as String?),
        donorNote: Value(merged['donor_note'] as String?),
        referenceNo: Value(merged['reference_no'] as String?),
        officialNumber: Value(merged['official_number'] as String?),
        updatedAt: Value(DateTime.now()),
        isDirty: const Value(true),
      ),
    );
  }

  Map<String, dynamic> _receiptMap(db.Receipt r) => {
        'id': r.id,
        'official_number': r.officialNumber,
        'status': r.status.name,
        'tx_type': r.txType.name,
        'total_paisa': r.totalPaisa,
        'payment_method': r.paymentMethod.name,
        'bank_account_id': r.bankAccountId,
        'staff_notes': r.staffNotes,
        'donor_note': r.donorNote,
        'reference_no': r.referenceNo,
        'updated_at': r.updatedAt.toUtc().toIso8601String(),
      };

  Map<String, dynamic> _donorMap(db.Donor r) => {
        'id': r.id,
        'name': r.name,
        'phone': r.phone,
        'email': r.email,
        'address': r.address,
        'notes': r.notes,
        'updated_at': r.updatedAt.toUtc().toIso8601String(),
      };

  Map<String, dynamic> _fundMap(db.FundType r) => {
        'id': r.id,
        'code': r.code,
        'name_ur': r.nameUr,
        'name_en': r.nameEn,
        'category': r.category.name,
        'is_restricted': r.isRestricted,
        'is_active': r.isActive,
        'opening_balance_paisa': r.openingBalancePaisa,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      };

  // ---------------- manual controls ----------------

  Future<void> retryFailed(String institutionId) async {
    final now = DateTime.now();
    await (_db.update(_db.syncOutbox)
          ..where((t) =>
              t.institutionId.equals(institutionId) &
              t.status.equalsValue(SyncStatus.failed)))
        .write(db.SyncOutboxCompanion(
      status: const Value(SyncStatus.pending),
      attempts: const Value(0),
      nextRetryAt: Value(now),
      lastError: const Value.absent(),
    ));
  }

  Future<List<db.SyncConflict>> openConflicts(String institutionId) =>
      (_db.select(_db.syncConflicts)
            ..where((t) =>
                t.institutionId.equals(institutionId) & t.status.equals('open'))
            ..orderBy([(t) => OrderingTerm.desc(t.detectedAt)]))
          .get();

  /// Manual resolution by an authorized user (audited).
  Future<void> resolveConflict({
    required String conflictId,
    required String resolution, // keep_local | keep_remote
    required String institutionId,
    required String actorId,
    String? note,
  }) async {
    final conflict = await (_db.select(_db.syncConflicts)
          ..where((t) => t.id.equals(conflictId)))
        .getSingle();
    final now = DateTime.now();
    await _db.transaction(() async {
      if (resolution == 'keep_remote') {
        final remote = jsonDecode(conflict.remoteJson) as Map<String, dynamic>;
        if (conflict.entityType == 'receipts') {
          await _overwriteReceipt(remote);
        }
      } else {
        // keep_local: re-enqueue the local state for pushing.
        if (conflict.entityType == 'receipts') {
          await (_db.update(_db.receipts)
                ..where((t) => t.id.equals(conflict.entityId)))
              .write(const db.ReceiptsCompanion(isDirty: Value(true)));
        }
      }
      await (_db.update(_db.syncConflicts)
            ..where((t) => t.id.equals(conflictId)))
          .write(db.SyncConflictsCompanion(
        status: Value('resolved_$resolution'),
        resolvedBy: Value(actorId),
        resolvedAt: Value(now),
        resolutionNote: Value(note),
      ));
      await _audit.log(
        institutionId: institutionId,
        draft: AuditDraft(
          entityType: 'sync_conflict',
          entityId: conflictId,
          action: 'sync.conflict_resolved',
          actorId: actorId,
          reason: note,
          afterJson: jsonEncode({'resolution': resolution}),
        ),
        now: now,
      );
    });
  }
}

class SyncResult {
  bool offline = false;
  int pushed = 0;
  int pulled = 0;
  int numbered = 0;
  int conflicts = 0;
  final List<String> errors = [];
  DateTime? lastSync;
}

/// last-sync timestamps + per-table watermarks.
class SyncStateStore {
  SyncStateStore(this._prefs);
  final Map<String, String> _prefs; // injected key-value store

  Future<DateTime?> lastSync(String institutionId) async {
    final v = _prefs['last_sync_$institutionId'];
    return v == null ? null : DateTime.tryParse(v);
  }

  Future<void> setLastSync(String institutionId, DateTime at) async {
    _prefs['last_sync_$institutionId'] = at.toUtc().toIso8601String();
  }

  Future<DateTime> watermark(String institutionId, String table) async {
    final v = _prefs['wm_${institutionId}_$table'];
    return v == null
        ? DateTime.fromMillisecondsSinceEpoch(0, isUtc: true)
        : DateTime.parse(v);
  }

  Future<void> setWatermark(
      String institutionId, String table, DateTime at) async {
    _prefs['wm_${institutionId}_$table'] = at.toUtc().toIso8601String();
  }
}
