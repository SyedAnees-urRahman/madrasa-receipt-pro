import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';
import '../local/app_database.dart' as db;
import '../../domain/entities/enums.dart';

const _uuid = Uuid();

/// Writes sync-outbox rows. MUST be called inside the same database
/// transaction as the local mutation it describes — atomicity of
/// "local write + queued sync" is what makes offline-first safe.
class OutboxWriter {
  OutboxWriter(this._db);
  final db.AppDatabase _db;

  Future<void> enqueue({
    required String institutionId,
    required String entityType,
    required String entityId,
    required OutboxOperation operation,
    required String payloadJson,
    String? idempotencyKey,
    DateTime? now,
  }) async {
    final at = now ?? DateTime.now();
    await _db.into(_db.syncOutbox).insert(
          db.SyncOutboxCompanion.insert(
            id: _uuid.v4(),
            institutionId: institutionId,
            entityType: entityType,
            entityId: entityId,
            operation: operation,
            payloadJson: payloadJson,
            idempotencyKey: idempotencyKey ?? _uuid.v4(),
            nextRetryAt: at,
            status: SyncStatus.pending,
            createdAt: at,
          ),
        );
  }
}
