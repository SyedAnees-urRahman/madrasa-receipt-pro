import 'dart:convert';

/// Deterministic conflict policy.
///
/// - Draft-only fields (notes, donor contact edits, labels): controlled
///   merge is allowed when NO financial field conflicts.
/// - Confirmed financial records (receipts, approved/paid expenses):
///   NEVER silently overwritten by last-write-wins. The conflict goes to
///   the authorized review queue with original values, attempted changes,
///   actor and timestamps preserved.
/// - Official receipt numbers: the server-issued number always wins;
///   the local provisional label is kept as an auditable mapping.
abstract final class ConflictPolicy {
  /// Financial fields that must never be auto-merged on confirmed records.
  static const financialFields = {
    'total_paisa',
    'amount_paisa',
    'status',
    'official_number',
    'fund_type_id',
    'purpose_id',
    'bank_account_id',
    'payment_method',
    'tx_type',
    'receipt_date',
    'voucher_date',
  };

  static const draftMergeableFields = {
    'staff_notes',
    'donor_note',
    'reference_no',
    'evidence_path',
    'phone',
    'email',
    'address',
    'notes',
    'description',
  };

  static ConflictDecision decide({
    required String entityType,
    required Map<String, dynamic> local,
    required Map<String, dynamic> remote,
    required bool localIsFinanciallyLocked,
  }) {
    final localJson = jsonEncode(local);
    final remoteJson = jsonEncode(remote);

    if (localIsFinanciallyLocked) {
      // Any difference on a locked financial record → human review.
      if (!_mapsEqual(local, remote)) {
        return ConflictDecision.review(
          reason: 'Confirmed financial record differs from server copy.',
          localJson: localJson,
          remoteJson: remoteJson,
        );
      }
      return ConflictDecision.keepRemote(localJson: localJson, remoteJson: remoteJson);
    }

    // Draft / non-locked entity: check whether any FINANCIAL field differs.
    final conflictingFinancial = <String>[];
    for (final field in financialFields) {
      if (!_valuesEqual(local[field], remote[field])) conflictingFinancial.add(field);
    }
    if (conflictingFinancial.isNotEmpty) {
      return ConflictDecision.review(
        reason: 'Financial fields differ: ${conflictingFinancial.join(', ')}.',
        localJson: localJson,
        remoteJson: remoteJson,
      );
    }

    // Only draft-safe fields differ → controlled merge, remote wins ties.
    final merged = Map<String, dynamic>.of(local);
    for (final field in draftMergeableFields) {
      if (remote.containsKey(field) && !_valuesEqual(local[field], remote[field])) {
        merged[field] = remote[field];
      }
    }
    // Server-issued official number always wins when present.
    if (entityType == 'receipts' && remote['official_number'] != null) {
      merged['official_number'] = remote['official_number'];
      merged['local_provisional_label'] = local['local_provisional_label'];
    }
    return ConflictDecision.merged(merged, localJson: localJson, remoteJson: remoteJson);
  }

  static bool _valuesEqual(dynamic a, dynamic b) {
    if (a == null && b == null) return true;
    if (a is num && b is num) return a == b;
    return a?.toString() == b?.toString();
  }

  static bool _mapsEqual(Map<String, dynamic> a, Map<String, dynamic> b) {
    if (a.length != b.length) return false;
    for (final k in a.keys) {
      if (!b.containsKey(k) || !_valuesEqual(a[k], b[k])) return false;
    }
    return true;
  }
}

class ConflictDecision {
  const ConflictDecision._({
    required this.kind,
    required this.merged,
    required this.reason,
    required this.localJson,
    required this.remoteJson,
  });

  factory ConflictDecision.review({
    required String reason,
    required String localJson,
    required String remoteJson,
  }) =>
      ConflictDecision._(
        kind: ConflictKind.review,
        merged: const {},
        reason: reason,
        localJson: localJson,
        remoteJson: remoteJson,
      );

  factory ConflictDecision.merged(
    Map<String, dynamic> merged, {
    required String localJson,
    required String remoteJson,
  }) =>
      ConflictDecision._(
        kind: ConflictKind.merged,
        merged: merged,
        reason: '',
        localJson: localJson,
        remoteJson: remoteJson,
      );

  factory ConflictDecision.keepRemote({
    required String localJson,
    required String remoteJson,
  }) =>
      ConflictDecision._(
        kind: ConflictKind.keepRemote,
        merged: const {},
        reason: '',
        localJson: localJson,
        remoteJson: remoteJson,
      );

  final ConflictKind kind;
  final Map<String, dynamic> merged;
  final String reason;
  final String localJson;
  final String remoteJson;
}

enum ConflictKind { review, merged, keepRemote }
