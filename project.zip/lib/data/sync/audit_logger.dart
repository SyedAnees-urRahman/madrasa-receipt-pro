import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:uuid/uuid.dart';
import '../local/app_database.dart' as db;
import '../../domain/repositories/repositories.dart';
import 'package:drift/drift.dart';

const _uuid = Uuid();

/// Append-only audit log with hash chaining (tamper-evidence).
/// Documented limitation: a hash chain detects AFTER-THE-FACT tampering
/// by anyone without the ability to rewrite the whole chain — it does NOT
/// make the log immutable against a privileged administrator with full
/// database access. Server-side RLS denies UPDATE/DELETE on audit_events
/// to ordinary roles.
class AuditLogger {
  AuditLogger(this._db);
  final db.AppDatabase _db;

  Future<void> log({
    required String institutionId,
    required AuditDraft draft,
    DateTime? now,
  }) async {
    // Truncate to seconds: drift/SQLite round-trips DateTime at second
    // precision, and the hash must be recomputable from the stored value.
    final at = DateTime.fromMillisecondsSinceEpoch(
        ((now ?? DateTime.now()).toUtc().millisecondsSinceEpoch ~/ 1000) *
            1000,
        isUtc: true);
    // Sequence + hash link are assigned atomically: the SELECT of the
    // previous tail and the INSERT happen in one transaction so two
    // concurrent writers cannot fork the chain.
    await _db.transaction(() async {
      final tail = await (_db.select(_db.auditEvents)
            ..where((t) => t.institutionId.equals(institutionId))
            ..orderBy([(t) => OrderingTerm.desc(t.sequence)])
            ..limit(1))
          .getSingleOrNull();
      final seq = (tail?.sequence ?? 0) + 1;
      final prevHash = tail?.hash ?? 'GENESIS';
      final id = _uuid.v4();
      final hash = _chainHash(
        prevHash: prevHash,
        id: id,
        entityType: draft.entityType,
        entityId: draft.entityId,
        action: draft.action,
        actorId: draft.actorId,
        occurredAt: at,
        beforeJson: draft.beforeJson,
        afterJson: draft.afterJson,
      );
      await _db.into(_db.auditEvents).insert(
            db.AuditEventsCompanion.insert(
              id: id,
              institutionId: institutionId,
              sequence: seq,
              entityType: draft.entityType,
              entityId: draft.entityId,
              action: draft.action,
              actorId: draft.actorId,
              occurredAt: at,
              reason: Value(draft.reason),
              beforeJson: Value(draft.beforeJson),
              afterJson: Value(draft.afterJson),
              prevHash: prevHash,
              hash: hash,
            ),
          );
    });
  }

  Future<String> _lastHash(String institutionId) async {
    final row = await (_db.select(_db.auditEvents)
          ..where((t) => t.institutionId.equals(institutionId))
          ..orderBy([(t) => OrderingTerm.desc(t.sequence)])
          ..limit(1))
        .getSingleOrNull();
    return row?.hash ?? 'GENESIS';
  }

  static String _chainHash({
    required String prevHash,
    required String id,
    required String entityType,
    required String entityId,
    required String action,
    required String actorId,
    required DateTime occurredAt,
    String? beforeJson,
    String? afterJson,
  }) {
    final canonical = jsonEncode({
      'prev': prevHash,
      'id': id,
      'entity': '$entityType:$entityId',
      'action': action,
      'actor': actorId,
      'at': occurredAt.toUtc().toIso8601String(),
      'before': beforeJson ?? '',
      'after': afterJson ?? '',
    });
    return sha256.convert(utf8.encode(canonical)).toString();
  }

  /// Verifies the hash chain for an institution. Returns false on the
  /// first broken link. Chain order is the monotonic sequence, never
  /// wall-clock time.
  Future<bool> verifyChain(String institutionId) async {
    final rows = await (_db.select(_db.auditEvents)
          ..where((t) => t.institutionId.equals(institutionId))
          ..orderBy([(t) => OrderingTerm(expression: t.sequence)]))
        .get();
    var prev = 'GENESIS';
    for (final r in rows) {
      if (r.prevHash != prev) return false;
      final recomputed = _chainHash(
        prevHash: r.prevHash,
        id: r.id,
        entityType: r.entityType,
        entityId: r.entityId,
        action: r.action,
        actorId: r.actorId,
        occurredAt: r.occurredAt,
        beforeJson: r.beforeJson,
        afterJson: r.afterJson,
      );
      if (recomputed != r.hash) return false;
      prev = r.hash;
    }
    return true;
  }
}
