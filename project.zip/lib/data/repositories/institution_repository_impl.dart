import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';
import '../local/app_database.dart' as db;
import '../local/mappers.dart';
import '../local/workspace_store.dart';
import '../sync/audit_logger.dart';
import '../sync/outbox_writer.dart';
import 'receipt_repository_impl.dart' show RepositoryContext;
import '../../domain/entities/entities.dart';
import '../../domain/entities/enums.dart';
import '../../domain/repositories/repositories.dart';
import '../../core/error/failures.dart';

const _uuid = Uuid();

/// Default fund catalog offered during setup (admin can edit afterwards).
const defaultFundDrafts = [
  FundDraft(code: 'ZAKAT', nameUr: 'زکوٰۃ', nameEn: 'Zakat', category: FundCategory.zakat, isRestricted: true),
  FundDraft(code: 'SADAQAH', nameUr: 'صدقۂ نافلہ', nameEn: 'Sadaqah (Nafilah)', category: FundCategory.sadaqahNafilah),
  FundDraft(code: 'LILLAH', nameUr: 'عطیاتِ لِلّٰہ', nameEn: 'Lillah / General', category: FundCategory.lillah),
  FundDraft(code: 'MEALS', nameUr: 'طلبہ کا کھانا', nameEn: 'Student Meals', category: FundCategory.studentMeals),
  FundDraft(code: 'BOOKS', nameUr: 'کتب و تعلیم', nameEn: 'Books & Education', category: FundCategory.booksEducation),
  FundDraft(code: 'BUILD', nameUr: 'تعمیر', nameEn: 'Construction', category: FundCategory.construction),
  FundDraft(code: 'UTIL', nameUr: 'بجلی و ضروریات', nameEn: 'Utilities', category: FundCategory.utilities),
];

const defaultPurposeDrafts = [
  PurposeDraft(nameUr: 'راشن و کھانا', nameEn: 'Food & rations'),
  PurposeDraft(nameUr: 'کتب', nameEn: 'Books'),
  PurposeDraft(nameUr: 'تعمیراتی کام', nameEn: 'Construction work'),
  PurposeDraft(nameUr: 'بجلی کا بل', nameEn: 'Electricity bill'),
  PurposeDraft(nameUr: 'اساتذہ کی تنخواہ', nameEn: 'Teacher salaries'),
];

class InstitutionRepositoryImpl implements InstitutionRepository {
  InstitutionRepositoryImpl(
    this._db,
    this._store,
    this._outbox,
    this._audit, {
    RepositoryContext? ctx,
  }) : _ctx = ctx;
  final db.AppDatabase _db;
  final WorkspaceStore _store;
  final OutboxWriter _outbox;
  final AuditLogger _audit;
  final RepositoryContext? _ctx;

  @override
  Future<Result<Institution?>> getCurrent() async {
    try {
      final id = _store.currentInstitutionId;
      if (id == null) return const Ok(null);
      final row = await (_db.select(_db.institutions)..where((t) => t.id.equals(id)))
          .getSingleOrNull();
      return Ok(row == null ? null : Mappers.institution(row));
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<Institution>> save(Institution institution) async {
    try {
      _ctx?.require('settings.write');
      final now = DateTime.now();
      await (_db.update(_db.institutions)
            ..where((t) => t.id.equals(institution.id)))
          .write(db.InstitutionsCompanion(
        nameUr: Value(institution.nameUr),
        nameEn: Value(institution.nameEn),
        logoPath: Value(institution.logoPath),
        address: Value(institution.address),
        phone: Value(institution.phone),
        email: Value(institution.email),
        registrationNo: Value(institution.registrationNo),
        ntn: Value(institution.ntn),
        receiptPrefix: Value(institution.receiptPrefix),
        numberingFormat: Value(institution.numberingFormat),
        receiptLanguage: Value(institution.receiptLanguage),
        printFormat: Value(institution.printFormat),
        acceptedMethodsJson:
            Value(Mappers.encodeMethods(institution.acceptedMethods)),
        signatoriesJson: Value(institution.signatoriesJson),
        dualApprovalThresholdPaisa:
            Value(institution.dualApprovalThresholdPaisa),
        autoSync: Value(institution.autoSync),
        updatedAt: Value(now),
        isDirty: const Value(true),
      ));
      await _outbox.enqueue(
        institutionId: institution.id,
        entityType: 'institutions',
        entityId: institution.id,
        operation: OutboxOperation.update,
        payloadJson: jsonEncode({'id': institution.id}),
        now: now,
      );
      final current = await getCurrent();
      return current.isOk && current.value != null
          ? Ok(current.value!)
          : const Err(DatabaseFailure());
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<void>> completeSetup(SetupDraft draft) async {
    try {
      final now = DateTime.now();
      final institutionId = _uuid.v4();
      await _db.transaction(() async {
        await _db.into(_db.institutions).insert(
              db.InstitutionsCompanion.insert(
                id: institutionId,
                nameUr: draft.nameUr.trim(),
                nameEn: draft.nameEn.trim(),
                logoPath: Value(draft.logoPath),
                address: Value(draft.address),
                phone: Value(draft.phone),
                email: Value(draft.email),
                registrationNo: Value(draft.registrationNo),
                ntn: Value(draft.ntn),
                fyStartMonth: Value(draft.fyStartMonth),
                fyStartDay: Value(draft.fyStartDay),
                receiptPrefix: Value(draft.receiptPrefix.trim()),
                numberingFormat: Value(draft.numberingFormat),
                receiptLanguage: Value(draft.receiptLanguage),
                printFormat: Value(draft.printFormat),
                acceptedMethodsJson:
                    Value(Mappers.encodeMethods(draft.acceptedMethods)),
                signatoriesJson: Value(jsonEncode([
                  for (final s in draft.signatories)
                    {'name': s.name, 'title': s.title},
                ])),
                dualApprovalThresholdPaisa:
                    Value(draft.dualApprovalThresholdPaisa),
                autoSync: Value(draft.autoSync),
                isDemo: Value(draft.seedDemo),
                createdAt: now,
                updatedAt: now,
              ),
            );
        final funds = draft.funds.isEmpty ? defaultFundDrafts : draft.funds;
        var order = 0;
        for (final f in funds) {
          await _db.into(_db.fundTypes).insert(
                db.FundTypesCompanion.insert(
                  id: _uuid.v4(),
                  institutionId: institutionId,
                  code: f.code,
                  nameUr: f.nameUr,
                  nameEn: f.nameEn,
                  category: f.category,
                  isRestricted: Value(f.isRestricted),
                  sortOrder: Value(order++),
                ),
              );
        }
        final purposes =
            draft.purposes.isEmpty ? defaultPurposeDrafts : draft.purposes;
        for (final p in purposes) {
          await _db.into(_db.purposes).insert(
                db.PurposesCompanion.insert(
                  id: _uuid.v4(),
                  institutionId: institutionId,
                  nameUr: p.nameUr,
                  nameEn: p.nameEn,
                ),
              );
        }
        final accounts = draft.accounts.isEmpty
            ? [
                const AccountDraft(
                    type: AccountType.cash, title: 'نقد — Cash in hand'),
              ]
            : draft.accounts;
        for (final a in accounts) {
          await _db.into(_db.bankAccounts).insert(
                db.BankAccountsCompanion.insert(
                  id: _uuid.v4(),
                  institutionId: institutionId,
                  type: a.type,
                  title: a.title,
                  bankName: Value(a.bankName),
                  openingBalancePaisa: Value(a.openingBalancePaisa),
                ),
              );
        }
        if (draft.seedDemo) {
          await _seedDemoData(institutionId, now);
        }
        // Create the local admin user (offline login via PIN).
        final pinHash =
            sha256.convert(utf8.encode('mrp:${draft.adminPin.trim()}')).toString();
        await _db.into(_db.userProfiles).insert(
              db.UserProfilesCompanion.insert(
                id: 'local-admin',
                institutionId: institutionId,
                displayName: draft.adminName.trim().isEmpty
                    ? 'ایڈمن'
                    : draft.adminName.trim(),
                email: 'admin@local',
                role: UserRole.admin,
                pinHash: Value(pinHash),
                createdAt: now,
              ),
            );
        await _audit.log(
          institutionId: institutionId,
          draft: AuditDraft(
            entityType: 'institution',
            entityId: institutionId,
            action: draft.seedDemo
                ? 'institution.demo_created'
                : 'institution.setup_completed',
            actorId: 'setup',
          ),
          now: now,
        );
      });
      await _store.setCurrentInstitutionId(institutionId);
      await _store.setSetupComplete(true);
      return const Ok(null);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  /// Sample data, clearly quarantined in the DEMO workspace (is_demo=true).
  Future<void> _seedDemoData(String institutionId, DateTime now) async {
    final donorId = _uuid.v4();
    await _db.into(_db.donors).insert(db.DonorsCompanion.insert(
          id: donorId,
          institutionId: institutionId,
          name: 'نمونہ عطیہ دہندہ (DEMO)',
          createdAt: now,
          updatedAt: now,
        ));
    final fund = await (_db.select(_db.fundTypes)
          ..where((t) => t.institutionId.equals(institutionId))
          ..limit(1))
        .getSingle();
    final cash = await (_db.select(_db.bankAccounts)
          ..where((t) => t.institutionId.equals(institutionId))
          ..limit(1))
        .getSingle();
    final receiptId = _uuid.v4();
    await _db.into(_db.receipts).insert(db.ReceiptsCompanion.insert(
          id: receiptId,
          institutionId: institutionId,
          status: ReceiptStatus.confirmed,
          txType: TxType.cash,
          donorId: Value(donorId),
          donorNameSnapshot: 'نمونہ عطیہ دہندہ (DEMO)',
          totalPaisa: 500000, // PKR 5,000 — sample only
          receiptDate: now,
          paymentMethod: PaymentMethod.cash,
          bankAccountId: Value(cash.id),
          donorNote: const Value('یہ صرف نمونہ ڈیٹا ہے'),
          idempotencyKey: _uuid.v4(),
          localProvisionalLabel: const Value('DEMO-0001'),
          createdAt: now,
          updatedAt: now,
        ));
    await _db.into(_db.receiptAllocations).insert(
          db.ReceiptAllocationsCompanion.insert(
            id: _uuid.v4(),
            receiptId: receiptId,
            fundTypeId: fund.id,
            amountPaisa: 500000,
          ),
        );
  }

  @override
  Future<Result<List<Institution>>> listWorkspaces() async {
    try {
      final rows = await (_db.select(_db.institutions)
            ..orderBy([(t) => OrderingTerm(expression: t.createdAt)]))
          .get();
      return Ok(rows.map(Mappers.institution).toList());
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<void>> switchWorkspace(String institutionId) async {
    try {
      final row = await (_db.select(_db.institutions)
            ..where((t) => t.id.equals(institutionId)))
          .getSingleOrNull();
      if (row == null) return const Err(DatabaseFailure());
      await _store.setCurrentInstitutionId(institutionId);
      return const Ok(null);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }
}
