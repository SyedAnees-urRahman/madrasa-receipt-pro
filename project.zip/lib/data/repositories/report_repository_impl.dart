import 'package:drift/drift.dart';
import '../local/app_database.dart' as db;
import '../local/mappers.dart';
import 'receipt_repository_impl.dart' show RepositoryContext;
import 'fund_donor_account_audit_repositories.dart'
    show FundRepositoryImpl;
import '../../domain/entities/entities.dart';
import '../../domain/entities/enums.dart';
import '../../domain/repositories/repositories.dart';
import '../../core/error/failures.dart';

/// Every report is derived from stored ledger rows with documented rules:
/// - confirmed totals include ONLY status=confirmed, net of reversals;
/// - pending/draft/pledge rows are reported separately, never in
///   confirmed collection totals;
/// - voided/reversed originals are excluded from confirmed totals.
class ReportRepositoryImpl implements ReportRepository {
  ReportRepositoryImpl(
    this._db,
    this._ctx,
    this._funds,
    this._receipts,
  );
  final db.AppDatabase _db;
  final RepositoryContext _ctx;
  final FundRepositoryImpl _funds;
  final ReceiptRepository _receipts;

  @override
  Future<Result<LedgerReport>> daily(DateTime day) async {
    final start = DateTime(day.year, day.month, day.day);
    final end = start.add(const Duration(days: 1));
    return period(start, end);
  }

  @override
  Future<Result<LedgerReport>> period(DateTime from, DateTime to) async {
    try {
      _ctx.require('reports.view');
      final confirmed = await _receipts.register(
        from: from,
        to: to,
        status: ReceiptStatus.confirmed,
        limit: 100000,
      );
      if (!confirmed.isOk) return Err(confirmed.failure);
      var confirmedTotal = 0;
      final byMethod = <PaymentMethod, int>{};
      final byFund = <String, int>{};
      for (final r in confirmed.value) {
        final sign = r.reversesId == null ? 1 : -1;
        confirmedTotal += sign * r.totalPaisa;
        byMethod[r.paymentMethod] =
            (byMethod[r.paymentMethod] ?? 0) + sign * r.totalPaisa;
        for (final a in r.allocations) {
          byFund[a.fundTypeId] = (byFund[a.fundTypeId] ?? 0) + sign * a.amountPaisa;
        }
      }
      // Pending shown separately — never inside confirmed totals.
      var pendingTotal = 0;
      for (final s in [ReceiptStatus.draft, ReceiptStatus.pendingVerification]) {
        final rows = await _receipts.register(from: from, to: to, status: s, limit: 100000);
        if (rows.isOk) {
          for (final r in rows.value) {
            pendingTotal += r.totalPaisa;
          }
        }
      }
      return Ok(LedgerReport(
        confirmedTotalPaisa: confirmedTotal,
        pendingTotalPaisa: pendingTotal,
        byMethod: byMethod,
        byFund: byFund,
        receipts: confirmed.value,
      ));
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<List<DonorHistoryRow>>> donorHistory(String donorId) async {
    try {
      _ctx.require('reports.view');
      final q = _db.select(_db.receipts)
        ..where((t) =>
            t.institutionId.equals(_ctx.institutionId) & t.donorId.equals(donorId))
        ..orderBy([(t) => OrderingTerm.desc(t.receiptDate)])
        ..limit(500);
      final funds = await _funds.funds(activeOnly: false);
      final fundNames = {
        for (final f in (funds.isOk ? funds.value : <FundType>[])) f.id: f.nameEn,
      };
      final out = <DonorHistoryRow>[];
      for (final row in await q.get()) {
        final allocs = await (_db.select(_db.receiptAllocations)
              ..where((t) => t.receiptId.equals(row.id)))
            .get();
        out.add(DonorHistoryRow(
          receipt: Mappers.receipt(row, allocs),
          fundNames: [
            for (final a in allocs) fundNames[a.fundTypeId] ?? a.fundTypeId,
          ],
        ));
      }
      return Ok(out);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<List<FundFlowRow>>> fundFlows(DateTime from, DateTime to) async {
    try {
      _ctx.require('reports.view');
      final balances = await _funds.allBalances();
      if (!balances.isOk) return Err(balances.failure);
      return Ok([
        for (final b in balances.value)
          FundFlowRow(
            fund: b.fund,
            receiptsPaisa: b.confirmedReceiptsPaisa,
            expensesPaisa: b.authorizedExpensesPaisa,
          ),
      ]);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<List<MethodSummaryRow>>> paymentMethodSummary(
      DateTime from, DateTime to) async {
    try {
      final report = await period(from, to);
      if (!report.isOk) return Err(report.failure);
      final counts = <PaymentMethod, int>{};
      for (final r in report.value.receipts) {
        counts[r.paymentMethod] = (counts[r.paymentMethod] ?? 0) + 1;
      }
      return Ok([
        for (final e in report.value.byMethod.entries)
          MethodSummaryRow(
            method: e.key,
            totalPaisa: e.value,
            count: counts[e.key] ?? 0,
          ),
      ]);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<List<PurposeFlowRow>>> purposeFlows(
      DateTime from, DateTime to) async {
    try {
      _ctx.require('reports.view');
      final a = _db.receiptAllocations;
      final r = _db.receipts;
      final p = _db.purposes;
      final q = _db.select(a).join([
        innerJoin(r, r.id.equalsExp(a.receiptId)),
        leftOuterJoin(p, p.id.equalsExp(a.purposeId)),
      ])
        ..where(r.institutionId.equals(_ctx.institutionId) &
            r.status.equalsValue(ReceiptStatus.confirmed) &
            r.receiptDate.isBiggerOrEqualValue(from) &
            r.receiptDate.isSmallerOrEqualValue(to) &
            a.purposeId.isNotNull());
      final totals = <String, int>{};
      final names = <String, Purpose>{};
      for (final row in await q.get()) {
        final purpose = row.read(p.id) == null
            ? null
            : Mappers.purpose(row.readTable(p));
        final pid = row.read(a.purposeId)!;
        final sign = row.read(r.reversesId) == null ? 1 : -1;
        totals[pid] = (totals[pid] ?? 0) + sign * row.read(a.amountPaisa)!;
        if (purpose != null) names[pid] = purpose;
      }
      return Ok([
        for (final e in totals.entries)
          PurposeFlowRow(
            purpose: names[e.key] ??
                Purpose(
                    id: e.key,
                    institutionId: _ctx.institutionId,
                    nameUr: e.key,
                    nameEn: e.key,
                    isActive: true),
            totalPaisa: e.value,
          ),
      ]);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<CashBook>> cashBook(
      DateTime from, DateTime to, String accountId) async {
    try {
      _ctx.require('reports.view');
      final dayBefore = from.subtract(const Duration(seconds: 1));
      final openingRes = await AccountBookHelper(_db, _ctx).balance(accountId, dayBefore);
      if (!openingRes.isOk) return Err(openingRes.failure);
      final lines = <CashBookLine>[];

      final inQ = _db.select(_db.receipts)
        ..where((t) =>
            t.institutionId.equals(_ctx.institutionId) &
            t.status.equalsValue(ReceiptStatus.confirmed) &
            t.bankAccountId.equals(accountId) &
            t.receiptDate.isBiggerOrEqualValue(from) &
            t.receiptDate.isSmallerOrEqualValue(to))
        ..orderBy([(t) => OrderingTerm(expression: t.receiptDate)]);
      for (final row in await inQ.get()) {
        final amount =
            row.reversesId == null ? row.totalPaisa : -row.totalPaisa;
        lines.add(CashBookLine(
          date: row.receiptDate,
          label: row.donorNameSnapshot,
          reference: row.officialNumber ?? row.localProvisionalLabel ?? row.id,
          inPaisa: amount > 0 ? amount : 0,
          outPaisa: amount < 0 ? -amount : 0,
        ));
      }
      final outQ = _db.select(_db.expenseVouchers)
        ..where((t) =>
            t.institutionId.equals(_ctx.institutionId) &
            t.status.equalsValue(ExpenseStatus.paid) &
            t.bankAccountId.equals(accountId) &
            t.voucherDate.isBiggerOrEqualValue(from) &
            t.voucherDate.isSmallerOrEqualValue(to))
        ..orderBy([(t) => OrderingTerm(expression: t.voucherDate)]);
      for (final row in await outQ.get()) {
        lines.add(CashBookLine(
          date: row.voucherDate,
          label: row.payee,
          reference: row.voucherNumber,
          inPaisa: 0,
          outPaisa: row.totalPaisa,
        ));
      }
      lines.sort((a, b) => a.date.compareTo(b.date));
      var closing = openingRes.value;
      for (final l in lines) {
        closing += l.inPaisa - l.outPaisa;
      }
      return Ok(CashBook(
          openingPaisa: openingRes.value, lines: lines, closingPaisa: closing));
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<List<Receipt>>> canceledRegister(
      DateTime from, DateTime to) async {
    try {
      _ctx.require('reports.view');
      final out = <Receipt>[];
      for (final s in [ReceiptStatus.voided, ReceiptStatus.reversed]) {
        final rows = await _receipts.register(
            from: from, to: to, status: s, limit: 100000);
        if (rows.isOk) out.addAll(rows.value);
      }
      out.sort((a, b) => b.receiptDate.compareTo(a.receiptDate));
      return Ok(out);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }
}

/// Shared book-balance helper (also used by reconciliation screens).
class AccountBookHelper {
  AccountBookHelper(this._db, this._ctx);
  final db.AppDatabase _db;
  final RepositoryContext _ctx;

  Future<Result<int>> balance(String accountId, DateTime asOf) async {
    try {
      final acct = await (_db.select(_db.bankAccounts)
            ..where((t) => t.id.equals(accountId)))
          .getSingleOrNull();
      if (acct == null || acct.institutionId != _ctx.institutionId) {
        return const Err(DatabaseFailure());
      }
      var bal = acct.openingBalancePaisa;
      final inQ = _db.select(_db.receipts)
        ..where((t) =>
            t.institutionId.equals(_ctx.institutionId) &
            t.status.equalsValue(ReceiptStatus.confirmed) &
            t.bankAccountId.equals(accountId) &
            t.receiptDate.isSmallerOrEqualValue(asOf));
      for (final row in await inQ.get()) {
        bal += row.reversesId == null ? row.totalPaisa : -row.totalPaisa;
      }
      final outQ = _db.select(_db.expenseVouchers)
        ..where((t) =>
            t.institutionId.equals(_ctx.institutionId) &
            t.status.equalsValue(ExpenseStatus.paid) &
            t.bankAccountId.equals(accountId) &
            t.voucherDate.isSmallerOrEqualValue(asOf));
      for (final row in await outQ.get()) {
        bal -= row.totalPaisa;
      }
      return Ok(bal);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }
}
