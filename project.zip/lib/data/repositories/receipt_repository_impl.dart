import 'dart:convert';
import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';
import '../local/app_database.dart' as db;
import '../local/mappers.dart';
import '../sync/audit_logger.dart';
import '../sync/outbox_writer.dart';
import '../../domain/auth/permissions.dart';
import '../../domain/entities/entities.dart';
import '../../domain/entities/enums.dart';
import '../../domain/repositories/repositories.dart';
import '../../core/error/failures.dart';

const _uuid = Uuid();

/// Who is acting, and in which workspace. All queries are scoped by
/// institutionId — demo and real data can never mix.
class RepositoryContext {
  const RepositoryContext({
    required this.institutionId,
    required this.actorId,
    required this.actorRole,
  });
  final String institutionId;
  final String actorId;
  final UserRole actorRole;

  void require(String permission) {
    if (!Permissions.can(actorRole, permission)) throw PermissionFailure();
  }
}

class ReceiptRepositoryImpl implements ReceiptRepository {
  ReceiptRepositoryImpl(this._db, this._ctx, this._outbox, this._audit);
  final db.AppDatabase _db;
  final RepositoryContext _ctx;
  final OutboxWriter _outbox;
  final AuditLogger _audit;

  // ---------------- create ----------------

  @override
  Future<Result<Receipt>> createDraft(ReceiptDraft draft) async {
    try {
      _ctx.require('receipt.create');
      _validateDraft(draft);

      final now = DateTime.now();
      final id = _uuid.v4();
      final idempotencyKey = _uuid.v4();
      final provisionalLabel = 'LOCAL-${id.substring(0, 8).toUpperCase()}';

      // Donor: reuse existing or create; anonymous stays null.
      String? donorId = draft.donorId;
      final donorSnapshot = draft.isAnonymous ? 'anonymous' : draft.donorName.trim();
      if (donorId == null && !draft.isAnonymous && draft.donorName.trim().isNotEmpty) {
        donorId = await _findOrCreateDonor(draft, now);
      }
      if (draft.donorId != null) {
        final existing = await (_db.select(_db.donors)
              ..where((t) => t.id.equals(draft.donorId!)))
            .getSingleOrNull();
        if (existing == null || existing.institutionId != _ctx.institutionId) {
          return const Err(ValidationFailure('errorRequired'));
        }
      }

      // Funds must exist, be active, and belong to this institution.
      for (final a in draft.allocations) {
        final fund = await (_db.select(_db.fundTypes)
              ..where((t) => t.id.equals(a.fundTypeId)))
            .getSingleOrNull();
        if (fund == null ||
            fund.institutionId != _ctx.institutionId ||
            !fund.isActive) {
          return const Err(ValidationFailure('warnAllocation'));
        }
        if (a.purposeId != null) {
          final purpose = await (_db.select(_db.purposes)
                ..where((t) => t.id.equals(a.purposeId!)))
              .getSingleOrNull();
          if (purpose == null || purpose.institutionId != _ctx.institutionId) {
            return const Err(ValidationFailure('warnAllocation'));
          }
        }
      }

      await _db.transaction(() async {
        await _db.into(_db.receipts).insert(
              Mappers.receiptInsert(
                id: id,
                institutionId: _ctx.institutionId,
                draft: draft,
                donorNameSnapshot: donorSnapshot,
                idempotencyKey: idempotencyKey,
                localProvisionalLabel: provisionalLabel,
                createdBy: _ctx.actorId,
                now: now,
              ),
            );
        for (final a in draft.allocations) {
          await _db.into(_db.receiptAllocations).insert(
                Mappers.allocationInsert(
                  id: _uuid.v4(),
                  receiptId: id,
                  draft: a,
                ),
              );
        }
        await _outbox.enqueue(
          institutionId: _ctx.institutionId,
          entityType: 'receipts',
          entityId: id,
          operation: OutboxOperation.insert,
          payloadJson: jsonEncode(_receiptPayloadStub(
            id: id,
            draft: draft,
            donorId: donorId,
            donorSnapshot: donorSnapshot,
            idempotencyKey: idempotencyKey,
            provisionalLabel: provisionalLabel,
            now: now,
          )),
          idempotencyKey: idempotencyKey,
          now: now,
        );
        await _audit.log(
          institutionId: _ctx.institutionId,
          draft: AuditDraft(
            entityType: 'receipt',
            entityId: id,
            action: 'receipt.created',
            actorId: _ctx.actorId,
            afterJson: jsonEncode({'total_paisa': draft.totalPaisa}),
          ),
          now: now,
        );
      });

      final created = await getById(id);
      return created!.isOk ? Ok(created.value!) : Err(created.failure);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  void _validateDraft(ReceiptDraft draft) {
    if (draft.totalPaisa <= 0) throw const ValidationFailure('errorInvalidAmount');
    if (draft.allocations.isEmpty) throw const ValidationFailure('warnAllocation');
    var sum = 0;
    for (final a in draft.allocations) {
      if (a.amountPaisa <= 0) throw const ValidationFailure('errorInvalidAmount');
      sum += a.amountPaisa;
    }
    if (sum != draft.totalPaisa) {
      throw const ValidationFailure('allocationTotalMismatch');
    }
    if (draft.donorName.trim().isEmpty && !draft.isAnonymous) {
      throw const ValidationFailure('errorRequired');
    }
  }

  Future<String> _findOrCreateDonor(ReceiptDraft draft, DateTime now) async {
    final name = draft.donorName.trim();
    final q = _db.select(_db.donors)
      ..where((t) =>
          t.institutionId.equals(_ctx.institutionId) & t.name.equals(name));
    if (draft.donorPhone != null && draft.donorPhone!.trim().isNotEmpty) {
      q.where((t) => t.phone.equals(draft.donorPhone!.trim()));
    }
    final existing = await q.getSingleOrNull();
    if (existing != null) return existing.id;
    final id = _uuid.v4();
    await _db.into(_db.donors).insert(
          db.DonorsCompanion.insert(
            id: id,
            institutionId: _ctx.institutionId,
            name: name,
            phone: Value(draft.donorPhone?.trim()),
            email: Value(draft.donorEmail?.trim()),
            address: Value(draft.donorAddress?.trim()),
            createdBy: Value(_ctx.actorId),
            createdAt: now,
            updatedAt: now,
          ),
        );
    await _outbox.enqueue(
      institutionId: _ctx.institutionId,
      entityType: 'donors',
      entityId: id,
      operation: OutboxOperation.insert,
      payloadJson: jsonEncode({'id': id, 'name': name}),
      now: now,
    );
    return id;
  }

  Map<String, dynamic> _receiptPayloadStub({
    required String id,
    required ReceiptDraft draft,
    required String? donorId,
    required String donorSnapshot,
    required String idempotencyKey,
    required String provisionalLabel,
    required DateTime now,
  }) =>
      {
        'id': id,
        'institution_id': _ctx.institutionId,
        'official_number': null,
        'local_provisional_label': provisionalLabel,
        'status': ReceiptStatus.draft.name,
        'tx_type': draft.txType.name,
        'donor_id': donorId,
        'donor_name_snapshot': donorSnapshot,
        'is_anonymous': draft.isAnonymous,
        'total_paisa': draft.totalPaisa,
        'receipt_date': draft.receiptDate.toUtc().toIso8601String(),
        'payment_method': draft.paymentMethod.name,
        'bank_account_id': draft.bankAccountId,
        'reference_no': draft.referenceNo,
        'staff_notes': draft.staffNotes,
        'donor_note': draft.donorNote,
        'created_by': _ctx.actorId,
        'idempotency_key': idempotencyKey,
        'allocations': [
          for (final a in draft.allocations)
            {
              'id': _uuid.v4(),
              'fund_type_id': a.fundTypeId,
              'purpose_id': a.purposeId,
              'amount_paisa': a.amountPaisa,
            },
        ],
        'updated_at': now.toUtc().toIso8601String(),
      };

  // ---------------- state transitions ----------------

  @override
  Future<Result<Receipt>> submitForVerification(String receiptId) async {
    try {
      _ctx.require('receipt.create');
      final row = await _receiptRow(receiptId);
      if (row == null) return const Err(DatabaseFailure());
      if (row.status != ReceiptStatus.draft) {
        return const Err(ValidationFailure('commonError'));
      }
      if (row.txType == TxType.pledge) {
        // A pledge is never submitted as a receivable.
        return const Err(ValidationFailure('statusPledge'));
      }
      final now = DateTime.now();
      await _db.transaction(() async {
        await (_db.update(_db.receipts)..where((t) => t.id.equals(receiptId)))
            .write(db.ReceiptsCompanion(
          status: const Value(ReceiptStatus.pendingVerification),
          updatedAt: Value(now),
          isDirty: const Value(true),
        ));
        await _enqueueReceiptUpdate(receiptId, now);
        await _audit.log(
          institutionId: _ctx.institutionId,
          draft: AuditDraft(
            entityType: 'receipt',
            entityId: receiptId,
            action: 'receipt.submitted_for_verification',
            actorId: _ctx.actorId,
            beforeJson: jsonEncode({'status': 'draft'}),
            afterJson: jsonEncode({'status': 'pendingVerification'}),
          ),
          now: now,
        );
      });
      return _required(receiptId);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<Receipt>> verifyPayment({
    required String receiptId,
    required String verifierId,
    required String evidenceSummary,
    String? note,
  }) async {
    try {
      _ctx.require('receipt.verify');
      final row = await _receiptRow(receiptId);
      if (row == null) return const Err(DatabaseFailure());
      if (row.status != ReceiptStatus.draft &&
          row.status != ReceiptStatus.pendingVerification) {
        return const Err(ValidationFailure('commonError'));
      }
      if (!DomainRules.pledgeCanConfirm(row.txType)) {
        return const Err(ValidationFailure('statusPledge'));
      }
      if (evidenceSummary.trim().isEmpty) {
        return const Err(ValidationFailure('errorRequired'));
      }
      // Separation of duties: verifier must differ from creator,
      // unless this is a single-user institution (bootstrap case).
      if (Permissions.isSelfApproval(verifierId, row.createdBy) &&
          await _activeUserCount() > 1) {
        return const Err(ValidationFailure('errorSelfApproval'));
      }

      final now = DateTime.now();
      await _db.transaction(() async {
        await (_db.update(_db.receipts)..where((t) => t.id.equals(receiptId)))
            .write(db.ReceiptsCompanion(
          status: const Value(ReceiptStatus.confirmed),
          verifiedBy: Value(verifierId),
          verifiedAt: Value(now),
          updatedAt: Value(now),
          isDirty: const Value(true),
        ));
        await _db.into(_db.paymentVerifications).insert(
              db.PaymentVerificationsCompanion.insert(
                id: _uuid.v4(),
                receiptId: receiptId,
                verifiedBy: verifierId,
                verifiedAt: now,
                evidenceSummary: evidenceSummary.trim(),
                note: Value(note?.trim()),
              ),
            );
        await _db.into(_db.approvals).insert(
              db.ApprovalsCompanion.insert(
                id: _uuid.v4(),
                institutionId: _ctx.institutionId,
                entityType: 'receipt',
                entityId: receiptId,
                action: 'verify',
                decision: ApprovalDecision.approved,
                actorId: verifierId,
                decidedAt: now,
                reason: Value(note?.trim()),
              ),
            );
        await _enqueueReceiptUpdate(receiptId, now);
        await _audit.log(
          institutionId: _ctx.institutionId,
          draft: AuditDraft(
            entityType: 'receipt',
            entityId: receiptId,
            action: 'receipt.verified',
            actorId: verifierId,
            reason: evidenceSummary.trim(),
            beforeJson: jsonEncode({'status': row.status.name}),
            afterJson: jsonEncode({'status': 'confirmed'}),
          ),
          now: now,
        );
      });
      return _required(receiptId);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<Receipt>> voidReceipt({
    required String receiptId,
    required String actorId,
    required String reason,
  }) async {
    try {
      _ctx.require('receipt.void');
      if (reason.trim().isEmpty) return const Err(ValidationFailure('errorRequired'));
      final row = await _receiptRow(receiptId);
      if (row == null) return const Err(DatabaseFailure());
      if (row.status == ReceiptStatus.voided || row.status == ReceiptStatus.reversed) {
        return const Err(ValidationFailure('commonError'));
      }
      final now = DateTime.now();
      await _db.transaction(() async {
        await (_db.update(_db.receipts)..where((t) => t.id.equals(receiptId)))
            .write(db.ReceiptsCompanion(
          status: const Value(ReceiptStatus.voided),
          voidReason: Value(reason.trim()),
          updatedAt: Value(now),
          isDirty: const Value(true),
        ));
        await _enqueueReceiptUpdate(receiptId, now);
        await _audit.log(
          institutionId: _ctx.institutionId,
          draft: AuditDraft(
            entityType: 'receipt',
            entityId: receiptId,
            action: 'receipt.voided',
            actorId: actorId,
            reason: reason.trim(),
            beforeJson: jsonEncode(
                {'status': row.status.name, 'official_number': row.officialNumber}),
            afterJson: jsonEncode({'status': 'voided'}),
          ),
          now: now,
        );
      });
      return _required(receiptId);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<Receipt>> reverseReceipt({
    required String receiptId,
    required String actorId,
    required String reason,
  }) async {
    try {
      _ctx.require('receipt.void');
      if (reason.trim().isEmpty) return const Err(ValidationFailure('errorRequired'));
      final original = await getById(receiptId);
      if (!original.isOk) return Err(original.failure);
      final src = original.value!;
      if (src.status != ReceiptStatus.confirmed) {
        return const Err(ValidationFailure('commonError'));
      }
      final now = DateTime.now();
      final reversalId = _uuid.v4();
      final reversalKey = _uuid.v4();
      await _db.transaction(() async {
        // 1. Mark the original reversed (history + number preserved).
        await (_db.update(_db.receipts)..where((t) => t.id.equals(receiptId)))
            .write(db.ReceiptsCompanion(
          status: const Value(ReceiptStatus.reversed),
          voidReason: Value(reason.trim()),
          replacedById: Value(reversalId),
          updatedAt: Value(now),
          isDirty: const Value(true),
        ));
        // 2. Linked contra entry with its own official number (issued on sync).
        await _db.into(_db.receipts).insert(
              db.ReceiptsCompanion.insert(
                id: reversalId,
                institutionId: _ctx.institutionId,
                status: ReceiptStatus.confirmed,
                txType: src.txType,
                donorId: Value(src.donorId),
                donorNameSnapshot: src.donorNameSnapshot,
                isAnonymous: Value(src.isAnonymous),
                totalPaisa: src.totalPaisa,
                receiptDate: now,
                paymentMethod: src.paymentMethod,
                bankAccountId: Value(src.bankAccountId),
                donorNote: const Value('Reversal of original receipt'),
                createdBy: Value(actorId),
                verifiedBy: Value(actorId),
                verifiedAt: Value(now),
                reversesId: Value(receiptId),
                idempotencyKey: reversalKey,
                localProvisionalLabel:
                    Value('REV-${src.officialNumber ?? src.localProvisionalLabel}'),
                createdAt: now,
                updatedAt: now,
              ),
            );
        for (final a in src.allocations) {
          await _db.into(_db.receiptAllocations).insert(
                db.ReceiptAllocationsCompanion.insert(
                  id: _uuid.v4(),
                  receiptId: reversalId,
                  fundTypeId: a.fundTypeId,
                  purposeId: Value(a.purposeId),
                  amountPaisa: a.amountPaisa,
                ),
              );
        }
        await _enqueueReceiptUpdate(receiptId, now);
        await _outbox.enqueue(
          institutionId: _ctx.institutionId,
          entityType: 'receipts',
          entityId: reversalId,
          operation: OutboxOperation.insert,
          payloadJson: jsonEncode({'id': reversalId, 'reverses_id': receiptId}),
          idempotencyKey: reversalKey,
          now: now,
        );
        await _audit.log(
          institutionId: _ctx.institutionId,
          draft: AuditDraft(
            entityType: 'receipt',
            entityId: receiptId,
            action: 'receipt.reversed',
            actorId: actorId,
            reason: reason.trim(),
            afterJson: jsonEncode({'reversal_id': reversalId}),
          ),
          now: now,
        );
      });
      return _required(reversalId);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  /// Called by the sync engine after the server acknowledges a push.
  Future<void> applyServerAck(
    String receiptId, {
    DateTime? serverUpdatedAt,
    String? officialNumber,
  }) async {
    final now = DateTime.now();
    await _db.transaction(() async {
      await (_db.update(_db.receipts)..where((t) => t.id.equals(receiptId)))
          .write(db.ReceiptsCompanion(
        serverAck: const Value(true),
        isDirty: const Value(false),
        serverUpdatedAt: Value(serverUpdatedAt ?? now),
        officialNumber: officialNumber == null
            ? const Value.absent()
            : Value(officialNumber),
        updatedAt: Value(now),
      ));
      if (officialNumber != null) {
        await _audit.log(
          institutionId: _ctx.institutionId,
          draft: AuditDraft(
            entityType: 'receipt',
            entityId: receiptId,
            action: 'receipt.official_number_assigned',
            actorId: 'server',
            afterJson: jsonEncode({'official_number': officialNumber}),
          ),
          now: now,
        );
      }
    });
  }

  // ---------------- reads ----------------

  Future<db.Receipt?> _receiptRow(String id) async {
    return (_db.select(_db.receipts)
          ..where((t) => t.id.equals(id)))
        .getSingleOrNull();
  }

  Future<int> _activeUserCount() async {
    final rows = await (_db.select(_db.userProfiles)
          ..where((t) =>
              t.institutionId.equals(_ctx.institutionId) & t.isActive.equals(true)))
        .get();
    return rows.length;
  }

  Future<void> _enqueueReceiptUpdate(String receiptId, DateTime now) async {
    await _outbox.enqueue(
      institutionId: _ctx.institutionId,
      entityType: 'receipts',
      entityId: receiptId,
      operation: OutboxOperation.update,
      payloadJson: jsonEncode({'id': receiptId}),
      now: now,
    );
  }

  Future<List<db.ReceiptAllocation>> _allocations(String receiptId) =>
      (_db.select(_db.receiptAllocations)
            ..where((t) => t.receiptId.equals(receiptId)))
          .get();

  @override
  Future<Result<Receipt?>> getById(String id) async {
    try {
      final row = await _receiptRow(id);
      if (row == null || row.institutionId != _ctx.institutionId) {
        return const Ok(null);
      }
      return Ok(Mappers.receipt(row, await _allocations(id)));
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<Receipt?>> getByOfficialNumber(String number) async {
    try {
      final row = await (_db.select(_db.receipts)
            ..where((t) =>
                t.institutionId.equals(_ctx.institutionId) &
                t.officialNumber.equals(number)))
          .getSingleOrNull();
      if (row == null) return const Ok(null);
      return Ok(Mappers.receipt(row, await _allocations(row.id)));
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  /// Fetch a receipt that must exist; maps the nullable getById result
  /// into the non-nullable Result the callers promise.
  Future<Result<Receipt>> _required(String receiptId) async {
    final res = await getById(receiptId);
    if (res.isErr) return Err(res.failure);
    final r = res.value;
    if (r == null) return const Err(DatabaseFailure());
    return Ok(r);
  }

  Future<Result<List<Receipt>>> register({
    DateTime? from,
    DateTime? to,
    ReceiptStatus? status,
    String? donorQuery,
    int limit = 100,
    int offset = 0,
  }) async {
    try {
      _ctx.require('receipt.view');
      final q = _db.select(_db.receipts)
        ..where((t) => t.institutionId.equals(_ctx.institutionId));
      if (from != null) q.where((t) => t.receiptDate.isBiggerOrEqualValue(from));
      if (to != null) q.where((t) => t.receiptDate.isSmallerOrEqualValue(to));
      if (status != null) q.where((t) => t.status.equalsValue(status));
      if (donorQuery != null && donorQuery.trim().isNotEmpty) {
        q.where((t) => t.donorNameSnapshot.like('%${donorQuery.trim()}%'));
      }
      q
        ..orderBy([(t) => OrderingTerm.desc(t.receiptDate)])
        ..limit(limit, offset: offset);
      final rows = await q.get();
      final out = <Receipt>[];
      for (final r in rows) {
        out.add(Mappers.receipt(r, await _allocations(r.id)));
      }
      return Ok(out);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<List<Receipt>>> pendingVerification() =>
      register(status: ReceiptStatus.pendingVerification, limit: 500);

  @override
  Future<Result<List<Receipt>>> findPossibleDuplicates(ReceiptDraft draft) async {
    try {
      final dayBefore = draft.receiptDate.subtract(const Duration(days: 1));
      final dayAfter = draft.receiptDate.add(const Duration(days: 1));
      final q = _db.select(_db.receipts)
        ..where((t) =>
            t.institutionId.equals(_ctx.institutionId) &
            t.totalPaisa.equals(draft.totalPaisa) &
            t.receiptDate.isBiggerOrEqualValue(dayBefore) &
            t.receiptDate.isSmallerOrEqualValue(dayAfter) &
            // Only live receipts can be duplicates; voided and reversed
            // entries are history, not candidates.
            t.status.isInValues([
              ReceiptStatus.draft,
              ReceiptStatus.pendingVerification,
              ReceiptStatus.confirmed,
            ]));
      if (draft.donorId != null) {
        q.where((t) => t.donorId.equals(draft.donorId!));
      } else if (!draft.isAnonymous) {
        q.where((t) => t.donorNameSnapshot.equals(draft.donorName.trim()));
      }
      final rows = await q.get();
      final out = <Receipt>[];
      for (final r in rows) {
        out.add(Mappers.receipt(r, await _allocations(r.id)));
      }
      return Ok(out);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<List<PaymentVerification>>> verificationHistory(
      String receiptId) async {
    try {
      final rows = await (_db.select(_db.paymentVerifications)
            ..where((t) => t.receiptId.equals(receiptId))
            ..orderBy([(t) => OrderingTerm(expression: t.verifiedAt)]))
          .get();
      return Ok(rows.map(Mappers.verification).toList());
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<Receipt>> issueOfficial(String receiptId) async {
    // Official numbers are issued by the trusted server. This marks the
    // receipt for numbering; the sync engine performs the server call and
    // stores the issued number. Offline, the receipt stays provisional.
    try {
      _ctx.require('receipt.create');
      final row = await _receiptRow(receiptId);
      if (row == null) return const Err(DatabaseFailure());
      if (row.officialNumber != null) return _required(receiptId);
      if (row.status != ReceiptStatus.confirmed) {
        return const Err(ValidationFailure('statusPendingVerification'));
      }
      final now = DateTime.now();
      await _db.transaction(() async {
        await (_db.update(_db.receipts)..where((t) => t.id.equals(receiptId)))
            .write(const db.ReceiptsCompanion(isDirty: Value(true)));
        await _enqueueReceiptUpdate(receiptId, now);
      });
      return _required(receiptId);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }
}
