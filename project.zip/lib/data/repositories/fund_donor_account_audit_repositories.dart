import 'dart:convert';
import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';
import '../local/app_database.dart' as db;
import '../local/mappers.dart';
import '../sync/audit_logger.dart';
import '../sync/outbox_writer.dart';
import 'receipt_repository_impl.dart' show RepositoryContext;
import '../../domain/entities/entities.dart';
import '../../domain/entities/enums.dart';
import '../../domain/repositories/repositories.dart';
import '../../core/error/failures.dart';

const _uuid = Uuid();

class FundRepositoryImpl implements FundRepository {
  FundRepositoryImpl(this._db, this._ctx, this._outbox, this._audit);
  final db.AppDatabase _db;
  final RepositoryContext _ctx;
  final OutboxWriter _outbox;
  final AuditLogger _audit;

  @override
  Future<Result<List<FundType>>> funds({bool activeOnly = true}) async {
    try {
      final q = _db.select(_db.fundTypes)
        ..where((t) => t.institutionId.equals(_ctx.institutionId));
      if (activeOnly) q.where((t) => t.isActive.equals(true));
      q.orderBy([(t) => OrderingTerm(expression: t.sortOrder)]);
      return Ok((await q.get()).map(Mappers.fund).toList());
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<List<Purpose>>> purposes({bool activeOnly = true}) async {
    try {
      final q = _db.select(_db.purposes)
        ..where((t) => t.institutionId.equals(_ctx.institutionId));
      if (activeOnly) q.where((t) => t.isActive.equals(true));
      return Ok((await q.get()).map(Mappers.purpose).toList());
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<FundType>> createFund(FundType fund) async {
    try {
      _ctx.require('funds.manage');
      final now = DateTime.now();
      await _db.transaction(() async {
        await _db.into(_db.fundTypes).insert(
              db.FundTypesCompanion.insert(
                id: fund.id,
                institutionId: _ctx.institutionId,
                code: fund.code,
                nameUr: fund.nameUr,
                nameEn: fund.nameEn,
                category: fund.category,
                isRestricted: Value(fund.isRestricted),
                openingBalancePaisa: Value(fund.openingBalancePaisa),
                sortOrder: Value(fund.sortOrder),
              ),
            );
        await _audit.log(
          institutionId: _ctx.institutionId,
          draft: AuditDraft(
            entityType: 'fund',
            entityId: fund.id,
            action: 'fund.created',
            actorId: _ctx.actorId,
            afterJson: jsonEncode({'code': fund.code}),
          ),
          now: now,
        );
      });
      final row = await (_db.select(_db.fundTypes)..where((t) => t.id.equals(fund.id)))
          .getSingle();
      return Ok(Mappers.fund(row));
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<void>> updateFund(FundType fund, {required String reason}) async {
    try {
      _ctx.require('funds.manage');
      if (reason.trim().isEmpty) return const Err(ValidationFailure('errorRequired'));
      final now = DateTime.now();
      final before = await (_db.select(_db.fundTypes)
            ..where((t) => t.id.equals(fund.id)))
          .getSingleOrNull();
      await _db.transaction(() async {
        await (_db.update(_db.fundTypes)..where((t) => t.id.equals(fund.id)))
            .write(db.FundTypesCompanion(
          nameUr: Value(fund.nameUr),
          nameEn: Value(fund.nameEn),
          isRestricted: Value(fund.isRestricted),
          isActive: Value(fund.isActive),
          openingBalancePaisa: Value(fund.openingBalancePaisa),
          isDirty: const Value(true),
        ));
        await _audit.log(
          institutionId: _ctx.institutionId,
          draft: AuditDraft(
            entityType: 'fund',
            entityId: fund.id,
            action: 'fund.updated',
            actorId: _ctx.actorId,
            reason: reason.trim(),
            beforeJson: before == null
                ? null
                : jsonEncode({'opening': before.openingBalancePaisa}),
            afterJson: jsonEncode({'opening': fund.openingBalancePaisa}),
          ),
          now: now,
        );
      });
      return const Ok(null);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  /// Net confirmed receipts for a fund. Reversal contra-entries subtract.
  Future<int> _netReceipts(String fundId, {DateTime? asOf}) async {
    final a = _db.receiptAllocations;
    final r = _db.receipts;
    final q = _db.select(a).join([
      innerJoin(r, r.id.equalsExp(a.receiptId)),
    ])
      ..where(r.institutionId.equals(_ctx.institutionId) &
          r.status.equalsValue(ReceiptStatus.confirmed) &
          a.fundTypeId.equals(fundId));
    if (asOf != null) q.where(r.receiptDate.isSmallerOrEqualValue(asOf));
    var total = 0;
    for (final row in await q.get()) {
      final amount = row.read(a.amountPaisa)!;
      final isReversal = row.read(r.reversesId) != null;
      total += isReversal ? -amount : amount;
    }
    return total;
  }

  Future<int> _pendingReceipts(String fundId) async {
    final a = _db.receiptAllocations;
    final r = _db.receipts;
    final q = _db.select(a).join([
      innerJoin(r, r.id.equalsExp(a.receiptId)),
    ])
      ..where(r.institutionId.equals(_ctx.institutionId) &
          r.status.isInValues(
              [ReceiptStatus.draft, ReceiptStatus.pendingVerification]) &
          a.fundTypeId.equals(fundId));
    var total = 0;
    for (final row in await q.get()) {
      total += row.read(a.amountPaisa)!;
    }
    return total;
  }

  /// Authorized expenses = approved or paid vouchers.
  Future<int> _authorizedExpenses(String fundId, {DateTime? asOf}) async {
    final a = _db.expenseAllocations;
    final v = _db.expenseVouchers;
    final q = _db.select(a).join([
      innerJoin(v, v.id.equalsExp(a.voucherId)),
    ])
      ..where(v.institutionId.equals(_ctx.institutionId) &
          v.status.isInValues([ExpenseStatus.approved, ExpenseStatus.paid]) &
          a.fundTypeId.equals(fundId));
    if (asOf != null) q.where(v.voucherDate.isSmallerOrEqualValue(asOf));
    var total = 0;
    for (final row in await q.get()) {
      total += row.read(a.amountPaisa)!;
    }
    return total;
  }

  @override
  Future<Result<FundBalance>> balance(String fundId, {DateTime? asOf}) async {
    try {
      final row = await (_db.select(_db.fundTypes)
            ..where((t) => t.id.equals(fundId)))
          .getSingleOrNull();
      if (row == null || row.institutionId != _ctx.institutionId) {
        return const Err(DatabaseFailure());
      }
      return Ok(FundBalance(
        fund: Mappers.fund(row),
        openingPaisa: row.openingBalancePaisa,
        confirmedReceiptsPaisa: await _netReceipts(fundId, asOf: asOf),
        approvedAdjustmentsPaisa: 0,
        authorizedExpensesPaisa:
            await _authorizedExpenses(fundId, asOf: asOf),
        pendingPaisa: await _pendingReceipts(fundId),
      ));
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<List<FundBalance>>> allBalances({DateTime? asOf}) async {
    try {
      final list = await funds();
      if (!list.isOk) return Err(list.failure);
      final out = <FundBalance>[];
      for (final f in list.value) {
        final b = await balance(f.id, asOf: asOf);
        if (b.isOk) out.add(b.value);
      }
      return Ok(out);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }
}

class DonorRepositoryImpl implements DonorRepository {
  DonorRepositoryImpl(this._db, this._ctx, this._outbox);
  final db.AppDatabase _db;
  final RepositoryContext _ctx;
  final OutboxWriter _outbox;

  @override
  Future<Result<List<Donor>>> search(String query, {int limit = 20}) async {
    try {
      final q = query.trim();
      final sel = _db.select(_db.donors)
        ..where((t) => t.institutionId.equals(_ctx.institutionId));
      if (q.isNotEmpty) {
        sel.where((t) =>
            t.name.like('%$q%') |
            t.phone.like('%$q%'));
      }
      sel
        ..orderBy([(t) => OrderingTerm.desc(t.updatedAt)])
        ..limit(limit);
      return Ok((await sel.get()).map(Mappers.donor).toList());
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<Donor>> create(Donor donor) async {
    try {
      _ctx.require('receipt.create');
      if (donor.name.trim().isEmpty) {
        return const Err(ValidationFailure('errorRequired'));
      }
      final now = DateTime.now();
      final id = _uuid.v4();
      await _db.transaction(() async {
        await _db.into(_db.donors).insert(
              db.DonorsCompanion.insert(
                id: id,
                institutionId: _ctx.institutionId,
                name: donor.name.trim(),
                phone: Value(donor.phone),
                email: Value(donor.email),
                address: Value(donor.address),
                notes: Value(donor.notes),
                createdBy: Value(_ctx.actorId),
                createdAt: now,
                updatedAt: now,
              ),
            );
        await _outbox.enqueue(
          institutionId: _ctx.institutionId,
          entityType: 'donors',
          entityId: id,
          operation: OutboxOperation.insert,
          payloadJson: jsonEncode({'id': id, 'name': donor.name.trim()}),
          now: now,
        );
      });
      final created = await getById(id);
      if (created.isErr || created.value == null) {
        return const Err<Donor>(DatabaseFailure());
      }
      return Ok(created.value!);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<Donor?>> getById(String id) async {
    try {
      final row = await (_db.select(_db.donors)..where((t) => t.id.equals(id)))
          .getSingleOrNull();
      if (row == null || row.institutionId != _ctx.institutionId) {
        return const Ok(null);
      }
      return Ok(Mappers.donor(row));
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<List<Donor>>> recent({int limit = 20}) => search('', limit: limit);
}

class AccountRepositoryImpl implements AccountRepository {
  AccountRepositoryImpl(this._db, this._ctx);
  final db.AppDatabase _db;
  final RepositoryContext _ctx;

  @override
  Future<Result<List<BankAccount>>> accounts({bool activeOnly = true}) async {
    try {
      final q = _db.select(_db.bankAccounts)
        ..where((t) => t.institutionId.equals(_ctx.institutionId));
      if (activeOnly) q.where((t) => t.isActive.equals(true));
      return Ok((await q.get()).map(Mappers.account).toList());
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<BankAccount>> create(BankAccount account) async {
    try {
      _ctx.require('accounts.manage');
      final id = _uuid.v4();
      await _db.into(_db.bankAccounts).insert(
            db.BankAccountsCompanion.insert(
              id: id,
              institutionId: _ctx.institutionId,
              type: account.type,
              title: account.title.trim(),
              bankName: Value(account.bankName),
              accountNoMasked: Value(account.accountNoMasked),
              openingBalancePaisa: Value(account.openingBalancePaisa),
            ),
          );
      final row = await (_db.select(_db.bankAccounts)..where((t) => t.id.equals(id)))
          .getSingle();
      return Ok(Mappers.account(row));
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<int>> bookBalance(String accountId, {DateTime? asOf}) async {
    try {
      final acct = await (_db.select(_db.bankAccounts)
            ..where((t) => t.id.equals(accountId)))
          .getSingleOrNull();
      if (acct == null || acct.institutionId != _ctx.institutionId) {
        return const Err(DatabaseFailure());
      }
      var balance = acct.openingBalancePaisa;
      // Money in: confirmed receipts (reversals subtract).
      final inQ = _db.select(_db.receipts)
        ..where((t) =>
            t.institutionId.equals(_ctx.institutionId) &
            t.status.equalsValue(ReceiptStatus.confirmed) &
            t.bankAccountId.equals(accountId));
      if (asOf != null) {
        inQ.where((t) => t.receiptDate.isSmallerOrEqualValue(asOf));
      }
      for (final row in await inQ.get()) {
        balance += row.reversesId == null ? row.totalPaisa : -row.totalPaisa;
      }
      // Money out: paid expenses only.
      final outQ = _db.select(_db.expenseVouchers)
        ..where((t) =>
            t.institutionId.equals(_ctx.institutionId) &
            t.status.equalsValue(ExpenseStatus.paid) &
            t.bankAccountId.equals(accountId));
      if (asOf != null) {
        outQ.where((t) => t.voucherDate.isSmallerOrEqualValue(asOf));
      }
      for (final row in await outQ.get()) {
        balance -= row.totalPaisa;
      }
      return Ok(balance);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }
}

class AuditRepositoryImpl implements AuditRepository {
  AuditRepositoryImpl(this._db, this._ctx, this._audit);
  final db.AppDatabase _db;
  final RepositoryContext _ctx;
  final AuditLogger _audit;

  @override
  Future<Result<void>> log(AuditDraft draft) async {
    try {
      _ctx.require('audit.view');
      await _audit.log(institutionId: _ctx.institutionId, draft: draft);
      return const Ok(null);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<List<AuditEvent>>> query({
    String? entityType,
    String? entityId,
    DateTime? from,
    DateTime? to,
    int limit = 200,
  }) async {
    try {
      _ctx.require('audit.view');
      final q = _db.select(_db.auditEvents)
        ..where((t) => t.institutionId.equals(_ctx.institutionId));
      if (entityType != null) q.where((t) => t.entityType.equals(entityType));
      if (entityId != null) q.where((t) => t.entityId.equals(entityId));
      if (from != null) q.where((t) => t.occurredAt.isBiggerOrEqualValue(from));
      if (to != null) q.where((t) => t.occurredAt.isSmallerOrEqualValue(to));
      q
        ..orderBy([(t) => OrderingTerm.desc(t.sequence)])
        ..limit(limit);
      return Ok((await q.get()).map(Mappers.auditEvent).toList());
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<bool>> verifyChain() async {
    try {
      _ctx.require('audit.view');
      return Ok(await _audit.verifyChain(_ctx.institutionId));
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }
}
