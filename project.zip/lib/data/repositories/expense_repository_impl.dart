import 'dart:convert';
import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';
import '../local/app_database.dart' as db;
import '../local/mappers.dart';
import '../sync/audit_logger.dart';
import '../sync/outbox_writer.dart';
import 'receipt_repository_impl.dart' show RepositoryContext;
import '../../domain/auth/permissions.dart';
import '../../domain/entities/entities.dart';
import '../../domain/entities/enums.dart';
import '../../domain/repositories/repositories.dart';
import '../../core/error/failures.dart';

const _uuid = Uuid();

class ExpenseRepositoryImpl implements ExpenseRepository {
  ExpenseRepositoryImpl(this._db, this._ctx, this._outbox, this._audit);
  final db.AppDatabase _db;
  final RepositoryContext _ctx;
  final OutboxWriter _outbox;
  final AuditLogger _audit;

  String _nextVoucherNumber(String prefix) =>
      '$prefix-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}';

  @override
  Future<Result<ExpenseVoucher>> create(ExpenseDraft draft) async {
    try {
      _ctx.require('expense.create');
      if (draft.totalPaisa <= 0) {
        return const Err(ValidationFailure('errorInvalidAmount'));
      }
      var sum = 0;
      for (final a in draft.allocations) {
        if (a.amountPaisa <= 0) return const Err(ValidationFailure('errorInvalidAmount'));
        sum += a.amountPaisa;
        final fund = await (_db.select(_db.fundTypes)
              ..where((t) => t.id.equals(a.fundTypeId)))
            .getSingleOrNull();
        if (fund == null || fund.institutionId != _ctx.institutionId || !fund.isActive) {
          return const Err(ValidationFailure('warnAllocation'));
        }
      }
      if (sum != draft.totalPaisa) {
        return const Err(ValidationFailure('allocationTotalMismatch'));
      }
      if (draft.payee.trim().isEmpty || draft.description.trim().isEmpty) {
        return const Err(ValidationFailure('errorRequired'));
      }

      final now = DateTime.now();
      final id = _uuid.v4();
      final key = _uuid.v4();
      final voucherNumber = _nextVoucherNumber('EXP');
      await _db.transaction(() async {
        await _db.into(_db.expenseVouchers).insert(
              db.ExpenseVouchersCompanion.insert(
                id: id,
                institutionId: _ctx.institutionId,
                voucherNumber: voucherNumber,
                voucherDate: draft.voucherDate,
                payee: draft.payee.trim(),
                description: draft.description.trim(),
                totalPaisa: draft.totalPaisa,
                paymentMethod: draft.paymentMethod,
                bankAccountId: Value(draft.bankAccountId),
                attachmentPath: Value(draft.attachmentPath),
                status: ExpenseStatus.draft,
                createdBy: Value(_ctx.actorId),
                idempotencyKey: key,
                createdAt: now,
                updatedAt: now,
              ),
            );
        for (final a in draft.allocations) {
          await _db.into(_db.expenseAllocations).insert(
                db.ExpenseAllocationsCompanion.insert(
                  id: _uuid.v4(),
                  voucherId: id,
                  fundTypeId: a.fundTypeId,
                  purposeId: Value(a.purposeId),
                  amountPaisa: a.amountPaisa,
                ),
              );
        }
        await _outbox.enqueue(
          institutionId: _ctx.institutionId,
          entityType: 'expense_vouchers',
          entityId: id,
          operation: OutboxOperation.insert,
          payloadJson: jsonEncode({'id': id, 'voucher_number': voucherNumber}),
          idempotencyKey: key,
          now: now,
        );
        await _audit.log(
          institutionId: _ctx.institutionId,
          draft: AuditDraft(
            entityType: 'expense',
            entityId: id,
            action: 'expense.created',
            actorId: _ctx.actorId,
            afterJson: jsonEncode({'total_paisa': draft.totalPaisa}),
          ),
          now: now,
        );
      });
      return _required(id);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<ExpenseVoucher>> approve({
    required String voucherId,
    required String approverId,
    String? note,
  }) async {
    try {
      _ctx.require('expense.approve');
      final row = await _row(voucherId);
      if (row == null) return const Err(DatabaseFailure());
      if (row.status != ExpenseStatus.draft &&
          row.status != ExpenseStatus.pendingApproval) {
        return const Err(ValidationFailure('commonError'));
      }
      if (Permissions.isSelfApproval(approverId, row.createdBy) &&
          await _activeUserCount() > 1) {
        return const Err(ValidationFailure('errorSelfApproval'));
      }
      // Two-person approval above the institution threshold.
      final institution = await (_db.select(_db.institutions)
            ..where((t) => t.id.equals(_ctx.institutionId)))
          .getSingleOrNull();
      final threshold = institution?.dualApprovalThresholdPaisa ?? 10000000;
      final needsSecond =
          row.totalPaisa >= threshold && row.createdBy != approverId;
      if (row.totalPaisa >= threshold && row.createdBy == approverId) {
        return const Err(ValidationFailure('errorSelfApproval'));
      }

      final now = DateTime.now();
      await _db.transaction(() async {
        await (_db.update(_db.expenseVouchers)..where((t) => t.id.equals(voucherId)))
            .write(db.ExpenseVouchersCompanion(
          status: const Value(ExpenseStatus.approved),
          approvedBy: Value(approverId),
          approvedAt: Value(now),
          updatedAt: Value(now),
          isDirty: const Value(true),
        ));
        await _db.into(_db.approvals).insert(
              db.ApprovalsCompanion.insert(
                id: _uuid.v4(),
                institutionId: _ctx.institutionId,
                entityType: 'expense',
                entityId: voucherId,
                action: needsSecond ? 'approve_second' : 'approve',
                decision: ApprovalDecision.approved,
                actorId: approverId,
                decidedAt: now,
                reason: Value(note),
              ),
            );
        await _enqueueUpdate(voucherId, now);
        await _audit.log(
          institutionId: _ctx.institutionId,
          draft: AuditDraft(
            entityType: 'expense',
            entityId: voucherId,
            action: 'expense.approved',
            actorId: approverId,
            reason: note,
            beforeJson: jsonEncode({'status': row.status.name}),
            afterJson: jsonEncode({'status': 'approved'}),
          ),
          now: now,
        );
      });
      return _required(voucherId);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<ExpenseVoucher>> reject({
    required String voucherId,
    required String approverId,
    required String reason,
  }) async {
    try {
      _ctx.require('expense.approve');
      if (reason.trim().isEmpty) return const Err(ValidationFailure('errorRequired'));
      final row = await _row(voucherId);
      if (row == null) return const Err(DatabaseFailure());
      final now = DateTime.now();
      await _db.transaction(() async {
        await (_db.update(_db.expenseVouchers)..where((t) => t.id.equals(voucherId)))
            .write(db.ExpenseVouchersCompanion(
          status: const Value(ExpenseStatus.rejected),
          rejectionReason: Value(reason.trim()),
          updatedAt: Value(now),
          isDirty: const Value(true),
        ));
        await _enqueueUpdate(voucherId, now);
        await _audit.log(
          institutionId: _ctx.institutionId,
          draft: AuditDraft(
            entityType: 'expense',
            entityId: voucherId,
            action: 'expense.rejected',
            actorId: approverId,
            reason: reason.trim(),
          ),
          now: now,
        );
      });
      return _required(voucherId);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<ExpenseVoucher>> markPaid({
    required String voucherId,
    required String actorId,
  }) async {
    try {
      _ctx.require('expense.pay');
      final row = await _row(voucherId);
      if (row == null) return const Err(DatabaseFailure());
      // Never mark paid merely because a voucher was drafted.
      if (row.status != ExpenseStatus.approved) {
        return const Err(ValidationFailure('commonError'));
      }
      final now = DateTime.now();
      await _db.transaction(() async {
        await (_db.update(_db.expenseVouchers)..where((t) => t.id.equals(voucherId)))
            .write(db.ExpenseVouchersCompanion(
          status: const Value(ExpenseStatus.paid),
          updatedAt: Value(now),
          isDirty: const Value(true),
        ));
        await _enqueueUpdate(voucherId, now);
        await _audit.log(
          institutionId: _ctx.institutionId,
          draft: AuditDraft(
            entityType: 'expense',
            entityId: voucherId,
            action: 'expense.paid',
            actorId: actorId,
            beforeJson: jsonEncode({'status': 'approved'}),
            afterJson: jsonEncode({'status': 'paid'}),
          ),
          now: now,
        );
      });
      return _required(voucherId);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  Future<db.ExpenseVoucher?> _row(String id) => (_db.select(_db.expenseVouchers)
        ..where((t) => t.id.equals(id)))
      .getSingleOrNull();

  Future<int> _activeUserCount() async {
    final rows = await (_db.select(_db.userProfiles)
          ..where((t) =>
              t.institutionId.equals(_ctx.institutionId) & t.isActive.equals(true)))
        .get();
    return rows.length;
  }

  Future<void> _enqueueUpdate(String id, DateTime now) => _outbox.enqueue(
        institutionId: _ctx.institutionId,
        entityType: 'expense_vouchers',
        entityId: id,
        operation: OutboxOperation.update,
        payloadJson: jsonEncode({'id': id}),
        now: now,
      );

  Future<List<db.ExpenseAllocation>> _allocs(String voucherId) =>
      (_db.select(_db.expenseAllocations)
            ..where((t) => t.voucherId.equals(voucherId)))
          .get();

  @override
  Future<Result<ExpenseVoucher?>> getById(String id) async {
    try {
      final row = await _row(id);
      if (row == null || row.institutionId != _ctx.institutionId) {
        return const Ok(null);
      }
      return Ok(Mappers.expense(row, await _allocs(id)));
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  @override
  Future<Result<ExpenseVoucher>> _required(String voucherId) async {
    final res = await getById(voucherId);
    if (res.isErr) return Err(res.failure);
    final v = res.value;
    if (v == null) return const Err(DatabaseFailure());
    return Ok(v);
  }

  Future<Result<List<ExpenseVoucher>>> register({
    DateTime? from,
    DateTime? to,
    ExpenseStatus? status,
    int limit = 100,
    int offset = 0,
  }) async {
    try {
      _ctx.require('expense.create');
      final q = _db.select(_db.expenseVouchers)
        ..where((t) => t.institutionId.equals(_ctx.institutionId));
      if (from != null) q.where((t) => t.voucherDate.isBiggerOrEqualValue(from));
      if (to != null) q.where((t) => t.voucherDate.isSmallerOrEqualValue(to));
      if (status != null) q.where((t) => t.status.equalsValue(status));
      q
        ..orderBy([(t) => OrderingTerm.desc(t.voucherDate)])
        ..limit(limit, offset: offset);
      final rows = await q.get();
      final out = <ExpenseVoucher>[];
      for (final r in rows) {
        out.add(Mappers.expense(r, await _allocs(r.id)));
      }
      return Ok(out);
    } on Failure catch (e) {
      return Err(e);
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }
}
