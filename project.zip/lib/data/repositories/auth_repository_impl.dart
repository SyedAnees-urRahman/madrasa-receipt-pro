import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:drift/drift.dart' show Value;
import 'package:local_auth/local_auth.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../local/app_database.dart' as db;
import '../local/mappers.dart';
import '../../core/config/app_config.dart';
import '../../domain/entities/entities.dart';
import '../../domain/entities/enums.dart';
import '../../domain/repositories/repositories.dart';
import '../../core/error/failures.dart';

/// Auth implementation: Supabase Auth when configured, otherwise offline
/// PIN login against the local admin user created during setup.
class AuthRepositoryImpl implements AuthRepository {
  AuthRepositoryImpl(this._db, {SupabaseClient? client})
      : _client = client ?? (AppConfig.isSupabaseConfigured ? Supabase.instance.client : null);
  final db.AppDatabase _db;
  final SupabaseClient? _client;
  final LocalAuthentication _biometrics = LocalAuthentication();

  @override
  Future<Result<UserProfile>> signIn(String email, String password) async {
    // Offline mode: verify PIN against local admin user.
    if (!AppConfig.isSupabaseConfigured || _client == null) {
      return _signInOffline(password);
    }
    try {
      final res = await _client!.auth.signInWithPassword(
        email: email.trim(),
        password: password,
      );
      final user = res.user;
      if (user == null) return const Err(ValidationFailure('loginFailed'));
      final profile = await _profileFor(user.id);
      if (profile == null) return const Err(ValidationFailure('loginFailed'));
      // Mirror into local DB for offline role checks.
      await _db.into(_db.userProfiles).insertOnConflictUpdate(
            db.UserProfilesCompanion.insert(
              id: profile.id,
              institutionId: profile.institutionId,
              displayName: profile.displayName,
              email: profile.email,
              role: profile.role,
              createdAt: DateTime.now(),
            ),
          );
      return Ok(profile);
    } on AuthException {
      return const Err(ValidationFailure('loginFailed'));
    } catch (_) {
      return const Err(NetworkFailure());
    }
  }

  /// Offline login: verify the PIN against the local admin's stored hash.
  /// The password field on the login screen carries the PIN in offline mode.
  /// If setup was completed with an older build that created no admin user,
  /// a default admin (PIN 1234) is created on first login attempt.
  Future<Result<UserProfile>> _signInOffline(String pin) async {
    try {
      var row = await (_db.select(_db.userProfiles)
            ..where((t) => t.id.equals('local-admin'))
            ..where((t) => t.isActive.equals(true))
            ..limit(1))
          .getSingleOrNull();
      if (row == null) {
        // Migration: older setup created no admin user. Create default.
        // Find the institution (there should be exactly one after setup).
        final institutions = await (_db.select(_db.institutions)..limit(1)).get();
        if (institutions.isEmpty) {
          return const Err(ValidationFailure('loginFailed'));
        }
        final institutionId = institutions.first.id;
        final pinHash =
            sha256.convert(utf8.encode('mrp:1234')).toString();
        await _db.into(_db.userProfiles).insert(
              db.UserProfilesCompanion.insert(
                id: 'local-admin',
                institutionId: institutionId,
                displayName: 'ایڈمن',
                email: 'admin@local',
                role: UserRole.admin,
                pinHash: Value(pinHash),
                createdAt: DateTime.now(),
              ),
            );
        row = await (_db.select(_db.userProfiles)
              ..where((t) => t.id.equals('local-admin'))
              ..limit(1))
            .getSingleOrNull();
      }
      if (row == null || row.pinHash == null) {
        return const Err(ValidationFailure('loginFailed'));
      }
      final hash =
          sha256.convert(utf8.encode('mrp:${pin.trim()}')).toString();
      if (hash != row.pinHash) {
        return const Err(ValidationFailure('loginFailed'));
      }
      return Ok(UserProfile(
        id: row.id,
        institutionId: row.institutionId,
        displayName: row.displayName,
        email: row.email,
        role: row.role,
        isActive: row.isActive,
        createdAt: row.createdAt,
      ));
    } catch (_) {
      return const Err(DatabaseFailure());
    }
  }

  Future<UserProfile?> _profileFor(String userId) async {
    final row = await _client!
        .from('user_profiles')
        .select()
        .eq('id', userId)
        .eq('is_active', true)
        .maybeSingle();
    if (row == null) return null;
    return UserProfile(
      id: row['id'] as String,
      institutionId: row['institution_id'] as String,
      displayName: row['display_name'] as String,
      email: row['email'] as String,
      role: UserRole.values.byName(row['role'] as String),
      isActive: true,
      createdAt: DateTime.parse(row['created_at'] as String),
    );
  }

  @override
  Future<Result<void>> signOut() async {
    try {
      await _client!.auth.signOut();
      return const Ok(null);
    } catch (_) {
      return const Err(NetworkFailure());
    }
  }

  @override
  Future<Result<UserProfile?>> currentSession() async {
    try {
      final user = _client!.auth.currentUser;
      if (user == null) return const Ok(null);
      // Prefer the local mirror when offline.
      final local = await (_db.select(_db.userProfiles)
            ..where((t) => t.id.equals(user.id)))
          .getSingleOrNull();
      if (local != null && local.isActive) {
        return Ok(Mappers.userProfile(local));
      }
      final remote = await _profileFor(user.id);
      return Ok(remote);
    } catch (_) {
      return const Ok(null);
    }
  }

  @override
  Future<Result<bool>> biometricAvailable() async {
    try {
      final can = await _biometrics.canCheckBiometrics;
      final enrolled = await _biometrics.getAvailableBiometrics();
      return Ok(can && enrolled.isNotEmpty);
    } catch (_) {
      return const Ok(false);
    }
  }

  @override
  Future<Result<bool>> authenticateBiometric() async {
    try {
      final ok = await _biometrics.authenticate(
        localizedReason: 'Confirm it is you',
        options: const AuthenticationOptions(biometricOnly: true),
      );
      return Ok(ok);
    } catch (_) {
      return const Ok(false);
    }
  }

  @override
  Future<Result<void>> revokeSession() async {
    try {
      await _client!.auth.signOut(scope: SignOutScope.global);
      return const Ok(null);
    } catch (_) {
      return const Err(NetworkFailure());
    }
  }
}
