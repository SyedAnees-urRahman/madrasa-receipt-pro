import 'dart:collection';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core/config/app_config.dart';
import 'core/theme/app_themes.dart';
import 'data/local/app_database.dart' show AppDatabase;
import 'data/local/workspace_store.dart';
import 'data/remote/remote_gateway.dart';
import 'data/remote/supabase_gateway.dart';
import 'data/repositories/auth_repository_impl.dart';
import 'data/repositories/expense_repository_impl.dart';
import 'data/repositories/fund_donor_account_audit_repositories.dart';
import 'data/repositories/institution_repository_impl.dart';
import 'data/repositories/receipt_repository_impl.dart';
import 'data/repositories/report_repository_impl.dart';
import 'data/sync/audit_logger.dart';
import 'data/sync/outbox_writer.dart';
import 'data/sync/sync_engine.dart';
import 'services/backup/backup_service.dart';
import 'domain/entities/entities.dart';
import 'domain/entities/enums.dart';
import 'domain/repositories/repositories.dart';
import 'services/pdf/receipt_pdf_service.dart';
import 'services/security/qr_verification.dart';

// ---------------- infrastructure ----------------

final sharedPrefsProvider =
    Provider<SharedPreferences>((_) => throw UnimplementedError());

final workspaceStoreProvider = Provider<WorkspaceStore>(
    (ref) => WorkspaceStore(ref.watch(sharedPrefsProvider)));

final appDatabaseProvider = Provider<AppDatabase>((ref) {
  final db = AppDatabase();
  ref.onDispose(() => db.close());
  return db;
});

final backupServiceProvider = Provider<BackupService>((ref) =>
    BackupService(
        ref.watch(appDatabaseProvider), ref.watch(workspaceStoreProvider)));

final outboxWriterProvider =
    Provider<OutboxWriter>((ref) => OutboxWriter(ref.watch(appDatabaseProvider)));

final auditLoggerProvider =
    Provider<AuditLogger>((ref) => AuditLogger(ref.watch(appDatabaseProvider)));

/// Offline stub: reports not-online; the engine then skips server work and
/// everything keeps functioning locally.
class _OfflineGateway implements RemoteGateway {
  @override
  Future<bool> get isOnline async => false;
  @override
  Future<DateTime> serverTime() => Future.value(DateTime.now().toUtc());
  @override
  Future<PushResult> pushReceipt(Map<String, dynamic> p) =>
      throw const GatewayException('offline', retryable: true);
  @override
  Future<PushResult> pushReceiptAllocations(String r, List<Map<String, dynamic>> a) =>
      throw const GatewayException('offline', retryable: true);
  @override
  Future<PushResult> pushExpense(Map<String, dynamic> p) =>
      throw const GatewayException('offline', retryable: true);
  @override
  Future<PushResult> pushDonor(Map<String, dynamic> p) =>
      throw const GatewayException('offline', retryable: true);
  @override
  Future<PushResult> pushAuditEvent(Map<String, dynamic> p) =>
      throw const GatewayException('offline', retryable: true);
  @override
  Future<String> issueOfficialNumber(
          {required String institutionId,
          required String receiptId,
          required String idempotencyKey}) =>
      throw const GatewayException('offline', retryable: true);
  @override
  Future<List<Map<String, dynamic>>> pullTable(
          {required String table,
          required String institutionId,
          required DateTime since,
          int limit = 500}) =>
      Future.value(const []);
  @override
  Future<Map<String, DateTime>> pullWatermarks(String institutionId) =>
      Future.value({'server_time': DateTime.now().toUtc()});
}

final remoteGatewayProvider = Provider<RemoteGateway>((ref) {
  if (AppConfig.isSupabaseConfigured) {
    return SupabaseGateway(Supabase.instance.client);
  }
  return _OfflineGateway();
});

class _PrefsMap extends MapBase<String, String> {
  _PrefsMap(this._prefs);
  final SharedPreferences _prefs;
  bool _ours(String k) => k.startsWith('last_sync_') || k.startsWith('wm_');
  @override
  String? operator [](Object? key) =>
      key is String ? _prefs.getString(key) : null;
  @override
  void operator []=(String key, String value) =>
      _prefs.setString(key, value);
  @override
  void clear() {}
  @override
  Iterable<String> get keys => _prefs.getKeys().where(_ours);
  @override
  String? remove(Object? key) {
    if (key is String) _prefs.remove(key);
    return null;
  }
}

final syncStateStoreProvider = Provider<SyncStateStore>(
    (ref) => SyncStateStore(_PrefsMap(ref.watch(sharedPrefsProvider))));

final syncEngineProvider = Provider<SyncEngine>((ref) => SyncEngine(
      database: ref.watch(appDatabaseProvider),
      gateway: ref.watch(remoteGatewayProvider),
      audit: ref.watch(auditLoggerProvider),
      state: ref.watch(syncStateStoreProvider),
    ));

// ---------------- session & context ----------------

final sessionProvider = StateProvider<UserProfile?>((_) => null);

final repositoryContextProvider = Provider<RepositoryContext?>((ref) {
  final session = ref.watch(sessionProvider);
  final institutionId = ref.watch(workspaceStoreProvider).currentInstitutionId;
  if (session == null || institutionId == null) return null;
  return RepositoryContext(
    institutionId: institutionId,
    actorId: session.id,
    actorRole: session.role,
  );
});

RepositoryContext _requireCtx(Ref ref) {
  final ctx = ref.watch(repositoryContextProvider);
  if (ctx == null) throw StateError('No active session/workspace');
  return ctx;
}

// ---------------- repositories ----------------

final institutionRepositoryProvider = Provider<InstitutionRepository>((ref) =>
    InstitutionRepositoryImpl(
      ref.watch(appDatabaseProvider),
      ref.watch(workspaceStoreProvider),
      ref.watch(outboxWriterProvider),
      ref.watch(auditLoggerProvider),
      ctx: ref.watch(repositoryContextProvider),
    ));

final authRepositoryProvider = Provider<AuthRepository>(
    (ref) => AuthRepositoryImpl(ref.watch(appDatabaseProvider)));

final receiptRepositoryProvider = Provider<ReceiptRepository>((ref) =>
    ReceiptRepositoryImpl(
      ref.watch(appDatabaseProvider),
      _requireCtx(ref),
      ref.watch(outboxWriterProvider),
      ref.watch(auditLoggerProvider),
    ));

final expenseRepositoryProvider = Provider<ExpenseRepository>((ref) =>
    ExpenseRepositoryImpl(
      ref.watch(appDatabaseProvider),
      _requireCtx(ref),
      ref.watch(outboxWriterProvider),
      ref.watch(auditLoggerProvider),
    ));

final fundRepositoryProvider = Provider<FundRepository>((ref) =>
    FundRepositoryImpl(
      ref.watch(appDatabaseProvider),
      _requireCtx(ref),
      ref.watch(outboxWriterProvider),
      ref.watch(auditLoggerProvider),
    ));

final donorRepositoryProvider = Provider<DonorRepository>((ref) =>
    DonorRepositoryImpl(
      ref.watch(appDatabaseProvider),
      _requireCtx(ref),
      ref.watch(outboxWriterProvider),
    ));

final accountRepositoryProvider = Provider<AccountRepository>((ref) =>
    AccountRepositoryImpl(
      ref.watch(appDatabaseProvider),
      _requireCtx(ref),
    ));

final auditRepositoryProvider = Provider<AuditRepository>((ref) =>
    AuditRepositoryImpl(
      ref.watch(appDatabaseProvider),
      _requireCtx(ref),
      ref.watch(auditLoggerProvider),
    ));

final reportRepositoryProvider = Provider<ReportRepository>((ref) =>
    ReportRepositoryImpl(
      ref.watch(appDatabaseProvider),
      _requireCtx(ref),
      ref.watch(fundRepositoryProvider) as FundRepositoryImpl,
      ref.watch(receiptRepositoryProvider),
    ));

// ---------------- services ----------------

final receiptPdfServiceProvider =
    Provider<ReceiptPdfService>((_) => ReceiptPdfService());

final qrVerificationProvider =
    Provider<QrVerificationService>((_) => QrVerificationService());

// ---------------- locale ----------------

final localeProvider = StateProvider<Locale>((ref) {
  final code = ref.watch(workspaceStoreProvider).localeCode;
  return Locale(code);
});

// ---------------- theme (Clay / Neumorphic) ----------------

final themeModeProvider = StateProvider<MrpThemeMode>((ref) {
  final name = ref.watch(workspaceStoreProvider).getString('theme_mode');
  return switch (name) {
    'neumorphic' => MrpThemeMode.neumorphic,
    'clay' => MrpThemeMode.clay,
    _ => MrpThemeMode.fintech,
  };
});
