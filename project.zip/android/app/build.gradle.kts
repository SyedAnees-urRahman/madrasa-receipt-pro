plugins {
    id("com.android.application")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.madrasa.madrasa_receipt_pro"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    defaultConfig {
        // TODO: Specify your own unique Application ID (https://developer.android.com/studio/build/application-id.html).
        applicationId = "com.madrasa.madrasa_receipt_pro"
        // You can update the following values to match your application needs.
        // For more information, see: https://flutter.dev/to/review-gradle-config.
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        // Uses the version code from pubspec.yaml. When using split APKs, 1000 * ABI_VERSION
        // is added automatically by Flutter. (https://developer.android.com/studio/build/configure-apk-splits#configure-APK-versions)
        // You can force using the value of versionCode by specifying the `-P force-version-code-ignoring-abi=true`
        // flag during build.
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    buildTypes {
        release {
            // TODO: Add your own signing config for the release build.
            // Signing with the debug keys for now, so `flutter run --release` works.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    // KMP jars (collection, coroutines) ship Kotlin/Native linkdata metadata
    // that collides at packaging time; it is compiler metadata, safe to drop.
    packaging {
        resources {
            excludes += "**/linkdata/**"
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}

flutter {
    source = "../.."
}

// Deduplicate androidx classes. Old -ktx artifacts (activity-ktx:1.5.1,
// collection-ktx:1.1.0) duplicate classes now living in the main artifacts,
// and datastore-core-okio is JVM-only so its datastore-core-jvm twin
// duplicates datastore-core-android. (2026-10-15 offline build)
configurations.all {
    resolutionStrategy {
        force("androidx.activity:activity-ktx:1.9.3")
    }
    exclude(group = "androidx.collection", module = "collection-ktx")
    exclude(group = "androidx.datastore", module = "datastore-core-jvm")
}
