package com.madrasa.madrasa_receipt_pro

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
