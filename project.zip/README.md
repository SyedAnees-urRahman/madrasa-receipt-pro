# Madrasa Receipt Pro

Offline-first donation receipt, fund and expense management for a Pakistani
madrasa. Urdu-first (RTL), English supported. PKR in integer paisa — never
floating point.

## Status (13 Oct 2026)

- App code: complete, `flutter analyze` 0 errors, 47 tests passing.
- APK: release build in progress.
- Server: Supabase SQL/RLS/Edge function written, **not yet deployed** —
  needs your project credentials (see below).

## Quick start (developer)

```bash
# 1. Toolchain
flutter --version   # 3.47.7 stable required

# 2. Dependencies + codegen
flutter pub get
dart run build_runner build --delete-conflicting-outputs

# 3. Configure backend (optional — app works offline without it)
cp .env.example .env
# fill in SUPABASE_URL and SUPABASE_ANON_KEY, then:
flutter run --dart-define-from-file=.env
# or: flutter run --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...

# 4. Tests
flutter test
flutter analyze
```

> The app runs **fully offline** without Supabase configured. Receipts get
> provisional IDs; official numbers are issued on first sync.

## Supabase setup (admin)

1. Create a project at supabase.com, note the URL + `anon` key.
2. In the SQL editor, run in order:
   - `supabase/migrations/0001_schema.sql`
   - `supabase/migrations/0002_rls.sql`
   - `supabase/migrations/0003_numbering.sql`
3. Deploy the edge function: `supabase/functions/issue-receipt-number/`
4. Create the private storage bucket `evidence` (see migration comments).
5. Create the first admin via Auth, then set their `user_profiles` row
   (`role = 'admin'`, `institution_id = ...`) in the SQL editor.
6. Put the URL + **anon** key in `.env`. Never the service-role key.

## First run (on device)

1. Open the app → 12-step setup wizard (institution, funds, accounts,
   signatories, admin PIN/biometric).
2. Without Supabase: a clearly-labeled **demo workspace** is seeded so you
   can try everything offline. Switch workspaces in Settings.
3. With Supabase: sign in; the wizard creates the real workspace.

## Roles

admin · accountant · receiptOperator · paymentVerifier · auditor.
Cash recorder ≠ cash verifier (needs at least 2 users). Auditors are
read-only.

## Docs

- `docs/ARCHITECTURE.md` — architecture, data flow, schema, security model
- `docs/ADMIN_GUIDE.md` — daily operations, backup, recovery
- `docs/LIMITATIONS.md` — honest list of what is NOT done / NOT verified
- `.env.example` — configuration template
